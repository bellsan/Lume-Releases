import io,json,struct,sys,hashlib
from pathlib import Path
import pytest
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'app'))
from frozen_update import validate_pe
from updater import parse_release,Updater

def test_pe(tmp_path):
    data=bytearray(256);data[:2]=b'MZ';struct.pack_into('<I',data,60,64);data[64:68]=b'PE\0\0';struct.pack_into('<H',data,68,0x8664);struct.pack_into('<H',data,88,0x20b)
    p=tmp_path/'sample.exe';p.write_bytes(data);validate_pe(p)
    data[68:70]=b'\x4c\x01';p.write_bytes(data)
    with pytest.raises(ValueError):validate_pe(p)

def test_channel_selection():
    repo='bellsan/Lume-Releases';ver='0.3.49';base=f'https://github.com/{repo}/releases/download/v{ver}/'
    names=[f'LumePro-{ver}.zip',f'LumePro-{ver}-windows-x64.exe'];assets=[{'name':n,'size':1000,'browser_download_url':base+n} for n in names+[n+'.sha256' for n in names]]
    r={'tag_name':'v'+ver,'assets':assets}
    assert parse_release(r,repo)['asset'].endswith('.zip')
    assert parse_release(r,repo,frozen=True)['asset'].endswith('-windows-x64.exe')
    r['assets']=[a for a in assets if not a['name'].endswith('exe.sha256')]
    assert not parse_release(r,repo,frozen=True)['installable']

@pytest.mark.parametrize('corrupt',[False,True])
def test_frozen_download_checks_digest(tmp_path,monkeypatch,corrupt):
    import updater as module
    root=Path(__file__).resolve().parents[1]
    m=Updater(root,tmp_path/'profile');m.frozen=True;m.install_root=tmp_path/'Downloads';m.install_root.mkdir()
    payload=bytearray(256);payload[:2]=b'MZ';struct.pack_into('<I',payload,60,64);payload[64:68]=b'PE\0\0';struct.pack_into('<H',payload,68,0x8664);struct.pack_into('<H',payload,88,0x20b)
    payload=bytes(payload);digest=hashlib.sha256(payload).hexdigest();checksum=(digest+'  LumePro.exe\n').encode()
    release={'version':'0.3.50','asset':'fixture-exe','checksum':'fixture-checksum','size':len(payload),'asset_digest':digest,'checksum_digest':hashlib.sha256(checksum).hexdigest()}
    monkeypatch.setattr(module,'read_bounded',lambda *args:checksum)
    monkeypatch.setattr(module,'open_url',lambda *args:io.BytesIO(payload[:-1]+b'x' if corrupt else payload))
    m._download_worker(release)
    assert list(m.install_root.iterdir())==[]
    if corrupt:assert m.phase=='error' and m.stage is None and not list((m.data/'updates').glob('.lume-update-*'))
    else:
        assert m.phase=='ready' and (m.stage/'LumePro.exe').read_bytes()==payload
        assert m.stage.parent.parent==m.data/'updates'
        m.finish()
        assert not list((m.data/'updates').glob('.lume-update-*'))
        assert list(m.install_root.iterdir())==[]


def test_update_helper_uses_interpreter_modules_and_dotnet_hash():
    from frozen_update import SCRIPT
    assert "[IO.Path]::Combine($PSHOME,'Modules')" in SCRIPT
    assert SCRIPT.index('$env:PSModulePath') < SCRIPT.index('ConvertFrom-Json')
    assert '[Security.Cryptography.SHA256]::Create()' in SCRIPT
    assert 'ComputeHash($stream)' in SCRIPT and '$stream.Dispose()' in SCRIPT
    assert 'Get-FileHash' not in SCRIPT
    assert '(Get-Hash $source) -ne $c.digest' in SCRIPT
    assert '(Get-Hash $backup) -ne $oldDigest' in SCRIPT
    assert '(Get-Hash $target) -ne $c.digest' in SCRIPT


def test_helper_copies_to_same_volume_and_keeps_backup_outside_install():
    from frozen_update import SCRIPT
    assert '[IO.File]::Copy($target,$backup,$false)' in SCRIPT
    assert '[IO.File]::Copy($source,$swap,$false)' in SCRIPT
    assert '[IO.File]::Replace($swap,$target,$localBackup,$true)' in SCRIPT
    assert '$swap = $target +' in SCRIPT
    assert 'Remove-Item -LiteralPath $file' in SCRIPT


def test_helper_launch_uses_short_bootstrap_and_diagnostics():
    import inspect
    from frozen_update import launch_update
    source=inspect.getsource(launch_update)
    assert 'update-helper.ps1' in source
    assert '[ScriptBlock]::Create([IO.File]::ReadAllText($p))' in source
    assert 'creationflags=subprocess.CREATE_NO_WINDOW,' in source
    assert 'DETACHED_PROCESS' not in source
    assert 'proc.returncode' in source and 'log.read_bytes()' in source
