"""Apply endpoint must not shut down when launching the external helper fails."""
import os, subprocess, sys, textwrap
from pathlib import Path

def test_apply_handoff(tmp_path):
    root=Path(__file__).resolve().parents[1]
    code=r'''
import json, threading, urllib.request, urllib.error
from pathlib import Path
from unittest.mock import patch
import server, frozen_update
u=server.updater; u.frozen=True; u.phase='ready'; u.stage=Path('fixture')
http=server.LocalServer(('127.0.0.1',0),server.Handler)
t=threading.Thread(target=http.serve_forever,daemon=True);t.start()
base=f'http://127.0.0.1:{http.server_address[1]}'
def request():
    req=urllib.request.Request(base+'/api/update/apply',data=b'{}',headers={'Content-Type':'application/json','X-Lume-Token':server.SECRET})
    try:
        with urllib.request.urlopen(req,timeout=4) as r:return r.status,json.loads(r.read())
    except urllib.error.HTTPError as e:return e.code,json.loads(e.read())
try:
    with patch.object(frozen_update,'launch_update',side_effect=RuntimeError('helper missing')):
        status,body=request(); assert status==400 and 'helper missing' in body['error']; assert not u.pending and u.phase=='ready' and t.is_alive()
    def launch(u,port):
        assert t.is_alive() and u.pending and u.phase=='applying' and port==http.server_address[1]
    with patch.object(frozen_update,'launch_update',side_effect=launch) as called:
        assert request()==(200,{'ok':True});called.assert_called_once()
        t.join(4);assert not t.is_alive()
finally:
    if t.is_alive():http.shutdown()
    http.server_close()
'''
    env=dict(os.environ,LOCALAPPDATA=str(tmp_path),PYTHONPATH=str(root/'app'))
    subprocess.run([sys.executable,'-c',code],env=env,cwd=tmp_path,check=True,timeout=20)
