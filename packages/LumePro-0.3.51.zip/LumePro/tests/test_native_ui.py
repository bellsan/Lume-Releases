from pathlib import Path
import sys
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'app'))
import native_ui

def test_native_spawn_does_not_open_edge():
    with patch('native_ui.subprocess.Popen') as spawn:
        native_ui.spawn(12345)
        assert spawn.call_args.args[0]==[sys.executable,'--native-ui','--port','12345']
    src=(ROOT/'app/server.py').read_text()
    assert 'msedge.exe' not in src and 'from native_ui import spawn' in src

def test_quit_and_context_menu_are_application_specific():
    src=(ROOT/'app/app.js').read_text()
    assert 'window.close()' not in src
    assert "document.addEventListener('contextmenu',e=>e.preventDefault())" in src
    assert "row.addEventListener('contextmenu'" in src
    assert "await savePreferences({editor:editorSnapshot(),live:isLive,hook:isHook});const result=await post('/api/shutdown'" in src

def test_update_reopens_only_visible_native_ui():
    from frozen_update import SCRIPT
    assert "if (-not $c.show_ui) { $launchArgs += '--no-browser' }" in SCRIPT
    assert native_ui.marker_path(ROOT,12345).name=='native-ui-12345.json'


def test_native_window_never_reauthenticates_to_replacement_server():
    src=(ROOT/'app/native_ui.py').read_text()
    assert "api(port,'/api/native_ready',token=token)" in src
    assert 'exc.code in (401,403)' in src
    assert src.count("token=api(port,'/api/token')['token']")==1
    assert "api(port,'/api/editor_closed',{},token)" in src
