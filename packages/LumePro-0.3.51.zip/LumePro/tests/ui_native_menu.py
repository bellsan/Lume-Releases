import asyncio,os
from pathlib import Path
from playwright.async_api import async_playwright
from ui_preset_menu import setup
ROOT=Path(__file__).resolve().parents[1]
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path=os.environ.get('CHROMIUM_PATH','/usr/bin/chromium'),args=['--no-sandbox'])
  page,errors=await setup(browser,{f:(ROOT/'app'/f).read_text() for f in ('index.html','style.css','app.js')})
  assert await page.evaluate("!document.body.dispatchEvent(new MouseEvent('contextmenu',{bubbles:true,cancelable:true}))")
  await page.locator('.layer-item.active').click(button='right')
  assert await page.locator('#layerMenu.open').is_visible()
  await page.keyboard.press('Escape')
  assert await page.evaluate("!document.body.dispatchEvent(new KeyboardEvent('keydown',{key:'F12',bubbles:true,cancelable:true}))")
  # Intercept only the existing app API helper; confirm quit doesn't call window.close.
  await page.evaluate('window.closeCalls=0;window.close=()=>closeCalls++;window.confirm=()=>true;window.quitCalls=[];window.post=async (p,b)=>{quitCalls.push(p);return {ok:true}}')
  await page.locator('[data-view=settings]').click();await page.wait_for_timeout(350)
  await page.locator('#quitBtn').click();await page.wait_for_timeout(250)
  assert await page.evaluate('closeCalls===0 && quitCalls.includes("/api/preferences") && quitCalls.includes("/api/shutdown")')
  assert not errors,errors
  await browser.close();print('PASS contextmenu suppression, layer menu, quit sequence, no browser close')
if __name__=='__main__':asyncio.run(main())
