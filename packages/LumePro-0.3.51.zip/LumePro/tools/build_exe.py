"""Build LumePro.exe on Windows x64 using the installed build environment."""
import json, os, platform, subprocess, sys
from pathlib import Path

root=Path(__file__).resolve().parents[1]
if sys.platform!='win32' or platform.machine().lower() not in ('amd64','x86_64'):
    raise SystemExit('Windows x64 Python required')
os.chdir(root)
meta=json.loads((root/'app/version.json').read_text())
version=meta['version']; v=tuple(map(int,version.split('.')))+(0,)
resource=root/'version_info.txt'
resource.write_text(f'''VSVersionInfo(ffi=FixedFileInfo(filevers={v},prodvers={v},mask=0x3f,flags=0,OS=0x40004,fileType=1,subtype=0,date=(0,0)),kids=[StringFileInfo([StringTable('040904B0',[StringStruct('FileDescription','LUME / PRO'),StringStruct('FileVersion','{version}'),StringStruct('InternalName','LumePro'),StringStruct('OriginalFilename','LumePro.exe'),StringStruct('ProductName','LUME / PRO'),StringStruct('ProductVersion','{version}')])]),VarFileInfo([VarStruct('Translation',[1033,1200])])])''',encoding='utf-8')
args=[sys.executable,'-m','PyInstaller','--noconfirm','--clean','--onefile','--windowed','--noupx','--name','LumePro','--icon','app/lume-app-icon.ico','--version-file',str(resource),'--paths','app']
for asset in ('index.html','app.js','style.css','version.json','lume-app-icon.ico','lume-app-icon.png','keyboard_geometry.json'):
    args+=['--add-data',f'app/{asset};app']
for module in ('soundcard','pyaudiowpatch','openrgb','websocket','webview'):
    args+=['--collect-all',module]
args+=['--hidden-import','pystray._win32','--hidden-import','hid','app/exe_entry.py']
subprocess.run(args,check=True)
exe=root/'dist/LumePro.exe'
if not exe.is_file():raise SystemExit('Missing executable')
print(exe,exe.stat().st_size)
