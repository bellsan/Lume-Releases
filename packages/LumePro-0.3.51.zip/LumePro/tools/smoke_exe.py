"""Windows CI: test the frozen executable, recovery and real file replacement in a temporary profile."""
import base64, hashlib, json, os, shutil, socket, subprocess, sys, tempfile, time, urllib.request
from pathlib import Path
exe=Path(sys.argv[1]).resolve();version=sys.argv[2]
root=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root/'app'))
from frozen_update import launch_update,validate_pe
from types import SimpleNamespace
from unittest.mock import patch

def port_number():
    with socket.socket() as s:s.bind(('127.0.0.1',0));return s.getsockname()[1]

def request(port,path,token=None,data=None):
    h={'X-Lume-Token':token} if token else {'X-Lume-Bootstrap':'1'}
    b=None if data is None else json.dumps(data).encode('utf-8')
    if b is not None:h['Content-Type']='application/json'
    with urllib.request.urlopen(urllib.request.Request(f'http://127.0.0.1:{port}{path}',data=b,headers=h),timeout=3) as r:return r.read()

def get(port,path,token=None,data=None):return json.loads(request(port,path,token,data))
def wait_for(predicate,seconds=90):
    end=time.monotonic()+seconds
    while time.monotonic()<end:
        try:
            result=predicate()
            if result:return result
        except (OSError,ValueError,KeyError):pass
        time.sleep(.4)
    raise RuntimeError('Startup/recovery timeout')

def kill_tree(pid):
    subprocess.run(['taskkill','/PID',str(pid),'/T','/F'],capture_output=True,timeout=15)

def session(data):return json.loads((data/'desktop_session.json').read_text('utf-8'))

def cleanup(proc,data):
    if proc.poll() is None:kill_tree(proc.pid)
    try:
        pid=session(data)['pid'];kill_tree(pid)
    except (OSError,ValueError,KeyError):pass
    try:proc.wait(timeout=15)
    except subprocess.TimeoutExpired:proc.kill();proc.wait()

with tempfile.TemporaryDirectory(prefix='lume-smoke-') as temp:
    data=Path(temp)/'LumePro';env=dict(os.environ,LOCALAPPDATA=temp)
    subprocess.run([str(exe),'--self-test'],env=env,check=True,timeout=120)
    port=port_number();proc=subprocess.Popen([str(exe),'--no-browser','--port',str(port)],env=env)
    try:
        wait_for(lambda:get(port,'/api/update/status')['current']==version)
        assert b'LUME / PRO' in request(port,'/')
        assert request(port,'/favicon.ico')[:4]==b'\0\0\1\0'
        assert len(request(port,'/app.js'))>10000
        token=get(port,'/api/token')['token']
        assert get(port,'/api/update/status',token)['frozen'] is True
        status=get(port,'/api/status',token)['desktop'];assert status['supported'] and not status['startup'] and status['recovery']
        assert 'presets' in get(port,'/api/presets',token)
        # Exercise settings and authentication without registering startup on this runner.
        assert get(port,'/api/desktop',token,{'recovery':True})['ok']
        assert get(port,'/api/preferences',token,{'auto':False})['ok']
        initial=session(data)['pid']
        duplicate=subprocess.run([str(exe),'--no-browser'],env=env,timeout=60)
        assert duplicate.returncode==0 and session(data)['pid']==initial
        # Simulated unexpected failure of this isolated test worker only.
        kill_tree(initial)
        wait_for(lambda:session(data)['pid']!=initial and get(port,'/api/update/status')['current']==version)
        new_token=get(port,'/api/token')['token'];assert new_token!=token
        assert get(port,'/api/preferences',new_token)['preferences']['auto'] is False
        assert get(port,'/api/shutdown',new_token,{})['ok']
        assert proc.wait(timeout=45)==0
    finally:cleanup(proc,data)
print('Windows EXE startup, resources, settings, duplicate launch, crash recovery and clean shutdown passed')

# Exercise the replacement helper with the previous published EXE when provided.
# The published artifact is never modified.
old_exe=Path(sys.argv[3]).resolve() if len(sys.argv)>3 else exe
old_version=sys.argv[4] if len(sys.argv)>4 else version
old_digest=hashlib.sha256(old_exe.read_bytes()).hexdigest()
if len(sys.argv)>3:assert old_digest!=hashlib.sha256(exe.read_bytes()).hexdigest()
with tempfile.TemporaryDirectory(prefix='lume-swap-') as temp:
    work=Path(temp);data=work/'profile'/'LumePro';data.mkdir(parents=True);install=work/'Downloads';install.mkdir()
    (data/'preferences.json').write_text(json.dumps({'auto':False,'tray':False,'recovery':False}),'utf-8')
    env=dict(os.environ,LOCALAPPDATA=str(data.parent));target=install/'LumePro.exe';shutil.copy2(old_exe,target)
    stage=data/'updates'/'.lume-update-test'/'stage';stage.mkdir(parents=True);candidate=stage/'LumePro.exe';shutil.copy2(exe,candidate)
    digest=hashlib.sha256(candidate.read_bytes()).hexdigest();validate_pe(candidate)
    port=port_number();backup=data/'updates'/'backups'/'LumePro.previous-test.exe';marker=data/'exe_update_error.txt'
    proc=subprocess.Popen([str(target),'--no-browser','--port',str(port)],env=env)
    ps=None
    try:
        wait_for(lambda:get(port,'/api/update/status')['current']==old_version)
        token=get(port,'/api/token')['token']
        (stage/'sha256.txt').write_text(digest,'ascii')
        updater=SimpleNamespace(pending=True,stage=stage,data=data,release={'version':version},cache={},_save=lambda:None)
        # Exercise the real launch function (including handshake), with an isolated installation and profile.
        with patch.object(sys,'executable',str(target)),patch.object(sys,'frozen',True,create=True),patch.dict(os.environ,dict(LOCALAPPDATA=str(data.parent),PSModulePath=str(work/'missing-modules'))):
            ps=launch_update(updater,port)
        assert get(port,'/api/shutdown',token,{})['ok'];assert proc.wait(timeout=45)==0
        ps.wait(timeout=240)
        assert ps.returncode==0, ((data/'updates'/'last-helper.log').read_text(errors='replace'), (marker.read_text('utf-8') if marker.exists() else ''), list(install.iterdir()))
        assert backup.is_file() and hashlib.sha256(backup.read_bytes()).hexdigest()==old_digest
        assert not stage.parent.exists() and hashlib.sha256(target.read_bytes()).hexdigest()==digest
        assert list(install.iterdir())==[target], list(install.iterdir())
        assert not marker.exists(),marker.read_text('utf-8') if marker.exists() else ''
        wait_for(lambda:get(port,'/api/update/status')['current']==version)
        new_token=get(port,'/api/token')['token'];assert new_token!=token
        assert get(port,'/api/preferences',new_token)['preferences']['auto'] is False
        assert get(port,'/api/shutdown',new_token,{})['ok']
        wait_for(lambda:not (data/'desktop_session.json').exists(),30)
        # Wait for the supervisor/bootloader to release the executable.
        def unlocked():
            try:target.rename(install/'verified.exe');return True
            except OSError:return False
        wait_for(unlocked,30)
    finally:
        if ps is not None and ps.poll() is None:ps.kill();ps.wait()
        cleanup(proc,data)
        # Kill only leftover processes belonging to this isolated test copy.
        subprocess.run(['powershell.exe','-NoProfile','-NonInteractive','-Command',
                        "Get-Process -Name LumePro -ErrorAction SilentlyContinue | Where-Object { $_.Path -eq $env:LUME_TEST_EXE } | Stop-Process -Force -ErrorAction SilentlyContinue"],env=dict(env,LUME_TEST_EXE=str(target)),capture_output=True,timeout=15)
print('Windows replacement helper: locked EXE -> backup -> restart -> health check -> settings retained passed')

with tempfile.TemporaryDirectory(prefix='lume-native-') as temp:
    import ctypes
    from ctypes import wintypes
    data=Path(temp)/'LumePro';data.mkdir()
    (data/'preferences.json').write_text(json.dumps({'auto':False,'tray':False,'recovery':False}),'utf-8')
    env=dict(os.environ,LOCALAPPDATA=temp);port=port_number()
    proc=subprocess.Popen([str(exe),'--port',str(port)],env=env)
    marker=data/f'native-ui-{port}.json'
    try:
        wait_for(lambda:get(port,'/api/update/status')['current']==version)
        try: info=wait_for(lambda:json.loads(marker.read_text('utf-8')),120)
        except RuntimeError:
            for n in ('startup_error.txt','native-ui-error.txt'):
                if (data/n).exists(): print(n,(data/n).read_text(errors='replace'))
            raise
        assert info['icon'] and info['renderer']!='mshtml', info
        token=get(port,'/api/token')['token']
        wait_for(lambda:get(port,'/api/native_ready',token)['ready'],45)
        user=ctypes.windll.user32
        user.GetWindowThreadProcessId.argtypes=(wintypes.HWND,ctypes.POINTER(wintypes.DWORD))
        pid=wintypes.DWORD();user.GetWindowThreadProcessId(info['hwnd'],ctypes.byref(pid))
        assert pid.value==info['pid'],info
        user.SendMessageW.argtypes=(wintypes.HWND,wintypes.UINT,wintypes.WPARAM,wintypes.LPARAM)
        user.SendMessageW.restype=ctypes.c_ssize_t
        assert user.SendMessageW(info['hwnd'],0x7f,1,0), 'Missing application window icon'
        token=get(port,'/api/token')['token']
        assert get(port,'/api/shutdown',token,{})['ok']
        assert proc.wait(timeout=45)==0
        wait_for(lambda:not marker.exists(),30)
    finally:
        if marker.exists():
            try:kill_tree(json.loads(marker.read_text('utf-8'))['pid'])
            except (OSError,ValueError,KeyError):pass
        cleanup(proc,data)
print('Windows native WebView window, app icon, page rendering and shutdown passed')
