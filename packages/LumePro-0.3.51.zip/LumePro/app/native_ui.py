"""Dedicated Windows WebView2 window. Never opens the user's Edge profile."""
import ctypes
from ctypes import wintypes
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import threading
import time
import urllib.request
import urllib.error

TITLE='LUME / PRO'
APP_ID='bellsan.LumePro.Desktop'


def marker_path(data,port):
    return Path(data)/f'native-ui-{int(port)}.json'


def api(port,path,data=None,token=None):
    if not 1<=int(port)<=65535:raise ValueError('Invalid local port')
    headers={'X-Lume-Token':token} if token else {'X-Lume-Bootstrap':'1'}
    payload=None
    if data is not None:
        headers['Content-Type']='application/json';payload=json.dumps(data).encode('utf-8')
    # Bypass proxy configuration, never follow redirects from the local server.
    class NoRedirect(urllib.request.HTTPRedirectHandler):
        def redirect_request(self,*args,**kwargs):return None
    opener=urllib.request.build_opener(urllib.request.ProxyHandler({}),NoRedirect())
    with opener.open(urllib.request.Request(f'http://127.0.0.1:{port}{path}',data=payload,headers=headers),timeout=2) as r:
        return json.loads(r.read(128000))


def spawn(port):
    # Same EXE, independent PyInstaller extraction. Do not change parent DLL search paths.
    env={k:v for k,v in os.environ.items() if not k.startswith('_PYI_')}
    env['PYINSTALLER_RESET_ENVIRONMENT']='1'
    return subprocess.Popen([sys.executable,'--native-ui','--port',str(int(port))],cwd=str(Path(sys.executable).parent),env=env,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))


def set_app_id():
    ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(APP_ID)


def own_window():
    user=ctypes.windll.user32
    user.GetWindowThreadProcessId.argtypes=(wintypes.HWND,ctypes.POINTER(wintypes.DWORD))
    user.GetWindowTextW.argtypes=(wintypes.HWND,wintypes.LPWSTR,ctypes.c_int)
    found=[]
    cbtype=ctypes.WINFUNCTYPE(wintypes.BOOL,wintypes.HWND,wintypes.LPARAM)
    @cbtype
    def visit(hwnd,_):
        pid=wintypes.DWORD();user.GetWindowThreadProcessId(hwnd,ctypes.byref(pid))
        if pid.value==os.getpid():
            name=ctypes.create_unicode_buffer(256);user.GetWindowTextW(hwnd,name,256)
            if name.value==TITLE:found.append(int(hwnd));return False
        return True
    user.EnumWindows(visit,0)
    return found[0] if found else None


def apply_icon(hwnd,path):
    user=ctypes.windll.user32
    user.LoadImageW.argtypes=(wintypes.HINSTANCE,wintypes.LPCWSTR,wintypes.UINT,ctypes.c_int,ctypes.c_int,wintypes.UINT)
    user.LoadImageW.restype=wintypes.HANDLE
    user.SendMessageW.argtypes=(wintypes.HWND,wintypes.UINT,wintypes.WPARAM,wintypes.LPARAM)
    user.SendMessageW.restype=ctypes.c_ssize_t
    handles=[]
    for kind,size in ((0,16),(1,32)):
        h=user.LoadImageW(None,str(path),1,size,size,0x10)
        if h:user.SendMessageW(hwnd,0x80,kind,h);handles.append(h)
    return len(handles)==2


def activate(data,port):
    try:
        p=json.loads(marker_path(data,port).read_text('utf-8'))
        hwnd=int(p['hwnd']);pid=wintypes.DWORD();u=ctypes.windll.user32
        u.GetWindowThreadProcessId.argtypes=(wintypes.HWND,ctypes.POINTER(wintypes.DWORD))
        u.GetWindowTextW.argtypes=(wintypes.HWND,wintypes.LPWSTR,ctypes.c_int)
        u.ShowWindow.argtypes=(wintypes.HWND,ctypes.c_int)
        u.SetForegroundWindow.argtypes=(wintypes.HWND,)
        u.GetWindowThreadProcessId(hwnd,ctypes.byref(pid))
        if pid.value!=p['pid']:return False
        buf=ctypes.create_unicode_buffer(256);u.GetWindowTextW(hwnd,buf,256)
        if buf.value!=TITLE:return False
        u.ShowWindow(hwnd,9);u.SetForegroundWindow(hwnd);return True
    except (OSError,ValueError,KeyError,TypeError):return False


def run(port,data,root):
    if sys.platform!='win32':raise RuntimeError('Windows required')
    import webview
    port=int(port);data=Path(data);root=Path(root)
    if not 1<=port<=65535:raise ValueError('Invalid port')
    # Check the exact local Lume instance before opening a renderer.
    api(port,'/api/update/status')
    token=api(port,'/api/token')['token']
    kernel=ctypes.WinDLL('kernel32',use_last_error=True)
    kernel.CreateMutexW.argtypes=(ctypes.c_void_p,wintypes.BOOL,wintypes.LPCWSTR)
    kernel.CreateMutexW.restype=wintypes.HANDLE
    kernel.CloseHandle.argtypes=(wintypes.HANDLE,)
    name='Local\\LumeProUI-'+hashlib.sha256(str(data.resolve()).casefold().encode()).hexdigest()[:24]+'-'+str(port)
    ctypes.set_last_error(0);handle=kernel.CreateMutexW(None,False,name)
    if not handle:raise OSError(ctypes.get_last_error(),'UI mutex failed')
    duplicate=ctypes.get_last_error()==183
    if duplicate:
        try:
            for _ in range(20):
                if activate(data,port):break
                time.sleep(.15)
        finally:kernel.CloseHandle(handle)
        return
    stop=threading.Event();server_gone=threading.Event();marker=marker_path(data,port)
    marker.unlink(missing_ok=True)
    try:
        set_app_id()
        # No custom Python API is exposed to the renderer; disable external link opening.
        webview.settings['ALLOW_DOWNLOADS']=True
        webview.settings['OPEN_EXTERNAL_LINKS_IN_BROWSER']=False
        window=webview.create_window(TITLE,f'http://127.0.0.1:{port}/?desktop=1',width=1260,height=800,min_size=(760,520),background_color='#16191b',text_select=True)
        def loaded():
            if marker.is_file():return
            hwnd=own_window()
            if hwnd:
                ok=apply_icon(hwnd,root/'lume-app-icon.ico')
                renderer=getattr(getattr(webview,'guilib',None),'renderer','unknown')
                tmp=marker.with_suffix('.tmp');tmp.write_text(json.dumps({'pid':os.getpid(),'port':port,'hwnd':hwnd,'icon':ok,'renderer':str(renderer)}),encoding='utf-8');tmp.replace(marker)
        window.events.loaded+=loaded
        window.events.closed+=lambda:stop.set()
        def monitor():
            failures=0
            while not stop.wait(.8):
                try:
                    # The original token identifies the server this window belongs to.
                    # A restarted server on the same port must never keep a stale UI alive.
                    api(port,'/api/native_ready',token=token);failures=0
                except urllib.error.HTTPError as exc:
                    failures=4 if exc.code in (401,403) else failures+1
                except (OSError,ValueError):failures+=1
                if failures>=4:
                    server_gone.set()
                    try:window.destroy()
                    except Exception:pass
                    return
        # Force the Edge WebView2 engine, not the user's browser process.
        webview.start(monitor,gui='edgechromium',debug=False,private_mode=False,storage_path=str(data/'webview2'))
    finally:
        stop.set()
        try:marker.unlink(missing_ok=True)
        except OSError:pass
        kernel.CloseHandle(handle)
        if not server_gone.is_set():
            try:
                # Use the original token; never shut down a replacement server.
                api(port,'/api/editor_closed',{},token)
                status=api(port,'/api/status',token=token)['desktop']
                if not status['tray'] or not status['resident']:api(port,'/api/shutdown',{},token)
            except (OSError,ValueError,KeyError):pass
