"""Frozen Windows executable update. The old EXE remains recoverable until replacement succeeds."""
from __future__ import annotations
import base64
import ctypes
import hashlib
import json
import os
from pathlib import Path
import re
import struct
import subprocess
import sys
import time


def validate_pe(path):
    """Reject non-PE and non-x64 executables before staging."""
    with Path(path).open('rb') as f:
        head=f.read(64)
        if len(head)!=64 or head[:2]!=b'MZ':raise ValueError('Invalid Windows executable')
        off=struct.unpack_from('<I',head,60)[0]
        if not 64<=off<=1024*1024:raise ValueError('Invalid PE header')
        f.seek(off);pe=f.read(26)
        if len(pe)!=26 or pe[:4]!=b'PE\0\0' or struct.unpack_from('<H',pe,4)[0]!=0x8664 or struct.unpack_from('<H',pe,24)[0]!=0x20b:
            raise ValueError('Expected Windows x64 executable')


def external_environment():
    env=dict(os.environ)
    # PyInstaller changes the DLL lookup path; avoid leaking it to Edge/PowerShell.
    if sys.platform=='win32' and getattr(sys,'frozen',False):
        ctypes.windll.kernel32.SetDllDirectoryW(None)
        env['PYINSTALLER_RESET_ENVIRONMENT']='1'
        for key in tuple(env):
            if key.startswith('_PYI_'):env.pop(key,None)
    return env


def restart_current(port):
    return subprocess.Popen([sys.executable,'--port',str(int(port)),'--no-browser'],cwd=str(Path(sys.executable).parent),env=external_environment(),creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))


# No untrusted text is interpolated as script code: configuration is base64 JSON.
SCRIPT=r'''
$ErrorActionPreference = 'Stop'
# A PowerShell 7 caller can pass incompatible module paths to Windows PowerShell.
# Use only modules shipped with the actual interpreter (no third-party autoload).
$env:PSModulePath = [IO.Path]::Combine($PSHOME,'Modules')
$c = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('__CONFIG__')) | ConvertFrom-Json
$target = [string]$c.target
$source = [string]$c.source
$backup = [string]$c.backup
$marker = [string]$c.marker
$child = $null
$oldDigest = $null
$failed = $false
$keepStage = $false
$swapped = $false
$replaceAttempted = $false
# File.Replace requires a same-volume source; the download/backup can be on C:
# while the installed EXE is on D:. Use temporary FILES, never a folder beside it.
$suffix = [Guid]::NewGuid().ToString('N')
$swap = $target + '.lume-swap-' + $suffix + '.tmp'
$localBackup = $target + '.lume-old-' + $suffix + '.tmp'
$rejected = $target + '.lume-rejected-' + $suffix + '.tmp' 
function Get-Hash([string]$p) {
    $sha = [Security.Cryptography.SHA256]::Create()
    $stream = $null
    try {
        $stream = [IO.File]::Open($p,[IO.FileMode]::Open,[IO.FileAccess]::Read,[IO.FileShare]::Read)
        return [BitConverter]::ToString($sha.ComputeHash($stream)).Replace('-','').ToLowerInvariant()
    } finally {
        if ($stream) { $stream.Dispose() }
        $sha.Dispose()
    }
}
function Wait-ForExit([int]$seconds) {
    $name = [IO.Path]::GetFileNameWithoutExtension($target)
    $until = [DateTime]::UtcNow.AddSeconds($seconds)
    do {
        $active = @(Get-Process -Name $name -ErrorAction SilentlyContinue | Where-Object { $_.Path -eq $target })
        if ($active.Count -eq 0) { return }
        Start-Sleep -Milliseconds 300
    } while ([DateTime]::UtcNow -lt $until)
    throw 'Previous executable is still running; no replacement performed'
}
function Start-Lume {
    $env:PYINSTALLER_RESET_ENVIRONMENT = '1'
    $launchArgs = @('--port',[string]$c.port)
    if (-not $c.show_ui) { $launchArgs += '--no-browser' }
    Start-Process -FilePath $target -ArgumentList $launchArgs -WorkingDirectory ([IO.Path]::GetDirectoryName($target)) -PassThru
}
try {
    if ($c.ready) { [IO.File]::WriteAllText([string]$c.ready,'ready') }
    # Wait for the worker AND the onefile bootloader/supervisor to exit.
    Wait-ForExit 60
    $oldDigest = Get-Hash $target
    if ((Get-Hash $source) -ne $c.digest) { throw 'Staged SHA-256 mismatch' }
    if ([IO.File]::Exists($backup)) { throw 'Backup path already exists' }
    [IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($backup)) | Out-Null
    [IO.File]::Copy($target,$backup,$false)
    if ((Get-Hash $backup) -ne $oldDigest) { throw 'Backup SHA-256 mismatch' }
    [IO.File]::Copy($source,$swap,$false)
    if ((Get-Hash $swap) -ne $c.digest) { throw 'Temporary executable SHA-256 mismatch' }
    $until = [DateTime]::UtcNow.AddSeconds(30)
    $replaceAttempted = $true
    while (-not $swapped) {
        try { [IO.File]::Replace($swap,$target,$localBackup,$true); $swapped = $true }
        catch [IO.IOException] { if ([IO.File]::Exists($localBackup) -or [DateTime]::UtcNow -ge $until) { throw }; Start-Sleep -Milliseconds 300 }
        catch [UnauthorizedAccessException] { if ([IO.File]::Exists($localBackup) -or [DateTime]::UtcNow -ge $until) { throw }; Start-Sleep -Milliseconds 300 }
    }
    if ((Get-Hash $backup) -ne $oldDigest) { throw 'Backup SHA-256 mismatch' }
    if ((Get-Hash $target) -ne $c.digest) { throw 'Installed executable SHA-256 mismatch' }
    # The new process must report the nonce from this launch, not stale status.
    $nonce = [Guid]::NewGuid().ToString('N')
    $env:LUMEPRO_UPDATE_HEALTH = $nonce
    $child = Start-Lume
    $healthy = $false
    $until = [DateTime]::UtcNow.AddSeconds(90)
    $last = 'no response'
    while ([DateTime]::UtcNow -lt $until) {
        try {
            $status = Invoke-RestMethod -UseBasicParsing -Uri ('http://127.0.0.1:' + $c.port + '/api/update/status') -TimeoutSec 2
            if ($status.current -eq $c.version -and $status.update_health -eq $nonce) { $healthy = $true; break }
            $last = 'unexpected version or startup identity'
        } catch { $last = $_.Exception.Message }
        Start-Sleep -Milliseconds 350
    }
    if (-not $healthy) { throw ('Updated executable failed startup validation: ' + $last) }
    Remove-Item -LiteralPath $marker -Force -ErrorAction SilentlyContinue
} catch {
    $failed = $true
    $failure = $_.Exception.Message
    Remove-Item Env:LUMEPRO_UPDATE_HEALTH -ErrorAction SilentlyContinue
    try {
        if ($child -and -not $child.HasExited) { & "$env:SystemRoot\System32\taskkill.exe" /PID $child.Id /T /F | Out-Null }
        if ($swapped -or ($replaceAttempted -and $oldDigest -and [IO.File]::Exists($localBackup))) {
            Wait-ForExit 45
            if (-not [IO.File]::Exists($backup) -or (Get-Hash $backup) -ne $oldDigest) { throw 'Verified old backup unavailable' }
            # Keep the verified backup even when restoring it.
            $restore = $swap + '.restore'
            [IO.File]::Copy($backup,$restore,$false)
            if ([IO.File]::Exists($target)) { [IO.File]::Replace($restore,$target,$rejected,$true) }
            else { [IO.File]::Move($restore,$target) }
            if ((Get-Hash $target) -ne $oldDigest) { throw 'Restored SHA-256 mismatch' }
        }
        [IO.File]::WriteAllText($marker,$failure,[Text.UTF8Encoding]::new($false))
        # Never start an unverified replacement or launch a duplicate old process.
        if ($oldDigest -and [IO.File]::Exists($target) -and (Get-Hash $target) -eq $oldDigest) { $null = Start-Lume }
    } catch {
        $keepStage = $true
        $failure += '; recovery: ' + $_.Exception.Message
        [IO.File]::WriteAllText($marker,$failure,[Text.UTF8Encoding]::new($false))
    }
    [Console]::Error.WriteLine($failure)
} finally {
    Remove-Item Env:LUMEPRO_UPDATE_HEALTH -ErrorAction SilentlyContinue
    # Only clean files owned by this transaction. Keep recovery copies in AppData.
    if (-not $keepStage) {
        foreach ($file in @($swap,$localBackup,$rejected,($swap + '.restore'))) {
            Remove-Item -LiteralPath $file -Force -ErrorAction SilentlyContinue
        }
        Remove-Item -LiteralPath ([string]$c.work) -Recurse -Force -ErrorAction SilentlyContinue
    }
}
if ($failed) { exit 1 }
exit 0
'''


def launch_update(updater,port):
    if sys.platform!='win32' or not getattr(sys,'frozen',False) or not updater.pending:raise RuntimeError('Not a frozen Windows update')
    target=Path(sys.executable).resolve();stage=Path(updater.stage).resolve();candidate=stage/'LumePro.exe'
    if stage.parent.parent!=(updater.data/'updates').resolve() or not stage.parent.name.startswith('.lume-update-') or stage.name!='stage':raise ValueError('Invalid update staging directory')
    digest=(stage/'sha256.txt').read_text('ascii').strip()
    if not re.fullmatch('[0-9a-f]{64}',digest):raise ValueError('Invalid digest')
    validate_pe(candidate)
    with candidate.open('rb') as f:
        h=hashlib.sha256()
        for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
    if h.hexdigest()!=digest:raise ValueError('Staged executable SHA-256 mismatch')
    backup=updater.data/'updates'/'backups'/('LumePro.previous-'+stage.parent.name.rsplit('-',1)[-1]+'.exe')
    ready=stage.parent/'helper-ready.txt'
    ready.unlink(missing_ok=True)
    config=dict(target=str(target),source=str(candidate),backup=str(backup),marker=str(updater.data/'exe_update_error.txt'),work=str(stage.parent),port=int(port),digest=digest,version=updater.release['version'],ready=str(ready),show_ui=(updater.data/f'native-ui-{int(port)}.json').is_file())
    script=SCRIPT.replace('__CONFIG__',base64.b64encode(json.dumps(config).encode('utf-8')).decode('ascii'))
    ps=Path(os.environ.get('SystemRoot',r'C:\Windows'))/'System32'/'WindowsPowerShell'/'v1.0'/'powershell.exe'
    updater.cache.pop('install_error',None);updater._save()
    # A spawned process is not necessarily a running helper (policy, parse error, DLL loading).
    # Wait for its acknowledgement before the server is allowed to shut down.
    log=updater.data/'updates'/'last-helper.log'
    # Keep the encoded command short; read the full helper from its private staging directory.
    script_file=stage.parent/'update-helper.ps1'
    script_file.write_text(script,encoding='utf-8')
    payload=base64.b64encode(str(script_file).encode('utf-8')).decode('ascii')
    bootstrap=("$ErrorActionPreference='Stop'; try { $p=[Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('"+payload+"')); & ([ScriptBlock]::Create([IO.File]::ReadAllText($p))); exit 0 } catch { [Console]::Error.WriteLine($_.ToString()); exit 1 }")
    with log.open('wb') as out:
        proc=subprocess.Popen([str(ps),'-NoProfile','-NonInteractive','-EncodedCommand',base64.b64encode(bootstrap.encode('utf-16le')).decode('ascii')],cwd=str(target.parent),env=external_environment(),creationflags=subprocess.CREATE_NO_WINDOW,stdin=subprocess.DEVNULL,stdout=out,stderr=subprocess.STDOUT)
    deadline=time.monotonic()+25
    while time.monotonic()<deadline:
        if proc.poll() is not None:break
        if ready.is_file():return proc
        time.sleep(.1)
    if proc.poll() is None:
        proc.terminate();proc.wait(timeout=5)
    # Include the actual startup error in CI and the UI instead of only a generic timeout.
    raw=log.read_bytes()[-4096:]
    detail=raw.decode('utf-16le' if raw.startswith(b'\xff\xfe') else 'utf-8',errors='replace').strip()
    raise RuntimeError(f'更新プログラムの起動確認に失敗しました (終了コード {proc.returncode})。{detail[-1000:] or "応答なし"}。LocalAppData/LumePro/updates/last-helper.log')
