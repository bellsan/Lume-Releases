"""Opt-in public GitHub Releases updater. No credentials, telemetry or background install."""
from __future__ import annotations
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import stat
import subprocess
import sys
import tempfile
import threading
import time
import urllib.error
import urllib.request
from urllib.parse import urlsplit
import zipfile

AUTO_INTERVAL = 6 * 60 * 60
MANUAL_INTERVAL = 30
MAX_ZIP = 64 * 1024 * 1024
MAX_EXE = 160 * 1024 * 1024
MAX_EXPANDED = 128 * 1024 * 1024
VERSION_FILE = 'app/version.json'
ROOT_FILES = {'start_windows.bat','launch_windows.ps1','install_music_backend.bat',
              'install_hid_backend.bat','install_openrgb_backend.bat','diagnose_windows.bat',
              'requirements_optional.txt','requirements_build_windows.txt','README_JA.md','CHANGELOG.md','RELEASE_NOTES_JA.md',
              'DESIGN_RESEARCH_JA.md','LGHUB_ANALYSIS_JA.md','RESEARCH_STATUS_JA.md',
              'GITHUB_RELEASE_JA.md'}


def version_tuple(value):
    m = re.fullmatch(r'v?(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)', str(value))
    if not m or len(str(value)) > 32:
        raise ValueError('バージョン形式が不正です')
    return tuple(map(int, m.groups()))


def read_metadata(root):
    data = json.loads((Path(root)/VERSION_FILE).read_text('utf-8'))
    version_tuple(data['version'])
    if not re.fullmatch(r'[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+', data['repository']):
        raise ValueError('リポジトリ名が不正です')
    return data


def allowed_download(url, repo, tag, asset):
    u = urlsplit(url)
    return (u.scheme == 'https' and u.netloc.lower() == 'github.com' and not u.query and not u.fragment
            and u.path[:len(repo)+1].lower() == ('/'+repo).lower()
            and u.path[len(repo)+1:] == f'/releases/download/{tag}/{asset}')


def parse_release(obj, repo, private=False, frozen=False):
    if obj.get('draft') or obj.get('prerelease'):
        raise ValueError('正式版ではありません')
    tag = obj.get('tag_name','')
    version_tuple(tag)
    ver = tag.removeprefix('v')
    name = f'LumePro-{ver}-windows-x64.exe' if frozen else f'LumePro-{ver}.zip'
    assets = {a.get('name'):a for a in obj.get('assets',[]) if isinstance(a,dict)}
    result = {'version':ver,'tag':tag,'title':str(obj.get('name') or tag)[:160],
              'notes':str(obj.get('body') or '更新内容は登録されていません。')[:20000],
              'published':str(obj.get('published_at',''))[:40],
              'page':f'https://github.com/{repo}/releases/tag/{tag}'}
    if name not in assets or name+'.sha256' not in assets:
        result['installable'] = False
        return result
    archive, checksum = assets[name], assets[name+'.sha256']
    # GitHub-provided asset digest is an additional consistency check, not an independent signature.
    for entry,field in ((archive,'asset_digest'),(checksum,'checksum_digest')):
        value=entry.get('digest')
        if value is not None:
            if not isinstance(value,str) or not re.fullmatch(r'sha256:[0-9a-fA-F]{64}',value):raise ValueError('GitHubのダイジェスト形式が不正です')
            result[field]=value[7:].lower()
    size = archive.get('size')
    if type(size) is not int or not 0<size<=(MAX_EXE if frozen else MAX_ZIP) or not 0<checksum.get('size',0)<=4096:
        raise ValueError('更新ファイルのサイズが不正です')
    for a in (archive,checksum):
        if not allowed_download(a.get('browser_download_url',''),repo,tag,a['name']):
            raise ValueError('更新ファイルの配布先が不正です')
    if private:
        if any(type(a.get('id')) is not int or a['id'] <= 0 for a in (archive, checksum)):
            raise ValueError('非公開更新のアセットIDが不正です')
        base=f'https://api.github.com/repos/{repo}/releases/assets/'
        return dict(result,installable=True,asset=base+str(archive['id']),checksum=base+str(checksum['id']),size=size)
    return dict(result,installable=True,asset=archive['browser_download_url'],checksum=checksum['browser_download_url'],size=size)


class ReleaseRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        u=urlsplit(newurl)
        if u.scheme!='https' or u.netloc.lower() not in ('github.com','release-assets.githubusercontent.com','objects.githubusercontent.com','github-releases.githubusercontent.com','api.github.com'):
            raise ValueError('許可されていないダウンロード先です')
        redirect=super().redirect_request(req,fp,code,msg,headers,newurl)
        # Never forward a GitHub credential to an asset CDN or another host.
        if redirect is not None:
            for key in list(redirect.headers):
                if key.lower()=='authorization':redirect.remove_header(key)
            for key in list(redirect.unredirected_hdrs):
                if key.lower()=='authorization':redirect.remove_header(key)
        return redirect


def open_url(url, headers=None):
    req=urllib.request.Request(url,headers={'User-Agent':'LumePro-Updater/2','Accept':'application/vnd.github+json',**(headers or {})})
    if any(k.lower()=='authorization' for k in req.headers) and urlsplit(url).netloc.lower()!='api.github.com':
        raise ValueError('認証情報の送信先が不正です')
    return urllib.request.build_opener(ReleaseRedirect()).open(req,timeout=10)


def read_bounded(url, maximum, headers=None):
    with open_url(url,headers) as r:
        data=r.read(maximum+1)
        if len(data)>maximum:raise ValueError('応答サイズが上限を超えています')
        return data


def github_token():
    """Use the user's local GitHub CLI login or an explicitly supplied environment token.
    Never store credentials in Lume preferences, update metadata, or logs.
    """
    token=os.environ.get('LUMEPRO_GITHUB_TOKEN','').strip()
    if not token:
        gh=shutil.which('gh')
        if not gh:
            raise ValueError('非公開更新にはGitHub CLIが必要です。login_updates.batで初期設定してください。')
        try:
            flags=subprocess.CREATE_NO_WINDOW if sys.platform=='win32' else 0
            proc=subprocess.run([gh,'auth','token','--hostname','github.com'],capture_output=True,text=True,timeout=10,creationflags=flags)
            if proc.returncode==0:token=proc.stdout.strip()
        except (OSError,subprocess.TimeoutExpired):pass
    if not token or not re.fullmatch(r'[A-Za-z0-9_\-]{10,512}',token):
        raise ValueError('GitHub認証が必要です。login_updates.batでログインしてから再確認してください。')
    return token


def safe_extract(archive, dest, expected_version, repo):
    """Only install application files. Reject traversal, links, duplicates and expansion abuse."""
    dest=Path(dest)
    with zipfile.ZipFile(archive) as z:
        infos=z.infolist()
        if len(infos)>2000 or sum(i.file_size for i in infos)>MAX_EXPANDED:
            raise ValueError('更新ZIPの展開サイズが不正です')
        names=set()
        for i in infos:
            p=PurePosixPath(i.filename)
            if '\\' in i.filename or ':' in i.filename or p.is_absolute() or '..' in p.parts or not p.parts:
                raise ValueError('更新ZIPに不正なパスがあります')
            parts=p.parts[1:] if p.parts[0]=='LumePro' else p.parts
            if stat.S_ISLNK(i.external_attr >> 16):raise ValueError('更新ZIPにリンクが含まれています')
            if not parts or i.is_dir():continue
            if any(x.endswith(('.', ' ')) or x in ('.','..') or x.split('.')[0].upper() in ('CON','PRN','AUX','NUL',*(f'COM{n}' for n in range(1,10)),*(f'LPT{n}' for n in range(1,10))) for x in parts):
                raise ValueError('更新ZIPにWindowsで使用できない名前があります')
            if parts[0]!='app' and not (len(parts)==1 and parts[0] in ROOT_FILES):continue
            if parts[0]=='app' and (len(parts)<2 or any(x.startswith('.') or x=='__pycache__' for x in parts[1:])):continue
            name='/'.join(parts).casefold()
            if name in names:raise ValueError('更新ZIPに重複ファイルがあります')
            names.add(name)
            out=dest.joinpath(*parts);out.parent.mkdir(parents=True,exist_ok=True)
            with z.open(i) as f, out.open('xb') as dst:shutil.copyfileobj(f,dst)
    for rel in ('app/server.py','app/index.html','app/app.js','app/style.css','app/updater.py',VERSION_FILE,'start_windows.bat','launch_windows.ps1'):
        if not (dest/rel).is_file():raise ValueError('更新ZIPに必要なファイルがありません: '+rel)
    meta=read_metadata(dest)
    if meta['version']!=expected_version or meta['repository'].lower()!=repo.lower():
        raise ValueError('更新ZIPのバージョンまたは配布元が一致しません')


def install_staged(root, stage):
    """Swap app directory after the server is closed; restore all replaced files on failure."""
    root,stage=Path(root),Path(stage)
    backup=Path(tempfile.mkdtemp(prefix='.lume-backup-',dir=root))
    moved=[]
    try:
        for name in ['app',*sorted(ROOT_FILES)]:
            src=stage/name
            if not src.exists():continue
            dst=root/name;old=backup/name
            had=dst.exists()
            if had:os.replace(dst,old)
            moved.append((dst,old,had,False))
            os.replace(src,dst)
            moved[-1]=(dst,old,had,True)
    except Exception:
        for dst,old,had,new in reversed(moved):
            if new:
                if dst.is_dir():shutil.rmtree(dst)
                else:dst.unlink()
            if had:os.replace(old,dst)
        shutil.rmtree(backup,ignore_errors=True)
        raise
    return backup


class Updater:
    def __init__(self, root, data):
        self.root=Path(root);self.data=Path(data);self.frozen=bool(getattr(sys,'frozen',False));self.cachefile=self.data/'update_state.json'
        self.install_root=Path(sys.executable).resolve().parent if self.frozen else self.root
        meta=read_metadata(self.root);self.version=meta['version'];self.repo=meta['repository'];self.private=meta.get('private') is True
        self.lock=threading.RLock();self.stage=None;self.pending=False;self.phase='idle';self.error='';self.progress=0;self.last_manual=0
        try:self.cache=json.loads(self.cachefile.read_text('utf-8'))
        except (OSError,ValueError):self.cache={}
        if not isinstance(self.cache,dict):self.cache={}
        elif self.cache.get('repo')!=self.repo or bool(self.cache.get('private'))!=self.private or bool(self.cache.get('frozen'))!=self.frozen:
            # Keep user's opt-out when the update channel changes; discard old release and notification metadata.
            self.cache={'auto': self.cache.get('auto',True) is not False}
        self.cache['repo']=self.repo;self.cache['private']=self.private;self.cache['frozen']=self.frozen
        if self.frozen:
            marker=self.data/'exe_update_error.txt'
            try:
                self.cache['install_error']=marker.read_text('utf-8-sig')[:300];marker.unlink();self._save()
            except OSError:pass
        if isinstance(self.cache.get('check_error'),str) and self.cache['check_error']:
            self.phase='error';self.error=self.cache['check_error'][:300]
        for key in ('last_attempt','last_check'):
            if type(self.cache.get(key)) not in (int,float) or not 0<=self.cache[key]<=time.time()+60:self.cache[key]=0
        self.release=None
        # Cache only trusted metadata obtained from our fixed repository.
        try:
            r=self.cache.get('release');self.release=parse_release(r,self.repo,self.private,self.frozen) if r else None
        except (TypeError,ValueError,AttributeError):self.release=None

    def _save(self):
        self.data.mkdir(parents=True,exist_ok=True)
        tmp=self.cachefile.with_suffix('.tmp');tmp.write_text(json.dumps(self.cache,ensure_ascii=False),'utf-8');os.replace(tmp,self.cachefile)

    def status(self):
        with self.lock:
            newer=bool(self.release and version_tuple(self.release['version'])>version_tuple(self.version))
            return {'current':self.version,'repository':self.repo,'private':self.private,'frozen':self.frozen,'phase':self.phase,'error':self.error,
                    'progress':self.progress,'available':newer,'release':{k:v for k,v in self.release.items() if k not in ('asset','checksum')} if newer else None,
                    'notify':newer and self.cache.get('notified')!=self.release['version'],
                    'auto':self.cache.get('auto',True) is not False,'last_check':self.cache.get('last_check',0),
                    'last_install_error':self.cache.get('install_error','')}

    def configure(self,auto):
        with self.lock:self.cache['auto']=bool(auto);self._save();return self.status()

    def acknowledge(self,version):
        with self.lock:
            if self.release and version==self.release['version']:
                self.cache['notified']=version;self._save()
            return self.status()

    def check(self,manual=False):
        with self.lock:
            if self.phase in ('checking','downloading','ready','applying'):return self.status()
            now=time.time()
            if manual:
                if self.phase!='error' and now-self.last_manual<MANUAL_INTERVAL:return self.status()
                self.last_manual=now
            elif self.cache.get('auto',True) is False or now-float(self.cache.get('last_attempt',0))<AUTO_INTERVAL:
                return self.status()
            self.cache['last_attempt']=now;self._save();self.phase='checking';self.error=''
            threading.Thread(target=self._check_worker,daemon=True).start()
            return self.status()

    def _headers(self, binary=False):
        h={'Accept':'application/octet-stream' if binary else 'application/vnd.github+json'}
        if self.private:h['Authorization']='Bearer '+github_token()
        return h

    def _check_worker(self):
        try:
            raw=json.loads(read_bounded(f'https://api.github.com/repos/{self.repo}/releases/latest',256*1024,self._headers()))
            release=parse_release(raw,self.repo,self.private,self.frozen)
            with self.lock:
                self.release=release;self.cache['release']=raw;self.cache['last_check']=time.time();self.cache.pop('check_error',None);self._save();self.phase='idle'
        except urllib.error.HTTPError as e:
            with self.lock:
                self.phase='error';self.release=None;self.cache.pop('release',None)
                if e.code==404:self.error='更新が未配布か、GitHubのリポジトリ閲覧権限がありません。' if self.private else '公開リリースがまだ配布されていません。'
                elif e.code in (401,403,429):self.error='GitHub認証・アクセス権限またはAPI制限を確認してください。' if self.private else 'GitHubのアクセス制限に達した可能性があります。時間をおいて再確認してください。ログインは不要です。'
                else:self.error=f'GitHubとの通信エラー ({e.code})'
                self.cache['check_error']=self.error
                try:self._save()
                except OSError:pass
        except Exception as e:
            with self.lock:
                self.phase='error';self.release=None;self.error=str(e)[:300];self.cache.pop('release',None);self.cache['check_error']=self.error
                try:self._save()
                except OSError:pass

    def download(self):
        with self.lock:
            if self.phase in ('checking','downloading','ready','applying'):return self.status()
            if not self.status()['available'] or not self.release.get('installable'):raise ValueError('インストール可能な更新がありません')
            self.phase='downloading';self.error='';self.progress=0
            threading.Thread(target=self._download_worker,args=(dict(self.release),),daemon=True).start();return self.status()

    def _download_worker(self,release):
        work=None
        try:
            # Frozen archives and recovery files belong to the user profile, not Downloads.
            staging_root=self.data/'updates' if self.frozen else self.install_root
            staging_root.mkdir(parents=True,exist_ok=True)
            work=Path(tempfile.mkdtemp(prefix='.lume-update-',dir=staging_root))
            headers=self._headers(binary=True)
            checksum_bytes=read_bounded(release['checksum'],4096,headers)
            if release.get('checksum_digest') and hashlib.sha256(checksum_bytes).hexdigest()!=release['checksum_digest']:raise ValueError('チェックサムファイルのSHA-256が一致しません')
            checksum=checksum_bytes.decode('ascii').split()
            expected=checksum[0].lower() if checksum else ''
            if not re.fullmatch(r'[0-9a-f]{64}',expected):raise ValueError('SHA-256が不正です')
            if release.get('asset_digest') and release['asset_digest']!=expected:raise ValueError('GitHubのSHA-256とチェックサムが一致しません')
            total=0;digest=hashlib.sha256();archive=work/('LumePro.exe' if self.frozen else 'release.zip');deadline=time.monotonic()+180
            with open_url(release['asset'],headers) as resp,archive.open('wb') as f:
                while True:
                    if time.monotonic()>deadline:raise TimeoutError('更新ファイルの取得がタイムアウトしました')
                    block=resp.read(65536)
                    if not block:break
                    total+=len(block)
                    if total>release['size'] or total>(MAX_EXE if self.frozen else MAX_ZIP):raise ValueError('ダウンロードサイズが一致しません')
                    digest.update(block);f.write(block)
                    with self.lock:self.progress=min(95,int(total/release['size']*95))
            if total!=release['size'] or digest.hexdigest()!=expected:raise ValueError('更新ファイルのSHA-256またはサイズが一致しません')
            stage=work/'stage';stage.mkdir()
            if self.frozen:
                from frozen_update import validate_pe
                validate_pe(archive)
                os.replace(archive,stage/'LumePro.exe')
                (stage/'sha256.txt').write_text(expected,'ascii')
            else:
                safe_extract(archive,stage,release['version'],self.repo);archive.unlink()
            with self.lock:self.stage=stage;self.phase='ready';self.progress=100
        except Exception as e:
            if work:shutil.rmtree(work,ignore_errors=True)
            with self.lock:self.phase='error';self.error=str(e)[:300]

    def request_apply(self):
        with self.lock:
            if self.phase!='ready' or self.stage is None:raise ValueError('更新ファイルの準備ができていません')
            self.pending=True;self.phase='applying'

    def finish(self):
        if self.stage is None:return False
        stage=self.stage
        if not self.pending:shutil.rmtree(stage.parent,ignore_errors=True);return False
        if self.frozen:raise RuntimeError('EXE updates require the external replacement helper')
        try:
            install_staged(self.root,stage)
            self.cache.pop('install_error',None)
            try:self._save()
            except OSError:pass
            return True
        except Exception as e:
            self.cache['install_error']=str(e)[:300]
            try:self._save()
            except OSError:pass
            return False
        finally:shutil.rmtree(stage.parent,ignore_errors=True)
