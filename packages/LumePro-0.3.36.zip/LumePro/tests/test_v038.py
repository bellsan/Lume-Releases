from engine import render,validate
from fn_hid import FnHidMonitor,FnLearner,vendor_collections
from preferences import Preferences
from test_v033 import backend

def scene(**kwargs):
 return dict(keys=[{'code':'KeyA','x':1,'y':1},{'code':'Fn','x':2,'y':1}],layers=[{'type':'static','color':'#0000ff','brightness':100},{'type':'ripple','color':'#ff0000','brightness':100,'blend':'add'}],keyColors={'Fn':'#0000ff'},**kwargs)

def test_ripple_foreground_and_individual_color_base():
 s=scene();assert render(validate(s),[],0)=={'KeyA':'#0000ff','Fn':'#0000ff'}
 assert render(validate(s),[(1,1,0)],0)['KeyA']=='#ff0000'
 assert render(validate(s),[(2,1,0)],0)['Fn']=='#ff0000'
 s['layers'][1]['color']='#00ff00'
 assert render(validate(s),[(2,1,0)],0)['Fn']=='#00ff00'
 assert render(validate(dict(s,fixedColorMode='fixed')),[(2,1,0)],0)['Fn']=='#0000ff'
 assert render(validate(dict(s,reactivePriority=False)),[(1,1,0)],0)['KeyA']=='#0000ff'

def test_multiple_special_signatures_and_no_duplicates():
 m=FnHidMonitor(lambda c:None);m.active=True
 for code,sig in [('Fn',b'fn'),('GameMode',b'game'),('LightButton',b'light')]:
  assert m.learn(code);m.learner.phase='verify';m.learner.signature=sig;m.learner.matches=1
  assert m.enable()
 assert m.status()['learned']==['Fn','GameMode','LightButton']
 assert m.learn('Fn');m.learner.phase='verify';m.learner.signature=b'game';m.learner.matches=1
 assert not m.enable();assert m.learned['Fn']==b'fn'
 assert not m.learn('KeyA')

def test_keep_bracket_setting_and_new_preferences(tmp_path):
 p=Preferences(tmp_path/'prefs.json');p.update({'bracket_method':'hid64','fn_method':'keyname'})
 p.update({'editor':{'layout':'jis','layers':[{'type':'ripple','color':'#ff0000'}],'fixedColorMode':'reactive','reactivePriority':False}})
 assert p.load()['bracket_method']=='hid64';assert p.load()['editor']['reactivePriority'] is False


def test_fn_auto_is_independent_and_preserves_bracket():
 b=backend()
 try:
  assert b.set_key_method('Backslash','hid64')
  assert b.set_method('scan')
  assert b._set_key('Fn',(100,0,0)) and b.sdk.calls[-1]==('hid',0xe6,100,0,0)
  assert b._set_key('Backslash',(0,100,0)) and b.sdk.calls[-1]==('hid',0x64,0,100,0)
  b.sdk.reject.add(('hid',0xe6));assert b._set_key('Fn',(0,0,100)) and b.sdk.calls[-1]==('scan',0x138,0,0,100)
 finally:b.close()
