"""Optional browser UI test with mocked OpenRGB and keyboard hook.
Run: python tests/ui_smoke.py (requires playwright and Chromium)."""
import asyncio,json,os
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parents[1]/'app'
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(headless=True,executable_path=os.environ.get('CHROMIUM_PATH','/usr/bin/chromium'),args=['--no-sandbox'])
  page=await browser.new_page(viewport={'width':1260,'height':800})
  page.set_default_timeout(5000)
  errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  await page.set_content((ROOT/'index.html').read_text().replace('<link rel="stylesheet" href="/style.css">','').replace('<script src="/app.js" defer></script>',''))
  await page.add_style_tag(content=(ROOT/'style.css').read_text())
  await page.evaluate('''window.calls=[];window.live=false;window.hook=false;window.active=false;window.confirm=()=>true;window.fetch=async(url,opts)=>{const u=String(url),b=opts?.body?JSON.parse(opts.body):{};calls.push({u,b});let data={ok:true};const hw={connected:true,active:window.active,device:window.active?0:null,devices:[{id:0,name:'PRO Gaming Keyboard',keyboard:true,leds:88}],backend:'logitech',bitmap_available:true,bitmap_mapping:window.testBitmap||{},matched:87,sent:0,led_map:[],missing_jis:['IntlYen'],error:''};if(u.includes('/api/token'))data={token:'test'};else if(u==='/api/preferences'&&!opts)data={preferences:{auto:true,backend:'logitech',hook:true,live:true,editor:null}};else if(u==='/api/auto_connect'){window.active=true;data={ok:true,hardware:{...hw,active:true,device:0}}}else if(u.includes('/api/status'))data={hardware:hw,engine:{active:live,pulses:0},keyhook:{enabled:hook}};else if(u.includes('/api/presets'))data={presets:[]};else if(u.includes('/api/keys'))data={seq:0,events:[]};else if(u.includes('/api/keyhook')){hook=b.enabled;data={ok:true,enabled:hook}}else if(u.includes('/api/live')){live=b.enabled;data={ok:true,engine:{active:live,pulses:0}}}else if(u.includes('/api/scene'))data={ok:true};else if(u.includes('/api/led_test')){live=false;data={ok:true,hardware:hw}}else if(u==='/api/coverage_test'){live=false;data={ok:true,hardware:hw}}else if(u==='/api/bitmap_test'){live=false;data={ok:true,hardware:hw}}else if(u==='/api/bitmap_config'){window.testBitmap=b.mapping;data={ok:true,hardware:{...hw,bitmap_mapping:b.mapping}}}else if(u==='/api/fn_hid'){data={ok:true,devices:[{index:0,name:'PRO Gaming Keyboard',pid:'C339',usage:'FF00:0001'}],status:{phase:'off',active:false}}};return {ok:true,json:async()=>data}}''')
  await page.evaluate('''()=>{const values=new Map();Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem:k=>values.get(k)??null,setItem:(k,v)=>values.set(k,String(v)),removeItem:k=>values.delete(k)}})}''')
  await page.add_script_tag(content=(ROOT/'app.js').read_text())
  await page.wait_for_timeout(450)
  assert await page.locator('.inspector').is_visible()
  assert await page.locator('.editor-grid').evaluate("e=>e.classList.contains('has-inspector')")
  board=page.locator('#keyboardFrame'); pane=page.locator('.inspector')
  async def separated():
   b=await board.bounding_box(); q=await pane.bounding_box(); assert b['x']+b['width']<=q['x']+1,(b,q)
  await separated()
  # Layer commands operate on the selected layer and support history.
  await page.locator('#layerDuplicateQuick').click(); assert await page.locator('.layer-item').count()==3
  await page.locator('#layerDownQuick').click(); assert await page.evaluate('state.layers[1].id===state.selectedLayer')
  await page.locator('#layerRemoveQuick').click(); assert await page.locator('.layer-item').count()==2
  await page.locator('.layer-item').first.click()
  # Select two physical keys in one gesture; one history entry, no extra input pulse.
  await page.locator('[data-preview-mode=target]').click()
  a=await page.locator('#keyboard [data-code=KeyA]').bounding_box(); d=await page.locator('#keyboard [data-code=KeyD]').bounding_box()
  await page.mouse.move(a['x']+a['width']/2,a['y']+a['height']/2); await page.mouse.down(); await page.mouse.move(d['x']+d['width']/2,d['y']+d['height']/2,steps=15); await page.mouse.up()
  await page.wait_for_timeout(250)
  assert await page.evaluate("currentLayer().targets.includes('KeyA')&&currentLayer().targets.includes('KeyD')")
  assert await page.evaluate("calls.filter(x=>x.u==='/api/scene').at(-1).b.layers.some(l=>l.targets.includes('KeyA'))")
  await page.locator('#undoBtn').click(); assert await page.evaluate("!(currentLayer().targets||[]).length")
  await page.locator('#redoBtn').click(); assert await page.evaluate("currentLayer().targets.includes('KeyD')")
  await page.locator('#resetTargetQuick').click(); await page.locator('[data-preview-mode=normal]').click()
  # Numeric value entry; keeps same slider and hardware payload.
  await page.locator('[data-inspector-tab=basic]').click(); await page.locator('#brightnessValue').click(); await page.locator('#brightnessValue input').fill('67'); await page.locator('#brightnessValue input').press('Enter'); assert await page.evaluate("currentLayer().brightness===67")
  # Add orbit and test actual origin and direction parameters.
  await page.locator('#newLayerBtn').click(); await page.locator('#effectSearch').fill('オービット'); await page.locator('[data-effect=orbit]').click()
  await page.locator('[data-preview-mode=origin]').click(); g=await page.locator('#keyboard').bounding_box()
  await page.mouse.click(g['x']+g['width']*.23,g['y']+g['height']*.65)
  assert await page.evaluate("currentLayer().originX<35 && currentLayer().originY>50")
  await page.locator('[data-preview-mode=angle]').click(); await page.mouse.click(g['x']+g['width']*.15,g['y']+g['height']*.23)
  assert await page.evaluate("currentLayer().angle<0&&currentLayer().angle>=-180")
  await page.wait_for_timeout(200)
  assert await page.evaluate("calls.filter(x=>x.u==='/api/scene').at(-1).b.layers.some(l=>l.type==='orbit'&&l.angle<0&&l.originX<35)")
  await page.locator('[data-inspector-tab=motion]').click(); await page.screenshot(path=str(ROOT.parent/'GUI_workspace_1260.png'))
  await page.locator('[data-preview-mode=normal]').click(); await page.set_viewport_size({'width':900,'height':600}); await page.wait_for_timeout(350); await separated()
  assert await page.locator('#showLayersBtn').is_visible(); assert not await page.locator('.layer-panel').is_visible(); await page.screenshot(path=str(ROOT.parent/'GUI_workspace_900.png'))
  await page.locator('#showLayersBtn').click(); assert await page.locator('.layer-panel').is_visible(); assert not await pane.is_visible()
  await page.locator('#newLayerBtn').click(); await page.locator('#effectSearch').fill('単色'); await page.locator('[data-effect=static]').click(); assert await pane.is_visible(); await separated()
  await page.locator('[data-view=profiles]').click(); await page.wait_for_timeout(250); assert await page.locator('.profile-card').count()==6
  await page.screenshot(path=str(ROOT.parent/'GUI_presets_900.png'))
  assert await page.evaluate("document.documentElement.scrollWidth<=innerWidth")
  await page.set_viewport_size({'width':1260,'height':800}); await page.wait_for_timeout(300); await page.screenshot(path=str(ROOT.parent/'GUI_presets_1260.png'))
  # v0.3.25: default card layout, switching preserves the same canvas thumbnails,
  # selection persists across reload and offscreen thumbnails do not animate.
  assert await page.locator('#profileGrid').get_attribute('data-presentation')=='cards'
  assert await page.locator('[data-profile-view=cards]').get_attribute('aria-pressed')=='true'
  assert await page.locator('.profile-card .preset-preview-canvas').count()>=1
  assert await page.evaluate("localStorage.getItem('lume-profile-view')==='cards'")
  card=page.locator('.profile-card').filter(has_text='Polar Aurora')
  await card.hover();await page.wait_for_timeout(180)
  c1=await card.locator('.profile-visual').evaluate("e=>JSON.stringify(e._thumb.frame)")
  n=await page.evaluate("calls.filter(c=>c.u==='/api/scene').length")
  await page.wait_for_timeout(300)
  c2=await card.locator('.profile-visual').evaluate("e=>JSON.stringify(e._thumb.frame)")
  assert c1!=c2 and await page.evaluate("calls.filter(c=>c.u==='/api/scene').length")==n
  await page.mouse.move(28,53);await page.wait_for_timeout(100);assert not await card.evaluate("e=>e.classList.contains('is-previewing')")
  await page.evaluate("window.firstThumbnail=document.querySelector('.profile-visual')")
  await page.locator('[data-profile-view=list]').click()
  assert await page.locator('#profileGrid').get_attribute('data-presentation')=='list'
  assert await page.evaluate("document.querySelector('.profile-visual')===window.firstThumbnail && localStorage.getItem('lume-profile-view')==='list'")
  await page.screenshot(path=str(ROOT.parent/'GUI_presets_list.png'))
  await page.locator('[data-profile-view=cards]').click()
  assert await page.locator('#profileGrid').get_attribute('data-presentation')=='cards'
  await page.locator('[data-view=lighting]').click()
  await page.locator('[data-preview-mode=normal]').click()
  # Same material and per-key lightmap in the editor; no LED colour on unlit keys.
  await page.evaluate("state.running=false;state.layers=[];state.keyColors={};state.selectedKeys=[];updateSelection();for(const k of keyboardKeys)paintKeyVisual(k,'#000000')")
  await page.wait_for_timeout(150)
  assert await page.evaluate("Array.from(document.querySelector('#keyboard .board-lightmap').getContext('2d').getImageData(0,0,1107,1).data).every(v=>v===0)")
  await page.locator('#keyboardFrame').screenshot(path=str(ROOT.parent/'GUI_baked_unlit.png'))
  await page.evaluate("for(const k of keyboardKeys)paintKeyVisual(k,k.x<6?'#268bff':k.x<12?'#34efc4':'#b283ff')")
  await page.wait_for_timeout(150)
  assert await page.evaluate("(()=>{const c=document.querySelector('#keyboard .board-lightmap');const a=c.getContext('2d').getImageData(0,0,c.width,c.height).data;return a.some((v,i)=>i%4===3&&v>0)})()")
  await page.locator('#keyboardFrame').screenshot(path=str(ROOT.parent/'GUI_baked_lit.png'))
  assert not errors,errors
  print('Workspace: panels, target drag, undo/redo, numeric entry, origin/angle payload, card/list switching, shared optical canvas, lit/unlit, no JS errors.')
  await browser.close()
if __name__=='__main__':asyncio.run(main())
