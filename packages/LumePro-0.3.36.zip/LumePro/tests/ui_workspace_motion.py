"""Verify actual intermediate geometry, reversal, reduced motion and compact mode."""
import asyncio, os
from pathlib import Path
from playwright.async_api import async_playwright
from ui_preset_menu import setup
ROOT=Path(__file__).resolve().parents[1]
SAMPLE='''async (open)=>{
 const sel=s=>document.querySelector(s),box=e=>e.getBoundingClientRect();
 const read=()=>{const b=box(sel('.keyboard-outer')),p=box(sel('.inspector')),btn=box(sel('#inputQuick')),stage=box(sel('.keyboard-stage'));return {t:performance.now(),x:b.x,w:b.width,p:p.x,opacity:+getComputedStyle(sel('.inspector')).opacity,btn:btn.x,stage:stage.width,raw:sel('.keyboard-outer').offsetWidth}};
 const frames=[read()];sel('#inspectorToggle').click();let start=performance.now();
 while(performance.now()-start<680){await new Promise(requestAnimationFrame);frames.push(read())}return frames;
}'''
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(headless=True,executable_path=os.environ.get('CHROMIUM_PATH','/usr/bin/chromium'),args=['--no-sandbox'])
  page,errors=await setup(browser,{f:(ROOT/'app'/f).read_text() for f in ('index.html','style.css','app.js')});await page.wait_for_timeout(700)
  for width,height in [(1260,800),(900,600)]:
   await page.set_viewport_size({'width':width,'height':height});await page.wait_for_timeout(350)
   await page.evaluate('setInspector(false,false)');await page.wait_for_timeout(100)
   for op in [True,False]:
    frames=await page.evaluate(SAMPLE,op);a,b=frames[0],frames[-1]
    print(width,'open' if op else 'close',len(frames),'frames',[(k,round(a[k],2),round(b[k],2),len(set(round(x[k],2) for x in frames))) for k in ['x','w','btn','stage','p','opacity','raw']],flush=True)
    for k in ['w','btn','stage']:
     assert abs(a[k]-b[k])>25,(k,a,b)
     mid=[x[k] for x in frames if min(a[k],b[k])+2<x[k]<max(a[k],b[k])-2]
     assert len(set(round(v,1) for v in mid))>=6,(k,frames)
    assert max(x['raw'] for x in frames)==min(x['raw'] for x in frames),'keyboard internal geometry changed'
    assert abs(b['opacity']-int(op))<.01
    assert await page.locator('.inspector').is_visible()==op
    if op: assert await page.locator('.keyboard-outer').evaluate("b=>b.getBoundingClientRect().right<=document.querySelector('.inspector').getBoundingClientRect().left+1")
   await page.evaluate('setInspector(true);setTimeout(()=>setInspector(false),180);setTimeout(()=>setInspector(true),330)');await page.wait_for_timeout(1050)
   assert await page.locator('.inspector').is_visible()
   assert not await page.locator('#view-lighting').evaluate("e=>e.classList.contains('workspace-motion')")
   await page.locator('[data-inspector-tab=advanced]').click();await page.wait_for_timeout(450)
   assert await page.locator('[data-accordion=inputs]').is_visible()
   await page.locator('[data-inspector-tab=basic]').click();await page.wait_for_timeout(450)
   await page.screenshot(path=f'/mnt/data/LumePro_v0.3.36_editor_{width}.png')
   if width==900: assert await page.locator('#showLayersBtn').is_visible()
   assert await page.evaluate('document.documentElement.scrollWidth<=innerWidth')
  await page.evaluate('setUiMotion(false);setInspector(false)');await page.wait_for_timeout(80);assert not await page.locator('.inspector').is_visible()
  await page.evaluate('setUiMotion(true)');await page.emulate_media(reduced_motion='reduce');await page.evaluate('setInspector(true)');await page.wait_for_timeout(80);assert await page.locator('.inspector').is_visible()
  assert not errors,errors
  await browser.close()
if __name__=='__main__':asyncio.run(main())
