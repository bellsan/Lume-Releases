"""Chromium gallery frame timing, node counts and interaction checks (mock device)."""
import asyncio,os,sys,json,statistics
from pathlib import Path
from playwright.async_api import async_playwright
from ui_preset_menu import setup
ROOT=Path(__file__).resolve().parents[1]
async def run(browser,root):
 page,errors=await setup(browser,{f:(root/'app'/f).read_text() for f in ('index.html','style.css','app.js')})
 await page.locator('[data-view=profiles]').click()
 await page.wait_for_timeout(800)
 card=page.locator('.profile-card').filter(has_text='Polar Aurora')
 await card.scroll_into_view_if_needed()
 await page.wait_for_timeout(200)
 counts=await page.evaluate("({nodes:document.querySelectorAll('#profileGrid *').length,keys:document.querySelectorAll('#profileGrid .physical-key').length,canvases:document.querySelectorAll('#profileGrid canvas').length})")
 await page.evaluate('''()=>{window.gallerySamples=[];const original=paintThumbnail;paintThumbnail=function(item,t){const before=performance.now();original(item,t);if(hoveredPreset&&item.host===hoveredPreset.host)gallerySamples.push([before,performance.now()-before])};}''')
 await card.hover();await page.wait_for_function('!!hoveredPreset');await page.wait_for_timeout(2100)
 samples=await page.evaluate('gallerySamples');times=[s[1] for s in samples];delta=[b[0]-a[0] for a,b in zip(samples,samples[1:])]
 assert len(samples)>1,(samples,errors)
 result={**counts,'frames':len(samples),'fps':round(1000/statistics.mean(delta),1),'frame_js_ms_median':round(statistics.median(times),2),'frame_interval_ms_p95':round(sorted(delta)[int(.95*(len(delta)-1))],2)}
 if root==ROOT:
  assert counts['keys']==0 and counts['canvases']>0
  assert await page.evaluate('thumbMaterials.size>=20 && thumbBoards.size===1')
  assert await card.locator('.profile-visual').evaluate("e=>Object.keys(e._thumb.frame).length>=90")
  await page.screenshot(path='/mnt/data/LumePro_v0.3.33_hover.png')
 await page.mouse.move(15,15);await page.wait_for_timeout(120)
 assert not await page.evaluate('!!hoveredPreset')
 result['cached_tab_ms']=await page.evaluate('''async()=>{const times=[];for(let i=0;i<5;i++){navigate('settings');await new Promise(r=>requestAnimationFrame(r));const t=performance.now();navigate('profiles');await new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r)));times.push(performance.now()-t)}return times.map(x=>Math.round(x*10)/10)}''')
 assert not errors,errors
 await page.close();return result
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(headless=True,executable_path=os.environ.get('CHROMIUM_PATH','/usr/bin/chromium'),args=['--no-sandbox'])
  for root in [*(Path(x) for x in sys.argv[1:]),ROOT]:print(root.name, json.dumps(await run(browser,root)),flush=True)
  await browser.close()
if __name__=='__main__':asyncio.run(main())
