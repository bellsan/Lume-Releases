import os
import pathlib
import subprocess
import sys
import tempfile
import time
import urllib.request
import json

ROOT=pathlib.Path(__file__).resolve().parents[1]

def request(port,path,token=None,data=None):
 url=f'http://127.0.0.1:{port}{path}'
 body=json.dumps(data).encode() if data is not None else None
 headers={'Content-Type':'application/json'} if data is not None else {}
 if token:headers['X-Lume-Token']=token
 with urllib.request.urlopen(urllib.request.Request(url,data=body,headers=headers),timeout=3) as response:
  return json.loads(response.read())

def test_local_api():
 import socket
 with socket.socket() as s:s.bind(('127.0.0.1',0));port=s.getsockname()[1]
 with tempfile.TemporaryDirectory() as tmp:
  env=dict(os.environ,LOCALAPPDATA=tmp)
  proc=subprocess.Popen([sys.executable,str(ROOT/'app'/'server.py'),'--no-browser','--port',str(port)],env=env,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
  try:
   for i in range(40):
    try:token=request(port,'/api/token')['token'];break
    except OSError:time.sleep(.10)
   else:raise AssertionError('server did not start')
   status=request(port,'/api/status')
   assert status['hardware']['active'] is False
   diag=request(port,'/api/diagnostic')
   assert diag['diagnostic_version']==3 and 'audio' in diag and diag['fn_hid']['active'] is False and diag['fn_hid']['collection_stats']==[]
   assert request(port,'/api/preferences')['preferences']['auto'] is True
   saved=request(port,'/api/preferences',token,{'auto':False,'live':True,'hook':True,'backend':'logitech'})
   assert saved['ok'] and saved['preferences']['live'] is True
   assert request(port,'/api/auto_connect',token,{})['ok'] is False
   assert request(port,'/api/preferences')['preferences']['auto'] is False
   save=request(port,'/api/save',token,{'preset':{'name':'test profile','state':{'layout':'jis','layers':[]}}})
   assert save['ok']
   names=[x['name'] for x in request(port,'/api/presets')['presets']]
   assert 'test profile' in names
   assert request(port,'/api/delete',token,{'name':'test profile'})['ok']
   assert request(port,'/api/presets')['presets']==[]
   assert request(port,'/api/audio')['enabled'] is False
   game=request(port,'/api/game_mode',token,{'enabled':False,'blocked':['KeyA'],'led':'off'})
   assert game['ok'] and game['game_mode']['blocked']==['KeyA']
   assert request(port,'/api/preferences')['preferences']['game_mode']['enabled'] is False
   assert request(port,'/api/status')['game_mode']['blocked']==['KeyA']
   try:request(port,'/api/game_mode',token,{'enabled':False,'blocked':['F12']});raise AssertionError('protected key accepted')
   except urllib.error.HTTPError as exc:assert exc.code==400
   request(port,'/api/shutdown',token,{})
   proc.wait(timeout=4)
  finally:
   if proc.poll() is None:proc.terminate();proc.wait(timeout=3)
