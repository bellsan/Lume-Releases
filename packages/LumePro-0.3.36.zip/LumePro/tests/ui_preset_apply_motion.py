"""Regression for v0.3.35; mock API, real Chromium click and animation tests."""
import asyncio, os
from pathlib import Path
from playwright.async_api import async_playwright
from ui_preset_menu import setup
ROOT=Path(__file__).resolve().parents[1]
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(headless=True,executable_path=os.environ.get('CHROMIUM_PATH','/usr/bin/chromium'),args=['--no-sandbox'])
  page,errors=await setup(browser,{f:(ROOT/'app'/f).read_text() for f in ('index.html','style.css','app.js')})
  await page.evaluate('hardware.active=true; window.calls=[]')
  await page.locator('[data-view=profiles]').click()
  card=page.locator('.profile-card').filter(has_text='Aqua / Ripple')
  await card.locator('.apply-profile').click()
  assert await page.locator('#view-profiles').is_visible()
  assert await card.locator('.apply-profile').inner_text()=='適用中'
  assert await page.evaluate("currentLayer().type==='ripple' && editingPreset===null")
  await page.wait_for_function("calls.some(x=>x.u==='/api/scene' && x.b.layers[0].type==='ripple')")
  await page.wait_for_function("calls.some(x=>x.u==='/api/preferences' && x.b.editor?.profileName==='Aqua / Ripple')")
  await page.locator('[data-profile-view=list]').click()
  user=page.locator('.profile-card').filter(has_text='Test 01')
  await user.locator('.apply-profile').click()
  assert await page.locator('#view-profiles').is_visible()
  assert await user.locator('.apply-profile').inner_text()=='適用中'
  assert await card.locator('.apply-profile').inner_text()=='適用'
  await user.locator('.preset-more').click()
  await page.locator('[data-preset-action=edit]').click()
  assert await page.locator('#view-lighting').is_visible()
  assert await page.evaluate("editingPreset==='Test 01'")
  await page.locator('[data-inspector-tab=motion]').click()
  assert await page.locator('#noMotion').is_visible()
  assert await page.evaluate('inspectorAnimations.size>0')
  await page.wait_for_timeout(460)
  assert await page.evaluate('inspectorAnimations.size===0')
  await page.locator('[data-inspector-tab=basic]').click()
  await page.wait_for_timeout(460)
  section=page.locator('[data-accordion=color]')
  trigger=section.locator('.accordion-trigger')
  await trigger.click()
  assert await trigger.get_attribute('aria-expanded')=='false'
  await page.wait_for_timeout(460)
  assert await section.locator('.accordion-clip').evaluate('e=>e.inert && e.getBoundingClientRect().height<1')
  await page.evaluate('renderInspector()')
  assert await trigger.get_attribute('aria-expanded')=='false'
  await trigger.click()
  assert await trigger.get_attribute('aria-expanded')=='true'
  await page.wait_for_timeout(460)
  assert await section.locator('.accordion-clip').evaluate('e=>!e.inert && e.getBoundingClientRect().height>30')
  # User preferences and operating-system reduced-motion both cancel animations.
  await page.evaluate("setUiMotion(false);setInspectorTab('keys',{animate:true})")
  assert await page.evaluate("inspectorAnimations.size===0 && getComputedStyle(document.querySelector('.accordion-clip')).transitionDuration==='0s'")
  await page.evaluate('setUiMotion(true)')
  await page.emulate_media(reduced_motion='reduce')
  await page.evaluate("setInspectorTab('basic',{animate:true})")
  assert await page.evaluate('inspectorAnimations.size===0')
  await page.emulate_media(reduced_motion='no-preference')
  await page.evaluate("setInspectorTab('keys',{animate:true});setInspectorTab('advanced',{animate:true});setInspectorTab('basic',{animate:true})")
  await page.wait_for_timeout(460)
  assert await page.evaluate("inspectorAnimations.size===0 && inspectorTab==='basic'")
  await page.set_viewport_size({'width':900,'height':600})
  await page.wait_for_timeout(250)
  assert await page.locator('.inspector').is_visible()
  assert await page.evaluate('document.documentElement.scrollWidth<=innerWidth')
  assert not errors,errors
  print('PASS: card/list apply stays in gallery, current badge, scene/save payload, edit routing, panel animations, independent accordion, motion opt-out/reduced-motion, rapid switch, compact layout; no JS errors')
  await browser.close()
if __name__=='__main__':asyncio.run(main())
