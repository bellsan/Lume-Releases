"""Preset menu / lazy rendering and motion settings regression (mocked local API)."""
import asyncio,os,json,time,zipfile
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parents[1]
MOCK='''()=>{const values=new Map();Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem:k=>values.get(k)??null,setItem:(k,v)=>values.set(k,String(v)),removeItem:k=>values.delete(k)}});window.confirm=()=>true;window.calls=[];window.presets=Array.from({length:2},(_,i)=>({name:'Test '+String(i+1).padStart(2,'0'),state:{layout:'jis',layers:[{id:1,type:'static',enabled:true,color:'#387de3',brightness:70,speed:30,spread:40,fade:50}],selectedLayer:1,keyColors:{}}}));window.fetch=async(url,opts)=>{let u=String(url),b=opts?.body?JSON.parse(opts.body):{};calls.push({u,b});let data={ok:true};if(u==='/api/token')data={token:'test'};else if(u==='/api/preferences')data={preferences:{auto:false,hook:false,live:false,backend:'logitech'}};else if(u==='/api/status')data={hardware:{active:false,devices:[],led_map:[]},engine:{active:false},keyhook:{enabled:false}};else if(u==='/api/presets')data={presets:JSON.parse(JSON.stringify(presets))};else if(u==='/api/save'){window.presets=presets.filter(p=>p.name!==b.previous_name&&p.name!==b.preset.name);presets.unshift(b.preset)}else if(u==='/api/delete'){window.presets=presets.filter(p=>p.name!==b.name)}else if(u==='/api/update/status'||u==='/api/update/check')data={current:'0.3.29',phase:'idle',auto:false,available:false};return {ok:true,json:async()=>data}}}'''
async def setup(browser,files):
 page=await browser.new_page(viewport={'width':1260,'height':800});page.set_default_timeout(8000)
 errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 await page.set_content(files['index.html'].replace('<link rel="stylesheet" href="/style.css">','').replace('<script src="/app.js" defer></script>',''))
 await page.add_style_tag(content=files['style.css']);await page.evaluate(MOCK);await page.add_script_tag(content=files['app.js']);await page.wait_for_function('!initializing && allProfiles.length===8',timeout=10000)
 return page,errors
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(headless=True,executable_path=os.environ.get('CHROMIUM_PATH','/usr/bin/chromium'),args=['--no-sandbox'])
  page,errors=await setup(browser,{f:(ROOT/'app'/f).read_text() for f in ('index.html','style.css','app.js')})
  assert await page.locator('#profileGrid .physical-key').count()==0
  await page.locator('[data-view=profiles]').click();await page.wait_for_function("document.querySelector('#profileGrid .profile-card .preset-preview-canvas')!==null")
  await page.wait_for_timeout(500)
  n=await page.locator('#profileGrid .preset-preview-canvas').count();assert 1<=n<=8,n
  assert await page.locator('#profileGrid .physical-key').count()==0
  await page.evaluate("window.oldCard=document.querySelector('#profileGrid .profile-card')")
  await page.locator('[data-view=keyboard]').click();await page.locator('[data-view=profiles]').click();assert await page.evaluate("document.querySelector('#profileGrid .profile-card')===oldCard")
  first=page.locator('.profile-card').first;await first.locator('.preset-more').click();await page.locator('#presetMenu').wait_for(state='visible')
  await page.screenshot(path='/mnt/data/LumePro_v0.3.33_presets_menu.png',timeout=8000)
  await page.keyboard.press('Escape');assert not await page.locator('#presetMenu').is_visible()
  await first.locator('.preset-more').click();await page.locator('[data-preset-action=rename]').click();await page.locator('#presetRenameInput').fill('Test 02');await page.locator('#presetRenameForm button[type=submit]').click();assert await page.locator('#presetRenameError').inner_text();await page.locator('#presetRenameInput').fill('Renamed');await page.locator('#presetRenameForm button[type=submit]').click();await page.wait_for_function("allProfiles.some(p=>p.name==='Renamed')")
  first=page.locator('.profile-card').first;await first.locator('.preset-more').click();await page.locator('[data-preset-action=duplicate]').click();await page.wait_for_function("allProfiles.some(p=>p.name==='Renamed コピー')")
  await page.get_by_role('button',name='Renamed コピー のメニュー',exact=True).click();await page.locator('[data-preset-action=delete]').click();await page.wait_for_function("!allProfiles.some(p=>p.name==='Renamed コピー')")
  await page.locator('[data-profile-view=list]').click();assert await page.locator('#profileGrid').get_attribute('data-presentation')=='list'
  await page.locator('[data-profile-view=cards]').click();await page.locator('[data-view=settings]').click();await page.locator('label:has(#uiMotionToggle)').click();assert await page.evaluate("document.documentElement.classList.contains('no-ui-motion')")
  await page.locator('label:has(#uiMotionToggle)').click();assert not await page.evaluate("document.documentElement.classList.contains('no-ui-motion')")
  assert not errors,errors
  print(f'Preset menu, duplicate/delete/rename validation, cached tabs, lazy thumbnails ({n} visible canvases; zero physical-key DOM nodes), motion toggle: OK.');await browser.close()
if __name__=='__main__':asyncio.run(main())
