"""Lume Pro: a lightweight localhost desktop UI + optional OpenRGB bridge."""
from __future__ import annotations
import argparse
import json
import os
import pathlib
import secrets
import socket
import subprocess
import sys
import threading
import time
import webbrowser
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse

from backend import BackendRouter
from keyhook import KeyboardWatcher
from audio import AudioMonitor,list_outputs
from engine import AnimationEngine,validate
from device_info import logitech_hid_ids
from fn_hid import FnHidMonitor
from ghub_state import GHubStateMonitor
from game_sync import GameSync
from preferences import Preferences,choose_device
from updater import Updater

ROOT=pathlib.Path(__file__).resolve().parent
DATA=pathlib.Path(os.environ.get('LOCALAPPDATA',str(pathlib.Path.home()))) / 'LumePro'
DATA.mkdir(parents=True,exist_ok=True)
PRESETS=DATA/'presets.json'
preset_lock=threading.RLock()
def save_presets(val):
 with preset_lock:
  tmp=PRESETS.with_suffix('.tmp');tmp.write_text(json.dumps(val,ensure_ascii=False,indent=2),'utf-8');os.replace(tmp,PRESETS)
prefs=Preferences(DATA/'preferences.json')
connection_lock=threading.RLock()
SECRET=secrets.token_urlsafe(22)
backend=BackendRouter()
keys=KeyboardWatcher()
_saved_game=prefs.load().get('game_mode')
if _saved_game:keys.game.configure(False,_saved_game['blocked'],_saved_game['led'],_saved_game['color'],_saved_game['dim'])
game_sync=GameSync(keys.game,lambda:keys.enabled)
ghub_state=GHubStateMonitor(keys.push,on_change=game_sync.change,on_disconnect=game_sync.disconnect)
def sync_status():
 return {**ghub_state.status(),'sync_enabled':game_sync.enabled}
def emit_hid(code):
 # A learned Fn can coexist with the G HUB state observer. For right-hand
 # buttons use the state route if it has a valid baseline; avoid double pulses.
 if code in ('GameMode','LightButton'):
  status=ghub_state.status()
  if status['connected'] and status['states'].get(code) is not None:return
 keys.push(code)
fn_hid=FnHidMonitor(emit_hid)
audio=AudioMonitor()
engine=AnimationEngine(backend,keys,audio)
updater=Updater(ROOT.parent,DATA)

class Handler(BaseHTTPRequestHandler):
 def log_message(self,fmt,*args):
  if os.getenv('LUMEPRO_DEBUG'):super().log_message(fmt,*args)

 def send_json(self,obj,status=200):
  data=json.dumps(obj,ensure_ascii=False).encode('utf-8')
  self.send_response(status);self.send_header('Content-Type','application/json; charset=utf-8')
  self.send_header('Cache-Control','no-store');self.send_header('Content-Length',str(len(data)))
  self.send_header('X-Content-Type-Options','nosniff');self.end_headers();self.wfile.write(data)

 def do_GET(self):
  path=urlparse(self.path).path
  if path=='/api/update/status':return self.send_json(updater.status())
  if path=='/api/ghub_state_status':return self.send_json(sync_status())
  if path=='/api/game_sync':return self.send_json({'status':sync_status(),'game_mode':keys.game.status()})
  if path=='/api/fn_hid_status':return self.send_json(fn_hid.status())
  if path=='/api/game_mode':return self.send_json(keys.game.status())
  if path=='/api/preferences':return self.send_json({'preferences':prefs.load()})
  if path=='/api/status':return self.send_json({'hardware':backend.status(), 'engine':engine.status(), 'keyhook':keys.diagnostic(),'game_mode':keys.game.status(),'ghub_state':sync_status()})
  if path=='/api/keys':
   try:seq=max(0,int(self.path.split('since=')[-1])) if 'since=' in self.path else 0
   except Exception:seq=0
   return self.send_json(keys.since(seq))
  if path=='/api/diagnostic':return self.send_json({'hardware':backend.status(),'engine':engine.status(),'keyhook':keys.diagnostic(),'logitech_hid_ids':logitech_hid_ids(),'fn_hid':fn_hid.status(),'ghub_state':ghub_state.status(),'audio':{k:v for k,v in audio.status().items() if k not in ('wave','trace','envelope','bands','stereo','spectrum','spectrum_slow','spectrum_peak')},'diagnostic_version':3})
  if path=='/api/audio':return self.send_json(audio.status())
  if path=='/api/audio_devices':return self.send_json(list_outputs())
  if path=='/api/presets':
   try:val=json.loads(PRESETS.read_text('utf-8'))
   except (OSError,ValueError):val=[]
   return self.send_json({'presets':val})
  assets={'/':'index.html','/index.html':'index.html','/style.css':'style.css','/app.js':'app.js'}
  if path not in assets:return self.send_error(404)
  file=ROOT/assets[path]
  data=file.read_bytes()
  typ='text/html; charset=utf-8' if file.suffix=='.html' else 'text/css; charset=utf-8' if file.suffix=='.css' else 'application/javascript; charset=utf-8'
  self.send_response(200);self.send_header('Content-Type',typ)
  self.send_header('Content-Security-Policy',"default-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; base-uri 'none'; form-action 'none'")
  self.send_header('X-Content-Type-Options','nosniff');self.send_header('Cache-Control','no-store')
  self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data)

 def do_POST(self):
  if self.headers.get('X-Lume-Token')!=SECRET:return self.send_json({'error':'unauthorized'},403)
  if self.headers.get('Content-Type','').split(';')[0]!='application/json':return self.send_json({'error':'json only'},415)
  try:
   n=int(self.headers.get('Content-Length','0'))
   if n<=0 or n>128_000:raise ValueError('サイズ超過')
   obj=json.loads(self.rfile.read(n))
   if not isinstance(obj,dict):raise ValueError('invalid input')
  except (ValueError,TypeError):return self.send_json({'error':'invalid payload'},400)
  path=urlparse(self.path).path
  if path.startswith('/api/update/'):
   try:
    if path=='/api/update/check':return self.send_json(updater.check(obj.get('manual') is True))
    if path=='/api/update/ack':return self.send_json(updater.acknowledge(obj.get('version')))
    if path=='/api/update/configure':return self.send_json(updater.configure(obj.get('auto') is True))
    if path=='/api/update/download':return self.send_json(updater.download())
    if path=='/api/update/apply':
     updater.request_apply();self.send_json({'ok':True})
     threading.Thread(target=self.server.shutdown,daemon=True).start();return
   except (ValueError,OSError) as e:return self.send_json({'error':str(e)},400)
  if path=='/api/preferences':
   try:return self.send_json({'ok':True,'preferences':prefs.update(obj)})
   except (OSError,ValueError,TypeError) as e:return self.send_json({'ok':False,'error':str(e)},400)
  if path=='/api/auto_connect':
   p=prefs.load()
   if not p['auto']:return self.send_json({'ok':False,'hardware':backend.status(),'error':'自動接続OFF'})
   with connection_lock:
    engine.enable(False)
    fn_hid.stop();ghub_state.stop()
    ok=backend.connect(p['backend'])
    if ok:
     idx=choose_device(backend.list_devices(),p)
     ok=idx is not None and backend.select(idx)
     if ok:
      backend.set_layout((p['editor'] or {}).get('layout','jis'))
      if p['backend']=='logitech':
       backend.set_method(p['method']);backend.set_key_method('Backslash',p['bracket_method']);backend.set_key_method('Fn',p['fn_method']);backend.set_key_method('IntlYen',p['yen_method'])
      if p['backend']=='logitech' and p['bitmap_layout']==backend.layout:
       backend.configure_bitmap(p['bitmap_mapping'],False)
       if p['bitmap_enabled'] and not backend.configure_bitmap(p['bitmap_mapping'],True):prefs.update({'bitmap_enabled':False})
      d=next((d for d in backend.list_devices() if d['id']==idx),None)
      if d:prefs.update({'device_name':d['name'],'device_leds':d['leds']})
    return self.send_json({'ok':ok,'hardware':backend.status(),'error':None if ok else '自動接続できませんでした。接続先を確認してください。'})
  if path=='/api/connect':
   with connection_lock:
    engine.enable(False)
    fn_hid.stop();ghub_state.stop()
    ok=backend.connect(obj.get('backend','openrgb'));return self.send_json({'ok':ok,'hardware':backend.status()})
  if path=='/api/select':
   with connection_lock:
    engine.enable(False)
    ok=backend.select(obj.get('index'))
    if ok:
     p=prefs.load();d=next((d for d in backend.list_devices() if d['id']==obj.get('index')),None)
     backend.set_layout((p['editor'] or {}).get('layout','jis'))
     if backend.kind=='logitech':
      backend.set_method(p['method']);backend.set_key_method('Backslash',p['bracket_method']);backend.set_key_method('Fn',p['fn_method']);backend.set_key_method('IntlYen',p['yen_method'])
     if backend.kind=='logitech' and p['bitmap_layout']==backend.layout:
      backend.configure_bitmap(p['bitmap_mapping'],False)
      if p['bitmap_enabled'] and not backend.configure_bitmap(p['bitmap_mapping'],True):prefs.update({'bitmap_enabled':False})
     if d:prefs.update({'backend':backend.kind,'device_name':d['name'],'device_leds':d['leds']})
    return self.send_json({'ok':ok,'hardware':backend.status()})
  if path=='/api/game_sync':
   enabled=obj.get('enabled')
   if type(enabled) is not bool:return self.send_json({'error':'invalid enabled'},400)
   with connection_lock:
    if enabled:
     hs=fn_hid.status()
     if hs['active'] and hs['phase']!='learned':return self.send_json({'error':'HID学習を停止してください'},400)
     if not keys.enabled:return self.send_json({'error':'入力検出を開始してください'},400)
     game_sync.arm(True)
     if not ghub_state.start():game_sync.disconnect();return self.send_json({'error':'G HUB監視を開始できません'},400)
    else:game_sync.arm(False);ghub_state.stop()
   return self.send_json({'ok':True,'status':sync_status(),'game_mode':keys.game.status()})
  if path=='/api/ghub_state':
   with connection_lock:
    if obj.get('action')=='start':
     hs=fn_hid.status()
     if hs['active'] and hs['phase']!='learned':return self.send_json({'ok':False,'error':'HID学習を完了または停止してから開始してください','status':ghub_state.status()})
     ok=keys.enabled and ghub_state.start()
    elif obj.get('action')=='stop':ghub_state.stop();ok=True
    else:return self.send_json({'error':'invalid action'},400)
    return self.send_json({'ok':ok,'status':ghub_state.status()})
  if path=='/api/fn_hid':
   action=obj.get('action')
   if action=='list':return self.send_json({'ok':True,'devices':fn_hid.list(),'status':fn_hid.status()})
   if action=='stop':fn_hid.stop();ok=True
   elif action=='start':
    ghub_state.stop()
    engine.enable(False)
    backend.clear_pending()
    # Wait for any already-dispatched SDK write before starting the HID baseline.
    if backend.kind=='logitech':
     with backend.impl.lock:pass
    ok=keys.enabled and fn_hid.start(obj.get('index'),obj.get('target','Fn'))
   elif action=='learn':
    ghub_state.stop()
    engine.enable(False)
    if backend.kind=='logitech':
     with backend.impl.lock:pass
    ok=keys.enabled and fn_hid.learn(obj.get('target'))
   elif action=='sample':ok=keys.enabled and fn_hid.arm()
   elif action=='enable':ok=keys.enabled and fn_hid.enable()
   else:return self.send_json({'error':'invalid action'},400)
   return self.send_json({'ok':ok,'status':fn_hid.status()})
  if path=='/api/special_probe':
   with connection_lock:
    engine.enable(False)
    ok=backend.kind=='logitech' and backend.probe_special(obj.get('code'),obj.get('method'),obj.get('color'))
    return self.send_json({'ok':ok,'hardware':backend.status()})
  if path=='/api/coverage_test':
   with connection_lock:
    engine.enable(False)
    ok=backend.kind=='logitech' and backend.test_coverage(obj.get('color'))
    return self.send_json({'ok':ok,'hardware':backend.status()})
  if path=='/api/bitmap_test':
   with connection_lock:
    engine.enable(False)
    ok=backend.kind=='logitech' and backend.test_bitmap(obj.get('pattern'),obj.get('index',0))
    return self.send_json({'ok':ok,'hardware':backend.status()})
  if path=='/api/bitmap_config':
   with connection_lock:
    engine.enable(False)
    mapping=obj.get('mapping');enabled=obj.get('enabled') is True
    if backend.kind!='logitech' or not isinstance(mapping,dict):return self.send_json({'ok':False,'error':'公式SDKに接続してください'},400)
    if enabled:
     # Full-frame SDK mode must cover all regular physical keys in the scene.
     scene=engine.scene
     required=set(scene[0])-{'Fn','BoardLogo','GameMode','LightButton'} if scene else set()
     if not required or not required.issubset(mapping):return self.send_json({'ok':False,'error':'通常キーの全対応付けが必要です。未割り当てのキーを消灯させないため、有効化を中止しました。'},400)
    ok=backend.configure_bitmap(mapping,enabled)
    if ok:prefs.update({'bitmap_layout':backend.layout,'bitmap_mapping':mapping,'bitmap_enabled':enabled})
    return self.send_json({'ok':ok,'hardware':backend.status()})
  if path=='/api/led_test':
   engine.enable(False)
   ok=backend.test_led(obj.get('index'),obj.get('color','#ffffff'));return self.send_json({'ok':ok,'hardware':backend.status()})
  if path=='/api/jis_test':
   engine.enable(False)
   ok=backend.kind=='logitech' and backend.test_jis();return self.send_json({'ok':ok,'hardware':backend.status()})
  if path=='/api/sdk_method':
   engine.enable(False)
   ok=backend.set_method(obj.get('method'))
   if ok:prefs.update({'method':obj['method']})
   return self.send_json({'ok':ok,'hardware':backend.status()})
  if path=='/api/key_method':
   engine.enable(False)
   ok=backend.set_key_method(obj.get('code'),obj.get('method'))
   if ok:prefs.update({({'Backslash':'bracket_method','Fn':'fn_method','IntlYen':'yen_method'}[obj['code']]):obj['method']})
   return self.send_json({'ok':ok,'hardware':backend.status()})
  if path=='/api/led_map':
   ok=backend.set_mapping(obj.get('index'),obj.get('code'));return self.send_json({'ok':ok,'hardware':backend.status()})
  if path=='/api/game_mode':
   try:
    enabled=obj.get('enabled') is True
    # Validate before installing the global hook. Never enable on startup.
    from game_mode import GameMode
    check=GameMode();check.configure(enabled,obj.get('blocked'),obj.get('led','off'),obj.get('color','#ff5555'),obj.get('dim',25))
    with connection_lock:
     if enabled and not keys.start():return self.send_json({'error':keys.error or '入力制御を開始できません'},400)
     with game_sync.lock:
      if enabled!=keys.game.status()['enabled']:game_sync.manual()
      keys.game.configure(enabled,obj['blocked'],obj.get('led','off'),obj.get('color','#ff5555'),obj.get('dim',25))
    try:prefs.update({'game_mode':{**keys.game.status(),'enabled':False}})
    except OSError:pass
    return self.send_json({'ok':True,'game_mode':keys.game.status()})
   except ValueError as e:return self.send_json({'error':str(e)},400)
  if path=='/api/scene':
   try:
    validate(obj)
    with engine.lock:
     backend.set_layout(obj.get('layout','jis'));engine.configure(obj)
    return self.send_json({'ok':True,'engine':engine.status()})
   except ValueError as e:return self.send_json({'ok':False,'error':str(e)},400)
  if path=='/api/live':
   try:engine.enable(obj.get('enabled') is True);return self.send_json({'ok':True,'engine':engine.status()})
   except ValueError as e:return self.send_json({'ok':False,'error':str(e)},400)
  if path=='/api/pulse':
   code=obj.get('code');return self.send_json({'ok':isinstance(code,str) and engine.pulse(code)})
  if path=='/api/frame':
   if engine.active:return self.send_json({'ok':False,'error':'サーバー描画が有効です'})
   if backend.device is None:return self.send_json({'ok':False,'error':'デバイス未選択'})
   backend.queue_frame(keys.game.mask(obj.get('colors',{})));return self.send_json({'ok':True})
  if path=='/api/audio_toggle':
   if obj.get('enabled'):ok=audio.start(obj.get('endpoint','default'))
   else:audio.stop();ok=True
   return self.send_json({'ok':ok,'audio':audio.status()})
  if path=='/api/audio_demo':
   audio.demo(obj.get('layer_id'));return self.send_json({'ok':True,'audio':audio.status()})
  if path=='/api/keyhook':
   if obj.get('enabled'):ok=keys.start()
   else:fn_hid.stop();ghub_state.stop();keys.stop();ok=True
   return self.send_json({'ok':ok,'enabled':keys.enabled,'error':keys.error})
  if path=='/api/save':
   if not isinstance(obj.get('preset'),dict):return self.send_json({'error':'invalid preset'},400)
   preset=obj['preset'];name=preset.get('name')
   if not isinstance(name,str) or not 1<=len(name)<=60:return self.send_json({'error':'名前は1～60文字'},400)
   try:val=json.loads(PRESETS.read_text('utf-8'))
   except (OSError,ValueError):val=[]
   preset={'name':name, 'state':preset.get('state',{})}
   if not isinstance(preset['state'],dict):return self.send_json({'error':'invalid state'},400)
   previous=obj.get('previous_name')
   if not isinstance(previous,str):previous=None
   val=[p for p in val if p.get('name') not in (name,previous)]
   val.insert(0,preset)
   val=val[:40]
   save_presets(val)
   return self.send_json({'ok':True,'presets':val})
  if path=='/api/delete':
   try:val=json.loads(PRESETS.read_text('utf-8'))
   except (OSError,ValueError):val=[]
   name=obj.get('name');val=[p for p in val if p.get('name')!=name]
   save_presets(val)
   return self.send_json({'ok':True,'presets':val})
  if path=='/api/shutdown':
   self.send_json({'ok':True})
   threading.Thread(target=self.server.shutdown,daemon=True).start();return
  return self.send_json({'error':'not found'},404)


def launch(url):
 if sys.platform=='win32':
  paths=[os.environ.get('PROGRAMFILES(X86)','')+r'\Microsoft\Edge\Application\msedge.exe',
         os.environ.get('PROGRAMFILES','')+r'\Microsoft\Edge\Application\msedge.exe',
         os.environ.get('LOCALAPPDATA','')+r'\Microsoft\Edge\Application\msedge.exe']
  for path in paths:
   if os.path.isfile(path):
    try:subprocess.Popen([path,'--app='+url,'--window-size=1260,800']);return
    except OSError:pass
 webbrowser.open(url)


def main():
 parser=argparse.ArgumentParser()
 parser.add_argument('--no-browser',action='store_true')
 parser.add_argument('--port',type=int,default=0)
 args=parser.parse_args()
 server=ThreadingHTTPServer(('127.0.0.1',args.port),Handler)
 # HTML can access runtime token only as part of same local origin.
 original_get=Handler.do_GET
 def adapted_get(self):
  if urlparse(self.path).path=='/api/token':return self.send_json({'token':SECRET})
  return original_get(self)
 Handler.do_GET=adapted_get
 port=server.server_address[1]
 url=f'http://127.0.0.1:{port}/'
 print('Lume Pro:',url,flush=True)
 if not args.no_browser:threading.Timer(0.65,launch,args=[url]).start()
 try:server.serve_forever(poll_interval=0.1)
 except KeyboardInterrupt:pass
 finally:
  engine.close();fn_hid.stop();ghub_state.stop();keys.stop();audio.stop();backend.close();server.server_close()
  restart=updater.pending
  updater.finish()
  if restart:
   kwargs={'cwd':str(ROOT.parent),'stdout':subprocess.DEVNULL,'stderr':subprocess.DEVNULL,'stdin':subprocess.DEVNULL}
   if sys.platform=='win32':kwargs['creationflags']=subprocess.DETACHED_PROCESS|subprocess.CREATE_NEW_PROCESS_GROUP
   # Keep the same local origin so the current UI can reconnect after restart.
   subprocess.Popen([sys.executable,'-u',str(ROOT/'server.py'),'--port',str(port),'--no-browser'],**kwargs)

if __name__=='__main__':main()
