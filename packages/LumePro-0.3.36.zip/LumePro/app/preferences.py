"""Local, port-independent editor and connection preferences. No input events are saved."""
import json
import threading
from bitmap_led import valid_mapping
from engine import EFFECTS
from pathlib import Path

DEFAULT={'auto':True,'backend':'logitech','device_name':None,'device_leds':None,'live':False,'hook':False,'method':'auto','bracket_method':'auto','fn_method':'auto','yen_method':'auto','editor':None,'bitmap_layout':'jis','bitmap_mapping':{},'bitmap_enabled':False,'game_mode':None,'motion_profile':'balanced'}

def clean(raw):
 d=dict(DEFAULT)
 if not isinstance(raw,dict):return d
 for k in ('auto','live','hook'):
  if type(raw.get(k)) is bool:d[k]=raw[k]
 if raw.get('motion_profile') in ('responsive','balanced','smooth'):d['motion_profile']=raw['motion_profile']
 if raw.get('backend') in ('logitech','openrgb'):d['backend']=raw['backend']
 for k in ('method','bracket_method','fn_method','yen_method'):
  if raw.get(k) in ('auto','hid','scan','keyname','off','hid31','iso56','hid64','scan56') and (k=='bracket_method' or raw[k] not in ('hid31','iso56','hid64','scan56')) and (k!='method' or raw[k] in ('auto','hid','scan')):d[k]=raw[k]
 if isinstance(raw.get('device_name'),str):d['device_name']=raw['device_name'][:200]
 if type(raw.get('device_leds')) is int and 0<raw['device_leds']<=4096:d['device_leds']=raw['device_leds']
 if raw.get('bitmap_layout') in ('jis','ansi'):d['bitmap_layout']=raw['bitmap_layout']
 d['bitmap_mapping']=valid_mapping(raw.get('bitmap_mapping'))
 d['bitmap_enabled']=raw.get('bitmap_enabled') is True and bool(d['bitmap_mapping'])
 g=raw.get('game_mode')
 if isinstance(g,dict):
  from game_mode import GameMode
  try:
   gate=GameMode();gate.configure(False,g.get('blocked'),g.get('led','off'),g.get('color','#ff5555'),g.get('dim',25));d['game_mode']=gate.status()
  except ValueError:pass
 e=raw.get('editor')
 if isinstance(e,dict) and e.get('layout') in ('jis','ansi') and isinstance(e.get('layers'),list) and 1<=len(e['layers'])<=8:
  if all(isinstance(l,dict) and l.get('type') in EFFECTS for l in e['layers']):
   d['editor']={k:e[k] for k in ('layout','layers','selectedLayer','keyColors','profileName','editingPreset','fixedColorMode','reactivePriority') if k in e}
 return d

class Preferences:
 def __init__(self,path):self.path=Path(path);self.lock=threading.RLock()
 def load(self):
  with self.lock:
   try:return clean(json.loads(self.path.read_text('utf-8')))
   except (OSError,ValueError):return dict(DEFAULT)
 def update(self,patch):
  with self.lock:
   raw=self.load();raw.update({k:v for k,v in patch.items() if k in DEFAULT});data=clean(raw)
   self.path.parent.mkdir(parents=True,exist_ok=True)
   tmp=self.path.with_suffix('.tmp');tmp.write_text(json.dumps(data,ensure_ascii=False,indent=2),'utf-8');tmp.replace(self.path)
   return data

def choose_device(devices,prefs):
 """Never guess a changed index or select a non-keyboard."""
 ds=[d for d in devices if d.get('keyboard') is True]
 name=prefs.get('device_name');leds=prefs.get('device_leds')
 if name:
  ds=[d for d in ds if d.get('name')==name and (leds is None or d.get('leds')==leds)]
 return ds[0]['id'] if len(ds)==1 else None
