"""Opt-in WASAPI loopback analysis. PCM is held only in memory, never saved."""
import ctypes
import math
import sys
import threading
import time
from collections import deque
from contextlib import contextmanager

@contextmanager
def com_apartment():
    if sys.platform != 'win32':
        yield
        return
    ole=ctypes.windll.ole32
    init=ole.CoInitializeEx
    init.argtypes=[ctypes.c_void_p,ctypes.c_ulong]
    init.restype=ctypes.c_int32
    hr=init(None,0) & 0xffffffff  # MTA, thread-local
    if hr not in (0,1,0x80010106):
        raise OSError(f'COM初期化失敗 0x{hr:08X}')
    try: yield
    finally:
        if hr in (0,1): ole.CoUninitialize()


def blank():
    return {'volume':0.,'wave':[0.]*18,'trace':[0.]*72,'envelope':[0.]*36,'bands':[0.]*18,'spectrum':[0.]*48,'spectrum_slow':[0.]*48,'spectrum_peak':[0.]*48,'stereo':[0.,0.],'bass':0.,'beat':0.,'rms':0.,'peak':0.}

class AudioAnalyzer:
    def __init__(self,rate=48000):
        self.rate=rate;self.data=blank();self.history=deque(maxlen=45);self.last_beat=-1e9
        self.pcm=None;self.spectrum_time=None;self.peak_until=None;self.envelope=deque([0.]*36,maxlen=36);self.env_pending=None
    def process(self,chunk,now=None):
        import numpy as np
        now=time.monotonic() if now is None else now
        a=np.asarray(chunk,dtype=np.float64)
        if a.ndim==1:a=a[:,None]
        if a.ndim!=2 or len(a)==0 or a.shape[1]==0:return self.data
        a=np.clip(np.nan_to_num(a,nan=0.,posinf=0.,neginf=0.),-1,1)
        level=lambda rms: float(np.clip(max(0.,rms-.00015)**.65*2.6,0,1))
        rms=np.sqrt(np.mean(a*a,axis=0));mono=a.mean(axis=1)
        # Preserve energy on out-of-phase stereo by using per-channel spectra.
        self.pcm=a if self.pcm is None or self.pcm.shape[1]!=a.shape[1] else np.concatenate((self.pcm,a),axis=0)
        self.pcm=self.pcm[-4096:]
        n=len(self.pcm);w=np.hanning(n);fft=np.abs(np.fft.rfft(self.pcm*w[:,None],axis=0))*2/max(1,w.sum());mag=np.sqrt(np.mean(fft**2,axis=1));freq=np.fft.rfftfreq(n,1/self.rate)
        edges=np.geomspace(45,min(16000,self.rate*.48),19)
        bands=[]
        for lo,hi in zip(edges[:-1],edges[1:]):
            m=mag[(freq>=lo)&(freq<hi)]
            bands.append(float(np.clip(np.sqrt(np.sum(m*m))*4,0,1)))
        # Dense log-frequency amplitudes with dB compression, no fake motion.
        # Triangular overlap prevents narrow low bands becoming empty at 4096 samples.
        centers=np.geomspace(40,min(16000,self.rate*.48),48)
        logfreq=np.log(np.maximum(freq,1.));logcent=np.log(centers)
        delta=max(.001,logcent[1]-logcent[0]);weights=np.maximum(0,1-np.abs(logfreq[None,:]-logcent[:,None])/delta)
        power=np.sqrt((weights*(mag[None,:]**2)).sum(axis=1))
        nearest=np.interp(centers,freq,mag)
        power=np.maximum(power,nearest*.7)
        dense=np.clip((20*np.log10(np.maximum(power,1e-9))+58)/54,0,1)
        dt=.025 if self.spectrum_time is None else max(.001,min(.25,now-self.spectrum_time));self.spectrum_time=now
        prev=np.asarray(self.data['spectrum']);slow=np.asarray(self.data['spectrum_slow']);peak=np.asarray(self.data['spectrum_peak'])
        fast=prev+(dense-prev)*(1-np.exp(-dt/np.where(dense>prev,.025,.15)))
        slow=slow+(dense-slow)*(1-np.exp(-dt/np.where(dense>slow,.09,.55)))
        if self.peak_until is None:self.peak_until=np.zeros(48)
        higher=fast>=peak;self.peak_until=np.where(higher,now+.32,self.peak_until)
        peak=np.where(higher,fast,np.maximum(fast,peak-np.where(now>=self.peak_until,dt*.9,0)))
        # 18 signed temporal samples; signed peaks of short blocks, not fake animation.
        wave=[float(np.clip(v[np.argmax(np.abs(v))]*2,-1,1)) if len(v) else 0. for v in np.array_split(mono,18)]
        # Time-domain trace, aligned to a rising zero crossing; signed samples.
        # The rolling envelope is real PCM amplitude, with one bin per 20 ms.
        # It is independent of the FFT and is never written to disk.
        size=max(72,min(len(mono),round(self.rate*.018)))
        trace_src=mono[-size:];cross=np.flatnonzero((trace_src[:-1]<=0)&(trace_src[1:]>0))
        if len(cross):
            start=int(cross[0]);trace_src=trace_src[start:]
        trace=np.interp(np.linspace(0,max(0,len(trace_src)-1),72),np.arange(len(trace_src)),trace_src) if len(trace_src) else np.zeros(72)
        amplitudes=np.max(np.abs(a),axis=1)
        self.env_pending=amplitudes if self.env_pending is None else np.concatenate((self.env_pending,amplitudes))
        step=max(1,round(self.rate*.020))
        while len(self.env_pending)>=step:
            block=self.env_pending[:step];self.env_pending=self.env_pending[step:]
            self.envelope.append(float(np.sqrt(np.mean(block*block))))
        bass=float(np.clip(np.sqrt(np.sum(mag[(freq>=35)&(freq<180)]**2))*4,0,1))
        baseline=sum(self.history)/len(self.history) if self.history else bass
        hit=len(self.history)>=8 and bass>max(.06,baseline*1.55+.025) and now-self.last_beat>.16
        if hit:self.last_beat=now
        self.history.append(bass)
        old=self.data
        smooth=lambda a,b: a+(b-a)*(.68 if b>a else .24)
        self.data={'volume':smooth(old['volume'],level(float(np.sqrt(np.mean(a*a))))),'wave':wave,'trace':trace.tolist(),'envelope':list(self.envelope),'bands':[smooth(x,y) for x,y in zip(old['bands'],bands)],'spectrum':fast.tolist(),'spectrum_slow':slow.tolist(),'spectrum_peak':peak.tolist(),'stereo':[smooth(x,level(float(rms[min(i,len(rms)-1)]))) for i,x in enumerate(old['stereo'])],'bass':smooth(old['bass'],bass),'beat':1. if hit else old['beat']*.82,'rms':float(np.sqrt(np.mean(a*a))),'peak':float(np.max(np.abs(a)))}
        return self.data

@contextmanager
def soundcard_capture(endpoint=None):
    # SoundCard initializes COM in its module constructor on Windows. Import
    # on the fresh capture thread BEFORE our own CoInitializeEx, otherwise
    # its constructor may misinterpret S_FALSE as an error (0x100000001).
    # On subsequent starts the module is cached; our apartment is still
    # required for the new worker thread.
    import soundcard as sc
    with com_apartment():
        speaker=sc.default_speaker() if endpoint is None else next((d for d in sc.all_speakers() if str(d.id)==endpoint),None)
        if speaker is None:raise RuntimeError('既定のスピーカーが見つかりません')
        capture=sc.get_microphone(id=str(speaker.id),include_loopback=True)
        if capture is None:raise RuntimeError('ループバックデバイスが見つかりません')
        with capture.recorder(samplerate=48000,blocksize=1024) as rec:
            yield str(speaker.name),48000,lambda:rec.record(numframes=1024)

@contextmanager
def portaudio_capture(endpoint=None):
    # Alternative Windows WASAPI loopback via PyAudioWPatch. No SoundCard COM
    # wrapper is involved. Use the endpoint's native sample rate/channels.
    import pyaudiowpatch as pa
    import numpy as np
    p=pa.PyAudio(); stream=None
    try:
        info=p.get_default_wasapi_loopback() if endpoint is None else p.get_device_info_by_index(int(endpoint))
        if not info.get('isLoopbackDevice'):raise RuntimeError('WASAPIループバックが見つかりません')
        rate=int(info['defaultSampleRate']); channels=int(info['maxInputChannels'])
        if not 8000<=rate<=384000 or not 1<=channels<=32:raise RuntimeError('音声形式が無効です')
        stream=p.open(format=pa.paInt16,channels=channels,rate=rate,input=True,input_device_index=int(info['index']),frames_per_buffer=1024)
        def read():
            return np.frombuffer(stream.read(1024,exception_on_overflow=False),dtype='<i2').reshape(-1,channels).astype(np.float32)/32768
        yield str(info['name']),rate,read
    finally:
        try:
            if stream is not None:stream.close()
        finally:p.terminate()

def list_outputs():
    devices=[];errors=[]
    try:
        import pyaudiowpatch as pa
        p=pa.PyAudio()
        try:
            for d in p.get_loopback_device_info_generator():
                if d.get('isLoopbackDevice'):
                    devices.append({'id':'pa:'+str(d['index']),'name':str(d['name']),'backend':'PyAudioWPatch'})
        finally:p.terminate()
    except Exception as exc:errors.append('PyAudioWPatch: '+str(exc)[:150])
    try:
        import soundcard as sc
        with com_apartment():
            for d in sc.all_speakers():
                devices.append({'id':'sc:'+str(d.id),'name':str(d.name),'backend':'SoundCard'})
    except Exception as exc:errors.append('SoundCard: '+str(exc)[:150])
    return {'devices':devices,'errors':errors}


def demo_signal(now):
    # Explicit synthetic visual test, not captured audio. No sound playback.
    a=.55+.35*math.sin(now*3)
    return {'volume':a,'wave':[.75*math.sin(i*.6-now*5) for i in range(18)],'trace':[.75*math.sin(i*.18-now*6)+.13*math.sin(i*.46+now*3) for i in range(72)],'envelope':[.08+.77*(.5+.5*math.sin(i*.43-now*7))**2 for i in range(36)],'bands':[.2+.75*(.5+.5*math.sin(i*.5-now*4)) for i in range(18)],'spectrum':[.06+.9*(.5+.5*math.sin(i*.39-now*4))**3 for i in range(48)],'spectrum_slow':[.12+.8*(.5+.5*math.sin(i*.39-now*3.6))**2 for i in range(48)],'spectrum_peak':[.16+.83*(.5+.5*math.sin(i*.39-now*4+.4))**2 for i in range(48)],'stereo':[a,1-a/2],'bass':a,'beat':.5+.5*math.sin(now*4),'rms':0.,'peak':0.}

class AudioMonitor:
    def __init__(self):
        self.enabled=False;self.error='未開始';self.thread=None;self._lock=threading.Lock();self._stop=None;self.data=blank();self.device='';self.frames=0;self.backend='';self.attempts=[];self.last_packet=None;self.rate=0;self.endpoint='default';self.demo_until=0.;self.demo_layer=None;self.signal_frames=0
    def start(self,endpoint='default'):
        with self._lock:
            if self.enabled:return self.endpoint==endpoint
            if not isinstance(endpoint,str) or len(endpoint)>512 or not (endpoint=='default' or endpoint.startswith('sc:') or (endpoint.startswith('pa:') and endpoint[3:].isdigit())):
                self.error='音声出力先が無効です';return False
            if self.thread and self.thread.is_alive():self.error='音声取得の終了処理中です。もう一度お試しください';return False
            self.enabled=True;self.data=blank();self.error='';self.device='';self.frames=0;self.backend='';self.attempts=[];self._stop=threading.Event();self.endpoint=endpoint;self.rate=0;self.last_packet=None;self.signal_frames=0;self.demo_until=0.;self.demo_layer=None
            self.thread=threading.Thread(target=self._run,args=(self._stop,),daemon=True);self.thread.start()
        return True
    def stop(self):
        with self._lock:
            if self._stop:self._stop.set()
            self.enabled=False;self.data=blank();self.demo_until=0.;self.demo_layer=None
    def demo(self,layer_id=None):
        with self._lock:self.demo_until=time.monotonic()+4.;self.demo_layer=layer_id if type(layer_id) is int else None
    def status(self):
        with self._lock:
            now=time.monotonic();age=None if self.last_packet is None else now-self.last_packet
            demo=now<self.demo_until
            stale=age is not None and age>1.5
            actual=self.data if self.enabled and not stale else blank()
            data=demo_signal(now) if demo else actual
            signal='test' if demo else 'off' if not self.enabled else 'waiting' if self.frames==0 else 'stalled' if stale else 'signal' if actual['peak']>.0002 else 'silent'
            return {'enabled':self.enabled,**data,'error':self.error,'device':self.device,'frames':self.frames,'backend':self.backend,'attempts':list(self.attempts),'endpoint':self.endpoint,'rate':self.rate,'packet_age_ms':None if age is None else round(age*1000),'signal_frames':self.signal_frames,'signal':signal,'demo':demo,'demo_layer':self.demo_layer if demo else None,'captured_rms':actual['rms'],'captured_peak':actual['peak']}
    def _run(self,stop):
        try:
            import numpy
            # Prefer the independent WASAPI implementation when installed.
            # Existing installations without PyAudioWPatch work via SoundCard.
            choices=[('WASAPI / PyAudioWPatch',portaudio_capture,'pa'),('WASAPI / SoundCard',soundcard_capture,'sc')]
            if self.endpoint!='default':choices=[c for c in choices if self.endpoint.startswith(c[2]+':')]
            for name,open_capture,prefix in choices:
                if stop.is_set():break
                try:
                    with (open_capture() if self.endpoint=='default' else open_capture(self.endpoint.split(':',1)[1])) as (device,rate,read):
                        with self._lock:self.device=device;self.backend=name;self.error='';self.rate=rate;self.last_packet=None
                        analyzer=AudioAnalyzer(rate)
                        while not stop.is_set():
                            data=analyzer.process(read())
                            with self._lock:
                                if stop.is_set():break
                                self.data=data;self.frames+=1;self.last_packet=time.monotonic();self.signal_frames+=int(data['peak']>.0002)
                    return
                except Exception as exc:
                    if stop.is_set():return
                    with self._lock:
                        self.attempts.append({'backend':name,'error':str(exc)[:180]});self.data=blank();self.backend=''
            if not stop.is_set():
                with self._lock:self.error='音声取得失敗: '+ ' / '.join(a['backend']+': '+a['error'] for a in self.attempts)+'。install_music_backend.bat で再設定できます。'
        except ImportError:
            with self._lock:self.error='音楽連動には install_music_backend.bat が必要です'
        finally:
            with self._lock:self.enabled=False;self.data=blank()
