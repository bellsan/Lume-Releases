"""Local animation worker: no dependence on browser refresh rate or focus."""
import math
import re
import threading
import time
from collections import deque

EFFECTS={'static','ripple','spring','flower','circle','music','aurora','silk','tide','ember','stardust','comet','bloom','prism','orbit','scanner','rain'}
AUDIO={'music','spectrum','waveform','stereo','beat','audio_wave'}
EFFECTS.update(AUDIO)
REACTIVE={'ripple','comet','bloom'}
CODE=re.compile(r'^[A-Za-z0-9]{1,25}$')
HEX=re.compile(r'^#[0-9a-fA-F]{6}$')

def clamp(v,a=0.,b=1.):return min(b,max(a,v))
def number(v,default=0.,a=0.,b=100.):
 if isinstance(v,(int,float)) and not isinstance(v,bool) and math.isfinite(v):return clamp(float(v),a,b)
 return default

def color(v):return tuple(int(v[i:i+2],16) for i in (1,3,5)) if isinstance(v,str) and HEX.fullmatch(v) else (118,243,225)
def mix(a,b,t):return tuple(x*(1-t)+y*t for x,y in zip(a,b))
def palette(colors,t):
 t=clamp(t)*(len(colors)-1);i=min(len(colors)-2,int(t))
 return mix(colors[i],colors[i+1],t-i) if len(colors)>1 else colors[0]
def sample(values,u):
 if not values:return 0.
 pos=clamp(u)*(len(values)-1);i=int(pos)
 return values[i]+(values[min(i+1,len(values)-1)]-values[i])*(pos-i)
def smooth(v):v=clamp(v);return v*v*(3-2*v)
def tinted(c,t):return mix(mix(c,(76,132,244),clamp(math.sin(t)*.25+.20)),(225,251,248),clamp((math.sin(t+1.2)+1)*.18))
def encode(c):return '#'+''.join(f'{round(clamp(v,0,255)):02x}' for v in c)

def validate(obj):
 """Validate bounded scene data supplied by the local editor."""
 if not isinstance(obj,dict):raise ValueError('設定が無効です')
 keys=obj.get('keys');layers=obj.get('layers')
 if not isinstance(keys,list) or not 1<=len(keys)<=180 or not isinstance(layers,list) or not 1<=len(layers)<=8:raise ValueError('キーまたはレイヤー数が無効です')
 positions={}
 for k in keys:
  if not isinstance(k,dict) or not isinstance(k.get('code'),str) or not CODE.fullmatch(k['code']):raise ValueError('キーコードが無効です')
  if k['code'] in positions:raise ValueError('キーコードが重複しています')
  positions[k['code']]=(number(k.get('x'),0,0,30),number(k.get('y'),0,0,10))
 output=[]
 for l in layers:
  if not isinstance(l,dict) or l.get('type') not in EFFECTS:raise ValueError('エフェクトが無効です')
  targets=l.get('targets');targets=frozenset(t for t in targets if isinstance(t,str) and t in positions) if isinstance(targets,list) else frozenset()
  output.append({'id':l.get('id') if type(l.get('id')) is int else None,'type':l['type'],'enabled':bool(l.get('enabled',True)),'color':color(l.get('color')),'brightness':number(l.get('brightness'),95)/100,'speed':.35+number(l.get('speed'),55)/100*2.4,'spread':.5+number(l.get('spread'),60)/100*1.8,'fade':number(l.get('fade'),65)/100,'direction':l.get('direction') if l.get('direction') in ('left','right','radial') else 'radial','blend':l.get('blend') if l.get('blend') in ('normal','add','max','replace') else 'normal','targets':targets,'secondary':color(l.get('secondary','#B79BFF')),'angle':number(l.get('angle'),0,-180,180),'phase':number(l.get('phase'),0)/100,'width':number(l.get('width'),50)/100,'floor':number(l.get('floor'),0)/100,'contrast':number(l.get('contrast'),50)/100,'duration':number(l.get('duration'),36,5,80)/10,'sensitivity':number(l.get('sensitivity'),50)/50,'audio_width':.045+number(l.get('audioWidth'),50)/100*.20,'gradient':tuple(color(v) for v in l.get('gradient',[])[:4] if isinstance(v,str) and HEX.fullmatch(v)) if isinstance(l.get('gradient'),list) else (), 'gradient_mode':l.get('gradientMode') if l.get('gradientMode') in ('linear','radial') else 'linear','gradient_angle':number(l.get('gradientAngle'),0,-180,180),'wave_gain':.25+number(l.get('waveGain'),50)/40,'wave_mirror':l.get('waveMirror') is not False,'bars':number(l.get('bars'),18,4,24),'bar_range':number(l.get('barRange'),54,24,78),'bar_tilt':number(l.get('barTilt'),0,-100,100)/100,'bar_response':l.get('barResponse') if l.get('barResponse') in ('balanced','fast','smooth') else 'balanced','bar_peak_color':color(l.get('barPeakColor','#E1F6FF')),'bar_height':number(l.get('barHeight'),100,25,180)/100,'bar_width':number(l.get('barWidth'),100,20,100)/100,'bar_smoothing':number(l.get('barSmooth'),30)/100,'bar_gate':number(l.get('barGate'),5,0,80)/100,'bar_origin':l.get('barOrigin') if l.get('barOrigin') in ('bottom','top','center') else 'bottom','bar_shape':l.get('barShape') if l.get('barShape') in ('blocks','soft','outline','dot') else 'blocks','bar_color':l.get('barColor') if l.get('barColor') in ('height','frequency') else 'height','bar_peak':l.get('barPeak') is True,'freq_low':number(l.get('freqLow'),0,0,95)/100,'freq_high':number(l.get('freqHigh'),100,5,100)/100,'bar_reverse':l.get('barReverse') is True,'bar_main':l.get('barMain') is True,'bar_black':l.get('barBlack') is True,'pulse_shape':l.get('pulseShape') if l.get('pulseShape') in ('circle','diamond','square','horizontal','vertical') else 'circle','aspect':number(l.get('aspect'),100,25,200)/100,'origin_x':number(l.get('originX'),50)/100,'origin_y':number(l.get('originY'),50)/100,'petals':number(l.get('petals'),6,2,12),'trail':number(l.get('motionTrail'),45)/100,'orbit_heads':round(number(l.get('orbitHeads'),2,1,3)),'rain_density':number(l.get('rainDensity'),55)/100,'scan_mode':l.get('scanMode') if l.get('scanMode') in ('bounce','loop') else 'bounce','curve':l.get('motionCurve') if l.get('motionCurve') in ('natural','linear','soft','sharp') else 'natural'})
 overrides=obj.get('keyColors');overrides={k:color(v) for k,v in overrides.items() if k in positions and isinstance(v,str) and HEX.fullmatch(v)} if isinstance(overrides,dict) else {}
 return positions,output,overrides,obj.get('fixedColorMode')!='fixed',obj.get('reactivePriority') is not False

def spectrum_pixel(l,a,u,v):
 """Discrete LED bars with continuous edge option; no imaginary sub-key LEDs."""
 count=round(l['bars']);q=clamp(u)*(count-1);col=math.floor(q+.5);f=col/max(1,count-1)
 lo=min(l['freq_low'],l['freq_high']);hi=max(l['freq_low'],l['freq_high']);f=lo+(hi-lo)*f
 dense=a.get('spectrum') or a.get('bands') or [0.];slow=a.get('spectrum_slow') or dense
 response=0 if l['bar_response']=='fast' else 1 if l['bar_response']=='smooth' else l['bar_smoothing']
 def shape_amp(v):return 0. if v<=0 else clamp(1+(v-1)*54/l['bar_range']+l['bar_tilt']*(f-.5)*.8)
 h=shape_amp(mix((sample(dense,f),),(sample(slow,f),),response)[0])
 h=clamp((h-l['bar_gate'])/max(.01,1-l['bar_gate'])*l['sensitivity']*l['bar_height'])
 # v is top=0, bottom=1; key centers land on 6 LED levels.
 edge=1-v if l['bar_origin']=='bottom' else v if l['bar_origin']=='top' else abs(v-.5)*2
 steps=6 if l['bar_origin']!='center' else 3
 z=edge*(steps-1)+.5;level=h*steps
 body=clamp(level-z+.5) if l['bar_shape']=='soft' else float(level>=z)
 if l['bar_shape']=='outline':body=float(h>.01 and (abs(level-z)<.55 or (level>=z and (abs(q-col)>.32 or z<1))))
 if l['bar_shape']=='dot':body=float(abs(level-z)<.5 and h>.01)
 mask=1. if l['bar_width']>=.999 else smooth((l['bar_width']*.5-abs(q-col)+.12)/.12)
 body*=mask
 pk=clamp((shape_amp(sample(a.get('spectrum_peak') or dense,f))-l['bar_gate'])/max(.01,1-l['bar_gate'])*l['sensitivity']*l['bar_height'])
 colors=l['gradient'] or (l['color'],l['secondary']);color_t=edge if l['bar_color']=='height' else f
 c=palette(colors,color_t)
 if l['bar_peak'] and pk>.04 and abs(pk*steps-z)<.52 and mask>.15:
  body=max(body,mask*.86);c=mix(c,l['bar_peak_color'],.62)
 return body,c

def motion_pixel(l,x,y,t,bounds):
 """Three distinct spatial models, mirrored by the browser renderer.
 Positions use physical key units, not a square virtual LED array.
 """
 x0,x1,y0,y1=bounds;dx=max(.1,x1-x0);dy=max(.1,y1-y0)
 direction=-1 if l['direction']=='left' else 1
 z=t*l['speed'];phase=l['phase'];w=l['width'];spread=clamp((l['spread']-.5)/1.8);trail=l['trail']
 theta=math.radians(l['angle']);co=math.cos(theta);si=math.sin(theta);c=l['color'];accent=l['secondary']
 if l['type']=='orbit':
  # Ellipse fits the physical TKL key field. Moving heads and trailing arcs,
  # not a full ring with a sinusoidal brightness modulation.
  cx=x0+dx*l['origin_x'];cy=y0+dy*l['origin_y'];radius=.38+.55*spread
  rx=max(.7,dx*.5*radius*l['aspect']);ry=max(.7,dy*.5*radius)
  px=(x-cx)/rx;py=(y-cy)/ry
  # Rotate the ellipse in normalized space, preserving keyboard aspect.
  u=px*co+py*si;v=-px*si+py*co
  angle=math.atan2(v,u);r=math.hypot(u,v)
  thickness=.12+.38*w;ring=math.exp(-((r-1)/thickness)**2)
  power=0.;hot=0.;head_angle=direction*(z*.85+phase*math.tau)
  for i in range(l['orbit_heads']):
   d=(direction*(head_angle+i*math.tau/l['orbit_heads']-angle)+math.pi)%math.tau-math.pi
   head=math.exp(-(d/(.18+.50*w))**2)
   tail=math.exp(-d/(.10+trail*1.4))*smooth((2.7-d)/.6) if d>0 and trail>0 else 0.
   power=max(power,head,tail*.68);hot=max(hot,head)
  return ring*power,mix(c,accent,hot)
 if l['type']=='scanner':
  # A continuous straight band across the full projected keyboard bounds.
  u=(x-(x0+x1)/2)*co+(y-(y0+y1)/2)*si
  half=max(.1,(abs(co)*dx+abs(si)*dy)/2);width=.38+1.55*w
  distance=(half+width*1.8)*(.45+.55*spread)
  progress=z*.20+phase
  if l['scan_mode']=='loop':
   center=direction*distance*(2*(progress%1)-1);travel=direction
  else:
   center=-direction*distance*math.cos(math.tau*progress);travel=direction*(1 if math.sin(math.tau*progress)>=0 else -1)
  signed=(center-u)*travel;head=math.exp(-((u-center)/width)**2)
  tail=math.exp(-signed/(.25+trail*4.5))*.58 if signed>0 and trail>0 else 0.
  if l['scan_mode']=='loop':
   p=progress%1;seam=smooth(min(p,1-p)/.055);head*=seam;tail*=seam
  else:tail*=smooth(abs(math.sin(math.tau*progress))/.22)
  return max(head,tail),mix(c,accent,head)
 # Independent falling particles: fixed lanes, deterministic density,
 # individual drop rates, staggered starts, bright heads and upward trails.
 # At angle 0 gravity points down; angle rotates the falling direction.
 u=(x-x0)*co+(y-y0)*si;v=-(x-x0)*si+(y-y0)*co
 # Determine projection bounds from the four corners, including diagonals.
 vv=[0,-dx*si,dy*co,-dx*si+dy*co];low=min(vv);high=max(vv);v=v-low
 if direction<0:v=high-low-v
 spacing=.85+(1-spread)*.9;lane=math.floor(u/spacing+.5)
 def seed(i,k):return ((i*137+k*191+97)%997)/997
 # Stable distribution; a changing cycle selects new drops per lane.
 rate=1.5+seed(lane,1)*2.1;length=max(1.,high-low);tail_len=.25+trail*3.1
 age=z*rate+seed(lane,2)*(length+4)+phase*(length+4);period=length+2+tail_len
 cycle=math.floor(age/period);head=(age%period)-1
 if seed(lane+cycle*31,3)>.22+.78*l['rain_density']:return 0.,c
 off=abs(u-lane*spacing);horizontal=math.exp(-(off/(.22+.65*w))**2)
 dist=head-v;hot=math.exp(-(dist/(.24+.58*w))**2)
 wake=math.exp(-dist/max(.1,tail_len))*.65 if dist>0 and trail>0 else 0.
 envelope=smooth(min(age%period,period-age%period)/.55)
 return horizontal*max(hot,wake)*envelope,mix(c,accent,hot)

def render(scene,pulses,t,volume=0.):
 positions,layers,overrides,reactive_fixed,priority=scene;out={}
 audio=volume if isinstance(volume,dict) else {'volume':volume}
 volume=audio.get('volume',0.)
 x0=min(x for x,y in positions.values());x1=max(x for x,y in positions.values());y0=min(y for x,y in positions.values());y1=max(y for x,y in positions.values())
 top=min((y for cc,(x,y) in positions.items() if cc not in ('BoardLogo','LightButton','GameMode')),default=y0)
 demo_layer=audio.get('demo_layer') if audio.get('demo') else None
 demo_selected=next((l for l in layers if demo_layer is not None and l['id']==demo_layer and l['type'] in AUDIO and l['enabled']),None)
 ordered=[demo_selected] if demo_selected is not None else list(reversed(layers))
 if priority:ordered.sort(key=lambda l:l['type'] in REACTIVE or l['type'] in AUDIO)
 for code,(x,y) in positions.items():
  fixed=None if demo_selected is not None else overrides.get(code);composite=fixed if fixed is not None else (0.,0.,0.)
  for l in ordered:
   if not l['enabled'] or l['targets'] and code not in l['targets']:continue
   kind=l['type']
   if fixed is not None and (not reactive_fixed or kind not in REACTIVE|AUDIO):continue
   c=l['color'];speed=l['speed'];spread=l['spread'];fade=l['fade'];direction=-1 if l['direction']=='left' else 1
   if kind in ('static','prism'):
    power=1.
    colors=l['gradient'] or (c,l['secondary']) if kind=='prism' else l['gradient']
    if len(colors)>1:
     u=clamp((x-x0)/max(.1,x1-x0));v=clamp((y-y0)/max(.1,y1-y0));theta=math.radians(l['gradient_angle']);a=math.cos(theta);b=math.sin(theta)
     pos=clamp(.5+((u-.5)*a+(v-.5)*b)/max(.001,abs(a)+abs(b))) if l['gradient_mode']=='linear' else clamp(math.hypot(u-.5,v-.5)*math.sqrt(2))
     if kind=='prism':pos=.5+.5*math.sin(pos*math.tau/spread-t*speed*direction)
     c=palette(colors,pos)
   elif kind in REACTIVE:
    power=0.
    for px,py,start in pulses:
     age=t-start
     if not 0<=age<=l['duration']:continue
     dx=(x-px)/l['aspect'];dy=y-py;shape=l['pulse_shape'] if kind=='ripple' else 'circle';d=abs(dx)+abs(dy) if shape=='diamond' else max(abs(dx),abs(dy)) if shape=='square' else abs(dy) if shape=='horizontal' else abs(dx) if shape=='vertical' else math.hypot(dx,dy);radius=age*(1.8+speed*1.9)*spread
     width=(.9+fade*1.5)*(.45+l['width']*1.1)
     # Soft front with immediate origin flash. Avoid permanent idle glow.
     ring=math.exp(-((d-radius)/width)**2*1.4)
     decay=math.exp(-age*(.55+(1-fade)*1.2))*smooth((l['duration']-age)/.65)
     if kind=='bloom':ring=math.exp(-(d/(.5+age*speed*spread))**2)*smooth((l['duration']-age)/l['duration'])
     elif kind=='comet':
      dx=x-px;dy=y-py;theta=math.radians(l['angle']);a=(dx*math.cos(theta)+dy*math.sin(theta))*direction;cross=-dx*math.sin(theta)+dy*math.cos(theta);ring=math.exp(-((a-radius)/width)**2- (cross/(.75+spread*.45))**2)*.9+math.exp(-(d/.6)**2)*math.exp(-age*6)*.35
     power=1-(1-power)*(1-clamp(ring*decay))
    power=clamp(power)
   elif kind=='spring':
    theta=math.radians(l['angle']);cx=9+(l['origin_x']-.5)*(x1-x0);cy=2.7+(l['origin_y']-.5)*(y1-y0)
    axis=math.hypot((x-cx)/l['aspect'],y-cy) if l['direction']=='radial' else (x*math.cos(theta)+y*math.sin(theta))*direction
    power=.31+.66*smooth((math.sin(axis*.57/spread-t*speed*2.1+l['phase']*math.tau)+1)/2);c=tinted(c,axis*.42-t*speed*.7)
   elif kind=='flower':
    dx=(x-9-(l['origin_x']-.5)*(x1-x0))/l['aspect'];dy=(y-2.45-(l['origin_y']-.5)*(y1-y0))*2.9;a=math.atan2(dy,dx)+math.radians(l['angle']);r=math.hypot(dx,dy)
    power=(.16+.82*smooth((math.sin(a*l['petals']-t*speed*.86+r*.34/spread+l['phase']*math.tau)+1)/2))*(.65+.35*smooth((math.cos(r*.48-t*speed)+1)/2));c=tinted(c,a*2+t)
   elif kind=='circle':
    r=math.hypot((x-9-(l['origin_x']-.5)*(x1-x0))/l['aspect'],(y-2.5-(l['origin_y']-.5)*(y1-y0))*2.8);power=.09+.9*smooth((math.sin(r*1.16/spread-t*speed*1.8*direction+l['phase']*math.tau)+.72)/1.65);c=tinted(c,r*.5-t*speed*.8)
   elif kind in ('aurora','silk','tide','ember','stardust'):
    theta=math.radians(l['angle']);u=(x-9)*math.cos(theta)+(y-3)*math.sin(theta);v=-(x-9)*math.sin(theta)+(y-3)*math.cos(theta);z=t*speed*direction+l['phase']*math.tau;f=u/spread;w=.35+l['width']*1.3
    if kind=='aurora':
     a=math.sin(f*.53+math.sin(v*.8+z*.48)*1.25-z*.7);b=math.sin(f*.24+v*.65+z*.35);power=.16+.84*smooth((a+b*.42+1.42)/2.84);c=mix(c,l['secondary'],smooth((b+1)/2))
    elif kind=='silk':
     a=math.sin(f*.85+math.sin(v*.68-z*.43)*1.45-z);power=.12+.88*math.exp(-(a/(.35+w*.45))**2);c=mix(c,l['secondary'],smooth((math.sin(f*.28+z*.33)+1)/2))
    elif kind=='tide':
     a=math.sin(f*.45-z*.7+math.sin(v*.8+z*.35)*.85);b=math.sin(f*.23+z*.44-v*.45);power=.15+.85*smooth((a+b*.65+1.65)/3.3);c=mix(c,l['secondary'],smooth((a+1)/2))
    elif kind=='ember':
     a=math.sin(f*.72+v*.91-z*.8);b=math.sin(f*1.13-v*.5+z*.49);power=.05+.95*smooth((a+b+2)/4)**2;c=mix(c,l['secondary'],power)
    else:
     seed=math.sin(x*127.1+y*311.7)*43758.5453;seed-=math.floor(seed);a=(math.sin(z*(.45+seed*.7)+seed*math.tau)+1)/2;power=.07+.93*a**(3.5/w);c=mix(c,l['secondary'],seed)
   elif kind in ('orbit','scanner','rain'):
    power,c=motion_pixel(l,x,y,t,(x0,x1,top,y1))
   elif kind in AUDIO:
    u=clamp((x-x0)/max(.1,x1-x0));v=clamp((y-y0)/max(.1,y1-y0));u=1-u if direction<0 else u
    gain=l['sensitivity'];width=l['audio_width'];idx=min(17,int(u*18));power=0.
    if kind=='music':power=clamp(volume*gain);c=mix(c,l['secondary'],clamp(audio.get('bass',0)*gain))
    elif kind=='spectrum':
     if l['bar_black'] and code not in ('BoardLogo','LightButton','GameMode') and (not l['bar_main'] or x<15.45):composite=(0.,0.,0.)
     if code in ('BoardLogo','LightButton','GameMode') or (l['bar_main'] and x>=15.45):power=0.
     else:
      # Header accessory y=0 is excluded from spectrum height.
      su=clamp((x-x0)/max(.1,(15 if l['bar_main'] else x1)-x0));sv=clamp((y-top)/max(.1,y1-top))
      power,c=spectrum_pixel(l,audio,1-su if l['bar_reverse'] else su,sv)
    elif kind=='waveform':
     wave=audio.get('trace') or audio.get('wave',[0.]*18);value=clamp(sample(wave,u)*gain*l['wave_gain'],-1,1);center=.5-.45*value
     power=math.exp(-((v-center)/max(.09,width))**2)*clamp(volume*gain*5);c=mix(c,l['secondary'],abs(value))
    elif kind=='audio_wave':
     values=audio.get('envelope') or [abs(z) for z in audio.get('wave',[0.]*18)];amp=1-math.exp(-max(0,sample(values,u))*gain*l['wave_gain']*2);edge=abs(v-.5)*2 if l['wave_mirror'] else 1-v
     power=smooth((amp-edge+width)*5)*clamp(amp*8)*clamp(volume*gain*5);c=mix(c,l['secondary'],clamp(edge))
    elif kind=='stereo':
     levels=audio.get('stereo',[0.,0.]);h=clamp(levels[0 if u<.5 else 1]*gain);power=smooth((h-abs(u-.5)*2+.08)*7)*min(1,h*5);c=mix(c,l['secondary'],u)
    elif kind=='beat':
     beat=clamp(audio.get('beat',0)*gain);radius=1-beat;dist=math.hypot((u-.5)*1.8,v-.5);power=beat*math.exp(-((dist-radius)/width)**2*3)+clamp(audio.get('bass',0)*gain)*.12;c=mix(c,l['secondary'],beat)
   if kind not in AUDIO and kind!='static':
    power=clamp(power);power=smooth(power) if l['curve']=='soft' else power**2.2 if l['curve']=='sharp' else math.sqrt(power) if l['curve']=='linear' else power
   if kind not in ('static','prism','spectrum') and len(l['gradient'])>1:c=palette(l['gradient'],clamp(power))
   if kind!='static':power=(l['floor']+(1-l['floor'])*clamp(power)**(2**((l['contrast']-.5)*2))) if kind not in REACTIVE else clamp(power)**(2**((l['contrast']-.5)*2))
   strength=clamp(power*l['brightness']);blend='normal' if fixed is not None or (priority and kind in REACTIVE|AUDIO) else l['blend']
   if blend=='add':composite=tuple(min(255,v+w*strength) for v,w in zip(composite,c))
   elif blend=='max':composite=tuple(max(v,w*strength) for v,w in zip(composite,c))
   elif blend=='replace' and strength>0:composite=mix((0,0,0),c,strength)
   else:composite=mix(composite,c,strength)
  out[code]=encode(composite)
 return out

MOTION_PROFILES={"responsive":(.006,.018),"balanced":(.014,.045),"smooth":(.034,.085)}
def filter_frame(frame,memory,dt,profile="balanced"):
 # Time-based attack/release, independent of render frequency.
 attack,release=MOTION_PROFILES.get(profile,MOTION_PROFILES["balanced"])
 dt=clamp(dt,0,.25);up=-math.expm1(-dt/attack);down=-math.expm1(-dt/release)
 out={}
 for code,hx in frame.items():
  target=color(hx);prev=memory.get(code,target)
  a=up if max(target)>=max(prev) else down
  current=tuple(v+(w-v)*a for v,w in zip(prev,target))
  current=tuple(w if abs(v-w)<.65 else v for v,w in zip(current,target))
  memory[code]=current;out[code]=encode(current)
 for code in tuple(memory):
  if code not in frame:del memory[code]
 return out

def crossfade_frame(source,target,progress):
 weight=smooth(progress)
 return {key:encode(mix(color(source.get(key,'#000000')),color(value),weight)) for key,value in target.items()}

class AnimationEngine:
 def __init__(self,backend,keys,audio):
  self.backend=backend;self.keys=keys;self.audio=audio;self.lock=threading.RLock();self.scene=None;self.active=False;self.running=True;self.alive=True;self.pulses=deque(maxlen=48);self.seq=0;self.pulse_count=0;self.frames=0;self.error='';self.last_frame=None;self.unmasked_frame=None;self.filtered={};self.raw_frame=None;self.scene_dirty=True;self.motion_profile="balanced";self.last_tick=0.;self.transition=None;self.transition_id=None;self.epoch=time.monotonic();self.thread=threading.Thread(target=self._loop,daemon=True);self.thread.start()
 def configure(self,obj):
  scene=validate(obj)
  with self.lock:
   if self.scene is None or self.scene[0]!=scene[0]:self.pulses.clear();self.filtered.clear();self.transition=None
   tr=obj.get('transition')
   if isinstance(tr,dict) and isinstance(tr.get('id'),str) and len(tr['id'])<=80 and tr['id']!=self.transition_id:
    self.transition_id=tr['id'];ms=number(tr.get('ms'),0,0,2000)
    if self.active and self.last_frame and ms and self.scene and self.scene[0]==scene[0]:self.transition=(dict(self.unmasked_frame or self.last_frame),time.monotonic(),ms/1000)
    else:self.transition=None
   self.scene=scene;self.running=bool(obj.get('running',True));self.scene_dirty=True;self.motion_profile=obj.get('motionProfile') if isinstance(obj.get('motionProfile'),str) and obj.get('motionProfile') in MOTION_PROFILES else 'balanced';self.last_frame=None
  return True
 def enable(self,on):
  with self.lock:
   if on and (self.scene is None or self.backend.device is None):raise ValueError('先にキーボードに接続してください')
   if on and self.active:return
   self.active=bool(on);self.transition=None;self.last_frame=None;self.unmasked_frame=None;self.pulses.clear();self.filtered.clear();self.raw_frame=None;self.scene_dirty=True;self.last_tick=0.;self.seq=self.keys.since(0)['seq'];self.error=''
   if not on:self.backend.clear_pending()
 def pulse(self,code,now=None):
  with self.lock:
   if not self.active or self.scene is None:return False
   # JIS has Fn in the right-Alt position; only alias when that physical
   # position has no AltRight key. Firmware-only Fn cannot be inferred.
   if code=='AltRight' and 'AltRight' not in self.scene[0] and 'Fn' in self.scene[0]:code='Fn'
   if code not in self.scene[0]:return False
   x,y=self.scene[0][code];self.pulses.append((x,y,time.monotonic() if now is None else now));self.pulse_count+=1;return True
 def status(self):
  with self.lock:return {'active':self.active,'running':self.running,'frames':self.frames,'pulses':self.pulse_count,'error':self.error,'audio_layers':sum(l['enabled'] and l['type'] in AUDIO for l in self.scene[1]) if self.scene else 0,'motion_profile':self.motion_profile,'target_fps':60,'lit_keys':sum(v!='#000000' for v in self.last_frame.values()) if self.last_frame else 0}
 def close(self):
  self.enable(False);self.alive=False;self.thread.join(timeout=1)
 def _loop(self):
  while self.alive:
   start=time.monotonic()
   try:
    with self.lock:
     if self.active and self.scene is not None:
      d=self.keys.since(self.seq);self.seq=d['seq']
      for e in d['events']:
       if start-e.get('at',start)<.45:self.pulse(e['code'],e.get('at',start))
      while self.pulses and start-self.pulses[0][2]>8:self.pulses.popleft()
      if self.backend.device is None:self.active=False
      elif self.running:
       layers=[l for l in self.scene[1] if l['enabled']]
       has_audio=any(l['type'] in AUDIO for l in layers)
       duration=max((l['duration'] for l in layers if l['type'] in REACTIVE),default=0.)
       has_pulse=duration>0 and any(0<=start-p[2]<=duration for p in self.pulses)
       animated=has_audio or has_pulse or any(l['type'] not in REACTIVE and l['type']!='static' for l in layers)
       if self.scene_dirty or self.raw_frame is None or animated or getattr(self,'was_animated',False):
        self.raw_frame=render(self.scene,tuple(self.pulses),start,self.audio.status() if has_audio else 0.)
        self.scene_dirty=False
       self.was_animated=animated
       frame=self.raw_frame
       dt=min(.25,max(.001,start-self.last_tick)) if self.last_tick else 1/60;self.last_tick=start
       if self.transition:
        source,began,duration=self.transition;progress=(start-began)/duration
        if progress>=1:self.transition=None
        else:frame=crossfade_frame(source,frame,progress)
       if self.transition or self.unmasked_frame!=frame or any(self.filtered.get(k)!=color(v) for k,v in frame.items()):
        frame=filter_frame(frame,self.filtered,dt,self.motion_profile)
       self.unmasked_frame=frame
      if self.backend.device is not None and self.unmasked_frame is not None:
       gate=getattr(self.keys,"game",None);frame=gate.mask(self.unmasked_frame) if gate else self.unmasked_frame
       if frame!=self.last_frame:self.backend.queue_frame(frame);self.last_frame=frame;self.frames+=1
      self.error=''
   except Exception as e:
    with self.lock:self.error=str(e)[:180];self.active=False;self.backend.clear_pending()
   time.sleep(max(.001,1/60-(time.monotonic()-start)))
