"""Frozen Windows executable update. The old EXE remains recoverable until replacement succeeds."""
from __future__ import annotations
import base64
import ctypes
import hashlib
import json
import os
from pathlib import Path
import re
import struct
import subprocess
import sys


def validate_pe(path):
    """Reject non-PE and non-x64 executables before staging."""
    with Path(path).open('rb') as f:
        head=f.read(64)
        if len(head)!=64 or head[:2]!=b'MZ':raise ValueError('Invalid Windows executable')
        off=struct.unpack_from('<I',head,60)[0]
        if not 64<=off<=1024*1024:raise ValueError('Invalid PE header')
        f.seek(off);pe=f.read(26)
        if len(pe)!=26 or pe[:4]!=b'PE\0\0' or struct.unpack_from('<H',pe,4)[0]!=0x8664 or struct.unpack_from('<H',pe,24)[0]!=0x20b:
            raise ValueError('Expected Windows x64 executable')


def external_environment():
    env=dict(os.environ)
    # PyInstaller changes the DLL lookup path; avoid leaking it to Edge/PowerShell.
    if sys.platform=='win32' and getattr(sys,'frozen',False):
        ctypes.windll.kernel32.SetDllDirectoryW(None)
        env['PYINSTALLER_RESET_ENVIRONMENT']='1'
    return env


def restart_current(port):
    return subprocess.Popen([sys.executable,'--port',str(int(port)),'--no-browser'],cwd=str(Path(sys.executable).parent),env=external_environment(),creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))


# No untrusted text is interpolated as script code: configuration is base64 JSON.
SCRIPT=r'''
$ErrorActionPreference = 'Stop'
$c = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('__CONFIG__')) | ConvertFrom-Json
$target = [string]$c.target
$source = [string]$c.source
$backup = [string]$c.backup
$marker = [string]$c.marker
$swapped = $false
try {
    if ((Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash.ToLowerInvariant() -ne $c.digest) { throw 'SHA-256 mismatch' }
    # The PyInstaller bootloader may retain its image handle after the Python child exits.
    $until = [DateTime]::UtcNow.AddSeconds(45)
    while (-not $swapped) {
        try { [IO.File]::Replace($source,$target,$backup,$true); $swapped = $true }
        catch [IO.IOException] { if ([DateTime]::UtcNow -ge $until) { throw }; Start-Sleep -Milliseconds 300 }
        catch [UnauthorizedAccessException] { if ([DateTime]::UtcNow -ge $until) { throw }; Start-Sleep -Milliseconds 300 }
    }
    if ((Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash.ToLowerInvariant() -ne $c.digest) { throw 'Installed executable hash mismatch' }
    $env:PYINSTALLER_RESET_ENVIRONMENT = '1'
    $null = Start-Process -FilePath $target -ArgumentList @('--port',[string]$c.port,'--no-browser') -WorkingDirectory ([IO.Path]::GetDirectoryName($target)) -PassThru
    Remove-Item -LiteralPath $marker -Force -ErrorAction SilentlyContinue
} catch {
    $failure = $_.Exception.Message
    if ($swapped -and [IO.File]::Exists($backup)) {
        try { [IO.File]::Replace($backup,$target,$null,$true) } catch { $failure += '; rollback: ' + $_.Exception.Message }
    }
    [IO.File]::WriteAllText($marker,$failure,[Text.UTF8Encoding]::new($false))
    if ([IO.File]::Exists($target)) {
        $env:PYINSTALLER_RESET_ENVIRONMENT = '1'
        Start-Process -FilePath $target -ArgumentList @('--port',[string]$c.port,'--no-browser') -WorkingDirectory ([IO.Path]::GetDirectoryName($target))
    }
} finally {
    Remove-Item -LiteralPath ([string]$c.work) -Recurse -Force -ErrorAction SilentlyContinue
}
'''


def launch_update(updater,port):
    if sys.platform!='win32' or not getattr(sys,'frozen',False) or not updater.pending:raise RuntimeError('Not a frozen Windows update')
    target=Path(sys.executable).resolve();stage=Path(updater.stage).resolve();candidate=stage/'LumePro.exe'
    if stage.parent.parent!=target.parent or not stage.parent.name.startswith('.lume-update-'):raise ValueError('Invalid update staging directory')
    digest=(stage/'sha256.txt').read_text('ascii').strip()
    if not re.fullmatch('[0-9a-f]{64}',digest):raise ValueError('Invalid digest')
    validate_pe(candidate)
    with candidate.open('rb') as f:
        h=hashlib.sha256()
        for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
    if h.hexdigest()!=digest:raise ValueError('Staged executable SHA-256 mismatch')
    backup=target.with_name(target.name+'.previous')
    # A previous successful update may have left a backup. Keep a uniquely named new backup.
    backup=target.with_name(target.name+'.previous-'+stage.parent.name.rsplit('-',1)[-1])
    config=dict(target=str(target),source=str(candidate),backup=str(backup),marker=str(updater.data/'exe_update_error.txt'),work=str(stage.parent),port=int(port),digest=digest)
    script=SCRIPT.replace('__CONFIG__',base64.b64encode(json.dumps(config).encode('utf-8')).decode('ascii'))
    ps=Path(os.environ.get('SystemRoot',r'C:\Windows'))/'System32'/'WindowsPowerShell'/'v1.0'/'powershell.exe'
    updater.cache.pop('install_error',None);updater._save()
    return subprocess.Popen([str(ps),'-NoProfile','-NonInteractive','-EncodedCommand',base64.b64encode(script.encode('utf-16le')).decode('ascii')],cwd=str(target.parent),env=external_environment(),creationflags=subprocess.CREATE_NO_WINDOW|subprocess.DETACHED_PROCESS,stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
