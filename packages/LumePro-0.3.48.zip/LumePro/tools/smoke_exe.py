"""Start the frozen EXE in a clean profile; test static resources and authenticated API."""
import json, os, socket, subprocess, sys, tempfile, time, urllib.request
from pathlib import Path
exe=Path(sys.argv[1]).resolve();version=sys.argv[2]
with tempfile.TemporaryDirectory(prefix='lume-smoke-') as temp:
    env=dict(os.environ,LOCALAPPDATA=temp)
    subprocess.run([str(exe),'--self-test'],env=env,check=True,timeout=120)
    with socket.socket() as s:s.bind(('127.0.0.1',0));port=s.getsockname()[1]
    base=f'http://127.0.0.1:{port}'
    def get(path, headers=None):
        with urllib.request.urlopen(urllib.request.Request(base+path,headers=headers or {}),timeout=3) as r:return r.read()
    proc=subprocess.Popen([str(exe),'--no-browser','--port',str(port)],env=env)
    try:
        end=time.monotonic()+90
        while True:
            try:status=json.loads(get('/api/update/status'));break
            except (OSError,ValueError):
                if proc.poll() is not None or time.monotonic()>end:raise RuntimeError('Frozen server failed to start')
                time.sleep(.5)
        assert status['current']==version,status
        assert b'LUME / PRO' in get('/')
        assert get('/favicon.ico')[:4]==b'\0\0\1\0'
        assert len(get('/app.js'))>10000
        token=json.loads(get('/api/token',{'X-Lume-Bootstrap':'1'}))['token']
        headers={'X-Lume-Token':token}
        assert json.loads(get('/api/update/status',headers))['frozen'] is True
        assert 'presets' in json.loads(get('/api/presets',headers))
        with urllib.request.urlopen(urllib.request.Request(base+'/api/shutdown',data=b'{}',headers={**headers,'Content-Type':'application/json'}),timeout=5) as r:assert json.loads(r.read())['ok']
        assert proc.wait(timeout=30)==0
    finally:
        if proc.poll() is None:proc.kill();proc.wait()
print('Windows EXE startup, resources, API and shutdown passed')
