import json
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'app'))
from updater import Updater, read_metadata

def test_public_channel_and_migration_preserves_auto_optout(tmp_path):
    root=Path(__file__).resolve().parents[1]
    meta=read_metadata(root)
    assert meta=={'version':'0.3.43','repository':'bellsan/Lume-Releases','private':False}
    (tmp_path/'update_state.json').write_text(json.dumps({'repo':'bellsan/Lume','auto':False,'notified':'0.3.21','last_attempt':123,'release':{'tag_name':'v0.3.21'}}))
    m=Updater(root,tmp_path)
    assert not m.status()['auto']
    assert not m.status()['available']
    assert m.cache.get('notified') is None
    assert m.check()['phase']=='idle'
