# LUME / PRO v0.3.43

- 標準プリセットを GLACIER / VELVET / NEBULA / MONOCHROME / DUSK / ABYSS / SOLARIS / SAKURA / AURORA / GHOST の10種類へ変更。
- シグネチャー背景とキー反応を独立した2レイヤーにし、ブラウザーと実機向けPythonエンジンの両方に同じ計算を追加。
- 既存のユーザー保存プリセット、従来エフェクト、UI、更新設定は維持。
- 参考デモの配色・発光式を実際のキー座標へ適合。実機のLEDの色・光量はハードウェア依存。
