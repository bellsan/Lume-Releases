"""Check rendered menu geometry, legends, lasso gestures and optical channel isolation."""
import asyncio, os
from pathlib import Path
from playwright.async_api import async_playwright
from ui_preset_menu import setup
ROOT=Path(__file__).resolve().parents[1]
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(headless=True,executable_path=os.environ.get('CHROMIUM_PATH','/usr/bin/chromium'),args=['--no-sandbox'])
  page,errors=await setup(browser,{f:(ROOT/'app'/f).read_text() for f in ('index.html','style.css','app.js')})
  await page.evaluate('setInspector(false,false)');await page.wait_for_timeout(400)
  for width,height in [(1260,800),(900,600)]:
   await page.set_viewport_size({'width':width,'height':height});await page.wait_for_timeout(250)
   await page.locator('#groupsToggle').click();await page.wait_for_timeout(380)
   metrics=await page.evaluate('''()=>{const r=s=>document.querySelector(s).getBoundingClientRect(),m=r('#groupsMenu'),b=r('#groupsToggle'),last=r('#groupsMenu [data-group=letters]');return {gap:m.top-b.bottom,alignment:m.right-b.right,bottom:m.bottom-last.bottom,height:m.height}}''')
   print(width,'selection menu',metrics,flush=True);assert 3<=metrics['gap']<=12;assert abs(metrics['alignment'])<3;assert 5<=metrics['bottom']<=15;assert metrics['height']<250
   await page.screenshot(path=f'/mnt/data/LumePro_v0.3.39_menu_{width}.png');await page.locator('#lassoMenuBtn').click();await page.wait_for_timeout(150)
   async def enclose(codes,modifier=None):
    rect=await page.evaluate('''codes=>{const boxes=codes.map(c=>document.querySelector('#keyboard [data-code="'+c+'"]').getBoundingClientRect());return {x:Math.min(...boxes.map(b=>b.left+b.width*.25)),y:Math.min(...boxes.map(b=>b.top+b.height*.25)),r:Math.max(...boxes.map(b=>b.right-b.width*.25)),b:Math.max(...boxes.map(b=>b.bottom-b.height*.25))}}''',codes)
    if modifier:await page.keyboard.down(modifier)
    await page.mouse.move(rect['x'],rect['y']);await page.mouse.down();await page.mouse.move(rect['r'],rect['y'],steps=10);await page.mouse.move(rect['r'],rect['b'],steps=8);await page.mouse.move(rect['x'],rect['b'],steps=10);await page.mouse.move(rect['x'],rect['y'],steps=8);await page.wait_for_timeout(100);await page.mouse.up()
    if modifier:await page.keyboard.up(modifier)
    await page.wait_for_timeout(100)
   await enclose(['KeyA','KeyS','KeyD']);assert set(await page.evaluate('state.selectedKeys'))=={'KeyA','KeyS','KeyD'}
   await enclose(['KeyQ'],'Shift');assert set(await page.evaluate('state.selectedKeys'))=={'KeyA','KeyS','KeyD','KeyQ'}
   await enclose(['KeyS'],'Alt');assert set(await page.evaluate('state.selectedKeys'))=={'KeyA','KeyD','KeyQ'}
   await page.locator('#applySelectionQuick').click();assert set(await page.evaluate('currentLayer().targets'))=={'KeyA','KeyD','KeyQ'}
   await page.locator('[data-preview-mode=normal]').click();await page.evaluate('state.layers.forEach(l=>l.enabled=false);state.keyColors={KeyA:"#ff0000",KeyS:"#0088ff",KeyD:"#ffffff"};previewDirty=true;paintFrame(performance.now()/1000)');await page.wait_for_timeout(300)
   result=await page.evaluate('''()=>{const k=document.querySelector('#keyboard [data-code=Home]'),t=k.querySelector('.key-legend');const c=document.querySelector('#keyboard .board-lightmap'),ctx=c.getContext('2d'),data=ctx.getImageData(0,0,c.width,c.height).data;let count=0;for(let i=3;i<data.length;i+=4)if(data[i])count++;return {legend:t.scrollWidth<=t.clientWidth+1,alphaPixels:count,total:c.width*c.height}}''');print(width,'optics',result,flush=True);assert result['legend'];assert 0<result['alphaPixels']<result['total']*.15
   await page.screenshot(path=f'/mnt/data/LumePro_v0.3.39_optics_{width}.png');await page.evaluate('state.keyColors={};previewDirty=true;paintFrame(performance.now()/1000)');await page.wait_for_timeout(100);assert await page.evaluate('''()=>{const c=document.querySelector('#keyboard .board-lightmap');return !c.getContext('2d').getImageData(0,0,c.width,c.height).data.some(v=>v)}''')
   await page.evaluate('setUiMotion(false)');await page.locator('#groupsToggle').click();assert await page.locator('#groupsMenu').evaluate("e=>getComputedStyle(e).transitionDuration==='0s'");await page.keyboard.press('Escape');await page.evaluate('setUiMotion(true)')
  assert not errors,errors
  print('Lasso replace/add/subtract and apply, menu anchors, legend fit, isolated LED glow, off state and motion toggle: OK',flush=True)
  await browser.close()
if __name__=='__main__':asyncio.run(main())
