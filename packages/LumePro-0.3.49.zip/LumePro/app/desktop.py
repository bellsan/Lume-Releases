"""Opt-in Windows startup, tray, bounded crash supervision and device presence."""
import json, os, subprocess, sys, time, threading
from pathlib import Path


def supported():
    return sys.platform=='win32' and bool(getattr(sys,'frozen',False))


def startup(enabled):
    if not supported(): raise ValueError('Windows EXE版専用の設定です')
    import winreg
    # Per-user only. Quote the exact executable; no elevated task or service.
    with winreg.CreateKeyEx(winreg.HKEY_CURRENT_USER,r'Software\Microsoft\Windows\CurrentVersion\Run',0,winreg.KEY_SET_VALUE) as key:
        if enabled:winreg.SetValueEx(key,'LumePro',0,winreg.REG_SZ,subprocess.list2cmdline([sys.executable,'--background']))
        else:
            try:winreg.DeleteValue(key,'LumePro')
            except FileNotFoundError:pass


def presence():
    """Read current HID enumeration, not the stale registry inventory. None = unknown."""
    try:
        import hid
        return bool(hid.enumerate(0x046d,0xc339))
    except Exception:return None


def restored_scene(p,root):
    e=p.get('editor')
    if not e:return None
    geometry=json.loads((root/'keyboard_geometry.json').read_text('utf-8'))
    return {**e,'keys':geometry[e['layout']],'running':True,'motionProfile':p['motion_profile']}


class Tray:
    def __init__(self,root,show,quit):
        self.ready=False;self.icon=None
        try:
            import pystray
            from PIL import Image
            with Image.open(root/'lume-app-icon.ico') as im: image=im.convert('RGBA').copy()
            self.icon=pystray.Icon('LumePro',image,'LUME / PRO',pystray.Menu(pystray.MenuItem('LUME / PRO を開く',lambda *_:show(),default=True),pystray.MenuItem('終了',lambda *_:quit())))
            def setup(icon):icon.visible=True;self.ready=True
            # Win32 backend supports a dedicated message loop thread.
            threading.Thread(target=lambda:self.icon.run(setup=setup),daemon=True).start()
        except Exception:self.icon=None
    def close(self):
        if self.icon:
            try:self.icon.stop()
            except Exception:pass
        self.ready=False


def supervise(argv, data):
    """Retry only unexpected exits, at most twice; no restart after clean exit/update."""
    import socket
    config=data/'preferences.json'
    try: enabled=json.loads(config.read_text('utf-8')).get('recovery',True) is not False
    except (OSError,ValueError,AttributeError):enabled=True
    args=list(argv)
    if '--port' not in args:
        with socket.socket() as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
        args+=['--port',str(port)]
    for attempt in range(3 if enabled else 1):
        code=subprocess.call([sys.executable,'--worker',*args],cwd=str(Path(sys.executable).parent),creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
        if code==0:return 0
        if not enabled or attempt==2:return code
        time.sleep(1.5*(attempt+1))
        args=[x for x in args if x!='--background']+(['--no-browser'] if '--no-browser' not in args else [])
    return 1

class Instance:
    def __init__(self,data):
        import ctypes, hashlib
        from ctypes import wintypes
        self.kernel=ctypes.WinDLL('kernel32',use_last_error=True)
        self.kernel.CreateMutexW.argtypes=(ctypes.c_void_p,wintypes.BOOL,wintypes.LPCWSTR)
        self.kernel.CreateMutexW.restype=wintypes.HANDLE
        self.kernel.CloseHandle.argtypes=(wintypes.HANDLE,)
        name='Local\\LumePro-'+hashlib.sha256(str(data.resolve()).casefold().encode()).hexdigest()[:24]
        ctypes.set_last_error(0)
        self.handle=self.kernel.CreateMutexW(None,False,name)
        if not self.handle:raise OSError(ctypes.get_last_error(),'CreateMutexW failed')
        self.duplicate=ctypes.get_last_error()==183
        self.marker=data/'desktop_session.json'
    def announce(self,port):
        tmp=self.marker.with_suffix('.tmp');tmp.write_text(json.dumps({'port':port,'pid':os.getpid()}),'utf-8');tmp.replace(self.marker)
    def existing_port(self):
        try:
            p=json.loads(self.marker.read_text('utf-8'))['port']
            if type(p) is int and 1<=p<=65535:return p
        except (OSError,ValueError,KeyError,TypeError):pass
        return None
    def close(self):
        if not self.duplicate:
            try:self.marker.unlink(missing_ok=True)
            except OSError:pass
        self.kernel.CloseHandle(self.handle)
