"""Optional, transient Windows key-down notifications. Never captures text or logs keystrokes."""
import ctypes
import os
import threading
import time
from collections import deque

# Windows SetWindowsHookEx(WH_KEYBOARD_LL), press-only. Disabled until user enables it.
from keyhook_codes import SCAN_CODE
from game_mode import GameMode


class KeyboardWatcher:
 def __init__(self):
  self.game=GameMode()
  self.events=deque(maxlen=100)
  self.seq=0
  self.special_counts={"Backslash":0,"AltRight":0,"Fn":0,"LightButton":0,"GameMode":0}
  self.enabled=False
  self._lock=threading.Lock()
  self._thread=None
  self._tid=None
  self._hook=None
  self._callback=None
  self.error=None
  self._ready=threading.Event()

 def start(self):
  if os.name!='nt':
   self.error='グローバルキー検出はWindows専用です'
   return False
  if self.enabled:return True
  if self._thread and self._thread.is_alive():
   self.error='入力検出の停止処理中です。もう一度お試しください';return False
  self.enabled=True
  self._ready.clear()
  self.error=None
  self._thread=threading.Thread(target=self._loop,daemon=True)
  self._thread.start()
  self._ready.wait(1.5)
  if not self._hook:
   self.enabled=False
   if not self.error:self.error='キーボードフックの起動に失敗しました'
  return self.enabled and bool(self._hook)

 def stop(self):
  self.game.disable()
  self.enabled=False
  if os.name=='nt' and self._tid:
   try:ctypes.windll.user32.PostThreadMessageW(self._tid,0x0012,0,0)
   except Exception:pass
  if self._thread and self._thread is not threading.current_thread():self._thread.join(timeout=.6)
  with self._lock:self.events.clear()

 def push(self,code):
  if not self.enabled:return
  with self._lock:
   self.seq+=1
   if code in self.special_counts:self.special_counts[code]+=1
   self.events.append({'id':self.seq,'code':code,'at':time.monotonic()})

 def diagnostic(self):
  with self._lock:return {'enabled':self.enabled,'error':self.error,'special_counts':dict(self.special_counts)}

 def since(self,seq):
  with self._lock:return {'seq':self.seq,'events':[e for e in self.events if e['id']>seq and time.monotonic()-e['at']<2]}

 def _loop(self):
  from ctypes import wintypes
  ULONG_PTR=ctypes.c_size_t
  class KBDLLHOOKSTRUCT(ctypes.Structure):
   _fields_=[('vkCode',wintypes.DWORD),('scanCode',wintypes.DWORD),('flags',wintypes.DWORD),('time',wintypes.DWORD),('dwExtraInfo',ULONG_PTR)]
  user32=ctypes.windll.user32
  kernel32=ctypes.windll.kernel32
  self._tid=kernel32.GetCurrentThreadId()
  msg=wintypes.MSG()
  user32.PeekMessageW(ctypes.byref(msg),None,0,0,0)
  kernel32.GetModuleHandleW.argtypes=[wintypes.LPCWSTR]
  kernel32.GetModuleHandleW.restype=wintypes.HMODULE
  user32.CallNextHookEx.argtypes=[wintypes.HANDLE,ctypes.c_int,wintypes.WPARAM,wintypes.LPARAM]
  user32.CallNextHookEx.restype=ctypes.c_ssize_t
  user32.UnhookWindowsHookEx.argtypes=[wintypes.HANDLE]
  CALLBACK=ctypes.WINFUNCTYPE(ctypes.c_ssize_t,ctypes.c_int,wintypes.WPARAM,wintypes.LPARAM)
  down=set()
  initial_vks={v for v in range(1,255) if user32.GetAsyncKeyState(v)&0x8000}
  def cb(code,wparam,lparam):
   if code>=0 and self.enabled and wparam in (0x100,0x104,0x101,0x105):
    info=ctypes.cast(lparam,ctypes.POINTER(KBDLLHOOKSTRUCT)).contents
    sc=int(info.scanCode)
    value=SCAN_CODE.get(sc)
    # Right Control/Alt have E0 extended flag
    if sc==0x1D and info.flags & 1:value='ControlRight'
    if int(info.vkCode)==0xA5 or (sc==0x38 and info.flags & 1):value='AltRight'
    if int(info.vkCode)==0x2C:value='PrintScreen'
    if int(info.vkCode)==0x13:value='Pause'
    if sc==0x5B:value='MetaLeft'
    if sc==0x5C:value='MetaRight'
    if int(info.vkCode)==0x1C:value='Convert'
    if int(info.vkCode)==0x1D:value='NonConvert'
    if int(info.vkCode)==0x15 and sc==0x70:value='KanaMode'
    identity=value or (sc,int(info.flags)&1)
    up=wparam in (0x101,0x105)
    injected=bool(info.flags & 0x10)
    if not injected:
     vk=int(info.vkCode)
     deny=self.game.event(identity,value,up,already_held=vk in initial_vks)
     if up:initial_vks.discard(vk);down.discard(identity)
     elif identity not in down:
      down.add(identity)
      if value and not deny:self.push(value)
     if deny:return 1
   return user32.CallNextHookEx(None,code,wparam,lparam)
  self._callback=CALLBACK(cb)
  user32.SetWindowsHookExW.argtypes=[ctypes.c_int,CALLBACK,wintypes.HINSTANCE,wintypes.DWORD]
  user32.SetWindowsHookExW.restype=wintypes.HANDLE
  self._hook=user32.SetWindowsHookExW(13,self._callback,kernel32.GetModuleHandleW(None),0)
  if not self._hook:
   self.error='Windowsのキーボードフックを登録できませんでした'
   self.enabled=False
   self._ready.set()
   return
  self._ready.set()
  msg=wintypes.MSG()
  while self.enabled and user32.GetMessageW(ctypes.byref(msg),None,0,0)>0:
   user32.TranslateMessage(ctypes.byref(msg));user32.DispatchMessageW(ctypes.byref(msg))
  if self._hook:user32.UnhookWindowsHookEx(self._hook)
  self._hook=None
  self.game.disable()
  self.game.held.clear();self.game.physical.clear()
  self.enabled=False
  self._tid=None
