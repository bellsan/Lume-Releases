"""Opt-in, read-only G HUB state notifications for the wired C339 keyboard.
Protocol paths were identified in the supplied G HUB archive, not proven on hardware.
No SET, firmware commands, credentials, serial numbers or raw payloads are stored.
"""
import json
import re
import threading
import time

PID = 0xC339
URL = 'ws://127.0.0.1:9010'
DEVICE_LIST = '/devices/list'
ENDPOINTS = {'GameMode': ('/keyboard/{}/game_mode', 'enabled'),
             'LightButton': ('/lighting/{}/master_switch_on', 'value')}


def target_device(payload):
    if not isinstance(payload, dict) or not isinstance(payload.get('deviceInfos'), list):
        return None
    matches = []
    for device in payload['deviceInfos']:
        if not isinstance(device, dict):
            continue
        pid = device.get('pid')
        try:
            if isinstance(pid, str):
                pid = int(pid, 16 if pid.lower().startswith('0x') or pid.lower() == 'c339' else 10)
        except ValueError:
            continue
        id_ = device.get('id')
        if pid == PID and isinstance(id_, str) and re.fullmatch(r'[A-Za-z0-9_.:-]{1,128}', id_) and id_ not in ('.', '..'):
            matches.append(device)
    return matches[0] if len(matches) == 1 else None


class StateTracker:
    def __init__(self, emit):
        self.emit = emit
        self.values = {k: None for k in ENDPOINTS}
        self.changes = {k: 0 for k in ENDPOINTS}
        self.messages = {k: 0 for k in ENDPOINTS}

    def feed(self, code, payload):
        if code not in ENDPOINTS or not isinstance(payload, dict):
            return False
        self.messages[code] += 1
        value = payload.get(ENDPOINTS[code][1])
        # Missing fields cannot establish a hardware state. Never treat missing as false.
        if type(value) is not bool:
            return False
        previous = self.values[code]
        self.values[code] = value
        if previous is not None and previous != value:
            self.changes[code] += 1
            self.emit(code)
            return True
        return False


class GHubStateMonitor:
    def __init__(self, emit, connector=None, on_change=None, on_disconnect=None):
        self.emit = emit
        self.on_change = on_change or (lambda code, value: None)
        self.on_disconnect = on_disconnect or (lambda: None)
        self.connector = connector or self._connect
        self.lock = threading.RLock()
        self.stop_event = threading.Event()
        self.thread = None
        self.ws = None
        self.active = False
        self.connected = False
        self.detected = False
        self.error = ''
        self.tracker = StateTracker(emit)
        self.capabilities = {}

    @staticmethod
    def _connect():
        import websocket
        return websocket.create_connection(URL, timeout=1.0, subprotocols=['json'],
                                           http_no_proxy=['127.0.0.1', 'localhost'])

    def start(self):
        with self.lock:
            if self.thread and self.thread.is_alive():
                return self.active and not self.stop_event.is_set()
            self.stop_event.clear()
            self.active = True
            self.connected = self.detected = False
            self.error = ''
            self.capabilities = {}
            self.tracker = StateTracker(self.emit)
            self.thread = threading.Thread(target=self._loop, daemon=True)
            self.thread.start()
            return True

    def stop(self):
        self.stop_event.set()
        with self.lock:
            ws, thread = self.ws, self.thread
        if ws:
            try:
                ws.shutdown()
            except Exception:
                pass
        if thread and thread is not threading.current_thread():
            thread.join(1.5)

    @staticmethod
    def _send(ws, verb, path):
        if verb not in ('GET', 'SUBSCRIBE'):
            raise ValueError('read-only protocol')
        ws.send(json.dumps({'verb': verb, 'path': path}, separators=(',', ':')))

    @staticmethod
    def _receive(ws):
        try:
            raw = ws.recv()
        except Exception as e:
            if isinstance(e, TimeoutError) or type(e).__name__ == 'WebSocketTimeoutException':
                return None
            raise
        if raw is None or raw == '':
            raise ConnectionError('closed')
        if not isinstance(raw, (str, bytes)) or len(raw) > 2_000_000:
            return None
        try:
            value = json.loads(raw)
        except (ValueError, UnicodeError):
            return None
        return value if isinstance(value, dict) else None

    def _loop(self):
        ws = None
        try:
            ws = self.connector()
            with self.lock:
                self.ws = ws
                self.connected = True
            self._send(ws, 'GET', DEVICE_LIST)
            deadline = time.monotonic() + 5
            device = None
            while not self.stop_event.is_set() and time.monotonic() < deadline:
                msg = self._receive(ws)
                if msg and msg.get('path') == DEVICE_LIST:
                    device = target_device(msg.get('payload'))
                    break
            if self.stop_event.is_set():
                return
            if not device:
                raise LookupError('C339 not uniquely detected')
            with self.lock:
                self.detected = True
                caps = device.get('capabilities')
                if isinstance(caps, dict):
                    lighting = caps.get('lightingSupport')
                    if isinstance(lighting, dict) and type(lighting.get('hasMasterSwitch')) is bool:
                        self.capabilities['hasMasterSwitch'] = lighting['hasMasterSwitch']
            paths = {template.format(device['id']): code for code, (template, _) in ENDPOINTS.items()}
            # Initial state first; subscriptions then deliver subsequent changes.
            for path in paths:
                self._send(ws, 'GET', path)
                self._send(ws, 'SUBSCRIBE', path)
            while not self.stop_event.is_set():
                msg = self._receive(ws)
                if not msg or not isinstance(msg.get('path'), str):
                    continue
                code = paths.get(msg['path'])
                if code and not self.stop_event.is_set():
                    with self.lock:
                        if self.tracker.feed(code, msg.get('payload')):
                            self.on_change(code, self.tracker.values[code])
        except Exception as e:
            if not self.stop_event.is_set():
                with self.lock:
                    if isinstance(e, ImportError):
                        self.error = 'websocket-client が必要です。install_hid_backend.bat を実行してください。'
                    elif isinstance(e, LookupError):
                        self.error = 'G HUBでC339を一意に識別できませんでした。'
                    else:
                        self.error = 'G HUBの読み取り接続に失敗・切断しました: ' + type(e).__name__
        finally:
            if ws:
                try: ws.shutdown()
                except Exception: pass
            with self.lock:
                self.ws = None
                self.active = self.connected = False
                self.on_disconnect()

    def status(self):
        with self.lock:
            return {'active': self.active, 'connected': self.connected, 'detected_c339': self.detected,
                    'error': self.error, 'states': dict(self.tracker.values),
                    'changes': dict(self.tracker.changes), 'messages': dict(self.tracker.messages),
                    'capabilities': dict(self.capabilities),
                    'verification': 'G HUB state changes only; not physical key-down or LED address'}
