"""Read-only Logitech USB/HID enumeration; no writes, no serial numbers."""
import os
import re

def logitech_hid_ids():
 if os.name!='nt':return []
 import winreg
 ids=set()
 try:
  with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE,r'SYSTEM\CurrentControlSet\Enum\HID') as root:
   for i in range(winreg.QueryInfoKey(root)[0]):
    name=winreg.EnumKey(root,i)
    if re.match(r'^VID_046D&PID_[0-9A-F]{4}',name,re.I):
     ids.add(name.upper())
 except OSError:pass
 return sorted(ids)
