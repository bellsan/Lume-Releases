"""Opt-in, read-only vendor HID Fn detection. No reports are written or exported.
Only identified Logitech PRO keyboard vendor collections are opened.
Supports Fn, lighting and game-mode notifications if emitted by the device.
A learned fingerprint is session-local; no raw report or other key history is retained.
"""
import hashlib
import secrets
import threading
import time


SPECIAL_CODES=frozenset(('Fn','GameMode','LightButton'))

KNOWN_PRO_PID=0xc339

def vendor_collections(rows):
    rows=list(rows)
    keyboard_pids={r.get('product_id') for r in rows if r.get('vendor_id')==0x046d and r.get('usage_page')==1 and r.get('usage')==6 and (r.get('product_id')==KNOWN_PRO_PID or 'pro' in str(r.get('product_string') or '').casefold())}
    result=[];seen=set()
    for row in rows:
        name=str(row.get('product_string') or '').casefold();pid=row.get('product_id');path=row.get('path')
        if row.get('vendor_id')!=0x046d or not path or path in seen:continue
        # C339 was observed in the JIS user's diagnostic. Missing product strings
        # are common on secondary collections; never open ordinary keyboard input.
        if pid!=KNOWN_PRO_PID and not ('pro' in name and ('keyboard' in name or pid in keyboard_pids)):continue
        if pid==KNOWN_PRO_PID and name and 'mouse' in name:continue
        page=row.get('usage_page')
        if type(page) is not int or not (0xff00<=page<=0xffff or (page==0x0c and pid in keyboard_pids)):continue
        seen.add(path);result.append(row)
    return result

class FnLearner:
    """Match repeated non-idle reports; toggles may alternate two signatures.
    Only salted report hashes are retained. Both toggle states must be verified.
    """
    def __init__(self,target='Fn'):
        self.required=3 if target=='Fn' else 4
        self.baseline=set();self.samples=[];self.trial=[];self.trials=[];self.signature=None;self.alternate=None
        self.phase='baseline';self.deadline=0.;self.last_match=-1e9
        self.error='';self.matches=0;self.verified=set();self.attempts=0;self.trial_reports=0;self.attempt_reports=[]
    def begin(self,now):
        self.phase='baseline';self.deadline=now+1.5;self.baseline.clear();self.samples.clear();self.trial.clear();self.trials.clear();self.signature=None;self.alternate=None;self.error='';self.matches=0;self.verified.clear();self.last_match=-1e9;self.attempts=0;self.trial_reports=0;self.attempt_reports.clear()
    def tick(self,now):
        if self.phase=='baseline' and now>=self.deadline:self.phase='ready'
        elif self.phase=='sample' and now>=self.deadline:
            self.attempt_reports.append({'reports':self.trial_reports,'distinct_nonidle':len(self.trial)})
            self.attempt_reports=self.attempt_reports[-12:]
            if not self.trial:
                self.phase='ready'
                self.error=('押下中にHID通知は届きましたが、待機時と区別できませんでした。' if self.trial_reports else '押下中に専用HID通知が届きませんでした。')
                return
            self.samples.append(self.trial[0]);self.trials.append(tuple(self.trial));self.trial.clear()
            if len(self.samples)>=self.required:
                common=set.intersection(*(set(t) for t in self.trials))-self.baseline
                first=[next((d for d in t if d in common),None) for t in self.trials]
                if first[0] is not None and len(set(first))==1:
                    self.signature=first[0]
                elif self.required==4:
                    # Two visits to each state in an A/B/A/B toggle sequence.
                    even=(set(self.trials[0])&set(self.trials[2]))-set(self.trials[1])-set(self.trials[3])-self.baseline
                    odd=(set(self.trials[1])&set(self.trials[3]))-set(self.trials[0])-set(self.trials[2])-self.baseline
                    # Reject ambiguity rather than learn a random changing payload.
                    if len(even)==len(odd)==1:
                        self.signature=next(iter(even));self.alternate=next(iter(odd))
                if self.signature is not None:self.phase='verify';self.error=''
                else:self.phase='failed';self.error='通知が再現しません。対象ボタン専用の通知として確定できません。'
            else:self.phase='ready';self.error=''
    def arm(self,now):
        self.tick(now)
        if self.phase!='ready':return False
        self.trial=[];self.trial_reports=0;self.attempts+=1;self.phase='sample';self.deadline=now+4.;self.error='';return True
    def feed(self,digest,now):
        self.tick(now)
        if self.phase in ('baseline','ready'):
            if len(self.baseline)<512:self.baseline.add(digest)
        elif self.phase=='sample':
            self.trial_reports+=1
            if digest not in self.baseline and digest not in self.trial and len(self.trial)<64:self.trial.append(digest)
        elif self.phase in ('verify','learned') and digest in (self.signature,self.alternate) and now-self.last_match>=.14:
            self.last_match=now;self.matches+=1;self.verified.add(digest);return self.phase=='learned'
        return False
    def can_enable(self):
        return self.phase=='verify' and self.signature is not None and self.matches>0 and (self.alternate is None or {self.signature,self.alternate}<=self.verified)


def fingerprints(value):
    return value if isinstance(value,tuple) else (value,)

class FnHidMonitor:
    def __init__(self,emit,loader=None):
        self.emit=emit;self.loader=loader or self._load;self.lock=threading.RLock();self.thread=None;self.stop_event=threading.Event();self.learner=FnLearner();self.error='';self.rows=[];self.salt=secrets.token_bytes(16);self.device=None;self.active=False;self.target='Fn';self.learned={};self.last_emit={};self.handles=[];self.collection_stats=[];self.enumerated=False
    @staticmethod
    def _load():
        import hid
        return hid
    @staticmethod
    def _describe(row,i):
        return {'index':i,'name':str(row.get('product_string') or 'PRO Keyboard'),'pid':f"{row.get('product_id',0):04X}",'usage':f"{row.get('usage_page',0):04X}:{row.get('usage',0):04X}",'interface':row.get('interface_number')}
    def list(self):
        with self.lock:
            self.enumerated=True
            try:
                self.rows=vendor_collections(self.loader().enumerate(0x046d,0));self.error=''
            except Exception as e:self.rows=[];self.error='HID診断を利用できません: '+type(e).__name__
            return [self._describe(r,i) for i,r in enumerate(self.rows)]
    def start(self,index,target='Fn'):
        if target not in SPECIAL_CODES:return False
        self.stop()
        with self.lock:
            if self.thread and self.thread.is_alive():self.error='停止処理中です';return False
            if type(index) is not int or not (-1<=index<len(self.rows)):self.error='専用HIDを選択してください';return False
            self.handles=[];self.collection_stats=[]
            try:
                module=self.loader();current=vendor_collections(module.enumerate(0x046d,0));wanted=self.rows if index==-1 else [self.rows[index]]
                by_path={r['path']:r for r in current}
                for i,row in enumerate(wanted):
                    stat={**self._describe(row,i),'opened':False,'reports':0,'errors':0,'phase_reports':{},'report_shapes':{}};self.collection_stats.append(stat)
                    d=None
                    try:
                        if row['path'] not in by_path:raise RuntimeError('device changed')
                        d=module.device();d.open_path(row['path']);d.set_nonblocking(1)
                        self.handles.append((i,d));stat['opened']=True
                    except Exception as e:
                        stat['errors']+=1;stat['error']=type(e).__name__
                        if d is not None:
                            try:d.close()
                            except Exception:pass
                if not self.handles:raise RuntimeError('no readable collections')
                self.device=self.handles[0][1];self.stop_event.clear();self.salt=secrets.token_bytes(16);self.learner=FnLearner(target);self.learner.begin(time.monotonic());self.error='';self.active=True;self.target=target;self.learned={};self.last_emit={}
                self.thread=threading.Thread(target=self._loop,daemon=True);self.thread.start();return True
            except Exception as e:
                for _,d in self.handles:
                    try:d.close()
                    except Exception:pass
                self.handles=[];self.device=None;self.active=False;self.error='専用HIDを開けません: '+type(e).__name__;return False
    def learn(self,target):
        with self.lock:
            if not self.active or target not in SPECIAL_CODES:return False
            self.target=target;self.learner=FnLearner(target);self.learner.begin(time.monotonic());self.error='';return True
    def arm(self):
        with self.lock:return self.active and self.learner.arm(time.monotonic())
    def enable(self):
        with self.lock:
            if not self.active or not self.learner.can_enable():return False
            signature=self.learner.signature if self.learner.alternate is None else (self.learner.signature,self.learner.alternate)
            if any(c!=self.target and set(fingerprints(sig))&set(fingerprints(signature)) for c,sig in self.learned.items()):
                self.error='別のボタンと通知が同一のため割り当てできません';return False
            self.learned[self.target]=signature;self.learner.phase='learned';return True
    def _loop(self):
        handles=list(self.handles);live=list(handles)
        try:
            while live and not self.stop_event.is_set():
                fire=[];received=False
                for index,d in list(live):
                    try:report=d.read(512,0)
                    except Exception as e:
                        with self.lock:
                            self.collection_stats[index]['errors']+=1;self.collection_stats[index]['error']=type(e).__name__
                        live.remove((index,d));continue
                    now=time.monotonic()
                    with self.lock:
                        if self.stop_event.is_set():break
                        self.learner.tick(now)
                        if not report:continue
                        received=True;stat=self.collection_stats[index];stat['reports']+=1
                        phase=self.learner.phase;stat['phase_reports'][phase]=stat['phase_reports'].get(phase,0)+1
                        # Length only: no report content, key history or raw payload retained.
                        shape=str(len(report));shapes=stat['report_shapes']
                        if shape in shapes or len(shapes)<32:shapes[shape]=shapes.get(shape,0)+1
                        digest=hashlib.sha256(self.salt+index.to_bytes(2,'little')+bytes(report)).digest()
                        self.learner.feed(digest,now)
                        for code,signature in self.learned.items():
                            if (code!=self.target or self.learner.phase=='learned') and digest in fingerprints(signature) and now-self.last_emit.get(code,-1e9)>=.18:
                                self.last_emit[code]=now;fire.append(code)
                if self.stop_event.is_set():break
                for code in fire:self.emit(code)
                self.stop_event.wait(.004 if received else .015)
            if not live and not self.stop_event.is_set():
                with self.lock:self.error='すべての専用HID読み取りが停止しました'
        finally:
            for _,d in handles:
                try:d.close()
                except Exception:pass
            with self.lock:self.active=False;self.device=None;self.handles=[]
    def stop(self):
        self.stop_event.set()
        t=self.thread
        if t and t is not threading.current_thread():t.join(.7)
        with self.lock:
            if not t or not t.is_alive():self.active=False;self.learner=FnLearner();self.learned={};self.last_emit={}
    def status(self):
        with self.lock:
            l=self.learner
            return {'active':self.active,'target':self.target,'learned':sorted(self.learned) if self.active else [],'phase':l.phase if self.active else 'off','samples':len(l.samples),'required_samples':l.required,'matches':l.matches,'can_enable':l.can_enable(),'alternate_states':l.alternate is not None,'verified_states':len(l.verified),'attempts':l.attempts,'attempt_reports':list(l.attempt_reports),'error':self.error or l.error,'remaining':round(max(0,l.deadline-time.monotonic()),1) if self.active and l.phase in ('baseline','sample') else 0,'enumerated':self.enumerated,'collections':[self._describe(r,i) for i,r in enumerate(self.rows)],'collection_stats':[dict(x) for x in self.collection_stats]}
