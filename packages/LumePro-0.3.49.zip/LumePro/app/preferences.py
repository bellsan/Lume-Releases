"""Local, port-independent editor and connection preferences. No input events are saved."""
import json
import math
import threading
from bitmap_led import valid_mapping
from engine import EFFECTS, CODE, HEX, SIGNATURE_STYLES
from pathlib import Path

DEFAULT={'auto':True,'backend':'logitech','device_name':None,'device_leds':None,'live':False,'hook':False,'method':'auto','bracket_method':'auto','fn_method':'auto','yen_method':'auto','editor':None,'bitmap_layout':'jis','bitmap_mapping':{},'bitmap_enabled':False,'game_mode':None,'motion_profile':'balanced','tray':True,'startup':False,'recovery':True,'audio_enabled':False,'audio_endpoint':'default'}

# Preserve the editor's raw units rather than the engine's normalized floats.
NUMERIC_FIELDS={k:(0,100) for k in ('brightness','speed','spread','fade','phase','width','floor','contrast','sensitivity','audioWidth','waveGain','waveMix','waveTrail','waveBeat','barSmooth','barGate','freqLow','freqHigh','originX','originY','motionTrail','rainDensity')}
NUMERIC_FIELDS.update(angle=(-180,180),gradientAngle=(-180,180),duration=(5,80),bars=(4,24),barRange=(24,78),barTilt=(-100,100),barHeight=(25,180),barWidth=(20,100),aspect=(25,200),petals=(2,12),orbitHeads=(1,3))
ENUM_FIELDS={'direction':('left','right','radial'),'blend':('normal','add','max','replace'),'gradientMode':('linear','radial'),'barResponse':('balanced','fast','smooth'),'barOrigin':('bottom','top','center'),'barShape':('blocks','soft','outline','dot'),'barColor':('height','frequency'),'pulseShape':('circle','diamond','square','horizontal','vertical'),'scanMode':('bounce','loop'),'motionCurve':('natural','linear','soft','sharp'),'signatureStyle':SIGNATURE_STYLES}
BOOL_FIELDS=('enabled','waveMirror','waveIdle','barPeak','barReverse','barMain','barBlack')
def clean_editor(raw,strict=False):
 def fail():raise ValueError('プリセットの設定が不正です')
 if not isinstance(raw,dict) or raw.get('layout') not in ('jis','ansi'):fail()
 layers=raw.get('layers')
 if not isinstance(layers,list) or not 1<=len(layers)<=8:fail()
 output=[];ids=set()
 for i,l in enumerate(layers):
  if not isinstance(l,dict) or not isinstance(l.get('type'),str) or l['type'] not in EFFECTS:fail()
  ident=l.get('id',i+1)
  if type(ident) is not int or not 1<=ident<=2**31-1 or ident in ids:fail()
  ids.add(ident);v={'id':ident,'type':l['type']}
  for k in ('color','secondary','barPeakColor'):
   if k not in l:
    if k=='color':
     if strict:fail()
     v[k]='#76F3E1'
    continue
   if not isinstance(l[k],str) or not HEX.fullmatch(l[k]):fail()
   v[k]=l[k]
  for k,(lo,hi) in NUMERIC_FIELDS.items():
   if k in l:
    n=l[k]
    if type(n) not in (int,float) or not lo<=n<=hi or not math.isfinite(n):fail()
    v[k]=n
  for k,choices in ENUM_FIELDS.items():
   if k in l:
    if l[k] not in choices:fail()
    v[k]=l[k]
  for k in BOOL_FIELDS:
   if k in l:
    if type(l[k]) is not bool:fail()
    v[k]=l[k]
  for k,limit,pattern in [('targets',180,CODE),('gradient',4,HEX)]:
   if k in l:
    a=l[k]
    if not isinstance(a,list) or len(a)>limit or any(not isinstance(x,str) or not pattern.fullmatch(x) for x in a):fail()
    v[k]=a[:]
  output.append(v)
 colors=raw.get('keyColors',{})
 if not isinstance(colors,dict) or len(colors)>180 or any(not CODE.fullmatch(k) or not isinstance(v,str) or not HEX.fullmatch(v) for k,v in colors.items()):fail()
 sel=raw.get('selectedLayer',output[0]['id'])
 if type(sel) is not int or sel not in ids:sel=output[0]['id']
 result={'layout':raw['layout'],'layers':output,'selectedLayer':sel,'keyColors':colors}
 for k in ('profileName','editingPreset'):
  if k in raw:
   if raw[k] is not None and (not isinstance(raw[k],str) or len(raw[k])>120):fail()
   result[k]=raw[k]
 fixed=raw.get('fixedColorMode','reactive');priority=raw.get('reactivePriority',False)
 if fixed not in ('reactive','fixed') or type(priority) is not bool:fail()
 result.update(fixedColorMode=fixed,reactivePriority=priority)
 return result

def clean(raw):
 d=dict(DEFAULT)
 if not isinstance(raw,dict):return d
 for k in ('auto','live','hook','tray','startup','recovery','audio_enabled'):
  if type(raw.get(k)) is bool:d[k]=raw[k]
 if isinstance(raw.get('audio_endpoint'),str) and len(raw['audio_endpoint'])<=200:d['audio_endpoint']=raw['audio_endpoint']
 if raw.get('motion_profile') in ('responsive','balanced','smooth'):d['motion_profile']=raw['motion_profile']
 if raw.get('backend') in ('logitech','openrgb'):d['backend']=raw['backend']
 for k in ('method','bracket_method','fn_method','yen_method'):
  if raw.get(k) in ('auto','hid','scan','keyname','off','hid31','iso56','hid64','scan56') and (k=='bracket_method' or raw[k] not in ('hid31','iso56','hid64','scan56')) and (k!='method' or raw[k] in ('auto','hid','scan')):d[k]=raw[k]
 if isinstance(raw.get('device_name'),str):d['device_name']=raw['device_name'][:200]
 if type(raw.get('device_leds')) is int and 0<raw['device_leds']<=4096:d['device_leds']=raw['device_leds']
 if raw.get('bitmap_layout') in ('jis','ansi'):d['bitmap_layout']=raw['bitmap_layout']
 d['bitmap_mapping']=valid_mapping(raw.get('bitmap_mapping'))
 d['bitmap_enabled']=raw.get('bitmap_enabled') is True and bool(d['bitmap_mapping'])
 g=raw.get('game_mode')
 if isinstance(g,dict):
  from game_mode import GameMode
  try:
   gate=GameMode();gate.configure(False,g.get('blocked'),g.get('led','off'),g.get('color','#ff5555'),g.get('dim',25));d['game_mode']=gate.status()
  except ValueError:pass
 e=raw.get('editor')
 if e is not None:
  try:d['editor']=clean_editor(e)
  except (ValueError,TypeError,OverflowError):pass
 return d

class Preferences:
 def __init__(self,path):self.path=Path(path);self.lock=threading.RLock()
 def load(self):
  with self.lock:
   try:return clean(json.loads(self.path.read_text('utf-8')))
   except (OSError,ValueError):return dict(DEFAULT)
 def update(self,patch):
  with self.lock:
   if patch.get('editor') is not None:clean_editor(patch['editor'],strict=True)
   raw=self.load();raw.update({k:v for k,v in patch.items() if k in DEFAULT});data=clean(raw)
   self.path.parent.mkdir(parents=True,exist_ok=True)
   tmp=self.path.with_suffix('.tmp');tmp.write_text(json.dumps(data,ensure_ascii=False,indent=2),'utf-8');tmp.replace(self.path)
   return data

def choose_device(devices,prefs):
 """Never guess a changed index or select a non-keyboard."""
 ds=[d for d in devices if d.get('keyboard') is True]
 name=prefs.get('device_name');leds=prefs.get('device_leds')
 if name:
  ds=[d for d in ds if d.get('name')==name and (leds is None or d.get('leds')==leds)]
 return ds[0]['id'] if len(ds)==1 else None
