"""One active controller at a time; changing backend shuts down the old one."""
from hardware import OpenRGBBackend
from logitech import LogitechBackend

class BackendRouter:
 def __init__(self):self.impl=OpenRGBBackend();self.kind='openrgb'
 def connect(self,kind='openrgb'):
  if kind not in ('openrgb','logitech'):return False
  self.impl.close();self.kind=kind
  self.impl=LogitechBackend() if kind=='logitech' else OpenRGBBackend()
  return self.impl.connect()
 def __getattr__(self,name):return getattr(self.impl,name)
 def status(self):return {**self.impl.status(),'backend':self.kind}
 def set_method(self,method):return self.kind=='logitech' and self.impl.set_method(method)

 def set_layout(self,layout):return self.kind!='logitech' or self.impl.set_layout(layout)
 def set_key_method(self,code,method):return self.kind=='logitech' and self.impl.set_key_method(code,method)
