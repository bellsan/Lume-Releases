"""Opt-in one-way synchronization from G HUB state changes, session only."""
import threading

class GameSync:
    def __init__(self, gate, hook_ready):
        self.gate = gate
        self.hook_ready = hook_ready
        self.lock = threading.RLock()
        self.enabled = False
        self.owns_gate = False

    def arm(self, enabled):
        with self.lock:
            if not enabled:
                self.disconnect()
            else:
                self.enabled = True

    def change(self, code, value):
        with self.lock:
            if not self.enabled or code != 'GameMode' or type(value) is not bool:
                return
            if not self.hook_ready():
                self.disconnect()
                return
            self.gate.set_enabled(value)
            self.owns_gate = value

    def manual(self):
        with self.lock:
            self.owns_gate = False

    def disconnect(self):
        with self.lock:
            if self.owns_gate:
                self.gate.disable()
            self.owns_gate = False
            self.enabled = False
