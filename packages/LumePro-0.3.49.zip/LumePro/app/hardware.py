"""Opt-in OpenRGB SDK adapter. Only writes to a user-selected keyboard."""
import threading
import time
import re

# Example OpenRGB LED names vary by model and version: Key: A, A, Key A, ESC, ...
ALIASES={
 'ESC':'Escape','ESCAPE':'Escape','RETURN':'Enter','ENTER':'Enter','SPACEBAR':'Space',
 'SPACE':'Space','BACKSPACE':'Backspace','BKSP':'Backspace','TAB':'Tab','CAPSLOCK':'CapsLock',
 'CAPS':'CapsLock','LEFTSHIFT':'ShiftLeft','RIGHTSHIFT':'ShiftRight','LSHIFT':'ShiftLeft',
 'RSHIFT':'ShiftRight','LEFTCTRL':'ControlLeft','RIGHTCTRL':'ControlRight',
 'LCTRL':'ControlLeft','RCTRL':'ControlRight','LEFTCONTROL':'ControlLeft',
 'RIGHTCONTROL':'ControlRight','LEFTALT':'AltLeft','RIGHTALT':'AltRight',
 'LEFTWINDOWS':'MetaLeft','RIGHTWINDOWS':'MetaRight','LWIN':'MetaLeft',
 'RWIN':'MetaRight','PRINTSCREEN':'PrintScreen','SCROLLLOCK':'ScrollLock',
 'PAGEUP':'PageUp','PAGEDOWN':'PageDown','PGUP':'PageUp','PGDN':'PageDown',
 'LEFTARROW':'ArrowLeft','RIGHTARROW':'ArrowRight','UPARROW':'ArrowUp',
 'DOWNARROW':'ArrowDown','DEL':'Delete','INS':'Insert','TILDE':'Backquote',
 'GRAVE':'Backquote','MINUS':'Minus','EQUALS':'Equal','BACKSLASH':'Backslash',
 'OPENBRACKET':'BracketLeft','CLOSEBRACKET':'BracketRight','LEFTBRACKET':'BracketLeft',
 'RIGHTBRACKET':'BracketRight','SEMICOLON':'Semicolon','APOSTROPHE':'Quote',
 'COMMA':'Comma','PERIOD':'Period','DOT':'Period','FORWARDSLASH':'Slash',
 'NONCONVERT':'NonConvert','MUHENKAN':'NonConvert','HENKAN':'Convert','CONVERT':'Convert','KANA':'KanaMode','KANAMODE':'KanaMode','HIRAGANA':'KanaMode','KATAKANA':'KanaMode','INTERNATIONAL1':'IntlRo','INTERNATIONAL2':'KanaMode','INTERNATIONAL3':'IntlYen','INTERNATIONAL4':'Convert','INTERNATIONAL5':'NonConvert','INTL1':'IntlRo','INTL2':'KanaMode','INTL3':'IntlYen','INTL4':'Convert','INTL5':'NonConvert','NONCONVERSION':'NonConvert','CONVERSION':'Convert','INTLRO':'IntlRo','INTLYEN':'IntlYen','YEN':'IntlYen','RO':'IntlRo','ZENKAKUHANKAKU':'Backquote','HANKAKUZENKAKU':'Backquote','LGUI':'MetaLeft','RGUI':'MetaRight','LEFTGUI':'MetaLeft','RIGHTGUI':'MetaRight','WINLEFT':'MetaLeft','WINRIGHT':'MetaRight','SHIFTLEFT':'ShiftLeft','SHIFTRIGHT':'ShiftRight','CONTROLLEFT':'ControlLeft','CONTROLRIGHT':'ControlRight','ALTLEFT':'AltLeft','ALTRIGHT':'AltRight','ARROWLEFT':'ArrowLeft','ARROWRIGHT':'ArrowRight','ARROWUP':'ArrowUp','ARROWDOWN':'ArrowDown','SLASH':'Slash',
 'LEFTWIN':'MetaLeft','RIGHTWIN':'MetaRight','WINDOWSLEFT':'MetaLeft','WINDOWSRIGHT':'MetaRight','BRACKETLEFT':'BracketLeft','BRACKETRIGHT':'BracketRight','QUOTE':'Quote','EQUAL':'Equal','BACKQUOTE':'Backquote','ESCAPEKEY':'Escape','PRTSC':'PrintScreen','PRTSCN':'PrintScreen','SCROLL':'ScrollLock','BACK':'Backspace','CAPSLOCKKEY':'CapsLock','APPLICATION':'ContextMenu','MENU':'ContextMenu','FUNCTION':'Fn','FN':'Fn','LOGO':'BoardLogo','GLOGO':'BoardLogo','GAMEMODE':'GameMode','GAMEMODEBUTTON':'GameMode','BRIGHTNESS':'LightButton','BRIGHTNESSBUTTON':'LightButton','LIGHTBUTTON':'LightButton','LIGHTINGBUTTON':'LightButton','NONUSNUMBER':'Backslash','NONUSHASH':'Backslash',
}

def normalize_led(name):
 s=str(name).strip()
 s=re.sub(r'^(?:key(?:board)?|led|button)(?:\s*[:_#-]\s*|\s+)','',s,flags=re.I)
 s=re.sub(r'\s*\(.*?\)','',s).strip()
 symbols={'-':'Minus','=':'Equal','^':'Equal','@':'BracketLeft','[':'BracketRight',']':'Backslash',';':'Semicolon',':':'Quote',"'":'Quote',',':'Comma','.':'Period','/':'Slash','\\':'Backslash','¥':'IntlYen','￥':'IntlYen','`':'Backquote','~':'Backquote','無変換':'NonConvert','変換':'Convert','カタカナひらがな':'KanaMode','かな':'KanaMode','ろ':'IntlRo','半角/全角':'Backquote','半角／全角':'Backquote'}
 if s in symbols:return symbols[s]
 s=re.sub('[^A-Za-z0-9]','',s).upper()
 if s.startswith('KEY') and len(s)>3:s=s[3:]
 if s in ALIASES:return ALIASES[s]
 if s.startswith('DIGIT') and len(s)==6 and s[-1].isdigit():return 'Digit'+s[-1]
 if len(s)==1 and s in 'ABCDEFGHIJKLMNOPQRSTUVWXYZ':return 'Key'+s
 if len(s)==1 and s in '0123456789':return 'Digit'+s
 if s.startswith('F') and s[1:].isdigit():return s
 if s.startswith('NUM') and s[3:].isdigit():return 'Numpad'+s[3:]
 return None

# OpenRGB protocol device type 5 is KEYBOARD. IntEnum.__str__ can return
# a number (Python 3.11+), so never rely on substring matching of str(type).
def is_keyboard_type(device_type):
 name=getattr(device_type,'name',None)
 value=getattr(device_type,'value',device_type)
 if isinstance(value,bool):return False
 if isinstance(value,int):return value==5
 if isinstance(name,str):return name.strip().upper()=='KEYBOARD'
 if isinstance(value,str):return value.strip().upper() in ('5','KEYBOARD','DEVICETYPE.KEYBOARD','DEVICE_TYPE_KEYBOARD')
 return False

class OpenRGBBackend:
 def __init__(self):
  self.client=None;self.devices=[];self.device=None;self.device_idx=None
  self.error='未接続';self._lock=threading.RLock()
  self.pending=None;self.event=threading.Event();self.running=True
  self.match_count=0;self.last_push=0;self.mapping=[];self.overrides={};self.sent=0;self.last_error=""
  self.thread=threading.Thread(target=self._worker,daemon=True);self.thread.start()

 def list_devices(self):
  with self._lock:return [{'id':i,'name':d.name,'leds':len(d.leds),'type':str(d.type),'keyboard':is_keyboard_type(d.type)} for i,d in enumerate(self.devices)]

 def connect(self):
  try:
   from openrgb import OpenRGBClient
  except ImportError:
   self.error='OpenRGB Python SDKが未インストールです（pip install openrgb-python）'
   return False
  try:
   client=OpenRGBClient('127.0.0.1',6742,name='Lume Pro')
   devs=list(client.devices)
   with self._lock:
    self.client=client;self.devices=devs;self.device=None;self.device_idx=None
    self.error='キーボードを選択してください';self.mapping=[];self.overrides={};self.pending=None;self.match_count=0
   return True
  except Exception as exc:
   self.error='OpenRGB接続失敗: '+str(exc)[:180]
   return False

 def select(self,idx):
  with self._lock:
   if type(idx) is not int or idx<0 or idx>=len(self.devices):
    self.error='接続先が見つかりません';return False
   d=self.devices[idx]
   # Limit output to keyboards to avoid accidentally writing to other hardware.
   if not is_keyboard_type(d.type):
    self.error=f'キーボード以外は選択できません（種類: {d.type}）';return False
   mapping=[normalize_led(x.name) for x in d.leds]
   matched=sum(bool(x) for x in mapping)
   try:
    # Direct mode may be required for per-key updates; fallback to device default.
    for m in d.modes:
     if str(m.name).lower() in ('direct','custom'):
      d.set_mode(m.name);break
   except Exception:pass
   self.device=d;self.device_idx=idx
   self.mapping=mapping;self.overrides={};self.match_count=matched;self.sent=0
   self.pending=None
   self.error='' if self.match_count else 'LEDの対応付けが必要です。全キー点灯テストで確認してください。'
   return True

 def set_mapping(self,index,code):
  with self._lock:
   if self.device is None or type(index) is not int or not 0<=index<len(self.mapping):return False
   if code is not None and (not isinstance(code,str) or not re.fullmatch(r'[A-Za-z0-9]{1,25}',code)):return False
   self.overrides[index]=code;self.match_count=sum(bool(self.overrides.get(i,c)) for i,c in enumerate(self.mapping));return True

 def test_led(self,index=None,color='#ffffff'):
  if not isinstance(color,str) or not re.fullmatch(r'#[0-9a-fA-F]{6}',color):return False
  with self._lock:
   if self.device is None or not is_keyboard_type(self.device.type):return False
   if index is not None and (type(index) is not int or not 0<=index<len(self.mapping)):return False
   try:
    from openrgb.utils import RGBColor
    rgb=RGBColor(*(int(color[i:i+2],16) for i in (1,3,5)))
    off=RGBColor(0,0,0)
    self.pending=None;self.device.set_colors([rgb if index is None or i==index else off for i in range(len(self.mapping))]);self.sent+=1;self.error='';return True
   except Exception as exc:self.error='点灯テスト失敗: '+str(exc)[:180];return False

 def clear_pending(self):
  with self._lock:self.pending=None;self.event.clear()

 def queue_frame(self,frame):
  if not isinstance(frame,dict):return
  safe={k:v for k,v in frame.items() if isinstance(k,str) and len(k)<40 and isinstance(v,str)
        and re.fullmatch(r'#[0-9a-fA-F]{6}',v)}
  if len(safe)>180:return
  with self._lock:self.pending=safe
  self.event.set()

 def _worker(self):
  while self.running:
   self.event.wait(0.5)
   if not self.running:break
   if not self.event.is_set():continue
   self.event.clear()
   # Device can handle a modest animation FPS; do not saturate USB/driver.
   elapsed=time.monotonic()-self.last_push
   if elapsed<0.055:time.sleep(0.055-elapsed)
   with self._lock:
    if not self.running:break
    frame=self.pending;self.pending=None;dev=self.device
    if not frame or dev is None:continue
    try:
     from openrgb.utils import RGBColor
     # Never assume an unknown LED's position, or turn it off merely because its name is unknown.
     mapping=[self.overrides.get(i,c) for i,c in enumerate(self.mapping)]
     if not any(code in frame for code in mapping):
      self.error='対応するLEDがありません。LED診断で確認してください。';continue
     existing=list(getattr(dev,'colors',[]) or [])
     colors=[]
     for i,code in enumerate(mapping):
      hx=frame.get(code)
      if hx is None:
       if i>=len(existing):raise ValueError('LED色の取得に失敗。全LEDの対応付けが必要です')
       colors.append(existing[i]);continue
      colors.append(RGBColor(int(hx[1:3],16),int(hx[3:5],16),int(hx[5:7],16)))
     dev.set_colors(colors)
     self.last_push=time.monotonic();self.sent+=1;self.error=''
    except Exception as exc:self.error='LED送信失敗: '+str(exc)[:180]

 def status(self):
  with self._lock:return {'connected':self.client is not None,'active':self.device_idx is not None,
  'device':self.device_idx,'devices':self.list_devices(),'matched':self.match_count,'sent':self.sent,'led_map':[{'index':i,'name':str(led.name),'sdk_id':str(getattr(led,'value',getattr(led,'id',''))),'code':self.overrides.get(i,self.mapping[i])} for i,led in enumerate(self.device.leds)] if self.device is not None else [],'error':self.error,'missing_jis':[c for c in ('NonConvert','Convert','KanaMode','IntlYen','IntlRo') if c not in [self.overrides.get(i,v) for i,v in enumerate(self.mapping)]] if self.device is not None else [],'device_info':{'name':str(self.device.name),'description':str(getattr(self.device,'description','')),'vendor':str(getattr(self.device,'vendor','')),'version':str(getattr(self.device,'version','')),'modes':[str(m.name) for m in getattr(self.device,'modes',[])],'zones':[{'name':str(z.name),'led_count':len(getattr(z,'leds',[]) or [])} for z in getattr(self.device,'zones',[])]} if self.device is not None else {}}

 def close(self):
  self.running=False;self.event.set()
  self.thread.join(timeout=1.5)
  with self._lock:
   self.pending=None;self.device=None;self.device_idx=None
   try:
    if self.client and hasattr(self.client,'disconnect'):self.client.disconnect()
   except Exception:pass
   self.client=None
  # No unrequested firmware or persistent hardware modifications.
