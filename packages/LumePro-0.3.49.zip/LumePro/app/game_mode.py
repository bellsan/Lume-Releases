"""Session-only input gate. No firmware writes, no key event logging."""
from keyhook_codes import BLOCKABLE, EMERGENCY
import threading

class GameMode:
 def __init__(self):
  self.config=(False,frozenset(('MetaLeft','MetaRight','ContextMenu')),'off','#ff5555',25)
  self.held={};self.physical=set();self.config_lock=threading.RLock()
 def configure(self,enabled,blocked,led='off',color='#ff5555',dim=25):
  if type(enabled) is not bool or not isinstance(blocked,list) or len(blocked)>120 or any(not isinstance(k,str) or k not in BLOCKABLE for k in blocked):raise ValueError('無効化できないキーが含まれています')
  if led not in ('off','dim','color','normal') or not isinstance(color,str) or len(color)!=7 or color[0]!='#' or any(c not in '0123456789abcdefABCDEF' for c in color[1:]) or type(dim) is not int or not 0<=dim<=100:raise ValueError('発光設定が不正です')
  with self.config_lock:self.config=(enabled,frozenset(blocked),led,color.lower(),dim)
 def set_enabled(self,enabled):
  with self.config_lock:
   _,*rest=self.config;self.config=(bool(enabled),*rest)
 def disable(self):
  self.set_enabled(False)
 def status(self):
  enabled,blocked,led,color,dim=self.config
  return {'enabled':enabled,'blocked':sorted(blocked),'led':led,'color':color,'dim':dim,'scope':'windows-all-keyboards'}
 def event(self,identity,code,up,injected=False,already_held=False):
  if injected:return False
  if up:
   self.physical.discard(identity);return self.held.pop(identity,False)
  self.physical.add(identity)
  # Escape hatch is always passed through. Its constituent keys cannot be blocked.
  if code=='F12' and any(k in self.physical for k in ('ControlLeft','ControlRight')) and any(k in self.physical for k in ('AltLeft','AltRight')):
   self.disable()
  if identity in self.held:return self.held[identity]
  enabled,blocked,*_=self.config
  deny=bool(enabled and code in blocked and not already_held)
  self.held[identity]=deny
  return deny
 def mask(self,frame):
  enabled,blocked,led,color,dim=self.config
  if not isinstance(frame,dict) or not enabled or led=='normal':return frame
  result=dict(frame)
  for k in blocked.intersection(result):
   if led=='off':result[k]='#000000'
   elif led=='color':result[k]=color
   else:
    try:result[k]='#'+''.join(f'{round(int(result[k][i:i+2],16)*dim/100):02x}' for i in (1,3,5))
    except (TypeError,ValueError):continue
  return result
