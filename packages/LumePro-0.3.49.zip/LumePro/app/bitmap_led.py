"""Logitech LED SDK's 21×6 BGRA bitmap. No guessed physical key map.
This module uses only the SDK bitmap API. A successful call is not physical proof.
"""
WIDTH=21
HEIGHT=6
SIZE=WIDTH*HEIGHT

def valid_mapping(raw,allowed=None):
 if not isinstance(raw,dict):return {}
 out={};used=set()
 for key,value in raw.items():
  if not isinstance(key,str) or (allowed is not None and key not in allowed):continue
  if type(value) is not int or not 0<=value<SIZE or value in used:continue
  out[key]=value;used.add(value)
 return out

def rgb(h):
 if not isinstance(h,str) or len(h)!=7 or h[0]!='#':raise ValueError('invalid color')
 return tuple(int(h[i:i+2],16) for i in (1,3,5))

def make_bitmap(colors):
 """Mapping of SDK cell index -> RGB triple; BGRA, 504 bytes."""
 buf=bytearray(SIZE*4)
 for i in range(SIZE):buf[i*4+3]=255
 for i,(r,g,b) in colors.items():
  if type(i) is not int or not 0<=i<SIZE or any(type(c) is not int or not 0<=c<=255 for c in (r,g,b)):raise ValueError('invalid bitmap cell')
  buf[i*4:i*4+4]=bytes((b,g,r,255))
 return bytes(buf)

def probe(pattern,index=0):
 """A reversible steady-color probe. No flashing and no undocumented device commands."""
 if pattern=='all':return make_bitmap({i:(0,96,96) for i in range(SIZE)})
 if pattern=='off':return make_bitmap({})
 if pattern in ('cell','cell_magenta'):
  if type(index) is not int or not 0<=index<SIZE:raise ValueError('invalid cell')
  return make_bitmap({index:(0,160,160) if pattern=='cell' else (160,0,160)})
 if pattern=='bit':
  if type(index) is not int or not 0<=index<7:raise ValueError('invalid bit')
  # Two steady, distinct colors, one bit at a time. Both illuminate if supported.
  return make_bitmap({i:((0,150,150) if i&(1<<index) else (150,0,150)) for i in range(SIZE)})
 raise ValueError('invalid probe')

def frame_bitmap(frame,mapping):
 return make_bitmap({idx:rgb(frame[key]) for key,idx in mapping.items() if key in frame})


def decode_bits(bits):
 """Seven observed bits, least-significant first. Reject nonobservations."""
 if not isinstance(bits,list) or len(bits)!=7 or any(type(b) is not int or b not in (0,1) for b in bits):return None
 value=sum(b<<i for i,b in enumerate(bits))
 return value if value<SIZE else None
