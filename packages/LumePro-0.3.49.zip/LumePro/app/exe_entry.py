"""Windowed entry point with bounded crash supervision for the frozen app."""
import os
import sys
from pathlib import Path

if __name__ == '__main__':
    if sys.stdout is None:sys.stdout=open(os.devnull,'w',encoding='utf-8')
    if sys.stderr is None:sys.stderr=open(os.devnull,'w',encoding='utf-8')
    data=Path(os.environ.get('LOCALAPPDATA',str(Path.home())))/'LumePro'
    try:
        if getattr(sys,'frozen',False) and '--self-test' not in sys.argv and '--worker' not in sys.argv:
            from desktop import supervise
            raise SystemExit(supervise(sys.argv[1:],data))
        from server import main
        main()
    except Exception as exc:
        try:
            data.mkdir(parents=True,exist_ok=True)
            (data/'startup_error.txt').write_text(type(exc).__name__+': '+str(exc)[:1000],encoding='utf-8')
        except OSError:pass
        if sys.platform=='win32' and '--worker' not in sys.argv and '--self-test' not in sys.argv and '--no-browser' not in sys.argv:
            import ctypes
            ctypes.windll.user32.MessageBoxW(None,'LUME / PRO could not start. See %LOCALAPPDATA%\\LumePro\\startup_error.txt.','LUME / PRO',0x10)
        raise SystemExit(1)
