"""Optional official Logitech LED SDK. Uses installed DLL only, no firmware or HID writes.
The SDK targets a device class, not an individual serial-numbered keyboard.
"""
import ctypes
import os
from pathlib import Path
import re
import threading
import time
from keyhook import SCAN_CODE
from bitmap_led import probe,frame_bitmap,valid_mapping,make_bitmap,rgb as bitmap_rgb,SIZE

JIS = {'IntlRo':0x87,'KanaMode':0x88,'IntlYen':0x89,'Convert':0x8a,'NonConvert':0x8b}
HID = {**{'Key'+chr(65+i):4+i for i in range(26)},**{'Digit'+c:30+i for i,c in enumerate('1234567890')},**{'F'+str(i):57+i for i in range(1,13)},'Enter':0x28,'Escape':0x29,'Backspace':0x2a,'Tab':0x2b,'Space':0x2c,'Minus':0x2d,'Equal':0x2e,'BracketLeft':0x2f,'BracketRight':0x30,'Backslash':0x31,'Semicolon':0x33,'Quote':0x34,'Backquote':0x35,'Comma':0x36,'Period':0x37,'Slash':0x38,'CapsLock':0x39,'PrintScreen':0x46,'ScrollLock':0x47,'Pause':0x48,'Insert':0x49,'Home':0x4a,'PageUp':0x4b,'Delete':0x4c,'End':0x4d,'PageDown':0x4e,'ArrowRight':0x4f,'ArrowLeft':0x50,'ArrowDown':0x51,'ArrowUp':0x52,'ContextMenu':0x65,'ControlLeft':0xe0,'ShiftLeft':0xe1,'AltLeft':0xe2,'MetaLeft':0xe3,'ControlRight':0xe4,'ShiftRight':0xe5,'AltRight':0xe6,'MetaRight':0xe7,**JIS}
SCAN = {code:sc for sc,code in SCAN_CODE.items() if code in HID}
SCAN.update({'ControlRight':0x11d,'AltRight':0x138,'MetaLeft':0x15b,'MetaRight':0x15c,'ContextMenu':0x15d,'Insert':0x152,'Delete':0x153,'Home':0x147,'End':0x14f,'PageUp':0x149,'PageDown':0x151,'ArrowLeft':0x14b,'ArrowRight':0x14d,'ArrowUp':0x148,'ArrowDown':0x150,'PrintScreen':0x137})
# Pause has no simple Set-1 scan code; use HID. Fn is not a normal HID keyboard usage.
SCAN.pop('Pause',None)
# G_LOGO is the Logitech LED SDK key-name enumeration, not a USB usage.
# The Fn key is firmware-specific. Right Alt is a candidate on JIS only;
# never address it on ANSI where a real Right Alt key can exist.
EXTRA_CODES=('Fn','BoardLogo','GameMode','LightButton')
JIS_CODES=set(JIS)
G_LOGO=0xFFFF1

def required_bitmap_codes(layout):
 # All physical ordinary keys in the respective TKL preview. Fn and
 # accessory lights may be unavailable; they cannot be inferred.
 return set(HID)-({'MetaRight','AltRight'} if layout=='jis' else {'MetaRight',*JIS})

HEX=re.compile(r'^#[0-9a-fA-F]{6}$')

def find_dll():
 if os.name!='nt':return None
 bits=ctypes.sizeof(ctypes.c_void_p)*8
 roots=[os.environ.get('ProgramW6432'),os.environ.get('ProgramFiles'),os.environ.get('ProgramFiles(x86)')]
 names=['sdk_legacy_led_x64.dll' if bits==64 else 'sdk_legacy_led_x86.dll']
 for root in dict.fromkeys(r for r in roots if r):
  for name in names:
   p=Path(root)/'LGHUB'/'sdks'/name
   if p.is_file():return p
 return None

def frame_period(latency_ms):
 # Latest-frame mailbox; slow SDKs back off instead of accumulating frames.
 return max(1/60,min(.25,max(0.,latency_ms)*.001*1.5))

def percent(hx):return tuple(round(int(hx[i:i+2],16)*100/255) for i in (1,3,5))

class SDK:
 def __init__(self,path):
  self.dll=ctypes.CDLL(str(path))
  self.init=self.bind('LogiLedInit',[])
  self.target=self.bind('LogiLedSetTargetDevice',[ctypes.c_int])
  self.hid=self.bind('LogiLedSetLightingForKeyWithHidCode',[ctypes.c_int]*4,optional=True)
  self.scan=self.bind('LogiLedSetLightingForKeyWithScanCode',[ctypes.c_int]*4,optional=True)
  self.keyname=self.bind('LogiLedSetLightingForKeyWithKeyName',[ctypes.c_int]*4,optional=True)
  self.all=self.bind('LogiLedSetLighting',[ctypes.c_int]*3)
  self.bitmap=self.bind('LogiLedSetLightingFromBitmap',[ctypes.POINTER(ctypes.c_ubyte)],optional=True)
  self.save=self.bind('LogiLedSaveCurrentLighting',[],optional=True)
  self.restore=self.bind('LogiLedRestoreLighting',[],optional=True)
  self.shutdown=self.bind('LogiLedShutdown',[],restype=None)
  if not self.hid and not self.scan and not self.bitmap:raise RuntimeError('キー単位SDK関数がありません')
 def send_bitmap(self,data):
  if not self.bitmap or len(data)!=504:return False
  buf=(ctypes.c_ubyte*504).from_buffer_copy(data)
  return bool(self.bitmap(buf))
 def bind(self,name,args,restype=ctypes.c_bool,optional=False):
  f=getattr(self.dll,name,None)
  if f is None:
   if optional:return None
   raise RuntimeError('SDKに '+name+' がありません')
  f.argtypes=args;f.restype=restype;return f

class LogitechBackend:
 """SDK bool results describe API acceptance, not physical illumination."""
 def __init__(self,sdk_factory=SDK,dll_finder=find_dll):
  self.factory=sdk_factory;self.find=dll_finder;self.sdk=None;self.path=None;self.device=None;self.device_idx=None
  self.lock=threading.RLock();self.event=threading.Event();self.pending=None;self.running=True;self.error='未接続';self.sent=0;self.accepted=0;self.failed={};self.cache={};self.method='auto';self.saved=False
  self.bitmap_mapping={};self.output_mode='key';self.bitmap_cache=None;self.codes=list(HID)+list(EXTRA_CODES);self.overrides={};self.layout='jis';self.fn_candidate=True;self.key_methods={'Backslash':'auto','Fn':'auto','IntlYen':'auto'};self.coverage_results={};self.mailbox=threading.Lock();self.latency_ms=0.;self.last_frame_at=0.;self.frame_interval_ms=0.;self.retry_after={};self.last_result={};self.thread=threading.Thread(target=self._worker,daemon=True);self.thread.start()
 def list_devices(self):
  return [{'id':0,'name':'Logicool LED SDK (per-key RGB 対応機器)','leds':len(self.codes),'keyboard':True}] if self.path else []
 def connect(self):
  with self.lock:
   self._disconnect();self.path=self.find();self.error='SDKを検出しました。選択して初期化してください' if self.path else 'G HUBのLED SDK DLLが見つかりません（Pythonの32/64bitも確認）';return bool(self.path)
 def select(self,idx):
  with self.lock:
   if type(idx) is not int or idx!=0 or not self.path:self.error='SDKが未検出です';return False
   self._disconnect()
   try:
    s=self.factory(self.path)
    if not s.init():raise RuntimeError('LogiLedInit が失敗しました。G HUBを起動してください')
    self.sdk=s
    time.sleep(.35)
    if not s.target(4):raise RuntimeError('per-key RGB のターゲット指定に失敗しました')
    self.saved=bool(s.save and s.save());self.device=s;self.device_idx=0;self.error='';self.sent=0;self.accepted=0;self.failed={};return True
   except Exception as exc:
    self._disconnect();self.error='Logicool SDK: '+str(exc)[:180];return False
 def _disconnect(self):
  with self.mailbox:self.pending=None;self.event.clear()
  self.cache.clear();self.retry_after.clear();self.last_result.clear();self.bitmap_cache=None
  if self.sdk:
   try:
    if self.saved and self.sdk.restore:self.sdk.restore()
   except Exception:pass
   try:self.sdk.shutdown()
   except Exception:pass
  self.sdk=None;self.device=None;self.device_idx=None;self.saved=False
 def set_method(self,method):
  if method not in ('auto','hid','scan'):return False
  with self.lock:self.method=method;self.cache.clear();self.failed.clear();self.retry_after.clear();return True
 def set_layout(self,layout):
  if layout not in ('jis','ansi'):return False
  with self.lock:
   if self.layout!=layout:self.clear_pending();self.layout=layout;self.cache.clear();self.retry_after.clear();self.last_result.clear();self.output_mode='key';self.bitmap_mapping={};self.bitmap_cache=None
  return True
 def _set_key(self,code,rgb):
  s=self.sdk
  if not s:return False
  if code=='BoardLogo':
   fn=getattr(s,'keyname',None)
   return bool(fn and fn(G_LOGO,*rgb))
  if code in ('GameMode','LightButton'):return False
  method=self.key_methods.get(code,'auto') if self.layout=='jis' else 'auto'
  if method=='off':return False
  # Keep the Fn candidate independent of a global route chosen for another key.
  if method=='auto' and code!='Fn':method=self.method
  if code=='Fn':
   if self.layout!='jis' or not self.fn_candidate:return False
   # Candidate only: this may be ignored by the device firmware.
   hid,scan=0xe6,0x138
  else:hid,scan=HID.get(code),SCAN.get(code)
  if self.layout=='jis' and code=='Backslash':
   # SDK uses the US logical key name even on some JIS devices.
   # 0x31 and 0x32 are distinct USB keyboard usages; test them separately.
   hid=0x32 if method in ('auto','hid') else 0x31;scan=0x2b
   if method=='hid31':return bool(s.hid and s.hid(0x31,*rgb))
   if method=='hid64':return bool(s.hid and s.hid(0x64,*rgb))
   if method=='scan56':return bool(s.scan and s.scan(0x56,*rgb))
   if method=='iso56':return bool(getattr(s,'keyname',None) and s.keyname(0x56,*rgb))
  calls=[]
  if method in ('auto','hid') and s.hid and hid is not None:calls.append((s.hid,hid))
  if method in ('auto','scan') and s.scan and scan is not None:calls.append((s.scan,scan))
  # Japanese ] occupies the non-US key position. Scan code is useful when
  # SDK accepts the ANSI HID address without actually lighting the JIS key.
  if method=='auto' and code=='Backslash' and self.layout=='jis' and s.hid:
   calls.insert(1,(s.hid,0x31))
  if method in ('auto','keyname') and code in ('Backslash','Fn','IntlYen') and self.layout=='jis' and scan is not None and getattr(s,'keyname',None):calls.append((s.keyname,scan))
  for fn,k in calls:
   if fn(k,*rgb):return True
  return False
 def set_key_method(self,code,method):
  if code not in self.key_methods or method not in ('auto','hid','scan','keyname','off','hid31','iso56','hid64','scan56'):return False
  if method in ('hid31','iso56','hid64','scan56') and code!='Backslash':return False
  with self.lock:
   self.key_methods[code]=method;self.cache.pop(code,None);self.retry_after.pop(code,None);self.failed.pop(code,None);self.last_result.pop(code,None)
  return True
 def set_fn_candidate(self,enabled):
  with self.lock:self.fn_candidate=bool(enabled);self.cache.pop('Fn',None);self.retry_after.pop('Fn',None)
  return True
 def bitmap_available(self):
  return bool(self.sdk and getattr(self.sdk,'bitmap',None) and callable(getattr(self.sdk,'send_bitmap',None)))
 def configure_bitmap(self,mapping,enabled=False):
  with self.lock:
   if not isinstance(mapping,dict) or valid_mapping(mapping,set(self.codes))!=mapping:return False
   if enabled and not self.bitmap_available():self.error='ビットマップAPIがありません';return False
   if enabled and not required_bitmap_codes(self.layout).issubset(mapping):
    self.error='通常キーの対応付けが不足しています（］を含む）';return False
   self.clear_pending();self.bitmap_mapping=dict(mapping);self.output_mode='bitmap' if enabled else 'key';self.cache.clear();self.bitmap_cache=None;self.last_result.clear();self.failed.clear();self.retry_after.clear();return True
 def test_bitmap(self,pattern,index=0):
  with self.lock:
   if not self.bitmap_available():self.error='SDKのビットマップAPIがありません';return False
   try:
    data=probe(pattern,index);self.clear_pending();self.cache.clear();self.bitmap_cache=None;self.retry_after.clear();self.last_result.clear()
    ok=self.sdk.send_bitmap(data);self.sent+=1;self.error='' if ok else 'SDKがビットマップを拒否しました';return ok
   except Exception as exc:self.error='ビットマップテスト: '+str(exc)[:150];return False
 def _write_bitmap(self,frame):
  if not self.bitmap_available():self.error='ビットマップAPIが利用できません';return False
  data=frame_bitmap(frame,self.bitmap_mapping)
  changed=data!=self.bitmap_cache
  if changed:
   if not self.sdk.send_bitmap(data):self.error='SDKがビットマップを拒否しました';return False
   self.bitmap_cache=data;self.sent+=1;self.accepted+=sum(k in frame for k in self.bitmap_mapping)
   self.last_result={k:'accepted' for k in self.bitmap_mapping if k in frame}
  # G logo is an independent official key-name target, not necessarily a matrix cell.
  if 'BoardLogo' in frame and 'BoardLogo' not in self.bitmap_mapping:
   color=percent(frame['BoardLogo'])
   if changed or self.cache.get('BoardLogo')!=color:
    ok=self._set_key('BoardLogo',color);self.last_result['BoardLogo']='accepted' if ok else 'rejected'
    if ok:self.cache['BoardLogo']=color;self.accepted+=1
    else:self.error='Gロゴの独立送信をSDKが拒否しました';return False
  self.error='';return True
 def test_coverage(self,color):
  """Uniform diagnostic only. No unverified addresses, no guessed bitmap map."""
  if color not in ('#00ffff','#000000'):return False
  with self.lock:
   if not self.sdk:return False
   self.clear_pending();self.cache.clear();self.bitmap_cache=None;self.retry_after.clear();self.last_result.clear();self.failed.clear()
   results={};c=percent(color)
   def attempt(label,call):
    try:results[label]='accepted' if call() else 'rejected'
    except Exception:results[label]='error'
   attempt('global',lambda:self.sdk.all(*c))
   if self.bitmap_available():attempt('bitmap',lambda:self.sdk.send_bitmap(make_bitmap({i:bitmap_rgb(color) for i in range(SIZE)})))
   # Matrix may omit JIS keys and the logo; explicitly send known SDK routes after it.
   for code in [*sorted(required_bitmap_codes(self.layout)),*(['Fn'] if self.layout=='jis' and self.fn_candidate else []),'BoardLogo']:
    if self.key_methods.get(code)=='off' and self.layout=='jis':continue
    attempt(code,lambda code=code:self._set_key(code,c))
   self.coverage_results={'color':color,'routes':results,'unaddressed':['GameMode','LightButton'],'physical_verified':False}
   self.sent+=1;self.accepted+=sum(x=='accepted' for x in results.values())
   self.error='一部のSDK送信が失敗しました' if any(v!='accepted' for v in results.values()) else ''
   return results.get('global')=='accepted' or results.get('bitmap')=='accepted'
 def _write(self,frame):
  if self.output_mode=='bitmap':return self._write_bitmap(frame)
  # Skip identical values; a failed call is reported, not treated as a verified LED.
  count=0;failed={};now=time.monotonic()
  for code,hx in frame.items():
   if code not in self.codes:continue
   if code in ('GameMode','LightButton') or (self.layout=='jis' and self.key_methods.get(code)=='off') or (code=='Fn' and (self.layout!='jis' or not self.fn_candidate)):continue
   if self.retry_after.get(code,0)>now:continue
   rgb=percent(hx)
   if self.cache.get(code)==rgb:continue
   if self._set_key(code,rgb):self.cache[code]=rgb;count+=1;self.failed.pop(code,None);self.retry_after.pop(code,None);self.last_result[code]='accepted'
   else:failed[code]='SDK rejected';self.failed[code]=failed[code];self.retry_after[code]=now+2.;self.last_result[code]='rejected'
  self.accepted+=count;self.sent+=1
  self.error=('SDKが拒否したキー: '+', '.join(self.failed)) if self.failed else ''
  return not failed
 def set_mapping(self,index,code):
  self.error='公式SDKではHID/スキャンコードを使用します。手動LED割り当てはOpenRGB専用です';return False
 def clear_pending(self):
  with self.mailbox:self.pending=None;self.event.clear()
 def queue_frame(self,frame):
  if not isinstance(frame,dict):return
  safe={k:v for k,v in frame.items() if k in self.codes and isinstance(v,str) and HEX.fullmatch(v)}
  with self.mailbox:self.pending=safe;self.event.set()
 def test_led(self,index=None,color='#ffffff'):
  if not isinstance(color,str) or not HEX.fullmatch(color):return False
  with self.lock:
   if not self.sdk:return False
   if index is not None and (type(index) is not int or not 0<=index<len(self.codes)):return False
   if self.output_mode=='bitmap':
    self.clear_pending();self.bitmap_cache=None;self.cache.clear()
    if index is None:
     from bitmap_led import make_bitmap,rgb,SIZE
     try:
      ok=self.sdk.send_bitmap(make_bitmap({i:rgb(color) for i in range(SIZE)}));self.sent+=1;self.error='' if ok else 'SDKがビットマップを拒否しました';return ok
     except Exception as exc:self.error=str(exc)[:150];return False
    cell=self.bitmap_mapping.get(self.codes[index])
    if cell is None:self.error='ビットマップ未割り当て: '+self.codes[index];return False
    try:
     from bitmap_led import make_bitmap,rgb
     ok=self.sdk.send_bitmap(make_bitmap({cell:rgb(color)}));self.sent+=1;self.error='' if ok else 'SDKがビットマップを拒否しました';return ok
    except Exception as exc:self.error=str(exc)[:150];return False
   if index is not None and self.codes[index] in ('GameMode','LightButton'):
    self.error='公式SDKに個別制御APIが公開されていません: '+self.codes[index];return False
   self.clear_pending();self.cache.clear();self.failed.clear();self.retry_after.clear()
   try:
    if not self.sdk.all(*percent(color if index is None else '#000000')):raise RuntimeError('全体点灯APIが失敗しました')
    # Whole-device test uses the official global method, not the OpenRGB LED list.
    if index is None:self.sent+=1;self.error='';return True
    code=self.codes[index];ok=self._set_key(code,percent(color));self.sent+=1
    self.error='' if ok else ('公式SDKに個別制御APIが公開されていません: '+code if code in ('GameMode','LightButton') else 'SDKが拒否: '+code)
    if not ok:self.failed[code]='SDK rejected'
    self.last_result[code]='accepted' if ok else 'rejected'
    return ok
   except Exception as exc:self.error='点灯テスト失敗: '+str(exc)[:180];return False
 def probe_special(self,code,method,color):
  # Explicit, bounded SDK probes; a true return is only API acceptance.
  choices={'Backslash':('hid','hid31','hid64','scan','scan56','keyname','iso56'),'Fn':('hid','scan','keyname'),'IntlYen':('hid','scan','keyname')}
  if code not in choices or method not in choices[code] or color not in ('#00b0ff','#d000dc'):return False
  with self.lock:
   if not self.sdk or self.layout!='jis':self.error='日本語配列の公式SDKに接続してください';return False
   self.clear_pending();self.cache.clear();self.bitmap_cache=None;self.retry_after.clear();self.last_result.clear()
   prev=self.key_methods[code];self.key_methods[code]=method
   try:
    if not self.sdk.all(0,0,0):raise RuntimeError('全体消灯APIが失敗しました')
    ok=self._set_key(code,percent(color));self.sent+=1
    self.error='' if ok else 'SDKがこの候補を拒否しました'
    return ok
   except Exception as exc:self.error=str(exc)[:180];return False
   finally:self.key_methods[code]=prev
 def test_jis(self):
  with self.lock:
   if not self.sdk:return False
   self.clear_pending();self.cache.clear();self.failed.clear();self.retry_after.clear()
   try:
    if not self.sdk.all(0,0,0):raise RuntimeError('全体消灯APIが失敗しました')
    return self._write(dict(zip(JIS,['#ff0000','#00ff00','#0080ff','#ff00ff','#ffff00'])))
   except Exception as exc:self.error='JIS点灯テスト失敗: '+str(exc)[:180];return False
 def _worker(self):
  # Latest frame wins. Rendering and key collection never wait for SDK writes.
  while self.running:
   self.event.wait(.5)
   if not self.running:break
   delay=frame_period(self.latency_ms)-(time.monotonic()-self.last_frame_at)
   if delay>0:time.sleep(delay)
   with self.lock:
    with self.mailbox:
     f=self.pending;self.pending=None;self.event.clear()
    if self.sdk and f:
     started=time.monotonic()
     if self.last_frame_at:self.frame_interval_ms=(started-self.last_frame_at)*1000
     self.last_frame_at=started
     try:self._write(f)
     except Exception as exc:self.error='SDK送信失敗: '+str(exc)[:180];self.cache.clear()
     measured=(time.monotonic()-started)*1000
     self.latency_ms=max(measured,self.latency_ms*.82+measured*.18)
 def status(self):
  with self.lock:
   return {'backend':'logitech','connected':bool(self.path),'active':self.device is not None,'device':self.device_idx,'devices':self.list_devices(),'matched':sum(v=='accepted' for v in self.last_result.values()) if self.device else 0,'sent':self.sent,'accepted_calls':self.accepted,'error':self.error,'method':self.method,'failed_keys':dict(self.failed),'missing_jis':[c for c in JIS if c in self.failed],'output_mode':self.output_mode,'bitmap_available':self.bitmap_available(),'bitmap_mapping':dict(self.bitmap_mapping),'bitmap_missing':sorted(required_bitmap_codes(self.layout)-self.bitmap_mapping.keys()),'unsupported_keys':([k for k in (*EXTRA_CODES,'Backslash') if k not in self.bitmap_mapping and not (k=='BoardLogo' and self.sdk and getattr(self.sdk,'keyname',None))] if self.output_mode=='bitmap' else ['GameMode','LightButton']+(['BoardLogo'] if not (self.sdk and getattr(self.sdk,'keyname',None)) else [])),'candidate_keys':['Fn'] if self.layout=='jis' else [],'layout':self.layout,'fn_candidate':self.fn_candidate,'key_methods':dict(self.key_methods),'send_ms':round(self.latency_ms,2),'send_fps':round(1000/self.frame_interval_ms,1) if self.frame_interval_ms else 0,'api_results':dict(self.last_result),'coverage_results':dict(self.coverage_results),'led_map':[{'index':i,'name':c,'code':c,'sdk_id':hex(0x32 if c=='Backslash' and self.layout=='jis' else HID[c]) if c in HID else ('G_LOGO' if c=='BoardLogo' else '候補 / 未公開')} for i,c in enumerate(self.codes)] if self.device else [],'device_info':{'dll':str(self.path or ''),'scope':'all compatible per-key RGB devices, no serial selection','verification':'API acceptance only; physical result unverified','hid_available':bool(self.sdk and self.sdk.hid),'scan_available':bool(self.sdk and self.sdk.scan),'keyname_available':bool(self.sdk and getattr(self.sdk,'keyname',None))}}
 def close(self):
  self.running=False;self.event.set();self.thread.join(timeout=2)
  with self.lock:self._disconnect()
