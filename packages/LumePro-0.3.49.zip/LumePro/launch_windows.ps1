﻿# LUME / PRO Windows launcher. No extra Python dependencies are needed for the UI.
# Windows PowerShell 5.1 compatible. UTF-8 BOM for Japanese Windows environments.
[CmdletBinding()]
param(
    [ValidateSet('run','openrgb','music','hid','diagnose')]
    [string]$Action = 'run',
    [string]$PythonPath = ''
)

$ErrorActionPreference = 'Continue'
Set-Location -LiteralPath $PSScriptRoot
$chosen = $null
$candidates = New-Object 'System.Collections.Generic.List[string]'
$seen = @{}

function Add-PythonCandidate {
    param([string]$Candidate)
    if ([string]::IsNullOrWhiteSpace($Candidate)) { return }
    $Candidate = $Candidate.Trim().Trim('"')
    if ($Candidate -like '*\Microsoft\WindowsApps\*') { return }
    try {
        if ((Test-Path -LiteralPath $Candidate -PathType Leaf) -and (-not $seen.ContainsKey($Candidate))) {
            $seen[$Candidate] = $true
            [void]$candidates.Add($Candidate)
        }
    } catch { }
}

# User override is tried first. An invalid override does not prevent fallbacks.
Add-PythonCandidate $PythonPath
Add-PythonCandidate $env:LUMEPRO_PYTHON

# An installed interpreter on PATH is preferable to a stale Python launcher registration.
foreach ($name in @('python.exe', 'python3.exe')) {
    Get-Command $name -All -ErrorAction SilentlyContinue | ForEach-Object {
        if ($_.Source) { Add-PythonCandidate $_.Source }
    }
}

# The launcher may know about several versions. Never blindly use `py -3`.
$launcher = Get-Command py.exe -ErrorAction SilentlyContinue
if ($launcher) {
    $entries = @(& $launcher.Source -0p 2>$null)
    foreach ($entry in $entries) {
        $match = [regex]::Match([string]$entry, '(?i)([A-Z]:\\.*?python\.exe)')
        if ($match.Success) { Add-PythonCandidate $match.Groups[1].Value }
    }
}

# Search only common installation paths, not arbitrary user directories.
$patterns = @()
if ($env:LOCALAPPDATA) {
    $patterns += (Join-Path $env:LOCALAPPDATA 'Programs\Python\Python*\python.exe')
    $patterns += (Join-Path $env:LOCALAPPDATA 'Python\pythoncore-*\python.exe')
    $patterns += (Join-Path $env:LOCALAPPDATA 'Microsoft\WinGet\Packages\*Python*\*\python.exe')
    $patterns += (Join-Path $env:LOCALAPPDATA 'uv\python\cpython-*\python.exe')
}
if ($env:ProgramFiles) { $patterns += (Join-Path $env:ProgramFiles 'Python*\python.exe') }
if (${env:ProgramFiles(x86)}) { $patterns += (Join-Path ${env:ProgramFiles(x86)} 'Python*\python.exe') }
$patterns += 'C:\Python*\python.exe'
foreach ($pattern in $patterns) {
    Get-ChildItem -Path $pattern -File -ErrorAction SilentlyContinue | ForEach-Object {
        Add-PythonCandidate $_.FullName
    }
}

# Only use a real, executable Python 3.10+; skip missing or damaged installations.
$versionCheck = 'import sys, http.server, ctypes, json, socket, pathlib; raise SystemExit(0 if sys.version_info >= (3,10) else 3)'
foreach ($candidate in $candidates) {
    try {
        & $candidate -I -c $versionCheck 1>$null 2>$null
        if ($LASTEXITCODE -eq 0) {
            $chosen = $candidate
            break
        }
    } catch { }
}

if ($Action -eq 'diagnose') {
    Write-Host ('[LUME] Checked ' + $candidates.Count + ' candidate(s).')
    foreach ($candidate in $candidates) { Write-Host ('  ' + $candidate) }
    if ($chosen) { Write-Host ('[LUME] Working Python: ' + $chosen); exit 0 }
    Write-Host '[LUME] No working Python 3.10+ was found.'
    exit 10
}

if (-not $chosen) {
    Write-Host ''
    Write-Host '[LUME] 利用可能な Python 3.10 以降が見つかりませんでした。' -ForegroundColor Yellow
    Write-Host '[LUME] 原因は未インストールとは限りません。古いパス登録や破損も考えられます。'
    Write-Host '[LUME] 設定例: set "LUMEPRO_PYTHON=C:\path\to\python.exe"'
    Write-Host '[LUME] https://www.python.org/downloads/windows/'
    exit 10
}

Write-Host ('[LUME] Python: ' + $chosen)
switch ($Action) {
    'run' {
        Write-Host '[LUME] Starting the editor...'
        & $chosen -u (Join-Path $PSScriptRoot 'app\server.py')
        exit $LASTEXITCODE
    }
    'openrgb' {
        & $chosen -m pip install openrgb-python
        exit $LASTEXITCODE
    }
    'hid' {
        & $chosen -m pip install hidapi websocket-client
        exit $LASTEXITCODE
    }
    'music' {
        & $chosen -m pip install soundcard numpy
        if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
        & $chosen -m pip install PyAudioWPatch
        if ($LASTEXITCODE -ne 0) { Write-Host "[LUME] Optional WASAPI backend installation failed; SoundCard remains available." -ForegroundColor Yellow }
        exit 0
    }
}
