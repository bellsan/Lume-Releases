"""Windows CI: test the frozen executable, recovery and real file replacement in a temporary profile."""
import base64, hashlib, json, os, shutil, socket, subprocess, sys, tempfile, time, urllib.request
from pathlib import Path
exe=Path(sys.argv[1]).resolve();version=sys.argv[2]
root=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root/'app'))
from frozen_update import SCRIPT,validate_pe

def port_number():
    with socket.socket() as s:s.bind(('127.0.0.1',0));return s.getsockname()[1]

def request(port,path,token=None,data=None):
    h={'X-Lume-Token':token} if token else {'X-Lume-Bootstrap':'1'}
    b=None if data is None else json.dumps(data).encode('utf-8')
    if b is not None:h['Content-Type']='application/json'
    with urllib.request.urlopen(urllib.request.Request(f'http://127.0.0.1:{port}{path}',data=b,headers=h),timeout=3) as r:return r.read()

def get(port,path,token=None,data=None):return json.loads(request(port,path,token,data))
def wait_for(predicate,seconds=90):
    end=time.monotonic()+seconds
    while time.monotonic()<end:
        try:
            result=predicate()
            if result:return result
        except (OSError,ValueError,KeyError):pass
        time.sleep(.4)
    raise RuntimeError('Startup/recovery timeout')

def kill_tree(pid):
    subprocess.run(['taskkill','/PID',str(pid),'/T','/F'],capture_output=True,timeout=15)

def session(data):return json.loads((data/'desktop_session.json').read_text('utf-8'))

def cleanup(proc,data):
    if proc.poll() is None:kill_tree(proc.pid)
    try:
        pid=session(data)['pid'];kill_tree(pid)
    except (OSError,ValueError,KeyError):pass
    try:proc.wait(timeout=15)
    except subprocess.TimeoutExpired:proc.kill();proc.wait()

with tempfile.TemporaryDirectory(prefix='lume-smoke-') as temp:
    data=Path(temp)/'LumePro';env=dict(os.environ,LOCALAPPDATA=temp)
    subprocess.run([str(exe),'--self-test'],env=env,check=True,timeout=120)
    port=port_number();proc=subprocess.Popen([str(exe),'--no-browser','--port',str(port)],env=env)
    try:
        wait_for(lambda:get(port,'/api/update/status')['current']==version)
        assert b'LUME / PRO' in request(port,'/')
        assert request(port,'/favicon.ico')[:4]==b'\0\0\1\0'
        assert len(request(port,'/app.js'))>10000
        token=get(port,'/api/token')['token']
        assert get(port,'/api/update/status',token)['frozen'] is True
        status=get(port,'/api/status',token)['desktop'];assert status['supported'] and not status['startup'] and status['recovery']
        assert 'presets' in get(port,'/api/presets',token)
        # Exercise settings and authentication without registering startup on this runner.
        assert get(port,'/api/desktop',token,{'recovery':True})['ok']
        assert get(port,'/api/preferences',token,{'auto':False})['ok']
        initial=session(data)['pid']
        duplicate=subprocess.run([str(exe),'--no-browser'],env=env,timeout=60)
        assert duplicate.returncode==0 and session(data)['pid']==initial
        # Simulated unexpected failure of this isolated test worker only.
        kill_tree(initial)
        wait_for(lambda:session(data)['pid']!=initial and get(port,'/api/update/status')['current']==version)
        new_token=get(port,'/api/token')['token'];assert new_token!=token
        assert get(port,'/api/preferences',new_token)['preferences']['auto'] is False
        assert get(port,'/api/shutdown',new_token,{})['ok']
        assert proc.wait(timeout=45)==0
    finally:cleanup(proc,data)
print('Windows EXE startup, resources, settings, duplicate launch, crash recovery and clean shutdown passed')

# Exercise the actual update helper against two isolated real EXE copies. The published
# artifact is not modified, and no external release must be downloaded in the test.
with tempfile.TemporaryDirectory(prefix='lume-swap-') as temp:
    work=Path(temp);data=work/'profile'/'LumePro';data.mkdir(parents=True)
    (data/'preferences.json').write_text(json.dumps({'auto':False,'tray':False,'recovery':False}),'utf-8')
    env=dict(os.environ,LOCALAPPDATA=str(data.parent));target=work/'LumePro.exe';shutil.copy2(exe,target)
    stage=work/'.lume-update-test';stage.mkdir();candidate=stage/'LumePro.exe';shutil.copy2(exe,candidate)
    digest=hashlib.sha256(candidate.read_bytes()).hexdigest();validate_pe(candidate)
    port=port_number();backup=work/'LumePro.exe.previous';marker=data/'exe_update_error.txt'
    proc=subprocess.Popen([str(target),'--no-browser','--port',str(port)],env=env)
    try:
        wait_for(lambda:get(port,'/api/update/status')['current']==version)
        token=get(port,'/api/token')['token']
        c=dict(target=str(target),source=str(candidate),backup=str(backup),marker=str(marker),work=str(stage),port=port,digest=digest,version=version)
        script=SCRIPT.replace('__CONFIG__',base64.b64encode(json.dumps(c).encode()).decode())
        encoded=base64.b64encode(script.encode('utf-16le')).decode()
        # Start the helper while the old EXE is still active, as the updater does.
        ps=subprocess.Popen(['powershell.exe','-NoProfile','-NonInteractive','-EncodedCommand',encoded],env=env,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
        assert get(port,'/api/shutdown',token,{})['ok'];assert proc.wait(timeout=45)==0
        _,err=ps.communicate(timeout=150);assert ps.returncode==0,err
        assert backup.is_file() and hashlib.sha256(backup.read_bytes()).hexdigest()==digest
        assert not stage.exists() and hashlib.sha256(target.read_bytes()).hexdigest()==digest
        assert not marker.exists(),marker.read_text('utf-8') if marker.exists() else ''
        wait_for(lambda:get(port,'/api/update/status')['current']==version)
        new_token=get(port,'/api/token')['token'];assert new_token!=token
        assert get(port,'/api/preferences',new_token)['preferences']['auto'] is False
        assert get(port,'/api/shutdown',new_token,{})['ok']
        wait_for(lambda:not (data/'desktop_session.json').exists(),30)
        # Wait for the supervisor/bootloader to release the executable.
        def unlocked():
            try:target.rename(work/'verified.exe');return True
            except OSError:return False
        wait_for(unlocked,30)
    finally:cleanup(proc,data)
print('Windows replacement helper: locked EXE -> backup -> restart -> health check -> settings retained passed')
