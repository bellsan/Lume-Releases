# 提供されたLGHUB.zipの静的調査

調査対象: LGHUB.zip（約251 MiB、540エントリー、パッケージ内バージョン43.8.4）。実行ファイルは実行せず、アーカイブ、文字列、PEエクスポートを確認した。

## 確認できた情報

- `LGHUB/data/lighting/effects/audio-visualizer-kb-per-key.json`: 周波数ビジュアライザーの汎用LED割り当て。PERKEY_KEYBOARD、PERKEY_INDICATOR（slotCode 1〜5）、PERKEY_CONSUMER（181、182、183、205、226）、PERKEY_BRANDING（1、2）、PERKEY_COSMETIC系の分類を確認。これはC339専用の割り当て表ではない。
- `LGHUB/sdks/sdk_legacy_led_x64.dll`: キー単位、ビットマップ、全体のLED制御に加え `LogiLedSetLightingForTargetZone` のエクスポートを確認。しかしC339の照明・ゲームモードボタンがこのAPIの有効ゾーンである証拠は見つからなかった。
- `LGHUB/lghub_agent.exe`: 上記のLED分類に関連する文字列を確認。C339専用の対応付けは未特定。
- `LGHUB/resources/app.asar`: GUIコードと画像を確認。実行時インターフェースのkeyboardLayout等を参照する構造だが、C339固有のボタン番号・再利用可能なJISキーボード画像を特定できなかった。

## 結論と今回の変更

G HUB内部には標準キー以外のLEDを分類する仕組みがある。ただし、当該キーボードの2ボタンが独立したRGB制御に対応することは確認できていない。推測したUSB命令やSDKゾーンへの送信は実装しない。既存の確認済みの］キーとFnの設定は保持。HID学習中のライティング送信を停止して通知の混入を減らす。Fn押下検出と右上2ボタンの点灯制御は引き続き未解決。次に必要なのは、G HUBが実行時に取得する当該機種のLED能力と実機での読み取り検証。

同梱LICENSEはElectronに関するライセンスを含むが、G HUB全体の画像やDLLの再配布許可を確認できない。配布用ZIPには元のファイルを含めず、すでにインストールされた公式SDKを利用する。


## v0.3.23 追加解析
LGHUB/resources/app.asar 内の main.js で ws://localhost:9010、JSONサブプロトコルとGET/SUBSCRIBEを確認。app.min.js には /devices/list、/keyboard/%(id)s/game_mode、/lighting/%(id)s/master_switch_on があり、状態処理には enabled と value が使われています。lghub_agent.exe の文字列には Feature4523DisableControls::Report::onGameModeEvent、Feature8080PerKeyLighting、Feature8081PerKeyLighting が存在します。ただしC339の対応機能やRGBゾーン番号は静的な文字列だけでは確定できません。新しい読み取り専用監視はこれらのパスを使用します。実機の応答がない場合は未取得と表示します。
