@echo off
setlocal
cd /d "%~dp0"

if not exist "app\server.py" (
    echo [LUME] app\server.py was not found.
    echo Extract the entire ZIP into a normal folder before starting the app.
    pause
    exit /b 2
)

where powershell.exe >nul 2>nul
if errorlevel 1 (
    echo [LUME] Windows PowerShell was not found.
    pause
    exit /b 3
)

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0launch_windows.ps1" -Action run
set "result=%errorlevel%"
if not "%result%"=="0" (
    echo.
    echo [LUME] Start failed, code %result%.
    echo Please check the message above. See README_JA.md for troubleshooting.
    pause
)
exit /b %result%
