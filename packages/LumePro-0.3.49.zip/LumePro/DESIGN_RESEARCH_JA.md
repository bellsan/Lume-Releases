# LUME / PRO — UI設計・調査メモ（2026-11-24）

## 方針

Deep Researchの結果を元に、**デスクトップ向けの精密なエディター**として設計した。キャッチコピーのあるランディングページ、意味のない装飾カード、どこでも光るネオンを排除。RGBは操作対象のキーボードにだけ使う。情報密度・視線移動・操作速度を優先する。

### 採用した実在製品の考え方

- Logitech G HUB / LIGHTSYNC：デバイス→機能の単純な導線、個別キーRGBの設定。公式： https://www.logitechg.com/en-us/software/guides/g-hub-basics 、 https://www.logitechg.com/en-us/software/guides/lightsync-rgb
- Razer Chroma Studio：レイヤーを重ねてキーに効果を割り当てる。参考： https://www.razer.com/ap-en/chroma
- Figmaの右サイドバー：選択オブジェクトだけのプロパティを見せる。参考： https://help.figma.com/hc/en-us/articles/360039832014-Design-prototype-and-explore-layer-properties-in-the-right-sidebar
- Adobe After Effects：必要なパネルをスタック化して作業領域を確保。参考： https://helpx.adobe.com/after-effects/desktop/get-started/get-familiar-with-the-interface/workspaces-panels-viewers.html
- DaVinci Resolve：大きなビューア＋タスク別パレットの操作密度。参考： https://www.blackmagicdesign.com/jp/products/davinciresolve/color
- Linear：控えめな色、コンパクトなタブ、落ち着いたヒエラルキー。参考： https://linear.app/now/behind-the-latest-design-refresh
- Microsoft Windows Settings：重要なものを開示し、高度なものを設定グループにまとめる。参考： https://learn.microsoft.com/en-us/windows/apps/design/app-settings/guidelines-for-app-settings
- Microsoft Fluent 2：短い機能的なモーション。参考： https://fluent2.microsoft.design/motion
- Attack Shark：公式配布ページと各モデルの機能を確認したが、正確なソフトのRGB編集画面は調査で追跡できなかった。UIの模倣元にはせず、ライティング機能の参考に限定。 https://attackshark.com/pages/driver-download

ギャラリー（色や質感の参考でありUX正当性の証拠ではない）：
- https://refero.design/pages/7a7ea171-0cf4-4475-8b45-cc8ec44fde8f
- https://muz.li/inspiration/dark-mode/
- https://muz.li/inspiration/settings-page/
- https://dribbble.com/search/wheel-slider
- https://www.behance.net/search/projects/desktop%20gui
- https://www.ui-pocket.com/apps/

## カラー＆文字

- App `#0A0B0E`, Primary panel `#0F1115`, Raised `#15181E`, Hover `#1B1E25`
- Border `#252A31`, Text `#F0F1F4`, Secondary `#A1A6B1`, Muted `#737B88`
- Accent `#9AA5FF`, Positive `#72CBB4`, Danger `#F27C86`
- Windows既存：`Segoe UI Variable`、日本語：`Yu Gothic UI`。将来の候補：Noto Sans JP。実際の配布パッケージへフォントの無断同梱はしない。
- コンパクトな操作ラベルは主に11–13px。ページタイトル22px。数値はtabular-nums。
- デバイスの発光色はGUIのメインアクセントとして乱用しない。

## CSS モーション仕様

- Hover / click: 140ms
- Accordion: grid-template-rows 0fr↔1fr + opacity, 240ms, cubic-bezier(.2,.8,.2,1)
- Popover: 190ms translateY(-5px→0) + scale(.985→1) + opacity
- View: 165ms cross fade
- modal: 240ms small translate + scale
- reduced-motion: `prefers-reduced-motion: reduce` で空間移動を即時化
- 大型パネルの長距離スライド、常時の装飾アニメーション、無意味なバウンスは実装しない。

## GUI操作設計

左パネルはレイヤー順と表示状態を常時提示し、追加エフェクトメニューは＋でだけ開示。中央プレビューを編集キャンバスとして最大化。右は「カラー」「動き」「合成・強度」「対象キー」「入力・連動」。最初から全設定を開かず、アコーディオンで段階的に提示する。プレビューの発光表現はキー上面の単純なRGB塗りつぶしではなく、黒いキーキャップ・刻印色・間接グローで表現。

## 次に必要な実機研究

- 正式型番、世代、接続方式、VID/PID
- JIS91物理形状（特にEnter・無変換・変換・かな周辺）の実機との突き合わせ
- OpenRGB認識、LED番号・名前・マッピング・更新FPS
- ソフトと実機の色校正と発光効果の動きの比較
- 1920×1080・1440×900・1280×760における画面密度・表示性能

## アクセシビリティ

主要項目をボタン／スライダー／セレクトで操作できるようにし、Tabとキーボードショートカットを用意。フォーカス可視化とreduced motionを尊重。今後はWindows実機で音声読み上げとキーボード移動の総合監査が必要。


## v0.3 — 今回のDeep Research反映

- [Fluent Motion](https://fluent2.microsoft.design/motion)、[Material duration/easing](https://m1.material.io/motion/duration-easing.html)、[NN/g Animation Duration](https://www.nngroup.com/articles/animation-duration/)、[MDN Animation performance](https://developer.mozilla.org/en-US/docs/Web/Performance/Guides/Animation_performance_and_frame_rate) の調査結果を参照。
- 起動時は詳細パネルを隠し、クリックで展開。選択グループもポップオーバー化。各詳細カテゴリは一つずつ展開。
- 操作フィードバック100ms、メニュー開200ms/閉140ms、詳細パネル開260ms/閉180ms。transform/opacity中心。キーボードプレビューは260msで再配置。縮小モーション設定対応。
- 91キーのJISプレビューを物理座標で再設計。L字Enter、上部インジケーター、筐体とキーキャップの立体感を追加。実機寸法の完全一致ではない。
- [Razer Chroma Guide](https://chroma.razer.com/ChromaGuide/) のキャンバスから編集を開く考え方を参考にした。
- 性能は60fpsを目標とし、非表示のキーボードへのスタイル更新を省略。実機送信は別レート・同時リクエスト制限を実装。実機FPSは未測定。

## v0.3.4 — 編集動線の再構成

既存の調査資料の段階的開示と選択対象中心の編集方針を継承。常設ツールバーの操作を減らし、二次操作をコンテキストメニューに移動した。レイヤーは色見本・強度・対象キー数・表示状態を安定した行内に配置。レイヤーを選ぶと詳細が展開し、基本/動き/対象/詳細のタブで目的に合う設定だけを提示する。メニューは opacity / transform の140〜190msトランジション、詳細の展開は260ms。縮小モーション設定に対応。


## v0.3.39 — Deep Research report applied
Erik Padamans toolbar/popups (https://dribbble.com/search/ui-toolbar), Constantine Smirnoff layer panel (https://dribbble.com/search/layer-panel), Fireart Studio dark cards (https://dribbble.com/search/ui-components-dark), Untitled UI and Relay CRM settings (https://dribbble.com/search/dark-theme-settings): grouping, visual hierarchy, selected state, readable labels, aligned switches. Source links are gallery search references from the report, not independently verified individual works. No curve editor or keyframes.
