@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0launch_windows.ps1" -Action openrgb
if errorlevel 1 echo [LUME] Installation failed. Check the messages above.
pause
