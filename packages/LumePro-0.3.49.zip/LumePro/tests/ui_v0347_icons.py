"""Vector icon refresh: mocked UI integration, no hardware writes."""
import asyncio,os
from pathlib import Path
from playwright.async_api import async_playwright
from ui_preset_menu import setup
ROOT=Path(__file__).resolve().parents[1]
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path=os.environ.get('CHROMIUM_PATH','/usr/bin/chromium'),args=['--no-sandbox'])
  page,errors=await setup(browser,{f:(ROOT/'app'/f).read_text() for f in ('index.html','style.css','app.js')})
  assert await page.locator('.rail .nav-link .lume-icon').count()==4
  assert await page.locator('.brand-mark .lume-brand').count()==1
  assert await page.evaluate('Object.keys(EFFECTS).every(t=>Object.hasOwn(EFFECT_ICONS,t)&&Object.hasOwn(LUME_ICONS,EFFECT_ICONS[t]))')
  for w,h in [(1260,800),(900,600)]:
   await page.set_viewport_size({'width':w,'height':h});await page.evaluate('navigate("lighting");setInspector(false,false);fitPreview()');await page.wait_for_timeout(600)
   await page.locator('#pauseBtn').click();assert await page.locator('#pauseBtn .lume-icon').count()==1
   await page.locator('#pauseBtn').click();assert await page.locator('#pauseBtn .lume-icon').count()==1
   await page.screenshot(path=f'/mnt/data/LumePro_v0.3.47_editor_{w}.png')
   await page.locator('#newLayerBtn').click();await page.wait_for_timeout(500)
   assert await page.evaluate('document.querySelectorAll(".effect-card .lume-icon").length===Object.keys(EFFECTS).length')
   await page.screenshot(path=f'/mnt/data/LumePro_v0.3.47_catalog_{w}.png')
   await page.locator('.effect-card[data-effect="audio_visualizer"]').click();await page.wait_for_timeout(600)
   assert await page.evaluate('currentLayer().type==="audio_visualizer" && $("effectIcon").querySelector(".lume-icon") && state.reactivePriority===false')
   await page.screenshot(path=f'/mnt/data/LumePro_v0.3.47_inspector_{w}.png')
   await page.evaluate('setInspector(false,false)');await page.wait_for_timeout(400)
   await page.locator('.layer-item.active .visible').click();assert await page.evaluate('!currentLayer().enabled')
   await page.locator('.layer-item.active .visible').click();assert await page.evaluate('currentLayer().enabled')
   await page.locator('.layer-item.active .layer-more').click();assert await page.locator('#layerMenu.open .lume-icon').count()==7
   await page.keyboard.press('Escape')
   await page.locator('[data-view=profiles]').click();await page.wait_for_timeout(350)
   assert await page.locator('[data-profile-view] .lume-icon').count()==2
   await page.locator('[data-profile-view=list]').click();await page.locator('[data-profile-view=cards]').click()
   await page.locator('.profile-card .preset-more').first.click();assert await page.locator('#presetMenu .lume-icon').count()==5
   await page.screenshot(path=f'/mnt/data/LumePro_v0.3.47_profiles_{w}.png')
   await page.keyboard.press('Escape');await page.locator('[data-view=keyboard]').click();await page.wait_for_timeout(250)
   assert await page.locator('#pickKeyColor .lume-icon').count()==1
   await page.locator('[data-view=settings]').click();await page.wait_for_timeout(350)
   await page.screenshot(path=f'/mnt/data/LumePro_v0.3.47_settings_{w}.png')
   print(w,'OK')
  assert not errors,errors
  await browser.close();print('PASS: navigation, vector effect catalog, inspector, playback, visibility, layer menu, preset menu, views')
if __name__=='__main__':asyncio.run(main())
