import hashlib, io, json, os, sys, time, zipfile
from pathlib import Path
import pytest
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'app'))
import updater as u

REPO='bellsan/Lume'
def release(ver='0.3.20',data=b'zip'):
    tag='v'+ver;name='LumePro-'+ver+'.zip';base=f'https://github.com/{REPO}/releases/download/{tag}/'
    return {'tag_name':tag,'name':tag,'body':'・機能を追加しました。\n・不具合を修正しました。','draft':False,'prerelease':False,
            'assets':[{'name':name,'size':len(data),'browser_download_url':base+name},{'name':name+'.sha256','size':65,'browser_download_url':base+name+'.sha256'}]}
def tree(root,ver='0.3.19'):
    (root/'app').mkdir(parents=True)
    for n in ('server.py','index.html','app.js','style.css','updater.py'):(root/'app'/n).write_text('old')
    (root/'app/version.json').write_text(json.dumps({'version':ver,'repository':REPO}))
    for n in ('start_windows.bat','launch_windows.ps1'):(root/n).write_text('old')
    return root

def archive(ver='0.3.20',extra=None):
    f=io.BytesIO()
    with zipfile.ZipFile(f,'w',zipfile.ZIP_DEFLATED) as z:
        for n in ('server.py','index.html','app.js','style.css','updater.py'):z.writestr('LumePro/app/'+n,'new')
        z.writestr('LumePro/app/version.json',json.dumps({'version':ver,'repository':REPO}))
        for n in ('start_windows.bat','launch_windows.ps1'):z.writestr('LumePro/'+n,'new')
        if extra:z.writestr(*extra)
    return f.getvalue()

def wait(m,phase):
    for _ in range(200):
        if m.status()['phase']==phase:return
        time.sleep(.01)
    raise AssertionError(m.status())

def test_version_numeric_and_release_urls():
    assert u.version_tuple('v0.3.20')>u.version_tuple('0.3.9')
    r=release();assert u.parse_release(r,REPO)['installable']
    r['assets'][0]['browser_download_url']='https://evil.example/package.zip'
    with pytest.raises(ValueError):u.parse_release(r,REPO)

def test_release_missing_checksum_and_prerelease():
    r=release();r['assets'].pop();assert not u.parse_release(r,REPO)['installable']
    r['prerelease']=True
    with pytest.raises(ValueError):u.parse_release(r,REPO)

def test_startup_cache_and_once_notification(tmp_path,monkeypatch):
    root=tree(tmp_path/'install');data=tmp_path/'data';calls=[]
    def read(*args,**kwargs):calls.append(args[0]);return json.dumps(release()).encode()
    monkeypatch.setattr(u,'read_bounded',read)
    m=u.Updater(root,data);m.check();wait(m,'idle');assert m.status()['notify'];m.acknowledge('0.3.20')
    m2=u.Updater(root,data);m2.check();assert not m2.status()['notify'];assert m2.status()['available'];assert len(calls)==1
    m2.check(manual=True);wait(m2,'idle');m2.check(manual=True);assert len(calls)==2
    m2.configure(False);m3=u.Updater(root,data);assert not m3.status()['auto'];m3.check();assert len(calls)==2

def test_download_verify_and_install_preserves_data(tmp_path,monkeypatch):
    root=tree(tmp_path/'install');data=tmp_path/'data';data.mkdir();(data/'presets.json').write_text('saved')
    payload=archive();r=release(data=payload)
    def read(url,*args,**kw):return (hashlib.sha256(payload).hexdigest()+'\n').encode() if url.endswith('.sha256') else json.dumps(r).encode()
    monkeypatch.setattr(u,'read_bounded',read);monkeypatch.setattr(u,'open_url',lambda *a,**k:io.BytesIO(payload))
    m=u.Updater(root,data);m.check();wait(m,'idle');m.download();wait(m,'ready');m.request_apply();assert m.finish()
    assert u.read_metadata(root)['version']=='0.3.20';assert (data/'presets.json').read_text()=='saved';assert (root/'app/server.py').read_text()=='new';assert list(root.glob('.lume-backup-*'))

def test_bad_checksum_rejected(tmp_path,monkeypatch):
    root=tree(tmp_path/'install');payload=archive();r=release(data=payload)
    monkeypatch.setattr(u,'read_bounded',lambda url,*a,**k: b'0'*64 if url.endswith('.sha256') else json.dumps(r).encode())
    monkeypatch.setattr(u,'open_url',lambda *a,**k:io.BytesIO(payload));m=u.Updater(root,tmp_path/'data');m.check();wait(m,'idle');m.download();wait(m,'error');assert 'SHA-256' in m.status()['error'];assert m.stage is None;assert u.read_metadata(root)['version']=='0.3.19'

def test_zip_traversal_and_wrong_version(tmp_path):
    with pytest.raises(ValueError):u.safe_extract(io.BytesIO(archive(extra=('LumePro/app/../../outside','bad'))),tmp_path/'stage','0.3.20',REPO)
    with pytest.raises(ValueError):u.safe_extract(io.BytesIO(archive('0.3.21')),tmp_path/'other','0.3.20',REPO)
    assert not (tmp_path/'outside').exists()

def test_rollback_on_file_replace_failure(tmp_path,monkeypatch):
    root=tree(tmp_path/'install');stage=tmp_path/'stage';u.safe_extract(io.BytesIO(archive()),stage,'0.3.20',REPO)
    real=os.replace
    def fail(src,dst):
        if Path(src)==stage/'start_windows.bat':raise PermissionError('locked')
        return real(src,dst)
    monkeypatch.setattr(u.os,'replace',fail)
    with pytest.raises(PermissionError):u.install_staged(root,stage)
    assert (root/'start_windows.bat').read_text()=='old';assert (root/'app/server.py').read_text()=='old';assert u.read_metadata(root)['version']=='0.3.19'

def test_older_release_not_offered(tmp_path,monkeypatch):
    m=u.Updater(tree(tmp_path/'install'),tmp_path/'data');monkeypatch.setattr(u,'read_bounded',lambda *a,**k:json.dumps(release('0.3.18')).encode());m.check();wait(m,'idle');assert not m.status()['available']
    with pytest.raises(ValueError):m.download()


def test_release_asset_digest_consistency(tmp_path,monkeypatch):
    root=tree(tmp_path/'install');payload=archive();r=release(data=payload)
    digest=hashlib.sha256(payload).hexdigest();checksum=(digest+'\n').encode()
    r['assets'][0]['digest']='sha256:'+digest
    r['assets'][1]['digest']='sha256:'+hashlib.sha256(checksum).hexdigest()
    assert u.parse_release(r,REPO)['asset_digest']==digest
    r['assets'][0]['digest']='sha256:'+'0'*64
    monkeypatch.setattr(u,'read_bounded',lambda url,*a,**kw:checksum if url.endswith('.sha256') else json.dumps(r).encode())
    def never(*a,**kw):raise AssertionError('must reject before download')
    monkeypatch.setattr(u,'open_url',never)
    m=u.Updater(root,tmp_path/'data');m.check();wait(m,'idle');m.download();wait(m,'error')
    assert 'SHA-256' in m.status()['error'] and m.stage is None
