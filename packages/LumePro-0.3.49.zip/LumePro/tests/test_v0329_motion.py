"""Temporal motion, matching browser math and safe adaptive output."""
import json, shutil, subprocess, time
from pathlib import Path
import pytest
from engine import filter_frame, AnimationEngine, validate, motion_pixel, MOTION_PROFILES
from logitech import frame_period
from test_v0316_studio import scene

def channel(frame):return int(frame['KeyA'][1:3],16)
def test_motion_profiles_and_exact_black():
    rise=[];fade=[]
    for mode in ('responsive','balanced','smooth'):
        m={'KeyA':(0.,0.,0.)};rise.append(channel(filter_frame({'KeyA':'#ff0000'},m,1/60,mode)))
        m={'KeyA':(255.,0.,0.)};fade.append(channel(filter_frame({'KeyA':'#000000'},m,1/60,mode)))
        for _ in range(120):f=filter_frame({'KeyA':'#000000'},m,1/60,mode)
        assert f['KeyA']=='#000000'
    assert rise[0]>rise[1]>rise[2]>0
    assert fade[0]<fade[1]<fade[2]<255

def test_frame_rate_independence():
    for mode in MOTION_PROFILES:
        a={'KeyA':(200.,100.,50.)};b=dict(a)
        for _ in range(6):f=filter_frame({'KeyA':'#000000'},a,1/60,mode)
        for _ in range(3):g=filter_frame({'KeyA':'#000000'},b,1/30,mode)
        assert abs(channel(f)-channel(g))<=1

def test_sdk_rate_backoff():
    assert frame_period(0)==pytest.approx(1/60)
    assert frame_period(20)==pytest.approx(.03)
    assert frame_period(70)==pytest.approx(.105)
    assert frame_period(1000)==.25

def test_scanner_loop_seam():
    l=scene('scanner',scanMode='loop',spread=20,motionTrail=100)[1][0]
    t=1/(l['speed']*.2)
    for x in (0,5,10,17):
        a=motion_pixel(l,x,2,t-.00001,(0,17,0,5))[0];b=motion_pixel(l,x,2,t+.00001,(0,17,0,5))[0]
        assert abs(a-b)<.001

@pytest.mark.skipif(not shutil.which('node'),reason='Node unavailable')
def test_browser_temporal_matches_engine(tmp_path):
    src=(Path(__file__).resolve().parents[1]/'app'/'app.js').read_text().rsplit('init();',1)[0]
    script=tmp_path/'filter.js';script.write_text(src+'''\nconst cases=JSON.parse(require('fs').readFileSync(0,'utf8'));let out=[];for(const c of cases){let p=[0,0,0];out.push(c.frames.map(f=>{p=filterRGB(hexToRGB(f[0]),p,f[1],c.mode);return rgbToHex(p)}))}console.log(JSON.stringify(out));''')
    cases=[{'mode':m,'frames':[['#ee8899',.016],['#2355ff',.028],['#000000',.010],['#777777',.045]]} for m in MOTION_PROFILES]
    result=json.loads(subprocess.check_output(['node',str(script)],input=json.dumps(cases).encode()))
    for case,arr in zip(cases,result):
        mem={'KeyA':(0.,0.,0.)}
        for (hx,dt),got in zip(case['frames'],arr):
            expected=filter_frame({'KeyA':hx},mem,dt,case['mode'])['KeyA']
            assert all(abs(int(got[i:i+2],16)-int(expected[i:i+2],16))<=1 for i in (1,3,5))

def test_static_scene_does_not_recompute(monkeypatch):
    import engine
    original=engine.render;calls=[]
    def count(*args,**kwargs):calls.append(1);return original(*args,**kwargs)
    monkeypatch.setattr(engine,'render',count)
    class Backend:
        device=object()
        def queue_frame(self,f):pass
        def clear_pending(self):pass
    class Keys:
        def since(self,seq):return {'seq':0,'events':[]}
    class Audio:
        def status(self):raise AssertionError('No audio effect is enabled')
    e=AnimationEngine(Backend(),Keys(),Audio())
    try:
        e.configure({'keys':[{'code':'KeyA','x':1,'y':1}], 'layers':[{'type':'static','color':'#aa0000'}]});e.enable(True)
        time.sleep(.15);assert calls==[1];assert e.status()['error']==''
    finally:e.close()

def test_motion_preference_persistence(tmp_path):
    from preferences import Preferences
    prefs=Preferences(tmp_path/'prefs.json')
    assert prefs.load()['motion_profile']=='balanced'
    prefs.update({'motion_profile':'smooth'})
    assert prefs.load()['motion_profile']=='smooth'
    assert prefs.update({'motion_profile':'unknown'})['motion_profile']=='balanced'
