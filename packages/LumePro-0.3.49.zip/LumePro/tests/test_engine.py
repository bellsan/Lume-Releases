import sys,time
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'app'))
from engine import AnimationEngine,render,validate
from keyhook import KeyboardWatcher
from audio import AudioMonitor
from hardware import normalize_led,OpenRGBBackend
import pytest

SCENE={'keys':[{'code':'KeyA','x':0,'y':0},{'code':'KeyS','x':1,'y':0},{'code':'KeyD','x':5,'y':0},{'code':'IntlYen','x':12,'y':0}], 'layers':[{'type':'ripple','color':'#ff0000','brightness':100,'speed':45,'spread':50,'fade':20,'enabled':True}],'keyColors':{}}
def test_idle_and_ripple():
 scene=validate(SCENE)
 assert set(render(scene,[],10).values())=={'#000000'}
 assert render(scene,[(0,0,10)],10)['KeyA']=='#ff0000'
 assert render(scene,[(0,0,10)],10)['KeyD']=='#000000'
 later=render(scene,[(0,0,10)],10+.53)
 assert int(later['KeyD'][1:3],16)>int(later['KeyA'][1:3],16)
 assert set(render(scene,[(0,0,10)],14).values())=={'#000000'}

def test_worker_responds_without_browser():
 class Fake:
  device=object()
  frames=[]
  def queue_frame(self,f):self.frames.append(f)
  def clear_pending(self):pass
 b=Fake();k=KeyboardWatcher();k.enabled=True;e=AnimationEngine(b,k,AudioMonitor())
 try:
  e.configure(SCENE);e.enable(True)
  time.sleep(.07);assert b.frames and b.frames[-1]['KeyA']=='#000000'
  k.push('KeyA')
  deadline=time.monotonic()+1
  while not e.pulse_count and time.monotonic()<deadline:time.sleep(.01)
  time.sleep(.06);assert e.pulse_count==1 and any(f['KeyA']!='#000000' for f in b.frames)
  e.enable(False);count=len(b.frames);k.push('KeyS');time.sleep(.08);assert len(b.frames)==count
 finally:e.close();k.stop()

def test_invalid_scene_rejected():
 with pytest.raises(ValueError):validate({'keys':[],'layers':[]})
 with pytest.raises(ValueError):validate({**SCENE,'keys':[SCENE['keys'][0]]*2})

def test_jis_coverage_not_faked():
 from types import SimpleNamespace
 b=OpenRGBBackend()
 try:
  b.devices=[SimpleNamespace(name='PRO Gaming Keyboard',type=5,leds=[SimpleNamespace(name='Key: A',value=4),SimpleNamespace(name='Key: International 3',value=137)],modes=[])]
  assert b.select(0);s=b.status();assert s['missing_jis']==['NonConvert','Convert','KanaMode','IntlRo'];assert s['led_map'][1]['sdk_id']=='137'
  for i,k in enumerate(['IntlRo','KanaMode','IntlYen','Convert','NonConvert'],1):assert normalize_led('Key: International '+str(i))==k
 finally:b.close()
