import json, urllib.error
from test_v0319_updater import tree, release, wait
import updater as u

def test_failed_check_does_not_reoffer_cached_release_after_restart(tmp_path, monkeypatch):
    root=tree(tmp_path/'install'); data=tmp_path/'data'
    monkeypatch.setattr(u,'read_bounded',lambda *a:json.dumps(release()).encode())
    m=u.Updater(root,data);m.check(True);wait(m,'idle');assert m.status()['available']
    def missing(*a):raise urllib.error.HTTPError('https://api.github.com',404,'missing',{},None)
    monkeypatch.setattr(u,'read_bounded',missing);m.last_manual=0;m.check(True);wait(m,'error')
    n=u.Updater(root,data);assert n.status()['phase']=='error';assert not n.status()['available']
    monkeypatch.setattr(u,'read_bounded',lambda *a:json.dumps(release()).encode());n.check(True);wait(n,'idle')
    assert n.status()['available'];assert 'check_error' not in n.cache

def test_periodic_checks_respect_interval_and_opt_out(tmp_path, monkeypatch):
    root=tree(tmp_path/'install');calls=[];t=[100000]
    monkeypatch.setattr(u.time,'time',lambda:t[0]);monkeypatch.setattr(u,'read_bounded',lambda *a:(calls.append(a[0]) or json.dumps(release()).encode()))
    m=u.Updater(root,tmp_path/'data');m.check();wait(m,'idle');assert len(calls)==1
    t[0]+=900;m.check();assert len(calls)==1
    t[0]+=u.AUTO_INTERVAL;m.check();wait(m,'idle');assert len(calls)==2
    m.configure(False);t[0]+=u.AUTO_INTERVAL;m.check();assert len(calls)==2
