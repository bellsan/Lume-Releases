"""Preset list dimensions, responsive columns and application regression."""
import asyncio, os
from pathlib import Path
from playwright.async_api import async_playwright
from ui_preset_menu import setup
ROOT=Path(__file__).resolve().parents[1]
async def main():
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path=os.environ.get('CHROMIUM_PATH','/usr/bin/chromium'),args=['--no-sandbox'])
  page,errors=await setup(b,{f:(ROOT/'app'/f).read_text() for f in ('index.html','style.css','app.js')})
  await page.locator('[data-view=profiles]').click();await page.locator('[data-profile-view=list]').click()
  for w,h,expected in [(1260,800,3),(900,600,2),(700,600,1)]:
   await page.set_viewport_size({'width':w,'height':h});await page.wait_for_timeout(600)
   await page.wait_for_function("document.querySelector('.profile-visual canvas')!==null")
   a=await page.locator('#profileGrid').evaluate('''e=>({cols:getComputedStyle(e).gridTemplateColumns.split(' ').length,cards:[...e.querySelectorAll('.profile-card')].map(c=>({height:c.getBoundingClientRect().height,overflow:c.scrollWidth>c.clientWidth+1,preview:c.querySelector('.profile-visual').getBoundingClientRect().width,button:c.querySelector('.apply-profile').getBoundingClientRect().height}))})''')
   print(w,a['cols'],a['cards'][0],flush=True)
   assert a['cols']==expected and all(c['height']>=98 and c['preview']>=125 and c['button']>=32 and not c['overflow'] for c in a['cards']),a
   if w in (1260,900): await page.screenshot(path=f'/mnt/data/LumePro_v0.3.43_list_{w}.png')
  await page.locator('.apply-profile').first.click();assert await page.locator('#view-profiles').is_visible()
  await page.locator('[data-profile-view=cards]').click();assert await page.locator('#profileGrid').get_attribute('data-presentation')=='cards'
  assert not errors,errors
  await b.close()
if __name__=='__main__':asyncio.run(main())
