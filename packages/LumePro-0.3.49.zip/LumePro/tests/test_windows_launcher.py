from pathlib import Path
import re

ROOT=Path(__file__).resolve().parents[1]

def test_launcher_avoids_broken_default_py3():
    start=(ROOT/'start_windows.bat').read_text('ascii')
    launcher=(ROOT/'launch_windows.ps1').read_text('utf-8-sig')
    assert 'py -3 app\\server.py' not in start
    assert 'launch_windows.ps1' in start
    assert 'app\\server.py' in start
    assert '\n    & $launcher.Source -3' not in launcher
    assert 'py -3 app' not in launcher
    assert "python.exe', 'python3.exe" in launcher
    assert '-0p' in launcher
    assert "sys.version_info >= (3,10)" in launcher
    assert 'http.server' in launcher
    assert 'LUMEPRO_PYTHON' in launcher

def test_installs_use_same_selector():
    for name,action in [('install_music_backend.bat','music'),('install_openrgb_backend.bat','openrgb')]:
        bat=(ROOT/name).read_text('ascii')
        assert 'launch_windows.ps1' in bat
        assert '-Action '+action in bat

def test_launcher_regex_examples():
    # Equivalent spelling: two regex backslashes in PowerShell source identify a Windows path.
    ps=(ROOT/'launch_windows.ps1').read_text('utf-8-sig')
    assert r'([A-Z]:\\.*?python\.exe)' in ps
    pat=re.compile(r'([A-Z]:\\.*?python\.exe)',re.I)
    cases=[
        ' -3.14-64 * C:\\Users\\bell\\AppData\\Local\\Python\\pythoncore-3.14-64\\python.exe',
        ' -V:3.13      C:\\Program Files\\Python313\\python.exe'
    ]
    for case in cases:
        match=pat.search(case)
        assert match and match.group(1).endswith('python.exe')
