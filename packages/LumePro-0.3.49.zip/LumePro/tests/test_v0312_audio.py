import numpy as np
from audio import AudioAnalyzer,blank,AudioMonitor,com_apartment
from engine import AUDIO,render,validate
from preferences import clean

def tone(hz,amp=.2,n=1024):
 return np.sin(2*np.pi*hz*np.arange(n)/48000)*amp

def feed(hz):
 a=AudioAnalyzer()
 for _ in range(8):d=a.process(tone(hz))
 return d

def test_fft_distinguishes_low_and_high_frequency():
 a,b=feed(90),feed(4000)
 assert np.argmax(a['bands'])<np.argmax(b['bands'])
 assert a['bass']>b['bass']+.2
 assert max(a['wave'])>0 and min(a['wave'])<0

def test_stereo_and_silence():
 a=AudioAnalyzer();t=tone(120)
 for _ in range(8):d=a.process(np.column_stack((t,np.zeros_like(t))))
 assert d['stereo'][0]>.3 and d['stereo'][1]==0
 for _ in range(40):d=a.process(np.zeros((1024,2)))
 assert d['volume']<.001 and max(d['bands'])<.001

def test_beat_after_quiet():
 a=AudioAnalyzer()
 for i in range(15):a.process(np.zeros(1024),i*.025)
 for i in range(4):
  d=a.process(tone(90,.7),.5+i*.025)
 assert d['beat']>0

def test_all_audio_effects_react_to_signal_and_stop():
 keys=[{'code':f'K{i}','x':i%18,'y':i//18} for i in range(108)]
 d={'volume':.8,'wave':[.7,-.7]*9,'bands':[.1,.8]*9,'stereo':[.8,.2],'beat':.7,'bass':.9}
 frames=[]
 for typ in AUDIO:
  raw={'keys':keys,'layers':[{'type':typ,'color':'#ff0000','secondary':'#0000ff','brightness':100}]}
  s=validate(raw);f=render(s,[],0,d)
  assert set(render(s,[],0,blank()).values())=={'#000000'}
  assert any(c!='#000000' for c in f.values())
  frames.append(tuple(f.values()))
  raw['layers'][0]['sensitivity']=0
  assert set(render(validate(raw),[],0,d).values())=={'#000000'}
  assert clean({'editor':{'layout':'jis','layers':raw['layers']}})['editor']['layers'][0]['type']==typ
 assert len(set(frames))==len(AUDIO)

def test_com_and_worker_mock(monkeypatch):
 import audio,sys,types,time
 calls=[]
 from contextlib import contextmanager
 @contextmanager
 def ctx():
  calls.append('init');yield;calls.append('uninit')
 class Recorder:
  def __enter__(self):return self
  def __exit__(self,*args):pass
  def record(self,numframes):time.sleep(.01);return tone(90,n=numframes)
 sp=types.SimpleNamespace(id='speaker-id',name='test speaker')
 def speaker():assert calls==['init'];return sp
 def microphone(id,include_loopback):assert id==sp.id and include_loopback;return types.SimpleNamespace(recorder=lambda **kw:Recorder())
 monkeypatch.setattr(audio,'com_apartment',ctx);monkeypatch.setitem(sys.modules,'soundcard',types.SimpleNamespace(default_speaker=speaker,get_microphone=microphone))
 m=AudioMonitor();assert m.start()
 try:
  end=time.monotonic()+2
  while m.status()['frames']<2 and time.monotonic()<end:time.sleep(.02)
  assert m.status()['frames']>=2 and m.status()['volume']>0
 finally:m.stop();m.thread.join(2)
 assert calls==['init','uninit'] and m.status()['volume']==0 and not m.status()['enabled']
