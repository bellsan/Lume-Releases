import asyncio
from pathlib import Path
from playwright.async_api import async_playwright
from ui_preset_menu import setup
async def main():
    root=Path(__file__).resolve().parents[1]/'app'
    async with async_playwright() as p:
        browser=await p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
        page,errors=await setup(browser,{f:(root/f).read_text() for f in ('index.html','style.css','app.js')})
        await page.locator('[data-view=settings]').click()
        await page.locator('#lightMotionProfile').select_option('smooth')
        assert await page.evaluate('scenePayload().motionProfile')=='smooth'
        assert await page.evaluate("calls.some(c=>c.u==='/api/preferences'&&c.b.motion_profile==='smooth')")
        await page.locator('#lightMotionProfile').select_option('responsive')
        assert await page.evaluate('scenePayload().motionProfile')=='responsive'
        assert not errors,errors
        print('Motion profile UI, persistence request and hardware scene payload: OK')
        await browser.close()
if __name__=='__main__':asyncio.run(main())
