"""Regression: the three spatial modes must actually use separate render paths."""
import json, math, shutil, subprocess, tempfile
from pathlib import Path
import pytest
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/"app"))
from engine import render,validate
from test_v0316_studio import KEYS,scene

KINDS=('orbit','scanner','rain')
ROOT=Path(__file__).resolve().parents[1]

def level(c):return max(int(c[i:i+2],16) for i in (1,3,5))

def test_motion_fields_are_distinct_at_same_colors():
    frames={k:render(scene(k),[],1.3) for k in KINDS}
    for i,a in enumerate(KINDS):
        for b in KINDS[i+1:]:
            assert sum(abs(level(frames[a][key])-level(frames[b][key]))>20 for key in frames[a])>15
    for k in KINDS:
        assert frames[k]!=render(scene(k),[],2.3)

def test_scanner_is_a_vertical_band_and_crosses_board():
    raw=lambda t:render(scene('scanner',angle=0,spread=100,width=20,motionTrail=0,speed=40),[],t)
    # During the outward sweep, same-column brightness must be identical.
    f=raw(.8)
    for col in range(18):
        assert len({f[f'K{r*18+col}'] for r in range(6)})==1
    def centroid(frame):
        weights=[level(frame[f'K{c}']) for c in range(18)]
        return sum(i*v for i,v in enumerate(weights))/max(1,sum(weights))
    assert centroid(raw(1.5))-centroid(raw(.5))>7

def test_orbit_keeps_center_dark_and_rain_has_direction():
    f=render(scene('orbit',spread=80,width=30,orbitHeads=2),[],.5)
    assert max(level(f[f'K{r*18+c}']) for r in (2,3) for c in (8,9))<5
    a=render(scene('rain',direction='right',rainDensity=100),[],.6)
    b=render(scene('rain',direction='left',rainDensity=100),[],.6)
    assert a!=b

def test_new_controls_change_hardware_frame():
    for k,options in [('orbit',[{'orbitHeads':1},{'originX':25},{'aspect':65},{'motionTrail':0}]),('scanner',[{'scanMode':'loop'},{'motionTrail':0},{'angle':90}]),('rain',[{'rainDensity':0},{'motionTrail':0},{'angle':50}])]:
        base=[render(scene(k),[],t) for t in (.4,1.3,2.1)]
        for opt in options:
            assert base!=[render(scene(k,**opt),[],t) for t in (.4,1.3,2.1)],(k,opt)

@pytest.mark.skipif(not shutil.which('node'),reason='Node required for actual browser-renderer parity test')
def test_js_actual_effect_branch_matches_python():
    # Run the real application JS (including effectAt and paintFrame), only skip DOM bootstrap.
    # Compare main preview, preset/hover use the same paintFrame implementation.
    source=(ROOT/'app'/'app.js').read_text(encoding='utf-8').rsplit('init();',1)[0]
    cases=[]
    for kind in KINDS:
        for params in ({},{'motionTrail':0,'angle':45,'direction':'left','gradient':['#000080','#00ffff','#ffffff']},{'motionTrail':100,'originX':25,'originY':70,'orbitHeads':3,'rainDensity':100,'scanMode':'loop','aspect':120,'width':70,'phase':35}):
            layer=dict(id=1,enabled=True,type=kind,color='#3366ff',secondary='#ffffff',brightness=100,speed=55,spread=60,fade=65,direction='right',**{})
            layer.update(params)
            for t in (.05,.71,1.47,3.2):cases.append({'layer':layer,'t':t})
    js='''\nconst input=JSON.parse(require('fs').readFileSync(0,'utf8')); keyboardKeys=input.keys;const result=[];for(const test of input.cases){state={...BASE(),layers:[test.layer],keyColors:{}};result.push(paintFrame(test.t,false));}process.stdout.write(JSON.stringify(result));'''
    # Avoid the OS per-argument length limit as the real application grows.
    with tempfile.TemporaryDirectory() as tmp:
        script=Path(tmp)/'parity.js'
        script.write_text(source+js,encoding='utf-8')
        result=subprocess.run(['node',str(script)],input=json.dumps({'keys':KEYS,'cases':cases}),text=True,capture_output=True,check=True)
    frames=json.loads(result.stdout)
    for case,frame in zip(cases,frames):
        expected=render(validate({'keys':KEYS,'layers':[case['layer']]}),[],case['t'])
        assert frame.keys()==expected.keys()
        for key in expected:
            assert all(abs(int(frame[key][i:i+2],16)-int(expected[key][i:i+2],16))<=1 for i in (1,3,5)),(case,key,frame[key],expected[key])
