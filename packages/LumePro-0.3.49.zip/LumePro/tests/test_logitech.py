import sys,time
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'app'))
from logitech import LogitechBackend,HID,SCAN,percent,JIS

class FakeSDK:
 def __init__(self,path):self.calls=[];self.reject=set();self.hid=lambda k,*c:self.call('hid',k,*c);self.scan=lambda k,*c:self.call('scan',k,*c)
 def call(self,kind,*args):self.calls.append((kind,*args));return (kind,args[0]) not in self.reject if args else True
 def init(self):return self.call('init')
 def target(self,k):return self.call('target',k)
 def save(self):return self.call('save')
 def restore(self):return self.call('restore')
 def shutdown(self):self.call('shutdown')
 def all(self,*c):return self.call('all',*c)

def make():
 b=LogitechBackend(FakeSDK,lambda:Path('dummy.dll'));assert b.connect();assert b.select(0);return b

def test_usage_codes_and_color():
 assert JIS=={'IntlRo':0x87,'KanaMode':0x88,'IntlYen':0x89,'Convert':0x8a,'NonConvert':0x8b}
 assert [SCAN[c] for c in JIS]==[0x73,0x70,0x7d,0x79,0x7b]
 assert HID['F1']==0x3a and HID['F6']==0x3f and HID['F12']==0x45
 assert percent('#ff8000')==(100,50,0)

def test_no_init_until_select():
 b=LogitechBackend(FakeSDK,lambda:Path('dummy.dll'))
 try:
  assert b.connect() and not b.status()['active'];assert b.sdk is None
  assert not b.select(True);assert b.select(0);assert ('target',4) in b.sdk.calls
 finally:b.close()

def test_global_and_jis_individual_and_restore():
 b=make();s=b.sdk
 try:
  assert b.test_led(None,'#404040');assert s.calls[-1]==('all',25,25,25)
  assert b.test_led(None,'#000000');assert s.calls[-1]==('all',0,0,0)
  for k,v in JIS.items():
   assert b.test_led(b.codes.index(k),'#ff0000');assert s.calls[-1]==('hid',v,100,0,0)
  assert b.set_method('scan');assert b.test_led(b.codes.index('NonConvert'),'#00ff00');assert s.calls[-1]==('scan',0x7b,0,100,0)
 finally:b.close()
 assert s.calls[-2:]==[('restore',),('shutdown',)]

def test_fallback_and_rejection():
 b=make();s=b.sdk
 try:
  s.reject.add(('hid',0x8b));assert b.test_led(b.codes.index('NonConvert'),'#ff0000');assert s.calls[-1]==('scan',0x7b,100,0,0)
  s.reject.add(('scan',0x7b));assert not b.test_led(b.codes.index('NonConvert'),'#ff0000');assert b.status()['missing_jis']==['NonConvert']
  assert not b.set_method('bad');assert b.set_method('hid');assert not b.set_mapping(0,'KeyA')
 finally:b.close()

def test_worker_and_change_cache():
 b=make();s=b.sdk
 try:
  b.queue_frame({'KeyA':'#00ff00','IntlYen':'#ff0000','bad':'#ff0000'})
  until=time.monotonic()+1
  while not b.sent and time.monotonic()<until:time.sleep(.01)
  assert ('hid',4,0,100,0) in s.calls and ('hid',0x89,100,0,0) in s.calls
  n=len(s.calls);b.queue_frame({'KeyA':'#00ff00','IntlYen':'#ff0000'});time.sleep(.12);assert len(s.calls)==n
 finally:b.close()

def test_jis_pattern():
 b=make();s=b.sdk
 try:
  assert b.test_jis();assert s.calls[-6:]==[('all',0,0,0),('hid',0x87,100,0,0),('hid',0x88,0,100,0),('hid',0x89,0,50,100),('hid',0x8a,100,0,100),('hid',0x8b,100,100,0)]
 finally:b.close()
