"""v0.3.40 component layout and direct preset editing (mock device API)."""
import asyncio,os
from pathlib import Path
from playwright.async_api import async_playwright
from ui_preset_menu import setup
ROOT=Path(__file__).resolve().parents[1]
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(headless=True,executable_path=os.environ.get('CHROMIUM_PATH','/usr/bin/chromium'),args=['--no-sandbox'])
  page,errors=await setup(browser,{f:(ROOT/'app'/f).read_text() for f in ('index.html','style.css','app.js')})
  for w,h in [(1260,800),(900,600)]:
   await page.set_viewport_size({'width':w,'height':h})
   await page.locator('[data-view=lighting]').click();await page.evaluate("applyProfile(allProfiles.find(p=>p.name==='GLACIER'),true);setInspector(false,false)");await page.wait_for_timeout(550)
   row=page.locator('.layer-item').first
   assert await row.evaluate("e=>getComputedStyle(e).display==='grid' && e.querySelector('.layer-text').getBoundingClientRect().right<=e.querySelector('.layer-more').getBoundingClientRect().left+1")
   await page.evaluate('setInspector(true,false)');await page.wait_for_timeout(600)
   assert await page.locator('.canvas-tool-group').count()==2
   assert await page.locator('.range-field').count()==30
   await page.locator('[data-inspector-tab=motion]').click();await page.wait_for_timeout(550)
   assert await page.locator('#speed').is_visible()
   await page.locator('#speed').fill('43');assert await page.locator('#speedValue').inner_text()=='43%'
   await page.locator('[data-inspector-tab=basic]').click();await page.wait_for_timeout(550)
   await page.screenshot(path=f'/mnt/data/LumePro_v0.3.40_editor_{w}.png')
   await page.locator('[data-view=profiles]').click();await page.wait_for_timeout(500)
   card=page.locator('.profile-card').first
   assert await card.locator('.apply-profile').evaluate("e=>e.getBoundingClientRect().width>100")
   await card.locator('.apply-profile').click();assert await page.locator('#view-profiles').is_visible()
   await card.locator('.preset-edit-direct').click();assert await page.locator('#view-lighting').is_visible()
   await page.wait_for_timeout(600)
  assert not errors,errors
  await browser.close();print('PASS: layer grid, tool groups, 30 range groups, value sync, full-width apply and direct edit, 1260/900.')
if __name__=='__main__':asyncio.run(main())
