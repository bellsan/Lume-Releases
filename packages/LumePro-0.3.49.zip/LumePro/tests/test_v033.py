import sys,time,threading
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'app'))
from logitech import LogitechBackend,G_LOGO
from hardware import normalize_led
from preferences import Preferences,choose_device
from engine import filter_frame,validate,render
from test_logitech import FakeSDK

class SDK(FakeSDK):
 def __init__(self,path):
  super().__init__(path);self.keyname=lambda k,*c:self.call('keyname',k,*c)

def backend():
 b=LogitechBackend(SDK,lambda:Path('dummy.dll'));assert b.connect() and b.select(0);return b

def test_bracket_layout_and_per_key_override():
 b=backend()
 try:
  s=b.sdk
  assert b._set_key('Backslash',(100,0,0));assert s.calls[-1]==('hid',0x32,100,0,0)
  assert b.set_key_method('Backslash','hid');assert b._set_key('Backslash',(0,100,0));assert s.calls[-1]==('hid',0x32,0,100,0)
  assert b.set_key_method('Backslash','keyname');assert b._set_key('Backslash',(0,0,100));assert s.calls[-1]==('keyname',0x2b,0,0,100)
  assert b.set_layout('ansi');assert b._set_key('Backslash',(0,0,100));assert s.calls[-1]==('hid',0x31,0,0,100)
 finally:b.close()

def test_fn_candidate_and_logo_no_unknown_button_addresses():
 b=backend()
 try:
  s=b.sdk;assert b._set_key('Fn',(100,0,0));assert s.calls[-1]==('hid',0xe6,100,0,0)
  assert b.set_key_method('Fn','scan');assert b._set_key('Fn',(0,100,0));assert s.calls[-1]==('scan',0x138,0,100,0)
  assert b._set_key('BoardLogo',(0,0,100));assert s.calls[-1]==('keyname',G_LOGO,0,0,100)
  n=len(s.calls);assert not b.test_led(b.codes.index('LightButton'),'#ff0000');assert len(s.calls)==n
  assert not b._set_key('GameMode',(100,0,0));assert len(s.calls)==n
  assert b.set_layout('ansi');assert not b._set_key('Fn',(100,0,0));assert len(s.calls)==n
  assert {'GameMode','LightButton'}<=set(b.status()['unsupported_keys'])
 finally:b.close()

def test_accessory_led_names():
 for raw,expected in [('Logo','BoardLogo'),('LED: G Logo','BoardLogo'),('Button: Game Mode','GameMode'),('Brightness Button','LightButton'),('Key: Fn','Fn')]:assert normalize_led(raw)==expected

def test_preferences_persist_and_no_input_history(tmp_path):
 path=tmp_path/'preferences.json';p=Preferences(path)
 p.update({'backend':'openrgb','device_name':'PRO Gaming Keyboard','device_leds':88,'live':True,'hook':True,'bracket_method':'keyname','input_history':['secret']})
 p.update({'editor':{'layout':'jis','layers':[{'type':'ripple','color':'#ff0000'}],'keyColors':{'BoardLogo':'#ffffff'}}})
 r=Preferences(path).load();assert r['live'] and r['hook'] and r['bracket_method']=='keyname' and r['editor']['keyColors']['BoardLogo']=='#ffffff'
 assert 'input_history' not in path.read_text()
 devices=[{'id':0,'name':'Mouse','keyboard':False,'leds':88},{'id':2,'name':'PRO Gaming Keyboard','keyboard':True,'leds':88}]
 assert choose_device(devices,r)==2
 assert choose_device(devices+[{'id':3,'name':'PRO Gaming Keyboard','keyboard':True,'leds':88}],r) is None
 assert choose_device([{'id':0,'name':'Other','keyboard':True,'leds':88}],r) is None

def test_temporal_filter_and_tail():
 m={};assert filter_frame({'KeyA':'#000000'},m,.025)['KeyA']=='#000000'
 f=filter_frame({'KeyA':'#ff0000'},m,.025)['KeyA'];assert 0<int(f[1:3],16)<255
 previous=int(f[1:3],16)
 for _ in range(100):
  f=filter_frame({'KeyA':'#000000'},m,.025)['KeyA'];cur=int(f[1:3],16);assert cur<=previous;previous=cur
 assert previous==0

def test_mailbox_does_not_wait_on_sdk_lock():
 b=backend();done=threading.Event()
 try:
  with b.lock:
   t=threading.Thread(target=lambda:(b.queue_frame({'KeyA':'#ff0000'}),b.queue_frame({'KeyA':'#00ff00'}),done.set()));t.start();assert done.wait(.25);t.join()
  deadline=time.monotonic()+1
  while time.monotonic()<deadline and not b.sent:time.sleep(.01)
  assert ('hid',4,0,100,0) in b.sdk.calls
  assert ('hid',4,100,0,0) not in b.sdk.calls
 finally:b.close()

def test_accessory_render_and_exact_override():
 scene=validate({'keys':[{'code':'BoardLogo','x':.6,'y':0},{'code':'GameMode','x':16.9,'y':0},{'code':'LightButton','x':17.8,'y':0}], 'layers':[{'type':'static','color':'#ff0000','brightness':100}], 'keyColors':{'BoardLogo':'#00ff00'}})
 assert render(scene,[],1)=={'BoardLogo':'#00ff00','GameMode':'#ff0000','LightButton':'#ff0000'}
