import asyncio,sys,os,math
from pathlib import Path
from playwright.async_api import async_playwright
from ui_preset_menu import setup
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'app'))
from audio import AudioAnalyzer,blank,demo_signal
from engine import validate,render
import numpy as np
async def main():
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path=os.environ.get('CHROMIUM_PATH','/usr/bin/chromium'),args=['--no-sandbox'])
  page,errors=await setup(b,{f:(ROOT/'app'/f).read_text() for f in ('index.html','style.css','app.js')})
  await page.locator('#newLayerBtn').click();await page.locator('#effectSearch').fill('オーディオウェーブ');await page.locator('[data-effect=audio_visualizer]').click()
  assert await page.evaluate('currentLayer().type')=='audio_visualizer'
  assert await page.locator('#visualizerControls').get_attribute('hidden') is None
  a=AudioAnalyzer();signals=[blank(),demo_signal(1.23)]
  for i in range(20):
   t=(np.arange(1024)+i*1024)/48000
   v=(.14+.1*math.sin(i*.4))*np.sin(t*2*np.pi*90)+.06*np.sin(t*2*np.pi*700)
   signals.append(a.process(v,i*1024/48000))
  frames=await page.evaluate('''signals=>{const orig=state.layers,oldAudio=audioStatus,oldOn=isAudioOn;try{state.layers=[currentLayer()];const l=state.layers[0];let out=[];for(const opts of [{waveMix:0},{waveMix:45},{waveMix:100,waveMirror:false},{waveIdle:true,waveTrail:100,waveBeat:100,direction:'left'}]){Object.assign(l,opts);for(const signal of signals){audioStatus=signal;isAudioOn=true;out.push({scene:scenePayload(),frame:paintFrame(10,false),signal})}}return out}finally{state.layers=orig;audioStatus=oldAudio;isAudioOn=oldOn}}''',signals)
  for q in frames:
   py=render(validate(q['scene']),[],10,q['signal']);js=q['frame'];assert py.keys()==js.keys();assert max(abs(int(py[k][i:i+2],16)-int(js[k][i:i+2],16)) for k in py for i in (1,3,5))<=1
  print(len(frames),'real/synthetic frames: JS/Python parity')
  await page.evaluate('''()=>{state.layers=[currentLayer()];Object.assign(currentLayer(),{waveMix:45,waveMirror:true,waveIdle:false,waveBeat:30,waveTrail:18,direction:'right'});refreshAll();state.running=false;catalogPreview=null;isAudioOn=false;audioStatus={...demoAudio(1.23),demo:true,demo_layer:currentLayer().id};paintFrame(10,true,false);previewDirty=false;}''')
  await page.screenshot(path='/mnt/data/LumePro_v0.3.45_audio.png')
  assert not errors,errors
  print('Catalog, inspector and preview OK');await b.close()
if __name__=='__main__':asyncio.run(main())
