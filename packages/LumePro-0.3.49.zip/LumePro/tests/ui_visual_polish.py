"""Verify the native slider visual fill, state changes and switch focus in mock browser."""
import asyncio, os
from pathlib import Path
from playwright.async_api import async_playwright
from ui_preset_menu import setup
ROOT=Path(__file__).resolve().parents[1]
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(headless=True,executable_path=os.environ.get('CHROMIUM_PATH','/usr/bin/chromium'),args=['--no-sandbox'])
  page,errors=await setup(browser,{f:(ROOT/'app'/f).read_text() for f in ('index.html','style.css','app.js')})
  await page.evaluate('setInspector(true,false)');await page.wait_for_timeout(600)
  slider=page.locator('#brightness')
  assert await slider.evaluate("e=>parseFloat(e.style.getPropertyValue('--range-fill'))===Number(e.value)")
  await slider.fill('42');assert await slider.evaluate("e=>e.style.getPropertyValue('--range-fill')==='42.00%'")
  assert await page.evaluate('currentLayer().brightness')==42
  await page.evaluate('currentLayer().brightness=75;renderInspector()');assert await slider.evaluate("e=>e.style.getPropertyValue('--range-fill')==='75.00%'")
  await page.locator('[data-view=settings]').click();await page.wait_for_timeout(400)
  toggle=page.locator('#uiMotionToggle');await toggle.focus();await page.keyboard.press('Space');assert not await toggle.is_checked();assert await page.evaluate("document.documentElement.classList.contains('no-ui-motion')")
  await page.keyboard.press('Space');assert await toggle.is_checked()
  assert not errors,errors
  print('Slider state, visual fill, programmatic refresh and keyboard switch: OK')
  await browser.close()
if __name__=='__main__':asyncio.run(main())
