"""Optional browser UI test with mocked OpenRGB and keyboard hook.
Run: python tests/ui_smoke.py (requires playwright and Chromium)."""
import asyncio,json,os
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parents[1]/'app'
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(headless=True,executable_path=os.environ.get('CHROMIUM_PATH','/usr/bin/chromium'),args=['--no-sandbox'])
  page=await browser.new_page(viewport={'width':1260,'height':800})
  page.set_default_timeout(5000)
  errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  await page.set_content((ROOT/'index.html').read_text().replace('<link rel="stylesheet" href="/style.css">','').replace('<script src="/app.js" defer></script>',''))
  await page.add_style_tag(content=(ROOT/'style.css').read_text())
  await page.evaluate('''window.game={enabled:false,blocked:['MetaLeft','ContextMenu'],led:'off',color:'#ff5555',dim:25};window.calls=[];window.live=false;window.hook=false;window.active=false;window.confirm=()=>true;window.fetch=async(url,opts)=>{const u=String(url),b=opts?.body?JSON.parse(opts.body):{};calls.push({u,b});let data={ok:true};const hw={connected:true,active:window.active,device:window.active?0:null,devices:[{id:0,name:'PRO Gaming Keyboard',keyboard:true,leds:88}],backend:'logitech',bitmap_available:true,bitmap_mapping:window.testBitmap||{},matched:87,sent:0,led_map:[],missing_jis:['IntlYen'],error:''};if(u.includes('/api/token'))data={token:'test'};else if(u==='/api/preferences'&&!opts)data={preferences:{auto:true,backend:'logitech',hook:true,live:true,editor:null}};else if(u==='/api/auto_connect'){window.active=true;data={ok:true,hardware:{...hw,active:true,device:0}}}else if(u.includes('/api/status'))data={hardware:hw,engine:{active:live,pulses:0},keyhook:{enabled:hook},game_mode:window.game};else if(u==='/api/game_mode'){window.game={...b};if(b.enabled)hook=true;data={ok:true,game_mode:window.game}}else if(u.includes('/api/presets'))data={presets:[]};else if(u.includes('/api/keys'))data={seq:0,events:[]};else if(u.includes('/api/keyhook')){hook=b.enabled;data={ok:true,enabled:hook}}else if(u.includes('/api/live')){live=b.enabled;data={ok:true,engine:{active:live,pulses:0}}}else if(u.includes('/api/scene'))data={ok:true};else if(u.includes('/api/led_test')){live=false;data={ok:true,hardware:hw}}else if(u==='/api/coverage_test'){live=false;data={ok:true,hardware:hw}}else if(u==='/api/bitmap_test'){live=false;data={ok:true,hardware:hw}}else if(u==='/api/bitmap_config'){window.testBitmap=b.mapping;data={ok:true,hardware:{...hw,bitmap_mapping:b.mapping}}}else if(u==='/api/fn_hid'){data={ok:true,devices:[{index:0,name:'PRO Gaming Keyboard',pid:'C339',usage:'FF00:0001'}],status:{phase:'off',active:false}}};return {ok:true,json:async()=>data}}''')
  await page.evaluate('''()=>{const values=new Map();Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem:k=>values.get(k)??null,setItem:(k,v)=>values.set(k,String(v)),removeItem:k=>values.delete(k)}})}''')
  await page.add_script_tag(content=(ROOT/'app.js').read_text())
  await page.wait_for_timeout(450)
  await page.locator('[data-view=keyboard]').click()
  await page.locator('[data-key-select=wasd]').click()
  assert await page.evaluate("state.selectedKeys.length===4")
  await page.locator('#keyColor').fill('#3080f0')
  await page.locator('#applyKeyColor').click()
  assert await page.evaluate("state.keyColors.KeyW==='#3080f0'&&state.keyColors.KeyA==='#3080f0'")
  assert await page.locator('#keyHexInput').input_value()=='#3080F0'
  assert await page.locator('#keySelectedNames').inner_text()!='キーボードからキーを選択'
  await page.wait_for_timeout(2600)
  await page.screenshot(path='/mnt/data/LumePro_v0.3.29_keys.png')
  await page.locator('#keyTabGame').click()
  await page.locator('#mappingKeyboard [data-code=KeyW]').click()
  await page.wait_for_function("!gameBusy&&gameState.blocked.includes('KeyW')")
  await page.locator('#mappingKeyboard [data-code=F12]').click()
  assert await page.evaluate("!gameState.blocked.includes('F12')")
  await page.locator('#gameToggle').click()
  await page.wait_for_function("!gameBusy&&gameState.enabled")
  assert await page.evaluate("gameMask('KeyW',[255,255,255]).join(',')==='0,0,0'")
  await page.locator('#gameLed').select_option('color')
  await page.wait_for_function("!gameBusy&&gameState.led==='color'")
  assert await page.evaluate("gameMask('KeyW',[255,255,255]).join(',')==='255,85,85'")
  await page.locator('#gameLed').select_option('off')
  await page.wait_for_function("!gameBusy&&gameState.led==='off'")
  await page.wait_for_timeout(2600)
  await page.screenshot(path='/mnt/data/LumePro_v0.3.29_game_mode.png')
  await page.locator('#gameToggle').click()
  await page.wait_for_function("!gameBusy&&!gameState.enabled")
  assert await page.evaluate("gameMask('KeyW',[1,2,3]).join(',')==='1,2,3'")
  await page.set_viewport_size({'width':900,'height':600})
  assert await page.evaluate('document.documentElement.scrollWidth<=innerWidth')
  await page.screenshot(path='/mnt/data/LumePro_v0.3.29_compact.png')
  assert await page.locator('#gameLed').is_visible()
  assert await page.locator('#gameToggle').is_visible()
  assert await page.locator('#gameLed').evaluate('(el)=>el.getBoundingClientRect().bottom<=innerHeight')
  await page.locator('#gameClear').click()
  await page.wait_for_function('!gameBusy&&gameState.blocked.length===0')
  assert not errors,errors
  print('Key workspace: group selection, individual colors, game toggle, LED policies, reserved keys, clear, compact layout; no JS errors.')
  await browser.close()
if __name__=='__main__':asyncio.run(main())
