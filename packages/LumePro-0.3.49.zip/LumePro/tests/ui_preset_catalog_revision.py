"""Verify gallery geometry and the effect catalogue transition in real Chromium."""
import asyncio, os
from pathlib import Path
from playwright.async_api import async_playwright
from ui_preset_menu import setup
ROOT=Path(__file__).resolve().parents[1]
SAMPLE='''async action=>{const el=document.querySelector('.keyboard-outer');const frames=[];const capture=()=>{const r=el.getBoundingClientRect();frames.push({x:r.x,w:r.width,raw:el.offsetWidth})};capture();if(action==='open')document.querySelector('#newLayerBtn').click();else if(action==='close')document.querySelector('#closePickerBtn').click();else document.querySelector('.effect-card[data-effect="ripple"]').click();const start=performance.now();while(performance.now()-start<750){await new Promise(requestAnimationFrame);capture()}return frames}'''
async def main():
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path=os.environ.get('CHROMIUM_PATH','/usr/bin/chromium'),args=['--no-sandbox'])
  page,errors=await setup(b,{f:(ROOT/'app'/f).read_text() for f in ('index.html','style.css','app.js')})
  for w,h in [(1260,800),(900,600)]:
   await page.set_viewport_size({'width':w,'height':h});await page.locator('[data-view=lighting]').click();await page.evaluate('setInspector(false,false);fitPreview()');await page.wait_for_timeout(750)
   for action in ['open','close','open','add']:
    frames=await page.evaluate(SAMPLE,action);a,z=frames[0],frames[-1];unique=len({round(f['w'],1) for f in frames});print(w,action,'width',round(a['w'],1),round(z['w'],1),'x',round(a['x'],1),round(z['x'],1),'steps',unique,flush=True)
    assert unique>=7,frames
    assert len({f['raw'] for f in frames})==1,frames
    if action=='open':
     await page.screenshot(path=f'/mnt/data/LumePro_v0.3.41_catalog_{w}.png');assert await page.locator('#effectSearch').is_visible()
     assert await page.locator('.effect-card small').first.is_visible()
    if action=='add': assert await page.locator('.inspector').is_visible()
   await page.locator('[data-view=profiles]').click();await page.wait_for_timeout(750)
   await page.locator('[data-profile-view=cards]').click();await page.wait_for_function("document.querySelector('.profile-visual canvas')!==null")
   result=await page.locator('.profile-card').first.evaluate('''e=>{const p=e.querySelector('.profile-visual'),c=p.querySelector('canvas'),r=c.getBoundingClientRect(),h=p.getBoundingClientRect();return {card:e.clientWidth,canvas:r.width,ratio:r.width/r.height,host:h.width,hostHeight:h.height,canvasHeight:r.height}}''')
   print(w,'card',result,flush=True);assert result['canvas']/result['card']>.88,result;assert abs(result['ratio']-720/305)<.02,result;assert result['canvasHeight']<=result['hostHeight'],result
   await page.screenshot(path=f'/mnt/data/LumePro_v0.3.41_cards_{w}.png');await page.locator('[data-profile-view=list]').click();await page.wait_for_timeout(250)
   cols=await page.locator('#profileGrid').evaluate("e=>getComputedStyle(e).gridTemplateColumns.split(' ').length")
   print(w,'list columns',cols,flush=True);assert cols==(3 if w==1260 else 2)
   for card in await page.locator('.profile-card').all():
    assert await card.evaluate("e=>e.scrollWidth<=e.clientWidth+1"),await card.inner_text()
   await page.screenshot(path=f'/mnt/data/LumePro_v0.3.41_list_{w}.png');await page.locator('.apply-profile').first.click();assert await page.locator('#view-profiles').is_visible()
   await page.locator('[data-view=lighting]').click();await page.evaluate('setInspector(false,false);fitPreview()');await page.wait_for_timeout(600)
   await page.evaluate('setUiMotion(false);setPickerOpen(true)');assert await page.evaluate('pickerInsetProgress===1');await page.evaluate('setPickerOpen(false)');assert await page.evaluate('pickerInsetProgress===0');await page.evaluate('setUiMotion(true)')
  assert not errors,errors
  await b.close()
  print('PASS: picker intermediate frames, add, fixed raw keyboard width, card geometry, responsive list, apply and motion off.')
if __name__=='__main__':asyncio.run(main())
