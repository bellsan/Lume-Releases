import numpy as np
from audio import AudioAnalyzer,demo_signal,blank
from engine import render,validate

def scene(typ,**kwargs):
 return validate({'keys':[{'code':f'K{i}','x':i%18,'y':i//18} for i in range(108)],'layers':[{'type':typ,'brightness':100,'color':'#ff0000','secondary':'#ff0000',**kwargs}]})

def test_four_color_gradient_direction():
 s=scene('static',gradient=['#ff0000','#00ff00','#0000ff','#ffffff'])
 f=render(s,[],0);assert f['K0']=='#ff0000' and f['K17']=='#ffffff'
 assert len(set(f.values()))==18
 v=render(scene('static',gradient=['#ff0000','#0000ff'],gradientAngle=90),[],0)
 assert v['K0']==v['K17']=='#ff0000' and v['K90']==v['K107']=='#0000ff'
 r=render(scene('static',gradient=['#ff0000','#0000ff'],gradientMode='radial'),[],0)
 assert r['K0']==r['K107']=='#0000ff' and r['K44']!=r['K0']

def test_prism_moves():
 s=scene('prism',gradient=['#ff0000','#0000ff','#ffffff'])
 assert render(s,[],0)!=render(s,[],.6)

def test_waveform_real_pcm_history_and_demo_motion():
 a=AudioAnalyzer(48000)
 for i in range(40):
  t=(np.arange(1024)+i*1024)/48000
  d=a.process(np.sin(2*np.pi*130*t)*(.02+.8*(i%12)/12))
 assert len(d['trace'])==72 and len(d['envelope'])==36
 assert max(d['trace'])>0 and min(d['trace'])<0 and max(d['envelope'])>min(d['envelope'])+.1
 for typ in ('waveform','audio_wave'):
  s=scene(typ)
  assert render(s,[],0,d)!=render(s,[],0,blank())
  f=render(s,[],0,demo_signal(1));g=render(s,[],0,demo_signal(1.6))
  assert f!=g and len(set(f.values()))>4

def test_envelope_mirror_and_gain():
 d=demo_signal(1)
 a=render(scene('audio_wave',waveMirror=True),[],0,d)
 b=render(scene('audio_wave',waveMirror=False),[],0,d)
 assert a!=b
 assert a!=render(scene('audio_wave',waveGain=0),[],0,d)

def test_demo_isolated_from_other_layers_and_fixed_colors():
 raw={'keys':[{'code':f'K{i}','x':i%18,'y':i//18} for i in range(108)],'layers':[{'id':1,'type':'music','color':'#ff0000','secondary':'#ff0000','brightness':100},{'id':2,'type':'audio_wave','color':'#00ffff','secondary':'#00ffff','brightness':100},{'id':3,'type':'static','color':'#ff0000','brightness':100}],'keyColors':{'K1':'#ff0000'}}
 d={**demo_signal(1),'demo':True,'demo_layer':2}
 f=render(validate(raw),[],1,d);assert any(c!='#000000' for c in f.values());assert all(c[1:3]=='00' for c in f.values())
 assert f!=render(validate(raw),[],1,{**d,'demo':False})
