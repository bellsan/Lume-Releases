from pathlib import Path
from test_v033 import backend
from keyhook import KeyboardWatcher
from engine import AnimationEngine
from audio import AudioMonitor
from preferences import Preferences

def test_bracket_new_route_and_fallback(tmp_path):
 b=backend()
 try:
  s=b.sdk
  assert b._set_key('Backslash',(100,0,0));assert s.calls[-1]==('hid',0x32,100,0,0)
  s.reject.add(('hid',0x32));assert b._set_key('Backslash',(0,100,0));assert s.calls[-1]==('hid',0x31,0,100,0)
  assert b.set_key_method('Backslash','iso56');assert b._set_key('Backslash',(0,0,100));assert s.calls[-1]==('keyname',0x56,0,0,100)
  assert not b.set_key_method('Fn','iso56')
  assert b.set_key_method('Backslash','hid31');p=Preferences(tmp_path/'prefs.json');assert p.update({'bracket_method':'hid31'})['bracket_method']=='hid31'
 finally:b.close()

def test_jis_fn_input_alias_and_diagnostics():
 class Fake:
  device=object()
  def queue_frame(self,f):pass
  def clear_pending(self):pass
 k=KeyboardWatcher();k.enabled=True;e=AnimationEngine(Fake(),k,AudioMonitor())
 try:
  scene={'keys':[{'code':'Fn','x':2,'y':3},{'code':'Backslash','x':4,'y':1}],'layers':[{'type':'ripple','color':'#ffffff'}]}
  e.configure(scene);e.enable(True)
  assert e.pulse('AltRight');assert e.pulses[-1][:2]==(2,3)
  k.push('AltRight');k.push('Backslash');assert k.diagnostic()['special_counts']=={'Backslash':1,'AltRight':1,'Fn':0,'LightButton':0,'GameMode':0}
  scene['keys'].append({'code':'AltRight','x':7,'y':3});e.configure(scene);assert e.pulse('AltRight');assert e.pulses[-1][:2]==(7,3)
 finally:e.close();k.stop()
