import hashlib, io, json, sys, urllib.request, urllib.error
from pathlib import Path
import pytest
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'app'))
import updater as u
from test_v0319_updater import tree, archive, release, wait, REPO

TOKEN='ghp_TESTtoken123456789'

def private_tree(root):
    tree(root)
    (root/'app/version.json').write_text(json.dumps({'version':'0.3.19','repository':REPO,'private':True}))
    return root

def private_release(payload):
    r=release(data=payload)
    for n,a in enumerate(r['assets'],101):a['id']=n
    return r

def test_private_release_auth_download_and_apply(tmp_path,monkeypatch):
    root=private_tree(tmp_path/'install');data=tmp_path/'data';data.mkdir();(data/'preferences.json').write_text('preserved')
    payload=archive();r=private_release(payload);seen=[]
    monkeypatch.setattr(u,'github_token',lambda:TOKEN)
    def read(url,maximum,headers=None):
        seen.append((url,headers));assert headers['Authorization']=='Bearer '+TOKEN
        return (hashlib.sha256(payload).hexdigest()+'  release.zip\n').encode() if url.endswith('/102') else json.dumps(r).encode()
    def open_mock(url,headers):
        seen.append((url,headers));assert url.endswith('/101');assert headers['Authorization']=='Bearer '+TOKEN
        return io.BytesIO(payload)
    monkeypatch.setattr(u,'read_bounded',read);monkeypatch.setattr(u,'open_url',open_mock)
    m=u.Updater(root,data);m.check(True);wait(m,'idle');assert m.status()['private'];assert m.status()['available'];assert 'asset' not in m.status()['release']
    m.download();wait(m,'ready');m.request_apply();assert m.finish()
    assert len(seen)==3 and seen[0][0].endswith('/releases/latest')
    assert all(h['Accept']=='application/octet-stream' for _,h in seen[1:])
    assert (data/'preferences.json').read_text()=='preserved'
    assert TOKEN not in (data/'update_state.json').read_text()
    assert u.read_metadata(root)['version']=='0.3.20'

def test_private_credentials_not_forwarded_to_cdn():
    req=urllib.request.Request('https://api.github.com/repos/bellsan/Lume/releases/assets/101',headers={'Authorization':'Bearer '+TOKEN,'Accept':'application/octet-stream'})
    redirect=u.ReleaseRedirect().redirect_request(req,None,302,'Found',{},'https://release-assets.githubusercontent.com/abc?sig=example')
    assert all(k.lower()!='authorization' for k,_ in redirect.header_items())
    with pytest.raises(ValueError):u.ReleaseRedirect().redirect_request(req,None,302,'Found',{},'https://evil.example/abc')
    with pytest.raises(ValueError):u.open_url('https://github.com/bellsan/Lume',{'Authorization':'Bearer '+TOKEN})

def test_private_requires_asset_ids():
    with pytest.raises(ValueError):u.parse_release(release(),REPO,True)

def test_no_login_retry_without_manual_wait(tmp_path,monkeypatch):
    m=u.Updater(private_tree(tmp_path/'install'),tmp_path/'data')
    def fail():raise ValueError('GitHub認証が必要です')
    monkeypatch.setattr(u,'github_token',fail);m.check(True);wait(m,'error');assert not m.status()['available']
    monkeypatch.setattr(u,'github_token',lambda:TOKEN)
    monkeypatch.setattr(u,'read_bounded',lambda *a,**k:json.dumps(private_release(b'zip')).encode())
    m.check(True);wait(m,'idle');assert m.status()['available']

def test_no_release_not_latest(tmp_path,monkeypatch):
    m=u.Updater(private_tree(tmp_path/'install'),tmp_path/'data')
    monkeypatch.setattr(u,'github_token',lambda:TOKEN)
    def fail(*a,**k):raise urllib.error.HTTPError('https://api.github.com',404,'Not Found',{},None)
    monkeypatch.setattr(u,'read_bounded',fail);m.check(True);wait(m,'error');assert '未配布' in m.status()['error'];assert not m.status()['available']
