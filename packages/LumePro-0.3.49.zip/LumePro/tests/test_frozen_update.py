import io,json,struct,sys,hashlib
from pathlib import Path
import pytest
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'app'))
from frozen_update import validate_pe
from updater import parse_release,Updater

def test_pe(tmp_path):
    data=bytearray(256);data[:2]=b'MZ';struct.pack_into('<I',data,60,64);data[64:68]=b'PE\0\0';struct.pack_into('<H',data,68,0x8664);struct.pack_into('<H',data,88,0x20b)
    p=tmp_path/'sample.exe';p.write_bytes(data);validate_pe(p)
    data[68:70]=b'\x4c\x01';p.write_bytes(data)
    with pytest.raises(ValueError):validate_pe(p)

def test_channel_selection():
    repo='bellsan/Lume-Releases';ver='0.3.49';base=f'https://github.com/{repo}/releases/download/v{ver}/'
    names=[f'LumePro-{ver}.zip',f'LumePro-{ver}-windows-x64.exe'];assets=[{'name':n,'size':1000,'browser_download_url':base+n} for n in names+[n+'.sha256' for n in names]]
    r={'tag_name':'v'+ver,'assets':assets}
    assert parse_release(r,repo)['asset'].endswith('.zip')
    assert parse_release(r,repo,frozen=True)['asset'].endswith('-windows-x64.exe')
    r['assets']=[a for a in assets if not a['name'].endswith('exe.sha256')]
    assert not parse_release(r,repo,frozen=True)['installable']

@pytest.mark.parametrize('corrupt',[False,True])
def test_frozen_download_checks_digest(tmp_path,monkeypatch,corrupt):
    import updater as module
    root=Path(__file__).resolve().parents[1]
    m=Updater(root,tmp_path/'profile');m.frozen=True;m.install_root=tmp_path
    payload=bytearray(256);payload[:2]=b'MZ';struct.pack_into('<I',payload,60,64);payload[64:68]=b'PE\0\0';struct.pack_into('<H',payload,68,0x8664);struct.pack_into('<H',payload,88,0x20b)
    payload=bytes(payload);digest=hashlib.sha256(payload).hexdigest();checksum=(digest+'  LumePro.exe\n').encode()
    release={'version':'0.3.50','asset':'fixture-exe','checksum':'fixture-checksum','size':len(payload),'asset_digest':digest,'checksum_digest':hashlib.sha256(checksum).hexdigest()}
    monkeypatch.setattr(module,'read_bounded',lambda *args:checksum)
    monkeypatch.setattr(module,'open_url',lambda *args:io.BytesIO(payload[:-1]+b'x' if corrupt else payload))
    m._download_worker(release)
    if corrupt:assert m.phase=='error' and m.stage is None and not list(tmp_path.glob('.lume-update-*'))
    else:
        assert m.phase=='ready' and (m.stage/'LumePro.exe').read_bytes()==payload
        m.finish()
        assert not list(tmp_path.glob('.lume-update-*'))
