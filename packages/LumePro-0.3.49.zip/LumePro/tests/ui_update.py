"""Browser regression for the update dialog, no network or actual install."""
import asyncio,os
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parents[1]
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(headless=True,executable_path=os.environ.get('CHROMIUM_PATH','/usr/bin/chromium'),args=['--no-sandbox'])
  page=await browser.new_page(viewport={'width':1260,'height':800});page.set_default_timeout(5000)
  errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  app=ROOT/'app';await page.set_content((app/'index.html').read_text().replace('<link rel="stylesheet" href="/style.css">','').replace('<script src="/app.js" defer></script>',''))
  await page.add_style_tag(content=(app/'style.css').read_text())
  await page.evaluate('''window.calls=[];window.acked=false;window.phase='idle';window.hasUpdate=false;window.auto=true;window.fetch=async(url,opts)=>{const u=String(url),b=opts?.body?JSON.parse(opts.body):{};calls.push({u,b});let data={ok:true};if(u==='/api/token')data={token:'test'};else if(u==='/api/preferences')data={preferences:{auto:false,backend:'logitech',hook:false,live:false,editor:null}};else if(u==='/api/status')data={hardware:{connected:false,active:false,devices:[],led_map:[]},engine:{active:false,pulses:0},keyhook:{enabled:false}};else if(u==='/api/presets')data={presets:[]};else if(u==='/api/keys')data={seq:0,events:[]};else if(u==='/api/audio')data={enabled:false,volume:0};else if(u.startsWith('/api/update/')){if(u.endsWith('/check')&&(!hasUpdate||b.manual)&&!['downloading','ready','checking'].includes(phase)){window.phase='checking';setTimeout(()=>{window.phase='idle';window.hasUpdate=true},300)}if(u.endsWith('/ack'))window.acked=true;if(u.endsWith('/configure'))window.auto=b.auto;if(u.endsWith('/download')){window.phase='downloading';setTimeout(()=>window.phase='ready',400)}if(u.endsWith('/apply'))return {ok:true,json:async()=>({ok:true})};data={current:'0.3.21',repository:'bellsan/Lume-Releases',phase,progress:phase==='ready'?100:20,available:hasUpdate,release:hasUpdate?{version:'0.3.22',published:'2026-11-25T00:00:00Z',installable:true,notes:'・更新確認を追加しました。\\n・表示の不具合を修正しました。\\n・動作を軽くするようにしました。'}:null,notify:hasUpdate&&!acked,auto,last_check:hasUpdate?Date.now()/1000:0,error:''}}return {ok:true,json:async()=>data}}''')
  await page.add_script_tag(content=(app/'app.js').read_text());await page.wait_for_timeout(400)
  assert await page.locator('#connectTopBtn').inner_text()=='設定'
  await page.locator('#connectTopBtn').click();assert await page.locator('#view-settings').is_visible()
  await page.locator('#checkUpdateBtn').click();assert await page.locator('#updateTitle').inner_text()=='更新を確認しています'
  await page.wait_for_timeout(1000);assert await page.locator('#updateTitle').inner_text()=='新しいバージョンがあります';assert '修正しました' in await page.locator('#updateNotes').inner_text()
  assert await page.evaluate('acked')
  assert await page.locator('.update-note-item').count()==3
  assert await page.locator('.update-note-marker').count()==0
  await page.screenshot(path=str(ROOT/'GUI_update.png'))
  await page.set_viewport_size({'width':900,'height':600});await page.wait_for_timeout(250)
  assert await page.locator('#updateAction').is_visible()
  assert await page.locator('.update-dialog').evaluate('(e)=>e.getBoundingClientRect().bottom<=innerHeight')
  await page.set_viewport_size({'width':1260,'height':800})
  await page.locator('#updateAction').click();await page.locator('#updateLater').click();await page.wait_for_timeout(900)
  assert not await page.locator('#updateBackdrop').is_visible()
  assert not await page.evaluate('calls.some(x=>x.u==="/api/update/apply")')
  # Startup check must not pop up for a version already shown to the user.
  await page.wait_for_timeout(1200);assert not await page.locator('#updateBackdrop').is_visible()
  assert await page.evaluate('calls.filter(x=>x.u==="/api/update/check"&&!x.b.manual).length')<=1
  await page.locator('label.switch:has(#autoUpdateCheck)').click();assert await page.evaluate('auto===false')
  # The ready download can be applied explicitly after postponement.
  await page.locator('#checkUpdateBtn').click();assert await page.locator('#updateAction').inner_text()=='再起動して更新'
  await page.locator('#updateAction').click();await page.wait_for_timeout(200)
  assert await page.evaluate('calls.filter(x=>x.u==="/api/update/apply").length')==1
  assert await page.locator('#updateTitle').inner_text()=='更新を適用しています'
  # Reset the mock to exercise the new one-click path independently.
  await page.evaluate("window.phase='idle'; updateApplyWhenReady=false; renderUpdate({...updateStatus,phase:'idle'}); calls.length=0")
  await page.locator('#updateAction').click();await page.wait_for_timeout(1000)
  assert await page.evaluate('calls.filter(x=>x.u==="/api/update/apply").length')==1
  assert await page.evaluate('calls.findIndex(x=>x.u==="/api/preferences"&&x.b.editor)<calls.findIndex(x=>x.u==="/api/update/apply")')
  assert not errors,errors
  await browser.close();print('Update UI: gear / dialog / notes / progress / acknowledgement / auto toggle OK; page errors: 0')
if __name__=='__main__':asyncio.run(main())
