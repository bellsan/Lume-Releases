from engine import validate,render,EFFECTS,REACTIVE
from preferences import clean
from fn_hid import vendor_collections
from pathlib import Path
import math

KEYS=[{'code':f'Key{chr(65+i)}','x':i%9*1.7,'y':1+i//9*1.7} for i in range(26)]

def scene(kind,**kwargs):
 return validate({'keys':KEYS,'layers':[dict(type=kind,color='#6478ff',secondary='#18eeb0',brightness=100,speed=45,spread=60,fade=65,**kwargs)]})

def test_new_ambient_effects_are_distinct_and_animated():
 frames=[]
 for kind in ('aurora','silk','tide','ember','stardust'):
  s=scene(kind);a=render(s,[],0);b=render(s,[],2.4)
  assert a!=b and len(set(a.values()))>4
  frames.append(tuple(a.values()))
 assert len(set(frames))==5

def test_new_reactive_effects_require_input_and_expire():
 for kind in REACTIVE:
  s=scene(kind,duration=15)
  assert set(render(s,[],0).values())=={'#000000'}
  assert render(s,[(0,1,0)],.02)['KeyA']!='#000000'
  assert set(render(s,[(0,1,0)],1.6).values())=={'#000000'}

def test_new_motion_controls_affect_frames():
 for key,value in [('angle',90),('phase',50),('floor',70),('contrast',90)]:
  assert render(scene('aurora',**{key:value}),[],.3)!=render(scene('aurora'),[],.3)
 assert render(scene('silk',width=10),[],.3)!=render(scene('silk',width=90),[],.3)
 s=scene('tide');before=render(s,[],.3);s[1][0]['secondary']=(255,0,0);assert render(s,[],.3)!=before

def test_new_effects_preferences_and_bounds():
 raw={'editor':{'layout':'jis','layers':[{'type':t,'color':'#123456','angle':90} for t in ('aurora','silk','tide','ember','stardust','comet','bloom')]}}
 saved=clean(raw)['editor'];assert saved['layout']=='jis' and saved['reactivePriority'] is False
 assert [{k:v for k,v in l.items() if k!='id'} for l in saved['layers']]==raw['editor']['layers']
 s=scene('comet',duration=999,angle=-999,contrast=float('nan'))
 assert s[1][0]['duration']==8 and s[1][0]['angle']==-180 and s[1][0]['contrast']==.5

def test_consumer_collection_only_for_identified_pro_keyboard():
 k={'vendor_id':0x046d,'product_id':0xc339,'product_string':'PRO Gaming Keyboard','path':b'k','usage_page':1,'usage':6}
 c=dict(k,path=b'consumer',usage_page=0x0c,usage=1)
 assert vendor_collections([k,c])==[c]
 assert vendor_collections([c])==[]
 assert vendor_collections([k,dict(c,product_id=0x1234)])==[]
