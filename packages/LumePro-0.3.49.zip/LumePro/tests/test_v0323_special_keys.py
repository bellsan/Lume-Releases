import json
import queue
import time
from ghub_state import GHubStateMonitor, StateTracker, target_device, DEVICE_LIST
from fn_hid import FnLearner, FnHidMonitor


def test_ghub_identifies_only_unique_c339():
    target = {'pid': 0xc339, 'id': 'dev00000001', 'serialNumber': 'private'}
    other = {'pid': 0xc231, 'id': 'other'}
    assert target_device({'deviceInfos': [other, target]}) is target
    assert target_device({'deviceInfos': [other]}) is None
    assert target_device({'deviceInfos': [target, {**target, 'id': 'another'}]}) is None
    assert target_device({'deviceInfos': [{**target, 'id': '../other'}]}) is None
    assert target_device({'deviceInfos': [{**target, 'pid': '0xC339'}]}) is not None
    assert target_device({'deviceInfos': None}) is None


def test_state_changes_only_and_no_missing_field_coercion():
    fired = []
    t = StateTracker(fired.append)
    assert not t.feed('GameMode', {'enabled': False})
    assert not t.feed('GameMode', {'enabled': False})
    assert not t.feed('GameMode', {'enabled': 1})
    assert t.feed('GameMode', {'enabled': True})
    assert not t.feed('GameMode', {})
    assert t.values['GameMode'] is True
    assert t.feed('GameMode', {'enabled': False})
    assert not t.feed('LightButton', {'value': True})
    assert t.feed('LightButton', {'value': False})
    assert fired == ['GameMode', 'GameMode', 'LightButton']


class FakeWS:
    def __init__(self):
        self.sent = []
        self.inbox = queue.Queue()
    def send(self, raw):
        self.sent.append(json.loads(raw))
    def recv(self):
        try: return self.inbox.get(timeout=.025)
        except queue.Empty: raise TimeoutError()
    def shutdown(self):
        self.inbox.put('')
    def put(self, path, payload):
        self.inbox.put(json.dumps({'path':path, 'payload':payload}))


def until(check):
    deadline = time.monotonic()+2
    while time.monotonic()<deadline:
        if check(): return
        time.sleep(.01)
    assert check()


def test_ghub_monitor_read_only_exact_paths_and_no_private_payload_export():
    ws=FakeWS();fired=[];m=GHubStateMonitor(fired.append,connector=lambda:ws)
    ws.put(DEVICE_LIST, {'deviceInfos':[{'pid':0xc339,'id':'dev01','serialNumber':'SECRET','capabilities':{'lightingSupport':{'hasMasterSwitch':True}}}]})
    assert m.start()
    try:
        until(lambda:len(ws.sent)==5)
        assert ws.sent == [{'verb':'GET','path':DEVICE_LIST},
                           {'verb':'GET','path':'/keyboard/dev01/game_mode'},
                           {'verb':'SUBSCRIBE','path':'/keyboard/dev01/game_mode'},
                           {'verb':'GET','path':'/lighting/dev01/master_switch_on'},
                           {'verb':'SUBSCRIBE','path':'/lighting/dev01/master_switch_on'}]
        ws.put('/keyboard/dev01/game_mode',{'enabled':False})
        ws.put('/keyboard/other/game_mode',{'enabled':True})
        ws.put('/keyboard/dev01/game_mode',{'enabled':True})
        ws.put('/keyboard/dev01/game_mode',{'enabled':True})
        ws.put('/lighting/dev01/master_switch_on',{'value':True})
        ws.put('/lighting/dev01/master_switch_on',{'value':False})
        until(lambda:len(fired)==2)
        assert fired==['GameMode','LightButton']
        status=m.status();assert status['detected_c339'] and status['capabilities']['hasMasterSwitch']
        assert status['changes']=={'GameMode':1,'LightButton':1}
        assert 'SECRET' not in str(status) and 'dev01' not in str(status)
    finally:m.stop()
    assert not m.status()['active']


def test_ghub_monitor_refuses_ambiguous_device():
    ws=FakeWS();m=GHubStateMonitor(lambda _:None,connector=lambda:ws)
    ws.put(DEVICE_LIST, {'deviceInfos':[{'pid':0xc339,'id':'a'},{'pid':0xc339,'id':'b'}]})
    assert m.start()
    try:
        until(lambda:not m.status()['active'])
        assert not m.status()['detected_c339']
        assert len(ws.sent)==1
    finally:m.stop()


def toggle_trials(l, sequences):
    l.begin(0);l.tick(2)
    for i, seq in enumerate(sequences):
        t=2+i*5
        assert l.arm(t)
        for j,h in enumerate(seq):l.feed(h,t+.2+j*.1)
        l.tick(t+4.1)


def test_toggle_requires_both_state_signatures_verified():
    l=FnLearner('GameMode');toggle_trials(l,[(b'a',),(b'b',),(b'a',),(b'b',)])
    assert l.phase=='verify' and l.signature==b'a' and l.alternate==b'b'
    l.feed(b'a',23);assert not l.can_enable()
    l.feed(b'b',24);assert l.can_enable()
    m=FnHidMonitor(lambda _:None);m.active=True;m.target='GameMode';m.learner=l
    assert m.enable() and m.learned['GameMode']==(b'a',b'b')


def test_toggle_ambiguous_and_baseline_reports_are_not_learned():
    l=FnLearner('LightButton');toggle_trials(l,[(b'a',b'x'),(b'b',),(b'a',b'x'),(b'b',)])
    assert l.phase=='failed' and not l.can_enable()
    l=FnLearner();l.begin(0);l.feed(b'idle',.1);l.tick(2);l.arm(2);l.feed(b'idle',2.2);l.tick(6.1)
    assert l.attempt_reports==[{'reports':1,'distinct_nonidle':0}]
    assert '区別できません' in l.error
