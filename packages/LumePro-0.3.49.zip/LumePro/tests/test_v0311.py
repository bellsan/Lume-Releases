from pathlib import Path
from test_v035 import BitmapSDK
from logitech import LogitechBackend,G_LOGO,required_bitmap_codes
from bitmap_led import make_bitmap,SIZE
from preferences import Preferences


def make():
 b=LogitechBackend(BitmapSDK,lambda:Path('dummy.dll'));assert b.connect() and b.select(0);return b


def test_uniform_coverage_uses_independent_logo_and_jis_routes():
 b=make()
 try:
  assert b.set_key_method('IntlYen','scan')
  assert b.test_coverage('#000000')
  s=b.sdk;assert ('all',0,0,0) in s.calls
  assert ('bitmap',make_bitmap({})) in s.calls
  assert ('scan',0x7d,0,0,0) in s.calls
  assert s.calls[-1]==('keyname',G_LOGO,0,0,0)
  d=b.status()['coverage_results'];assert d['physical_verified'] is False
  assert set(d['unaddressed'])=={'GameMode','LightButton'}
  assert b.test_coverage('#00ffff') and ('scan',0x7d,0,100,100) in s.calls
  assert s.calls[-1]==('keyname',G_LOGO,0,100,100)
  assert not b.test_coverage('#ff0000')
 finally:b.close()


def test_logo_independent_in_bitmap_mode_and_cache():
 b=make()
 try:
  assert b.configure_bitmap({k:i for i,k in enumerate(sorted(required_bitmap_codes('jis')))},True)
  f={'KeyA':'#ff0000','BoardLogo':'#00ffff'}
  assert b._write(f) and b.sdk.calls[-1]==('keyname',G_LOGO,0,100,100)
  assert 'BoardLogo' not in b.status()['unsupported_keys']
  n=len(b.sdk.calls);assert b._write(f) and len(b.sdk.calls)==n
  assert b._write({**f,'BoardLogo':'#000000'}) and b.sdk.calls[-1]==('keyname',G_LOGO,0,0,0)
 finally:b.close()


def test_yen_probe_and_prefs_preserve_bracket(tmp_path):
 b=make()
 try:
  assert b.set_key_method('Backslash','hid64')
  for method,kind,addr in [('hid','hid',0x89),('scan','scan',0x7d),('keyname','keyname',0x7d)]:
   assert b.probe_special('IntlYen',method,'#00b0ff')
   assert b.sdk.calls[-1][:2]==(kind,addr)
  assert b.key_methods['Backslash']=='hid64' and b.key_methods['IntlYen']=='auto'
  p=Preferences(tmp_path/'prefs.json');p.update({'bracket_method':'hid64','yen_method':'scan'})
  assert p.load()['yen_method']=='scan' and p.load()['bracket_method']=='hid64'
 finally:b.close()
