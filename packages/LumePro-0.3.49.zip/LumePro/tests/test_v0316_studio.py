"""Studio regression: FFT, physical bars, layer parameters and LED safety."""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/"app"))
import numpy as np
from engine import render,validate,REACTIVE,EFFECTS
from audio import AudioAnalyzer,blank,demo_signal
from preferences import clean

KEYS=[{'code':f'K{r*18+c}','x':c+.5,'y':r+.8} for r in range(6) for c in range(18)]
KEYS+= [{'code':'BoardLogo','x':.6,'y':0},{'code':'LightButton','x':17.8,'y':0}]
def scene(kind='spectrum',**kw):
 return validate({'keys':KEYS,'layers':[dict(type=kind,id=1,color='#0055ff',secondary='#00ffff',brightness=100,**kw)]})

def test_fft_dense_correct_frequency_and_release():
 def run(hz):
  a=AudioAnalyzer(48000)
  for i in range(30):
   t=(np.arange(1024)+i*1024)/48000
   d=a.process(np.sin(t*2*np.pi*hz)*.18,now=i*1024/48000)
  return a,d
 a,low=run(90);_,high=run(4000)
 assert len(low['spectrum'])==len(low['spectrum_slow'])==len(low['spectrum_peak'])==48
 assert np.argmax(low['spectrum'])+18<np.argmax(high['spectrum'])
 assert max(low['spectrum'])>.65
 for i in range(80): d=a.process(np.zeros(1024),now=.65+i*.03)
 assert max(d['spectrum'])<.001 and max(d['spectrum_peak'])<.001

def test_physical_bars_are_discrete_and_color_height():
 a={**blank(),'spectrum':[.5]*48,'spectrum_slow':[.5]*48}
 frame=render(scene(barGate=0,barSmooth=0),[],0,a)
 # Exactly the three bottom rows (each key is a pixel, no fake sub-key LEDs).
 assert sum(frame[f'K{i}']!='#000000' for i in range(108))==54
 assert all(frame[f'K{i}']=='#000000' for i in range(54))
 assert frame['K90']=='#0055ff' and frame['K54']!=frame['K90']
 assert frame['BoardLogo']==frame['LightButton']=='#000000'

def test_spectrum_shapes_and_settings_change_output():
 a={**blank(),'spectrum':np.linspace(.2,.95,48).tolist(),'spectrum_slow':np.linspace(.95,.2,48).tolist(),'spectrum_peak':[.95]*48}
 base=render(scene(barSmooth=0,barGate=0),[],0,a)
 for kw in ({'barOrigin':'top'},{'barOrigin':'center'},{'barShape':'dot'},{'barShape':'outline'},{'barShape':'soft'},{'bars':7},{'barWidth':30},{'barHeight':65},{'barReverse':True},{'barSmooth':100},{'barGate':45},{'barColor':'frequency'},{'barPeak':True},{'freqLow':45},{'freqHigh':45},{'barMain':True},{'gradient':['#ff0000','#ffff00','#ffffff']}):
  settings={'barSmooth':0,'barGate':0};settings.update(kw)
  assert render(scene(**settings),[],0,a)!=base,kw
 assert set(render(scene(barPeak=True),[],0,blank()).values())=={'#000000'}

def test_dark_spectrum_can_mask_background():
 raw={'keys':KEYS,'layers':[{'type':'spectrum','barBlack':True},{'type':'static','color':'#ff0000','brightness':100}]}
 f=render(validate(raw),[],0,blank());assert f['K0']=='#000000' and f['BoardLogo']=='#ff0000'
 raw['layers'][0]['barBlack']=False;assert render(validate(raw),[],0,blank())['K0']=='#ff0000'

def test_new_effects_and_motion_are_real():
 for typ in ['orbit','scanner','rain']:
  s=scene(typ);a=render(s,[],.1);b=render(s,[],1.7)
  assert len(set(a.values()))>5 and a!=b,typ
  assert a!=render(scene(typ,gradient=['#ff0000','#ff00ff','#ffffff']),[],.1),typ
  assert clean({'editor':{'layout':'jis','layers':[{'type':typ}]}})['editor'] is not None
 for typ,kw in [('ripple',{'pulseShape':'diamond'}),('ripple',{'aspect':50}),('flower',{'petals':9}),('circle',{'originX':15}),('spring',{'angle':85,'direction':'right'}),('silk',{'motionCurve':'sharp'})]:
  a=render(scene(typ),[(4,2,0)],.5);b=render(scene(typ,**kw),[(4,2,0)],.5);assert a!=b, (typ,kw)

def test_demo_frames_change_and_actual_audio_distinct():
 s=scene(barPeak=True);assert render(s,[],1,demo_signal(1))!=render(s,[],2,demo_signal(2))
 assert render(s,[],1,demo_signal(1))!=render(s,[],1,blank())
