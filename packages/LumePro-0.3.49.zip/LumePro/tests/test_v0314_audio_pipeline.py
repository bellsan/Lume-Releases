import time
from contextlib import contextmanager
import numpy as np
import audio
from engine import AnimationEngine,render,validate


def test_audio_foreground_and_fixed_color():
    raw={'keys':[{'code':'KeyA','x':1,'y':1}], 'layers':[{'type':'static','color':'#0000ff','brightness':100},{'type':'music','color':'#ff0000','secondary':'#ff0000','brightness':100}], 'keyColors':{'KeyA':'#0000ff'}}
    assert render(validate(raw),[],0,{'volume':1})['KeyA']=='#ff0000'
    assert render(validate(raw),[],0,audio.blank())['KeyA']=='#0000ff'
    raw['fixedColorMode']='fixed'
    assert render(validate(raw),[],0,{'volume':1})['KeyA']=='#0000ff'


def test_capture_signal_reaches_hardware_worker(monkeypatch):
    class Backend:
        device=object()
        def __init__(self):self.output=[]
        def queue_frame(self,f):self.output.append(f)
        def clear_pending(self):pass
    class Keys:
        def since(self,seq):return {'seq':0,'events':[]}
    @contextmanager
    def capture(endpoint):
        assert endpoint=='7'
        def read():
            time.sleep(.02)
            return np.full((1024,2),.12)
        yield 'Test output',48000,read
    monkeypatch.setattr(audio,'portaudio_capture',capture)
    b=Backend();m=audio.AudioMonitor();e=AnimationEngine(b,Keys(),m)
    try:
        e.configure({'keys':[{'code':'KeyA','x':1,'y':1}], 'layers':[{'type':'music','color':'#ff0000','secondary':'#ff0000','brightness':100}]})
        e.enable(True);assert m.start('pa:7')
        deadline=time.monotonic()+3
        while not any(f['KeyA']!='#000000' for f in b.output) and time.monotonic()<deadline:time.sleep(.03)
        assert any(f['KeyA']!='#000000' for f in b.output)
        assert m.status()['signal']=='signal' and m.status()['signal_frames']>0
        assert e.status()['audio_layers']==1
    finally:
        e.close();m.stop();m.thread.join(2)


def test_silence_stale_and_demo_are_distinct():
    m=audio.AudioMonitor();m.enabled=True;m.frames=2;m.last_packet=time.monotonic()
    assert m.status()['signal']=='silent'
    m.last_packet-=2
    assert m.status()['signal']=='stalled'
    m.demo();assert m.status()['signal']=='test' and m.status()['volume']>0 and m.status()['captured_rms']==0
    m.stop();assert m.status()['signal']=='off'


def test_quiet_audio_detected():
    a=audio.AudioAnalyzer();d=a.process(np.full((1024,2),.001))
    assert d['volume']>.005 and d['peak']==.001
