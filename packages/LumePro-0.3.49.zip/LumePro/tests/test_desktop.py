import json, sys
from pathlib import Path
from unittest.mock import Mock
import pytest
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'app'))
import desktop
from engine import validate
from preferences import clean

@pytest.mark.parametrize('layout',['jis','ansi'])
def test_restore_geometry(layout):
    p=clean({'editor':{'layout':layout,'layers':[{'id':1,'type':'static','color':'#123456'}]}})
    scene=desktop.restored_scene(p,ROOT/'app')
    keys=validate(scene)[0]
    assert len(keys)>=87 and len(keys)==len(scene['keys'])
    assert 'Fn' in keys and 'BoardLogo' in keys and 'Backslash' in keys
    assert ('IntlYen' in keys)==(layout=='jis')
    assert scene['layers'][0]['color']=='#123456'

def test_bounded_crash_restart(tmp_path,monkeypatch):
    run=Mock(side_effect=[1,1,0]);monkeypatch.setattr(desktop.subprocess,'call',run);monkeypatch.setattr(desktop.time,'sleep',lambda _:None)
    assert desktop.supervise(['--port','12345'],tmp_path)==0
    assert run.call_count==3
    assert '--worker' in run.call_args.args[0] and '--no-browser' in run.call_args.args[0]
    run.reset_mock(side_effect=True);run.side_effect=[0]
    assert desktop.supervise(['--port','12345'],tmp_path)==0 and run.call_count==1
    (tmp_path/'preferences.json').write_text(json.dumps({'recovery':False}))
    run.reset_mock(side_effect=True);run.side_effect=[1]
    assert desktop.supervise(['--port','12345'],tmp_path)==1 and run.call_count==1

def test_presence_tristate(monkeypatch):
    fake=Mock();monkeypatch.setitem(sys.modules,'hid',fake);fake.enumerate.return_value=[{}]
    assert desktop.presence() is True;fake.enumerate.assert_called_with(0x046d,0xc339)
    fake.enumerate.return_value=[];assert desktop.presence() is False
    fake.enumerate.side_effect=OSError;assert desktop.presence() is None

def test_desktop_preferences_safe_defaults():
    p=clean({});assert p['startup'] is False and p['audio_enabled'] is False and p['hook'] is False
    assert p['tray'] is True and p['recovery'] is True
    assert clean({'startup':'yes','recovery':0,'audio_enabled':1})['startup'] is False
