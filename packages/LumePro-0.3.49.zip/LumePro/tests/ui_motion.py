"""Real Chromium regression of effect hover, inspector, and preset thumbnails (mock SDK)."""
import asyncio, os
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parents[1]
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(headless=True,executable_path=os.environ.get('CHROMIUM_PATH','/usr/bin/chromium'),args=['--no-sandbox'])
  page=await browser.new_page(viewport={'width':1260,'height':800});page.set_default_timeout(5000)
  errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  app=ROOT/'app';await page.set_content((app/'index.html').read_text().replace('<link rel="stylesheet" href="/style.css">','').replace('<script src="/app.js" defer></script>',''))
  await page.add_style_tag(content=(app/'style.css').read_text())
  await page.evaluate('''window.calls=[];window.fetch=async(url,opts)=>{const u=String(url),b=opts?.body?JSON.parse(opts.body):{};calls.push({u,b});let data={ok:true};if(u==='/api/token')data={token:'test'};else if(u==='/api/preferences')data={preferences:{auto:false,backend:'logitech',hook:false,live:false,editor:null}};else if(u==='/api/status')data={hardware:{connected:false,active:false,devices:[],led_map:[]},engine:{active:false,pulses:0},keyhook:{enabled:false}};else if(u==='/api/presets')data={presets:[]};else if(u==='/api/keys')data={seq:0,events:[]};else if(u==='/api/audio')data={enabled:false,volume:0};return {ok:true,json:async()=>data}}''')
  await page.add_script_tag(content=(app/'app.js').read_text());await page.wait_for_timeout(450)
  assert await page.locator('#keyboard button.key').count()==91
  await page.locator('#newLayerBtn').click();await page.locator('#effectCategory').select_option('ambient')
  snapshots={}
  for kind in ('orbit','scanner','rain'):
   await page.locator(f'[data-effect={kind}]').hover();await page.wait_for_timeout(100)
   assert await page.evaluate('catalogPreview.type')==kind
   snapshots[kind]=await page.evaluate('paintFrame(1.3,false)')
  assert len({str(f) for f in snapshots.values()})==3
  await page.locator('[data-effect=orbit]').click();await page.locator('[data-inspector-tab=motion]').click()
  assert await page.locator('#orbitHeads').is_visible() and await page.locator('#motionTrail').is_visible()
  assert not await page.locator('#rainDensity').is_visible()
  await page.locator('#orbitHeads').fill('3');await page.wait_for_timeout(150)
  assert await page.evaluate('currentLayer().orbitHeads')==3
  # Use app's exact painting pipeline at controlled phases and capture the actual keyboard UI.
  await page.evaluate("""()=>{state.layers=[{...freshEffect('orbit'),id:1}];state.selectedLayer=1;state.selectedKeys=[];state.running=false;catalogPreview=null;refreshAll();setInspector(false);updateSelection()}""")
  await page.wait_for_timeout(300)
  for kind in ('orbit','scanner','rain'):
   await page.evaluate('(k)=>{state.layers=[{...freshEffect(k),id:1}];state.selectedLayer=1;refreshAll();paintFrame(1.35,true)}',kind)
   await page.wait_for_timeout(180)
   await page.locator('#keyboardFrame').screenshot(path=str(ROOT/f'GUI_{kind}.png'))
  # UI inspector exposes only controls relevant to current effect.
  for kind,visible,invisible in [('scanner','scanMode','orbitHeads'),('rain','rainDensity','scanMode')]:
   await page.evaluate('(k)=>{state.layers=[{...freshEffect(k),id:1}];state.selectedLayer=1;refreshAll();setInspector(true);setInspectorTab("motion")}',kind)
   assert await page.locator('#'+visible).is_visible() and not await page.locator('#'+invisible).is_visible()
  assert not errors,errors
  await browser.close();print('Motion UI: hover / actual painting / inspector OK; page errors: 0')
if __name__=='__main__':asyncio.run(main())
