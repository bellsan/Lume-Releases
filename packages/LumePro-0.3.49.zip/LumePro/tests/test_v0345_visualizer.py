import numpy as np
from audio import AudioAnalyzer, blank
from engine import validate, visualizer_pixel, render

def layer(**kw):
    return validate({'keys':[{'code':'KeyA','x':1,'y':2}], 'layers':[{'type':'audio_visualizer','color':'#FFFFFF','secondary':'#FFFFFF',**kw}]})[1][0]

def test_pcm_history_and_stereo_cancellation():
    a=AudioAnalyzer(); t=np.arange(1024)/48000
    for i in range(12):
        s=.25*np.sin(2*np.pi*90*(t+i*1024/48000))
        r=a.process(np.column_stack((s,-s)),i*1024/48000)
    assert len(r['visual_envelope'])==24 and min(r['visual_envelope'])>.08
    assert max(abs(v) for v in r['trace'])<1e-9
    for i in range(12,32):r=a.process(np.zeros((1024,2)),i*1024/48000)
    assert max(r['visual_envelope'])==0
    assert visualizer_pixel(layer(),r,.5,.5)[0]<.001

def test_wave_shape_and_mix():
    a=blank();a.update(volume=.6,visual_envelope=[0]*12+[.5]*12,spectrum=[.8]*24+[0]*24)
    w=layer(waveMix=0); f=layer(waveMix=100)
    assert visualizer_pixel(w,a,.8,.5)[0]>.9 and visualizer_pixel(w,a,.2,.5)[0]==0
    assert visualizer_pixel(f,a,.2,.5)[0]>.9 and visualizer_pixel(f,a,.8,.5)[0]==0
    assert abs(visualizer_pixel(w,a,.8,.2)[0]-visualizer_pixel(w,a,.8,.8)[0])<1e-9
    assert visualizer_pixel(w,a,.8,.5)[0]>=visualizer_pixel(w,a,.8,0)[0]
    a['packet_age_ms']=500;assert visualizer_pixel(w,a,.8,.5)[0]==0

def test_idle_and_accent():
    a=blank();assert visualizer_pixel(layer(),a,.5,.5)[0]==0
    assert visualizer_pixel(layer(waveIdle=True),a,.5,.5)[0]>0
    a.update(volume=.5,visual_envelope=[.06]*24,rhythm={'events':[{'kind':'kick','age':0,'strength':1}]})
    assert visualizer_pixel(layer(waveBeat=100),a,.12,.2)[0]>visualizer_pixel(layer(waveBeat=0),a,.12,.2)[0]
    assert visualizer_pixel(layer(sensitivity=0),a,.12,.5)[0]==0
