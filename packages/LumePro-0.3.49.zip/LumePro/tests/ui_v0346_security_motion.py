"""Browser UI with mocked local API; actual HTTP policy is tested in test_server.py."""
import asyncio, os, sys, socket, subprocess, tempfile, urllib.request, time
from pathlib import Path
from playwright.async_api import async_playwright
from ui_preset_menu import setup
ROOT=Path(__file__).resolve().parents[1]
SAMPLE='''async open=>{const menu=$('effectPicker'),board=document.querySelector('.keyboard-outer');const read=()=>({t:performance.now(),opacity:+getComputedStyle(menu).opacity,inset:pickerInsetProgress,x:board.getBoundingClientRect().x,w:board.getBoundingClientRect().width,raw:board.offsetWidth});const a=[read()];setPickerOpen(open);const start=performance.now();while(performance.now()-start<420){await new Promise(requestAnimationFrame);a.push(read())}return a}'''
async def main():
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path=os.environ.get('CHROMIUM_PATH','/usr/bin/chromium'),args=['--no-sandbox'])
  page,errors=await setup(b,{f:(ROOT/'app'/f).read_text() for f in ('index.html','style.css','app.js')})
  assert await page.evaluate('secret==="test" && state.reactivePriority===false && allProfiles.filter(p=>p.builtin).every(p=>p.state.reactivePriority===false)')
  assert await page.evaluate('!$("reactivePriority").checked')
  for w,h in [(1260,800),(900,600)]:
   await page.set_viewport_size({'width':w,'height':h});await page.evaluate('setInspector(false,false);fitPreview()');await page.wait_for_timeout(650)
   for op in [True,False]:
    frames=await page.evaluate(SAMPLE,op);a,z=frames[0],frames[-1]
    print(w,op,'frames',len(frames),'width',round(a['w'],1),round(z['w'],1),'error',max(abs(f['opacity']-f['inset']) for f in frames),flush=True)
    assert abs(z['opacity']-int(op))<.001 and all(abs(f['opacity']-f['inset'])<.00001 for f in frames)
    assert len({round(f['w'],1) for f in frames})>=6 and len({f['raw'] for f in frames})==1
    assert abs(z['w']-a['w'])>20
    if op: await page.screenshot(path=f'/mnt/data/LumePro_v0.3.46_picker_{w}.png')
   await page.evaluate('setPickerOpen(true);setTimeout(()=>setPickerOpen(false),70);setTimeout(()=>setPickerOpen(true),140)');await page.wait_for_timeout(550)
   assert await page.evaluate('pickerInsetProgress===1 && +getComputedStyle($("effectPicker")).opacity===1')
   await page.locator('.effect-card[data-effect="audio_visualizer"]').click();await page.wait_for_timeout(650)
   assert await page.evaluate('currentLayer().type==="audio_visualizer" && state.reactivePriority===false && pickerInsetProgress===0')
   await page.evaluate('setInspector(false);setUiMotion(false);setPickerOpen(true)');assert await page.evaluate('pickerInsetProgress===1');await page.evaluate('setPickerOpen(false);setUiMotion(true)')
  # Save payload and readback using the browser mock.
  result=await page.evaluate('''async()=>{let p={name:'Security regression',state:presetState()};let r=await post('/api/save',{preset:p});let list=await(await apiFetch('/api/presets')).json();return {ok:r.ok,found:list.presets.some(x=>x.name===p.name&&x.state.reactivePriority===false)}}''')
  assert result=={'ok':True,'found':True},result
  assert not errors,errors
  await b.close();print('PASS mocked UI: builtins default OFF, catalogue shared fade/geometry, reversal and motion off')
if __name__=='__main__':asyncio.run(main())
