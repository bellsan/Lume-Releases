import builtins
import sys
import time
import types
from contextlib import contextmanager

import numpy as np
import pytest
import audio


def test_soundcard_import_before_com_initialization(monkeypatch):
    events=[]
    real_import=builtins.__import__
    class Recorder:
        def __enter__(self): return self
        def __exit__(self,*args): events.append('closed')
        def record(self,numframes): return np.zeros((numframes,2))
    fake=types.SimpleNamespace(default_speaker=lambda:types.SimpleNamespace(id='endpoint',name='Speaker'),get_microphone=lambda **kw:types.SimpleNamespace(recorder=lambda **kw:Recorder()))
    def importing(name,*args,**kwargs):
        if name=='soundcard':
            # Model the reported SoundCard implementation rejecting S_FALSE
            # if its first import follows an explicit COM initialization.
            if 'COM' in events: raise RuntimeError('Error 0x100000001')
            events.append('import')
            return fake
        return real_import(name,*args,**kwargs)
    @contextmanager
    def apartment():
        events.append('COM'); yield; events.append('uninit')
    monkeypatch.setattr(builtins,'__import__',importing)
    monkeypatch.setattr(audio,'com_apartment',apartment)
    with audio.soundcard_capture() as (device,rate,read):
        assert device=='Speaker' and rate==48000 and read().shape==(1024,2)
    assert events==['import','COM','closed','uninit']

@pytest.mark.parametrize('hr,uninit',[(0,True),(1,True),(-2147417850,False)])
def test_com_hresult_success_and_existing_apartment(monkeypatch,hr,uninit):
    events=[]
    def init(*args): return hr
    monkeypatch.setattr(audio.sys,'platform','win32')
    monkeypatch.setattr(audio.ctypes,'windll',types.SimpleNamespace(ole32=types.SimpleNamespace(CoInitializeEx=init,CoUninitialize=lambda:events.append('uninit'))),raising=False)
    with audio.com_apartment(): events.append('capture')
    assert events==(['capture','uninit'] if uninit else ['capture'])


def test_portaudio_native_endpoint_format_and_cleanup(monkeypatch):
    events=[]
    class Stream:
        def read(self,n,exception_on_overflow):
            assert not exception_on_overflow
            return np.tile(np.array([16384,-16384],dtype='<i2'),n).tobytes()
        def close(self):events.append('closed')
    class Driver:
        def get_default_wasapi_loopback(self):return dict(isLoopbackDevice=True,defaultSampleRate=44100,maxInputChannels=2,index=7,name='Headphones loopback')
        def open(self,**kw):
            assert kw['rate']==44100 and kw['channels']==2 and kw['input_device_index']==7
            return Stream()
        def terminate(self):events.append('terminated')
    monkeypatch.setitem(sys.modules,'pyaudiowpatch',types.SimpleNamespace(PyAudio=Driver,paInt16=8))
    with audio.portaudio_capture() as (device,rate,read):
        data=read();assert rate==44100 and device=='Headphones loopback'
        assert data.shape==(1024,2) and np.allclose(data[0],[.5,-.5])
    assert events==['closed','terminated']


def test_monitor_falls_back_and_restarts(monkeypatch):
    @contextmanager
    def failed():
        raise RuntimeError('test device unavailable')
        yield
    @contextmanager
    def working():
        def read():
            time.sleep(.01)
            return .1*np.ones((1024,2))
        yield 'Test',48000,read
    monkeypatch.setattr(audio,'portaudio_capture',failed)
    monkeypatch.setattr(audio,'soundcard_capture',working)
    m=audio.AudioMonitor()
    for _ in range(2):
        assert m.start()
        try:
            end=time.monotonic()+2
            while m.status()['frames']<2 and time.monotonic()<end:time.sleep(.02)
            state=m.status()
            assert state['frames']>=2 and state['volume']>0
            assert state['backend']=='WASAPI / SoundCard'
            assert state['attempts'][0]['error']=='test device unavailable'
        finally:m.stop();m.thread.join(2)
        assert not m.status()['enabled'] and not m.thread.is_alive()


def test_all_backends_fail_with_diagnostics(monkeypatch):
    @contextmanager
    def failed():
        raise RuntimeError('test failure')
        yield
    monkeypatch.setattr(audio,'portaudio_capture',failed)
    monkeypatch.setattr(audio,'soundcard_capture',failed)
    m=audio.AudioMonitor();assert m.start();m.thread.join(2)
    state=m.status();assert not state['enabled'] and len(state['attempts'])==2
    assert 'SoundCard' in state['error'] and 'PyAudioWPatch' in state['error']
