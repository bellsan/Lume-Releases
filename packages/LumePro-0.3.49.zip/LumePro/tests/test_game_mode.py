import sys,time
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'app'))
import pytest
from game_mode import GameMode
from keyhook import KeyboardWatcher
from engine import AnimationEngine
from audio import AudioMonitor
from preferences import Preferences

@pytest.mark.parametrize('led,expected',[('off','#000000'),('dim','#402010'),('color','#ff5555'),('normal','#ff8040')])
def test_led_policy_and_restore(led,expected):
 g=GameMode();base={'KeyA':'#ff8040','KeyB':'#123456'};g.configure(True,['KeyA'],led,dim=25)
 assert g.mask(base)=={'KeyA':expected,'KeyB':'#123456'};assert base['KeyA']=='#ff8040'
 g.disable();assert g.mask(base)==base

def test_block_and_release_across_toggle():
 g=GameMode();g.configure(False,['KeyA']);assert not g.event('KeyA','KeyA',False)
 g.configure(True,['KeyA']);assert not g.event('KeyA','KeyA',False);assert not g.event('KeyA','KeyA',True)
 assert g.event('KeyA','KeyA',False);assert g.event('KeyA','KeyA',False)
 g.disable();assert g.event('KeyA','KeyA',True);assert not g.event('KeyA','KeyA',False)

def test_emergency_release():
 g=GameMode();g.configure(True,['KeyA']);assert not g.event('ControlLeft','ControlLeft',False);assert not g.event('AltRight','AltRight',False);assert not g.event('F12','F12',False);assert not g.status()['enabled'];assert not g.event('KeyA','KeyA',False)

def test_unmatched_release_and_injected():
 g=GameMode();g.configure(True,['KeyA']);assert not g.event('KeyA','KeyA',True);assert not g.event('KeyA','KeyA',False,injected=True);assert not g.event('KeyA','KeyA',False,already_held=True);assert not g.event('KeyA','KeyA',True)

def test_invalid_and_reserved():
 g=GameMode()
 for k in ['Fn','BoardLogo','GameMode','F12','AltLeft','ControlRight','not-a-key']:
  with pytest.raises(ValueError):g.configure(True,[k])
 with pytest.raises(ValueError):g.configure(True,['KeyA'],'bad')
 assert not g.status()['enabled']

def test_saved_settings_never_activate(tmp_path):
 p=Preferences(tmp_path/'prefs.json');g=GameMode();g.configure(True,['KeyA'],'color','#11aabb');p.update({'game_mode':g.status()});s=p.load()['game_mode'];assert not s['enabled'] and s['blocked']==['KeyA'] and s['color']=='#11aabb'

def test_led_mask_in_worker_while_paused():
 class Backend:
  device=object()
  def __init__(self):self.frames=[]
  def queue_frame(self,f):self.frames.append(f)
  def clear_pending(self):pass
 b=Backend();k=KeyboardWatcher();e=AnimationEngine(b,k,AudioMonitor())
 try:
  scene={'keys':[{'code':'KeyA','x':0,'y':0},{'code':'KeyB','x':1,'y':0}],'layers':[{'type':'static','enabled':True,'color':'#ff8040','brightness':100}],'keyColors':{}}
  e.configure(scene);e.enable(True);time.sleep(.12);assert b.frames[-1]['KeyA']!='#000000'
  with e.lock:e.running=False
  old=b.frames[-1];k.game.configure(True,['KeyA']);time.sleep(.1);assert b.frames[-1]=={**old,'KeyA':'#000000'}
  k.game.disable();time.sleep(.1);assert b.frames[-1]==old
 finally:e.close()
