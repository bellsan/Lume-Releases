"""Check actual desktop layout across all existing tabs; uses mocked device API."""
import asyncio, os
from pathlib import Path
from playwright.async_api import async_playwright
from ui_preset_menu import setup
ROOT=Path(__file__).resolve().parents[1]
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(headless=True,executable_path=os.environ.get('CHROMIUM_PATH','/usr/bin/chromium'),args=['--no-sandbox'])
  page,errors=await setup(browser,{f:(ROOT/'app'/f).read_text() for f in ('index.html','style.css','app.js')})
  for w,h in [(1260,800),(900,600)]:
   await page.set_viewport_size({'width':w,'height':h})
   for view in ('lighting','profiles','keyboard','settings'):
    await page.locator(f'[data-view={view}]').click();await page.wait_for_timeout(500)
    if view=='lighting':
     await page.evaluate('setInspector(true,false)');await page.wait_for_timeout(600)
     data=await page.evaluate('''()=>{let a=document.querySelector('.canvas-panel').getBoundingClientRect(),b=document.querySelector('.canvas-actions').getBoundingClientRect();return {buttonFits:b.right<=a.right+1, height:document.querySelector('#inspectorToggle').getBoundingClientRect().height}}''')
     assert data['buttonFits'] and data['height']>=24,data
    if view=='settings':
     data=await page.evaluate('''()=>Array.from(document.querySelectorAll('#view-settings .setting-line')).filter(e=>e.getClientRects().length && e.getBoundingClientRect().height>0).filter(e=>{let c=e.children;return c.length>=2 && c[0].getBoundingClientRect().right>c[1].getBoundingClientRect().left+1}).length''')
     assert data==0,data
    assert await page.evaluate('document.documentElement.scrollWidth<=innerWidth'),(w,view)
    await page.screenshot(path=f'/mnt/data/LumePro_v0.3.40_{view}_{w}.png')
    print(w,view,'OK',flush=True)
   await page.locator('[data-view=profiles]').click();await page.wait_for_timeout(200)
   await page.locator('[data-profile-view=list]').click();assert await page.locator('#profileGrid').get_attribute('data-presentation')=='list'
   await page.locator('[data-profile-view=cards]').click()
  assert not errors,errors
  await browser.close()
if __name__=='__main__':asyncio.run(main())
