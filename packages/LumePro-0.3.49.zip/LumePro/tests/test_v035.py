from pathlib import Path
from test_v033 import SDK
from logitech import LogitechBackend,required_bitmap_codes
from bitmap_led import make_bitmap,probe,frame_bitmap,valid_mapping,SIZE
from preferences import Preferences

class BitmapSDK(SDK):
 def __init__(self,path):
  super().__init__(path);self.bitmap=True
 def send_bitmap(self,data):return self.call('bitmap',data)

def test_bitmap_format_and_probe():
 assert SIZE==126
 b=make_bitmap({0:(11,22,33),125:(5,6,7)})
 assert len(b)==504 and b[:4]==bytes([33,22,11,255]) and b[-4:]==bytes([7,6,5,255])
 for n in range(126):
  v=sum((probe('bit',i)[n*4+1]>0)<<i for i in range(7))
  assert v==n
 assert probe('off')==bytes([0,0,0,255])*126

def test_bitmap_actual_output_and_cache():
 b=LogitechBackend(BitmapSDK,lambda:Path('dummy.dll'))
 try:
  assert b.connect() and b.select(0)
  assert b.bitmap_available()
  assert b.test_bitmap('all') and b.sdk.calls[-1]==('bitmap',probe('all'))
  assert not b.test_bitmap('cell',126)
  assert not b.configure_bitmap({'Fn':2,'Backslash':2},True)
  assert not b.configure_bitmap({'Fn':0,'Backslash':1,'GameMode':2,'LightButton':3,'KeyA':4},True)
  mapping={'Fn':0,'Backslash':1,'GameMode':2,'LightButton':3,'KeyA':4}
  for i,k in enumerate(sorted(required_bitmap_codes('jis')-mapping.keys()),5):mapping[k]=i
  assert b.configure_bitmap(mapping,True)
  colors={'Fn':'#ff0000','Backslash':'#00ff00','GameMode':'#0000ff','LightButton':'#ffffff','KeyA':'#123456'}
  assert b._write(colors)
  assert b.sdk.calls[-1]==('bitmap',frame_bitmap(colors,b.bitmap_mapping))
  assert b.status()['output_mode']=='bitmap'
  assert 'Fn' not in b.status()['unsupported_keys']
  n=len(b.sdk.calls);assert b._write(colors) and len(b.sdk.calls)==n
  assert b.test_led(b.codes.index('GameMode'),'#00ff00')
  assert b.sdk.calls[-1][1][8:12]==bytes([0,255,0,255])
  assert b.set_layout('ansi') and b.output_mode=='key' and not b.bitmap_mapping
 finally:b.close()

def test_bitmap_prefs_roundtrip(tmp_path):
 p=Preferences(tmp_path/'prefs.json')
 assert p.update({'bitmap_mapping':{'Fn':2,'LightButton':125},'bitmap_layout':'jis','bitmap_enabled':True})['bitmap_enabled']
 assert p.load()['bitmap_mapping']=={'Fn':2,'LightButton':125}
 assert valid_mapping({'Fn':2,'GameMode':2,'LightButton':126,'KeyA':True})=={'Fn':2}
