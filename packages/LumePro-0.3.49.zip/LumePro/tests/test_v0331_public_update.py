import hashlib, io, json, sys
from pathlib import Path
import pytest
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'app'))
import updater as u
from test_v0319_updater import tree, archive, release, wait, REPO
PUBLIC='bellsan/Lume-Releases'

def test_public_end_to_end_without_login(tmp_path,monkeypatch):
    import zipfile
    root=tree(tmp_path/'install','0.3.31')
    (root/'app/version.json').write_text(json.dumps({'version':'0.3.31','repository':PUBLIC,'private':False}))
    data=tmp_path/'data';data.mkdir();(data/'preferences.json').write_text('saved')
    buf=io.BytesIO()
    with zipfile.ZipFile(io.BytesIO(archive('0.3.32'))) as old,zipfile.ZipFile(buf,'w') as new:
        for name in old.namelist():
            new.writestr(name,json.dumps({'version':'0.3.32','repository':PUBLIC,'private':False}) if name.endswith('version.json') else old.read(name))
    payload=buf.getvalue();r=release('0.3.32',payload)
    for a in r['assets']:a['browser_download_url']=a['browser_download_url'].replace(REPO,PUBLIC)
    def no_token():pytest.fail('Public updater must not request credentials')
    monkeypatch.setattr(u,'github_token',no_token)
    def check(url,headers):
        assert PUBLIC in url
        assert not any(k.lower()=='authorization' for k in headers)
    def read(url,maximum,headers):
        check(url,headers)
        return hashlib.sha256(payload).hexdigest().encode() if url.endswith('.sha256') else json.dumps(r).encode()
    def open_mock(url,headers):
        check(url,headers);return io.BytesIO(payload)
    monkeypatch.setattr(u,'read_bounded',read);monkeypatch.setattr(u,'open_url',open_mock)
    m=u.Updater(root,data);m.check(True);wait(m,'idle');assert m.status()['available'];m.download();wait(m,'ready');m.request_apply();assert m.finish();assert u.read_metadata(root)['version']=='0.3.32';assert (data/'preferences.json').read_text()=='saved'
