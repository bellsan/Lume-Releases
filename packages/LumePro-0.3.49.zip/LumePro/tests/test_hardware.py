import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'app'))
from hardware import normalize_led,OpenRGBBackend
from keyhook import KeyboardWatcher


def test_led_aliases():
 expected={'Key: A':'KeyA','Key: 0':'Digit0','Left Shift':'ShiftLeft','Escape':'Escape',
 'Backspace':'Backspace','Page Down':'PageDown','Key: Return':'Enter','Key: F12':'F12',
 'Key: Spacebar':'Space','Right Alt':'AltRight','Key: LEFT ARROW':'ArrowLeft',
 'Gibberish 22':None}
 for raw,normalized in expected.items():assert normalize_led(raw)==normalized,(raw,normalize_led(raw))


def test_keyhook_does_not_capture_by_default():
 watcher=KeyboardWatcher()
 watcher.push('KeyA')
 assert watcher.since(0)['events']==[]
 assert watcher.start() is False if sys.platform!='win32' else True
 watcher.stop()


def test_openrgb_queue_validates_rgb():
 adapter=OpenRGBBackend()
 adapter.queue_frame({'KeyA':'#ff9900','Bad':'blue','Too long':'#ABCDEF','Zero':'#000000'})
 assert adapter.pending=={'KeyA':'#ff9900','Too long':'#ABCDEF','Zero':'#000000'}
 adapter.close()


def test_device_type_compatibility():
 from enum import IntEnum,Enum
 from hardware import is_keyboard_type
 class DeviceType(IntEnum):
  KEYBOARD=5
  MOUSE=6
 class OldType(Enum):
  KEYBOARD=5
 assert str(DeviceType.KEYBOARD)=='5' or str(DeviceType.KEYBOARD)=='DeviceType.KEYBOARD'
 for val in (DeviceType.KEYBOARD,OldType.KEYBOARD,5,'5','KEYBOARD','DeviceType.KEYBOARD','DEVICE_TYPE_KEYBOARD'):
  assert is_keyboard_type(val),val
 for val in (0,1,2,3,4,6,7,8,'6','MOUSE','NOT_KEYBOARD','KEYBOARD_FAKE',None,True):
  assert not is_keyboard_type(val),val


def test_select_real_keyboard_and_reject_others():
 from types import SimpleNamespace
 from enum import IntEnum
 class DeviceType(IntEnum):
  KEYBOARD=5
  MOUSE=6
 class Device:
  def __init__(self,name,kind,leds):
   self.name=name;self.type=kind;self.leds=[SimpleNamespace(name=n) for n in leds];self.modes=[]
 adapter=OpenRGBBackend()
 try:
  adapter.devices=[Device('PRO Gaming Keyboard',DeviceType.KEYBOARD,['Key: A','Key: Escape']),Device('Mouse',DeviceType.MOUSE,['Key: A']),Device('Unknown keyboard',5,['Unknown LED'])]
  assert [x['keyboard'] for x in adapter.list_devices()]==[True,False,True]
  assert not adapter.select(1)
  assert not adapter.status()['active']
  assert adapter.select(2)
  assert adapter.status()['active'] and adapter.status()['matched']==0
  assert not adapter.select(True)
  assert adapter.select(0)
  assert adapter.status()['active']
  assert adapter.status()['matched']==2
  assert adapter.device.name=='PRO Gaming Keyboard'
  assert not adapter.select(1)
  assert adapter.device.name=='PRO Gaming Keyboard'
 finally:adapter.close()


def test_jis_aliases():
 for name,code in {'KEY_A':'KeyA','Key: KeyA':'KeyA','Key: @':'BracketLeft','Key: ¥':'IntlYen','Key: 無変換':'NonConvert','Key: International1':'IntlRo','Key: 変換':'Convert','Key: /':'Slash'}.items():
  assert normalize_led(name)==code,(name,code)


def test_sdk_output_and_unknown_preservation(monkeypatch):
 import types,time
 class RGB(tuple):
  def __new__(cls,r,g,b):return tuple.__new__(cls,(r,g,b))
 sdk=types.ModuleType('openrgb');utils=types.ModuleType('openrgb.utils');utils.RGBColor=RGB
 monkeypatch.setitem(sys.modules,'openrgb',sdk);monkeypatch.setitem(sys.modules,'openrgb.utils',utils)
 class Keyboard:
  name='PRO Gaming Keyboard';type=5;modes=[]
  leds=[types.SimpleNamespace(name=n) for n in ['KEY_A','Key: -','Key: 無変換','Unknown LED']]
  colors=[RGB(11,22,33)]*4
  def set_colors(self,colors):self.colors=colors
 adapter=OpenRGBBackend();device=Keyboard();adapter.devices=[device]
 try:
  assert adapter.select(0)
  assert adapter.test_led(None,'#404040')
  assert device.colors==[(64,64,64)]*4
  adapter.queue_frame({'KeyA':'#123456','Minus':'#789abc','NonConvert':'#fedcba'})
  deadline=time.monotonic()+1
  while adapter.sent<2 and time.monotonic()<deadline:time.sleep(.01)
  assert device.colors==[(18,52,86),(120,154,188),(254,220,186),(64,64,64)]
  assert adapter.set_mapping(3,'KeyB')
  assert adapter.test_led(3,'#112233')
  assert device.colors==[(0,0,0)]*3+[(17,34,51)]
  assert not adapter.test_led(4)
 finally:adapter.close()
