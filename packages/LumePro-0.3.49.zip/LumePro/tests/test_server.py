import os
import pathlib
import subprocess
import sys
import tempfile
import time
import urllib.request
import json
import pytest

ROOT=pathlib.Path(__file__).resolve().parents[1]

def request(port,path,token=None,data=None,extra=None):
 url=f'http://127.0.0.1:{port}{path}'
 body=json.dumps(data).encode() if data is not None else None
 headers={'Content-Type':'application/json'} if data is not None else {}
 if token:headers['X-Lume-Token']=token
 if extra:headers.update(extra)
 with urllib.request.urlopen(urllib.request.Request(url,data=body,headers=headers),timeout=3) as response:
  return json.loads(response.read())

@pytest.mark.parametrize('nonce',['','abcd'*8,'invalid'])
def test_local_api(nonce):
 import socket
 with socket.socket() as s:s.bind(('127.0.0.1',0));port=s.getsockname()[1]
 with tempfile.TemporaryDirectory() as tmp:
  env=dict(os.environ,LOCALAPPDATA=tmp,LUMEPRO_UPDATE_HEALTH=nonce)
  proc=subprocess.Popen([sys.executable,str(ROOT/'app'/'server.py'),'--no-browser','--port',str(port)],env=env,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
  try:
   for i in range(40):
    try:token=request(port,'/api/token',extra={'X-Lume-Bootstrap':'1'})['token'];break
    except OSError:time.sleep(.10)
   else:raise AssertionError('server did not start')
   # Anonymous API access, untrusted origins and forged hosts must be denied.
   for path in ('/api/keys','/api/presets','/api/audio','/api/status','/api/preferences','/api/token'):
    with pytest.raises(urllib.error.HTTPError) as err:request(port,path)
    assert err.value.code==403
   for extra in ({'Host':'untrusted.invalid'},{'Origin':'https://untrusted.invalid'},{'Sec-Fetch-Site':'cross-site'}):
    with pytest.raises(urllib.error.HTTPError) as err:request(port,'/api/status',token,extra=extra)
    assert err.value.code==403
    with pytest.raises(urllib.error.HTTPError) as err:request(port,'/api/token',extra={'X-Lume-Bootstrap':'1',**extra})
    assert err.value.code==403
   with pytest.raises(urllib.error.HTTPError) as err:request(port,'/api/keyhook','incorrect',{'enabled':True})
   assert err.value.code==403
   health=request(port,'/api/update/status')
   assert set(health)==({'current','phase','last_install_error','update_health'} if len(nonce)==32 else {'current','phase','last_install_error'})
   if len(nonce)==32:assert health['update_health']==nonce
   assert 'events' in request(port,'/api/keys?since=0',token)
   with urllib.request.urlopen(f'http://127.0.0.1:{port}/') as response:
    assert response.headers['X-Frame-Options']=='DENY'
    assert "frame-ancestors 'none'" in response.headers['Content-Security-Policy']
   status=request(port,'/api/status',token)
   assert status['hardware']['active'] is False
   diag=request(port,'/api/diagnostic',token)
   assert diag['diagnostic_version']==3 and 'audio' in diag and diag['fn_hid']['active'] is False and diag['fn_hid']['collection_stats']==[]
   assert request(port,'/api/preferences',token)['preferences']['auto'] is True
   saved=request(port,'/api/preferences',token,{'auto':False,'live':True,'hook':True,'backend':'logitech'})
   assert saved['ok'] and saved['preferences']['live'] is True
   assert request(port,'/api/auto_connect',token,{})['ok'] is False
   assert request(port,'/api/preferences',token)['preferences']['auto'] is False
   save=request(port,'/api/save',token,{'preset':{'name':'test profile','state':{'layout':'jis','layers':[{'id':1,'type':'static','color':'#ffffff'}]}}})
   assert save['ok'] and save['presets'][0]['state']['reactivePriority'] is False
   for bad in ({'layout':'jis','layers':[]},{'layout':'jis','layers':[{'id':'bad','type':'static','color':'#ffffff'}]},{'layout':'jis','layers':[{'type':'static','color':'invalid'}]},{'layout':'jis','layers':[{'type':'static','color':'#ffffff','brightness':999}]}):
    with pytest.raises(urllib.error.HTTPError) as err:request(port,'/api/save',token,{'preset':{'name':'invalid','state':bad}})
    assert err.value.code==400
   names=[x['name'] for x in request(port,'/api/presets',token)['presets']]
   assert 'test profile' in names
   assert request(port,'/api/delete',token,{'name':'test profile'})['ok']
   assert request(port,'/api/presets',token)['presets']==[]
   assert request(port,'/api/audio',token)['enabled'] is False
   game=request(port,'/api/game_mode',token,{'enabled':False,'blocked':['KeyA'],'led':'off'})
   assert game['ok'] and game['game_mode']['blocked']==['KeyA']
   assert request(port,'/api/preferences',token)['preferences']['game_mode']['enabled'] is False
   assert request(port,'/api/status',token)['game_mode']['blocked']==['KeyA']
   try:request(port,'/api/game_mode',token,{'enabled':False,'blocked':['F12']});raise AssertionError('protected key accepted')
   except urllib.error.HTTPError as exc:assert exc.code==400
   request(port,'/api/shutdown',token,{})
   proc.wait(timeout=4)
  finally:
   if proc.poll() is None:proc.terminate();proc.wait(timeout=3)
