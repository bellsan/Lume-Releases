from pathlib import Path
import sys,time
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'app'))
from fn_hid import FnLearner,vendor_collections,FnHidMonitor
from bitmap_led import decode_bits,probe

def test_only_logitech_pro_vendor_collections():
    base={'vendor_id':0x046d,'product_id':0xc339,'product_string':'PRO Gaming Keyboard','path':b'dummy','usage_page':0xff00}
    assert vendor_collections([base,{**base,'usage_page':1},{**base,'product_string':'PRO Wireless Mouse'},{**base,'vendor_id':0x1234}])==[base]

def test_fn_learning_repeated_press_and_explicit_enable():
    l=FnLearner();l.begin(0);l.feed(b'idle',.2);l.tick(1.6)
    for t in (2,7,12):
        assert l.arm(t)
        assert not l.feed(b'idle',t+.1)
        assert not l.feed(b'press',t+.2)
        assert not l.feed(b'release',t+.4)
        l.tick(t+4.1)
    assert l.phase=='verify' and l.signature==b'press'
    assert not l.feed(b'press',17) and l.matches==1
    monitor=FnHidMonitor(lambda code:None);monitor.active=True;monitor.learner=l
    assert monitor.enable() and l.phase=='learned'
    assert l.feed(b'press',18)
    assert not l.feed(b'press',18.02)
    assert not l.feed(b'other',19)

def test_fn_ambiguous_or_no_report_does_not_enable():
    l=FnLearner();l.begin(0);l.tick(2);assert l.arm(2);l.tick(6.1);assert l.phase=='ready' and not l.samples
    for i,t in enumerate((7,12,17)):
        assert l.arm(t);l.feed(bytes([i]),t+.1);l.tick(t+4.1)
    assert l.phase=='failed' and l.signature is None

def test_bitmap_decode_and_two_color_proof():
    for i in range(126):
        assert decode_bits([(i>>j)&1 for j in range(7)])==i
    for bits in ([1]*7,[None]*7,[True]*7,[0]*6):assert decode_bits(bits) is None
    assert probe('cell',125)[-4:]==bytes([160,160,0,255])
    assert probe('cell_magenta',125)[-4:]==bytes([160,0,160,255])
