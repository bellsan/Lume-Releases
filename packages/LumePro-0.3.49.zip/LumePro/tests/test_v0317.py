import time
from engine import AnimationEngine,crossfade_frame,render,validate
from audio import AudioMonitor,blank
from keyhook import KeyboardWatcher
from fn_hid import FnLearner
from test_v0316_studio import scene

def test_transition_endpoints_and_midpoint():
 assert crossfade_frame({'A':'#ff0000'},{'A':'#0000ff'},0)=={'A':'#ff0000'}
 assert crossfade_frame({'A':'#ff0000'},{'A':'#0000ff'},.5)=={'A':'#800080'}
 assert crossfade_frame({'A':'#ff0000'},{'A':'#0000ff'},1)=={'A':'#0000ff'}

def test_worker_transition_has_intermediate_frames():
 class Fake:
  device=object()
  def __init__(self):self.frames=[]
  def queue_frame(self,f):self.frames.append(f)
  def clear_pending(self):pass
 b=Fake();k=KeyboardWatcher();e=AnimationEngine(b,k,AudioMonitor())
 def config(col,**kw):return {'keys':[{'code':'KeyA','x':1,'y':1}], 'layers':[{'type':'static','color':col,'brightness':100}],**kw}
 try:
  e.configure(config('#ff0000'));e.enable(True);time.sleep(.10);assert b.frames[-1]['KeyA']=='#ff0000'
  e.configure(config('#0000ff',transition={'id':'t1','ms':250}));time.sleep(.14)
  mid=b.frames[-1]['KeyA'];assert int(mid[1:3],16)>0 and int(mid[5:7],16)>0
  time.sleep(.50);assert b.frames[-1]['KeyA']=='#0000ff' and e.transition is None
 finally:e.close()

def test_audio_controls_affect_real_frame_and_silence():
 a={**blank(),'spectrum':[.4]*48,'spectrum_slow':[.8]*48,'spectrum_peak':[.7]*48}
 base=render(scene(barGate=0),[],0,a)
 for kw in ({'barRange':30},{'barTilt':100},{'barResponse':'fast'},{'barResponse':'smooth'}):
  assert render(scene(barGate=0,**kw),[],0,a)!=base,kw
 assert render(scene(barPeak=True,barPeakColor='#ff0000'),[],0,a)!=render(scene(barPeak=True),[],0,a)
 assert set(render(scene(barTilt=100,barRange=78),[],0,blank()).values())=={'#000000'}

def test_hid_learning_skips_transient_noise_but_rejects_ambiguity():
 l=FnLearner();l.begin(0);l.tick(2)
 for i,t in enumerate((2,7,12)):
  assert l.arm(t);l.feed(bytes([i]),t+.1);l.feed(b'press',t+.2);l.feed(b'release',t+.3);l.tick(t+4.1)
 assert l.phase=='verify' and l.signature==b'press'
