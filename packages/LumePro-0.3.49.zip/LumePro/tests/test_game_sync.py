from game_mode import GameMode
from game_sync import GameSync
from ghub_state import GHubStateMonitor, DEVICE_LIST
from test_v0323_special_keys import FakeWS, until

def test_sync_real_monitor_path_baseline_duplicate_disconnect():
    ws=FakeWS();gate=GameMode();gate.configure(False,['KeyA']);sync=GameSync(gate,lambda:True)
    monitor=GHubStateMonitor(lambda _:None,connector=lambda:ws,on_change=sync.change,on_disconnect=sync.disconnect)
    ws.put(DEVICE_LIST,{'deviceInfos':[{'pid':0xc339,'id':'dev01'}]});sync.arm(True);monitor.start()
    try:
        until(lambda:len(ws.sent)==5)
        path='/keyboard/dev01/game_mode'
        ws.put(path,{'enabled':True});until(lambda:monitor.status()['states']['GameMode'] is True)
        assert not gate.status()['enabled']
        ws.put(path,{'enabled':False});until(lambda:monitor.status()['states']['GameMode'] is False)
        ws.put(path,{'enabled':True});until(lambda:gate.status()['enabled'])
        assert gate.mask({'KeyA':'#ffffff'})['KeyA']=='#000000'
        gate.disable();ws.put(path,{'enabled':True});until(lambda:monitor.status()['messages']['GameMode']==4)
        assert not gate.status()['enabled']
        ws.put('/keyboard/other/game_mode',{'enabled':False});ws.put(path,{'enabled':False});until(lambda:monitor.status()['states']['GameMode'] is False)
        ws.put(path,{'enabled':True});until(lambda:gate.status()['enabled'])
    finally:monitor.stop()
    assert not gate.status()['enabled'] and not sync.enabled

def test_sync_does_not_enable_without_opt_in_or_hook():
    gate=GameMode();sync=GameSync(gate,lambda:False);sync.change('GameMode',True);assert not gate.status()['enabled'];sync.arm(True);sync.change('GameMode',True);assert not sync.enabled and not gate.status()['enabled']

def test_manual_activation_is_not_owned_by_monitor():
    gate=GameMode();sync=GameSync(gate,lambda:True);sync.arm(True);gate.set_enabled(True);sync.manual();sync.disconnect();assert gate.status()['enabled']
