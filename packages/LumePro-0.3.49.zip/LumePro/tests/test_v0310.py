from fn_hid import vendor_collections,FnHidMonitor
import time

def test_c339_without_product_name():
 k=dict(vendor_id=0x046d,product_id=0xc339,product_string=None,path=b'normal',usage_page=1,usage=6)
 v=dict(k,path=b'v',usage_page=0xff00,usage=1)
 c=dict(k,path=b'c',usage_page=0x0c,usage=1)
 assert vendor_collections([k,v,c,v,dict(v,path=b'x',product_id=0xc231)])==[v,c]

def test_multi_collection_read_only():
 rows=[dict(vendor_id=0x046d,product_id=0xc339,path=bytes([i]),usage_page=0xff00,usage=i) for i in (1,2)]
 class Device:
  def open_path(self,path):self.path=path;self.count=0
  def set_nonblocking(self,x):assert x==1
  def read(self,size,timeout):
   assert timeout==0
   self.count+=1
   return [5] if self.count==1 else []
  def close(self):pass
 class Module:
  def enumerate(self,*args):return rows
  def device(self):return Device()
 m=FnHidMonitor(lambda _:None,loader=Module)
 assert len(m.list())==2
 assert m.start(-1)
 try:
  until=time.monotonic()+1
  while time.monotonic()<until and sum(x['reports'] for x in m.status()['collection_stats'])<2:time.sleep(.01)
  s=m.status();assert s['active'] and [x['reports'] for x in s['collection_stats']]==[1,1]
  assert 'path' not in str(s) and s['enumerated']
 finally:m.stop()
 assert not m.status()['active']
