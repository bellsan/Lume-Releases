from test_v033 import backend
from preferences import Preferences

def test_explicit_special_probe_and_persistence(tmp_path):
 b=backend()
 try:
  s=b.sdk
  for method,api,addr in [('hid64','hid',0x64),('scan56','scan',0x56),('hid31','hid',0x31)]:
   assert b.probe_special('Backslash',method,'#00b0ff')
   assert s.calls[-1][:2]==(api,addr)
   assert b.key_methods['Backslash']=='auto'
  assert not b.probe_special('LightButton','hid','#00b0ff')
  assert not b.probe_special('Fn','hid64','#00b0ff')
  assert not b.probe_special('Backslash','hid64','#ffffff')
  assert b.set_key_method('Backslash','hid64')
  assert b._set_key('Backslash',(10,20,30)) and s.calls[-1]==('hid',0x64,10,20,30)
  p=Preferences(tmp_path/'prefs.json');assert p.update({'bracket_method':'hid64'})['bracket_method']=='hid64'
  assert p.update({'fn_method':'hid64'})['fn_method']=='auto'
  assert b.set_layout('ansi') and not b.probe_special('Backslash','hid64','#00b0ff')
 finally:b.close()
