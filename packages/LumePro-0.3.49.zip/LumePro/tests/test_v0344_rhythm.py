import math
import time
import numpy as np
import pytest
from audio import AudioAnalyzer, AudioMonitor, blank
from engine import rhythm_pixel

@pytest.mark.parametrize('hz,kind',[(90,'kick'),(700,'mid'),(6000,'high')])
def test_timed_attacks_and_sustained_tone(hz,kind):
    a=AudioAnalyzer();seen={};n=1024;rate=48000
    for i in range(150):
        t=i*n/rate; amp=.24 if 20<=i<60 or 90<=i<94 else 0.
        d=a.process(amp*np.sin(2*np.pi*hz*(np.arange(n)+i*n)/rate),t)
        for event in d['rhythm']['events']:
            seen[event['id']]=(event['kind'], t-event['age'])
    actual=[t for k,t in seen.values() if k==kind]
    assert len(actual)==2, seen
    assert abs(actual[0]-20*n/rate)<=n/rate
    assert abs(actual[1]-90*n/rate)<=n/rate
    assert len(seen)==2, seen
    assert max(d['rhythm']['levels'])<.001

def test_beat_travels_by_elapsed_time_not_volume():
    def pixel(age,u,v):
        a=blank();a['rhythm']['events']=[{'kind':'kick','age':age,'strength':1.}]
        return rhythm_pixel('beat',a,u,v,1.,.11,1.67,(0,0,255),(255,255,255))[0]
    assert pixel(0,.5,.5)>pixel(0,.75,.5)
    assert pixel(.26,.75,.5)>pixel(.26,.5,.5)
    assert pixel(.99,.5,.5)<.01

def test_status_ages_event_without_new_packet():
    m=AudioMonitor();m.enabled=True;m.last_packet=time.monotonic()-.12
    m.data=blank();m.data['rhythm']['events']=[{'kind':'kick','id':1,'age':.01,'strength':1.}]
    assert m.status()['rhythm']['events'][0]['age']>=.12
    assert m.data['rhythm']['events'][0]['age']==.01
    m.stop();assert not m.status()['rhythm']['events']
