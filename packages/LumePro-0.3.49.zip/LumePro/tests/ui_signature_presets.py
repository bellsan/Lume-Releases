"""Browser/Python parity on real keyboard geometry; gallery and editor integration."""
import asyncio,os,sys
from pathlib import Path
from playwright.async_api import async_playwright
from ui_preset_menu import setup
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'app'))
from engine import render,validate

async def main():
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path=os.environ.get('CHROMIUM_PATH','/usr/bin/chromium'),args=['--no-sandbox'])
  page,errors=await setup(b,{f:(ROOT/'app'/f).read_text() for f in ('index.html','style.css','app.js')})
  names=['GLACIER','VELVET','NEBULA','MONOCHROME','DUSK','ABYSS','SOLARIS','SAKURA','AURORA','GHOST']
  assert await page.evaluate('allProfiles.filter(p=>p.builtin).map(p=>p.name)')==names
  assert await page.evaluate('allProfiles.filter(p=>!p.builtin).map(p=>p.name)')==['Test 01','Test 02']
  await page.locator('[data-view=profiles]').click()
  for name in names:
   card=page.locator('.profile-card').filter(has=page.locator('strong',has_text=name))
   await card.locator('.apply-profile').click()
   assert await page.locator('#view-profiles').is_visible()
   assert await card.locator('.apply-profile').inner_text()=='適用中'
   data=await page.evaluate('''()=>{let old=pulseEvents;const out=[];try{const k=keyboardKeys.find(k=>k.code==='KeyG');const scene=scenePayload();for(const age of [null,0,.15,.5,1.1,2.8]){pulseEvents=age===null?[]:[{x:k.x,y:k.y,start:10-age}];out.push({p:pulseEvents.map(p=>[p.x,p.y,p.start]),frame:paintFrame(10,false)})}return {scene,out}}finally{pulseEvents=old}}''')
   scene=validate(data['scene']);frames=[]
   for q in data['out']:
    py=render(scene,q['p'],10);js=q['frame']; assert py.keys()==js.keys()
    assert max(abs(int(py[k][i:i+2],16)-int(js[k][i:i+2],16)) for k in py for i in (1,3,5))<=1,name
    frames.append(py)
   assert frames[0]!=frames[1] and frames[0]==frames[-1],name
   print(name,'6 frames parity, press/decay, apply OK',flush=True)
  await page.locator('#profileFilter').select_option('builtin')
  await page.wait_for_timeout(3300)
  await page.screenshot(path='/mnt/data/LumePro_v0.3.43_presets.png')
  await page.locator('.profile-card').filter(has=page.locator('strong',has_text='GLACIER')).locator('.preset-edit-direct').click()
  assert await page.locator('#view-lighting').is_visible()
  await page.locator('[data-inspector-tab=motion]').click()
  assert await page.locator('#signatureStyle').is_visible()
  await page.locator('#signatureStyle').select_option('GHOST')
  assert await page.evaluate("currentLayer().signatureStyle==='GHOST'")
  await page.evaluate("state.selectedLayer=2;refreshAll()")
  await page.locator('[data-inspector-tab=motion]').click()
  assert await page.locator('#secondaryColor').is_visible()
  await page.locator('[data-inspector-tab=basic]').click()
  assert await page.locator('#gradientStops input').count()==4
  assert await page.evaluate("currentLayer().type==='signature_flow'")
  assert not errors,errors
  print('10 builtins, user presets retained, editor and theme selector OK',flush=True)
  await b.close()
if __name__=='__main__':asyncio.run(main())
