from pathlib import Path
import sys
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'app'))
import native_ui

def test_native_spawn_does_not_open_edge():
    with patch('native_ui.subprocess.Popen') as spawn:
        native_ui.spawn(12345)
        assert spawn.call_args.args[0]==[sys.executable,'--native-ui','--port','12345']
    src=(ROOT/'app/server.py').read_text()
    assert 'msedge.exe' not in src and 'from native_ui import spawn' in src

def test_quit_and_context_menu_are_application_specific():
    src=(ROOT/'app/app.js').read_text()
    assert 'window.close()' not in src
    assert "document.addEventListener('contextmenu',e=>e.preventDefault())" in src
    assert "row.addEventListener('contextmenu'" in src
    assert "await savePreferences({editor:editorSnapshot(),live:isLive,hook:isHook});const result=await post('/api/shutdown'" in src

def test_update_reopens_only_visible_native_ui():
    from frozen_update import SCRIPT
    assert "if (-not $c.show_ui) { $launchArgs += '--no-browser' }" in SCRIPT
    assert native_ui.marker_path(ROOT,12345).name=='native-ui-12345.json'


def test_native_window_never_reauthenticates_to_replacement_server():
    src=(ROOT/'app/native_ui.py').read_text()
    assert "api(port,'/api/native_ready',token=token)" in src
    assert 'exc.code in (401,403)' in src
    assert src.count("token=api(port,'/api/token')['token']")==1
    assert "api(port,'/api/editor_closed',{},token)" in src


def test_native_close_only_after_original_server_stops():
    import urllib.error
    with patch('native_ui.api',return_value={'ready':True,'shutdown':False}):
        assert not native_ui.close_allowed(12345,'original')
    with patch('native_ui.api',return_value={'ready':True,'shutdown':True}) as api:
        assert native_ui.close_allowed(12345,'original')
        api.assert_called_once_with(12345,'/api/native_ready',token='original')
    with patch('native_ui.api',side_effect=ConnectionRefusedError):
        assert native_ui.close_allowed(12345,'original')
    with patch('native_ui.api',side_effect=urllib.error.HTTPError('http://127.0.0.1',403,'forbidden',{},None)):
        assert native_ui.close_allowed(12345,'original')
    with patch('native_ui.api',side_effect=urllib.error.HTTPError('http://127.0.0.1',500,'error',{},None)):
        assert not native_ui.close_allowed(12345,'original')


def test_shared_icon_and_rounded_corners():
    from PIL import Image
    with Image.open(ROOT/'app/lume-app-icon.png') as im:
        assert im.size==(512,512) and im.mode=='RGBA'
        assert im.getpixel((0,0))[3]==0 and im.getpixel((256,0))[3]==255
    with Image.open(ROOT/'app/lume-app-icon.ico') as im:
        assert im.ico.sizes()=={(s,s) for s in (16,24,32,48,64,128,256)}
    assert 'class="lume-brand" src="/lume-app-icon.png"' in (ROOT/'app/index.html').read_text()
