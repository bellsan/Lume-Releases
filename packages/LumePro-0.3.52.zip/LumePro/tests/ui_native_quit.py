"""Verify the actual settings button's native bridge and failed-save behavior."""
import asyncio,os
from pathlib import Path
from playwright.async_api import async_playwright
from ui_preset_menu import MOCK
ROOT=Path(__file__).resolve().parents[1]
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path=os.environ.get('CHROMIUM_PATH','/usr/bin/chromium'),args=['--no-sandbox'])
  page=await browser.new_page(viewport={'width':1260,'height':800});errors=[]
  page.on('pageerror',lambda e:errors.append(str(e)))
  # Local Chromium sandbox blocks all URL navigations; use an in-memory document.
  # Inject the desktop query in the test environment and inline the exact logo asset.
  import base64
  html=(ROOT/'app/index.html').read_text().replace('<link rel="stylesheet" href="/style.css">','').replace('<script src="/app.js" defer></script>','')
  html=html.replace('src="/lume-app-icon.png"','src="data:image/png;base64,'+base64.b64encode((ROOT/'app/lume-app-icon.png').read_bytes()).decode()+'"')
  await page.set_content(html)
  await page.add_style_tag(content=(ROOT/'app/style.css').read_text())
  await page.evaluate(MOCK)
  await page.evaluate("()=>{window.URLSearchParams=class extends URLSearchParams {constructor(s){super(s===location.search?'desktop=1':s)}}}")
  await page.add_script_tag(content=(ROOT/'app/app.js').read_text())
  await page.wait_for_function('!initializing && allProfiles.length===12')
  await page.evaluate('''window.quitOrder=[];window.close=()=>quitOrder.push('browser-close');window.pywebview={api:{close_after_shutdown:async()=>{quitOrder.push('native-close');return true}}};window.failSave=true;window.post=async(p,b)=>{if(p==='/api/preferences'){quitOrder.push('save');if(failSave)throw Error('test save error')}else if(p==='/api/shutdown')quitOrder.push('shutdown');return {ok:true}}''')
  await page.locator('[data-view=settings]').click();await page.locator('#quitBtn').click()
  await page.wait_for_function('quitOrder.length===1 && !document.querySelector("#quitBtn").disabled')
  assert await page.evaluate('JSON.stringify(quitOrder)==="[\\"save\\"]"')
  await page.evaluate('quitOrder=[];failSave=false');await page.locator('#quitBtn').click()
  await page.wait_for_function('quitOrder.includes("native-close")')
  assert await page.evaluate('JSON.stringify(quitOrder)==="[\\"save\\",\\"shutdown\\",\\"native-close\\"]"')
  assert await page.locator('.lume-brand').evaluate('el=>el.complete && el.naturalWidth===512')
  assert not errors,errors
  await browser.close();print('PASS native quit button: save failure keeps app open; save -> shutdown -> native close; new logo loaded')
if __name__=='__main__':asyncio.run(main())
