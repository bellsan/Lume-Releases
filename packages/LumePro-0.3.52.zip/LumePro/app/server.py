"""Lume Pro: a lightweight localhost desktop UI + optional OpenRGB bridge."""
from __future__ import annotations
import argparse
import json
import math
import os
import pathlib
import secrets
import socket
import subprocess
import sys
import threading
import time
import webbrowser
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse

from backend import BackendRouter
from keyhook import KeyboardWatcher
from audio import AudioMonitor,list_outputs
from engine import AnimationEngine,validate,CODE,HEX,AUDIO
from preferences import clean_editor
from device_info import logitech_hid_ids
from fn_hid import FnHidMonitor
from ghub_state import GHubStateMonitor
from game_sync import GameSync
from preferences import Preferences,choose_device
from updater import Updater
import desktop

ROOT=(pathlib.Path(sys._MEIPASS)/'app' if getattr(sys,'frozen',False) else pathlib.Path(__file__).resolve().parent)
DATA=pathlib.Path(os.environ.get('LOCALAPPDATA',str(pathlib.Path.home()))) / 'LumePro'
DATA.mkdir(parents=True,exist_ok=True)
PRESETS=DATA/'presets.json'
preset_lock=threading.RLock()
def load_presets():
 with preset_lock:
  try:val=json.loads(PRESETS.read_text('utf-8'))
  except (OSError,ValueError):return []
  if not isinstance(val,list):return []
  result=[]
  for p in val[:40]:
   if not isinstance(p,dict) or not isinstance(p.get('name'),str) or not 1<=len(p['name'])<=60:continue
   try:result.append({'name':p['name'],'state':clean_editor(p.get('state'),strict=True)})
   except (ValueError,TypeError):continue
  return result

def save_presets(val):
 with preset_lock:
  # Preserve the original legacy file before normalization or deletion.
  backup=PRESETS.with_name('presets.pre-0.3.46.json')
  if PRESETS.is_file() and not backup.exists():
   with backup.open('xb') as dst:dst.write(PRESETS.read_bytes())
  tmp=PRESETS.with_suffix('.tmp');tmp.write_text(json.dumps(val,ensure_ascii=False,indent=2),'utf-8');os.replace(tmp,PRESETS)
prefs=Preferences(DATA/'preferences.json')
connection_lock=threading.RLock()
SECRET=secrets.token_urlsafe(22)
UPDATE_HEALTH=os.environ.pop('LUMEPRO_UPDATE_HEALTH','')
if len(UPDATE_HEALTH)!=32 or any(c not in '0123456789abcdef' for c in UPDATE_HEALTH):UPDATE_HEALTH=''
backend=BackendRouter()
keys=KeyboardWatcher()
_saved_game=prefs.load().get('game_mode')
if _saved_game:keys.game.configure(False,_saved_game['blocked'],_saved_game['led'],_saved_game['color'],_saved_game['dim'])
game_sync=GameSync(keys.game,lambda:keys.enabled)
ghub_state=GHubStateMonitor(keys.push,on_change=game_sync.change,on_disconnect=game_sync.disconnect)
def sync_status():
 return {**ghub_state.status(),'sync_enabled':game_sync.enabled}
def emit_hid(code):
 # A learned Fn can coexist with the G HUB state observer. For right-hand
 # buttons use the state route if it has a valid baseline; avoid double pulses.
 if code in ('GameMode','LightButton'):
  status=ghub_state.status()
  if status['connected'] and status['states'].get(code) is not None:return
 keys.push(code)
fn_hid=FnHidMonitor(emit_hid)
audio=AudioMonitor()
engine=AnimationEngine(backend,keys,audio)
updater=Updater(ROOT.parent,DATA)

def auto_connect(p):
 if not p['auto']:return False
 with connection_lock:
  if desktop.supported() and p['backend']=='logitech' and desktop.presence() is not True:return False
  if backend.kind==p['backend'] and backend.device is not None:return True
  engine.enable(False)
  fn_hid.stop();ghub_state.stop()
  ok=backend.connect(p['backend'])
  if ok:
   idx=choose_device(backend.list_devices(),p)
   ok=idx is not None and backend.select(idx)
   if ok:
    backend.set_layout((p['editor'] or {}).get('layout','jis'))
    if p['backend']=='logitech':
     backend.set_method(p['method']);backend.set_key_method('Backslash',p['bracket_method']);backend.set_key_method('Fn',p['fn_method']);backend.set_key_method('IntlYen',p['yen_method'])
    if p['backend']=='logitech' and p['bitmap_layout']==backend.layout:
     backend.configure_bitmap(p['bitmap_mapping'],False)
     if p['bitmap_enabled'] and not backend.configure_bitmap(p['bitmap_mapping'],True):prefs.update({'bitmap_enabled':False})
    d=next((d for d in backend.list_devices() if d['id']==idx),None)
    if d:prefs.update({'device_name':d['name'],'device_leds':d['leds']})
    if desktop.supported():
     try:restore_saved(p)
     except (ValueError,OSError):pass
  return ok

resident_tray=None
native_page_ready=threading.Event()
shutdown_requested=threading.Event()

def desktop_status():
 p=prefs.load()
 return {'supported':desktop.supported(),'resident':bool(resident_tray and resident_tray.ready),**{k:p[k] for k in ('tray','startup','recovery')}}

def restore_saved(p):
 scene=desktop.restored_scene(p,ROOT)
 if not scene:return
 with engine.lock:
  backend.set_layout(scene['layout']);engine.configure(scene)
 if p['hook'] and not keys.enabled:keys.start()
 if p['live']:engine.enable(True)
 if p['audio_enabled'] and any(l['enabled'] and l['type'] in AUDIO for l in engine.scene[1]) and not audio.enabled:
  audio.start(p['audio_endpoint'])

def desktop_monitor(stop):
 last_attempt=0.;missing=0;next_update=0.
 while not stop.wait(2):
  try:
   p=prefs.load()
   now=time.monotonic()
   if now>=next_update:
    updater.check(False);next_update=now+900
   if not p['auto'] or not p['editor']:continue
   if p['backend']=='logitech':
    present=desktop.presence()
    if present is False:
     missing+=1
     if missing>=2 and backend.kind=='logitech' and backend.device is not None:
      with connection_lock:
       engine.enable(False);fn_hid.stop();ghub_state.stop();keys.stop();audio.stop();backend.connect('logitech')
     continue
    if present is not True:continue
    missing=0
   # Don't override a user's manual connection, or guess between multiple keyboards.
   if backend.device is None and now-last_attempt>=12 and (p['live'] or p['device_name']):
    last_attempt=now
    with connection_lock:
     if backend.device is None and not stop.is_set():auto_connect(p)
  except Exception:
   # The monitor is auxiliary; a failed SDK or device enumeration must not kill the UI.
   continue

def bounded_json(raw):
 def reject(_):raise ValueError('non-finite number')
 obj=json.loads(raw,parse_constant=reject)
 def check(v,depth=0):
  if depth>10:raise ValueError('too deeply nested')
  if isinstance(v,dict):
   if len(v)>200:raise ValueError('too many fields')
   for k,x in v.items():
    if len(k)>100 or k in ('__proto__','constructor','prototype'):raise ValueError('invalid field')
    check(x,depth+1)
  elif isinstance(v,list):
   if len(v)>256:raise ValueError('too many items')
   for x in v:check(x,depth+1)
  elif isinstance(v,float) and not math.isfinite(v):raise ValueError('non-finite number')
  elif isinstance(v,str) and len(v)>8192:raise ValueError('string too long')
 check(obj)
 if not isinstance(obj,dict):raise ValueError('invalid input')
 return obj

class LocalServer(ThreadingHTTPServer):
 # Avoid unbounded threads from slow or malformed local HTTP clients.
 request_queue_size=32
 daemon_threads=True
 def __init__(self,*a,**kw):
  self.slots=threading.BoundedSemaphore(32);super().__init__(*a,**kw)
 def get_request(self):
  sock,addr=super().get_request();sock.settimeout(5);return sock,addr
 def process_request(self,request,address):
  if not self.slots.acquire(blocking=False):self.shutdown_request(request);return
  try:super().process_request(request,address)
  except BaseException:self.slots.release();raise
 def process_request_thread(self,request,address):
  try:super().process_request_thread(request,address)
  finally:self.slots.release()

class Handler(BaseHTTPRequestHandler):
 def end_headers(self):
  self.send_header('X-Frame-Options','DENY')
  self.send_header('Referrer-Policy','no-referrer')
  self.send_header('Cross-Origin-Resource-Policy','same-origin')
  super().end_headers()
 def valid_origin(self):
  host=f'127.0.0.1:{self.server.server_address[1]}'
  if self.headers.get_all('Host')!=[host]:return False
  origin=self.headers.get_all('Origin') or []
  if origin and origin!=['http://'+host]:return False
  site=self.headers.get('Sec-Fetch-Site')
  return site in (None,'none','same-origin')
 def authorized(self):
  tokens=self.headers.get_all('X-Lume-Token') or []
  return len(tokens)==1 and secrets.compare_digest(tokens[0].encode('utf-8'),SECRET.encode('ascii'))
 def do_GET(self):
  if not self.valid_origin():return self.send_json({'error':'invalid origin'},403)
  path=urlparse(self.path).path
  if path=='/api/token':
   if self.headers.get('X-Lume-Bootstrap')!='1':return self.send_json({'error':'unauthorized'},403)
   return self.send_json({'token':SECRET})
  if path.startswith('/api/') and not self.authorized():
   # Compatibility with pre-0.3.46 clients waiting for the new server after updating.
   # Never disclose hardware, input, preset, audio or error text without a token.
   if path=='/api/update/status':
    d=updater.status();return self.send_json({'current':d['current'],'phase':d['phase'],'last_install_error':bool(d['last_install_error']),**({'update_health':UPDATE_HEALTH} if UPDATE_HEALTH else {})})
   return self.send_json({'error':'unauthorized'},403)
  try:self.get_api(path)
  except (ValueError,TypeError,KeyError,IndexError,OverflowError,RecursionError):return self.send_json({'error':'invalid request'},400)
 def do_POST(self):
  if not self.valid_origin() or not self.authorized():return self.send_json({'error':'unauthorized'},403)
  try:self.post_api()
  except (ValueError,TypeError,KeyError,IndexError,AttributeError,OverflowError,RecursionError):return self.send_json({'error':'invalid request'},400)

 def log_message(self,fmt,*args):
  if os.getenv('LUMEPRO_DEBUG'):super().log_message(fmt,*args)

 def send_json(self,obj,status=200):
  data=json.dumps(obj,ensure_ascii=False).encode('utf-8')
  self.send_response(status);self.send_header('Content-Type','application/json; charset=utf-8')
  self.send_header('Cache-Control','no-store');self.send_header('Content-Length',str(len(data)))
  self.send_header('X-Content-Type-Options','nosniff');self.end_headers();self.wfile.write(data)

 def get_api(self,path):
  if path=='/api/update/status':return self.send_json(updater.status())
  if path=='/api/native_ready':return self.send_json({'ready':native_page_ready.is_set(),'shutdown':shutdown_requested.is_set()})
  if path=='/api/ghub_state_status':return self.send_json(sync_status())
  if path=='/api/game_sync':return self.send_json({'status':sync_status(),'game_mode':keys.game.status()})
  if path=='/api/fn_hid_status':return self.send_json(fn_hid.status())
  if path=='/api/game_mode':return self.send_json(keys.game.status())
  if path=='/api/preferences':return self.send_json({'preferences':prefs.load()})
  if path=='/api/status':return self.send_json({'hardware':backend.status(), 'engine':engine.status(), 'keyhook':keys.diagnostic(),'game_mode':keys.game.status(),'ghub_state':sync_status(),'desktop':desktop_status(),'audio':{'enabled':audio.enabled}})
  if path=='/api/keys':
   try:seq=max(0,int(self.path.split('since=')[-1])) if 'since=' in self.path else 0
   except Exception:seq=0
   return self.send_json(keys.since(seq))
  if path=='/api/diagnostic':return self.send_json({'hardware':backend.status(),'engine':engine.status(),'keyhook':keys.diagnostic(),'logitech_hid_ids':logitech_hid_ids(),'fn_hid':fn_hid.status(),'ghub_state':ghub_state.status(),'audio':{k:v for k,v in audio.status().items() if k not in ('wave','trace','envelope','bands','stereo','spectrum','spectrum_slow','spectrum_peak')},'diagnostic_version':3})
  if path=='/api/audio':return self.send_json(audio.status())
  if path=='/api/audio_devices':return self.send_json(list_outputs())
  if path=='/api/presets':
   return self.send_json({'presets':load_presets()})
  assets={'/':'index.html','/index.html':'index.html','/style.css':'style.css','/app.js':'app.js','/favicon.ico':'lume-app-icon.ico','/lume-app-icon.png':'lume-app-icon.png'}
  if path not in assets:return self.send_error(404)
  file=ROOT/assets[path]
  data=file.read_bytes()
  typ={'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'application/javascript; charset=utf-8','.ico':'image/x-icon','.png':'image/png'}[file.suffix]
  self.send_response(200);self.send_header('Content-Type',typ)
  self.send_header('Content-Security-Policy',"default-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; base-uri 'none'; form-action 'none'; frame-ancestors 'none'; object-src 'none'")
  self.send_header('X-Content-Type-Options','nosniff');self.send_header('Cache-Control','no-store')
  self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data)

 def post_api(self):
  if self.headers.get('Content-Type','').split(';')[0]!='application/json':return self.send_json({'error':'json only'},415)
  try:
   if self.headers.get('Transfer-Encoding') or len(self.headers.get_all('Content-Length') or [])!=1:raise ValueError('invalid length')
   n=int(self.headers.get('Content-Length','0'))
   if n<=0 or n>128_000:raise ValueError('サイズ超過')
   raw=self.rfile.read(n)
   if len(raw)!=n:raise ValueError('incomplete input')
   obj=bounded_json(raw)
  except (ValueError,TypeError,RecursionError,OverflowError,TimeoutError):return self.send_json({'error':'invalid payload'},400)
  path=urlparse(self.path).path
  if path.startswith('/api/update/'):
   try:
    if path=='/api/update/check':return self.send_json(updater.check(obj.get('manual') is True))
    if path=='/api/update/ack':return self.send_json(updater.acknowledge(obj.get('version')))
    if path=='/api/update/configure':return self.send_json(updater.configure(obj.get('auto') is True))
    if path=='/api/update/download':return self.send_json(updater.download())
    if path=='/api/update/apply':
     updater.request_apply()
     if updater.frozen:
      # Launch the replacement before closing HTTP, so an immediate launch failure is visible.
      from frozen_update import launch_update
      try:launch_update(updater,self.server.server_address[1])
      except Exception as e:
       updater.pending=False;updater.phase='ready';return self.send_json({'ok':False,'error':str(e)[:300]},400)
     shutdown_requested.set()
     try:self.send_json({'ok':True})
     finally:threading.Thread(target=self.server.shutdown,daemon=True).start()
     return
   except (ValueError,OSError) as e:return self.send_json({'error':str(e)},400)
  if path=='/api/native_ready':
   native_page_ready.set();return self.send_json({'ok':True})
  if path=='/api/editor_closed':
   native_page_ready.clear()
   # Never leave an input-blocking game mode active after closing the editor.
   with connection_lock:
    game_sync.arm(False);ghub_state.stop();keys.game.disable()
    if not desktop_status()['resident']:
     fn_hid.stop();keys.stop();engine.enable(False);audio.stop()
   return self.send_json({'ok':True})
  if path=='/api/desktop':
   if not desktop.supported():return self.send_json({'error':'Windows EXE版専用です'},400)
   if not obj or any(k not in ('startup','tray','recovery') or type(v) is not bool for k,v in obj.items()):raise ValueError('invalid desktop settings')
   try:
    if 'startup' in obj:desktop.startup(obj['startup'])
    p=prefs.update(obj)
    return self.send_json({'ok':True,'preferences':p,'resident':desktop_status()['resident']})
   except OSError:return self.send_json({'error':'Windows設定を保存できませんでした'},400)
  if path=='/api/preferences':
   # Startup registration is handled only by the dedicated endpoint.
   obj.pop('startup',None)
   try:return self.send_json({'ok':True,'preferences':prefs.update(obj)})
   except (OSError,ValueError,TypeError) as e:return self.send_json({'ok':False,'error':str(e)},400)
  if path=='/api/auto_connect':
   p=prefs.load();ok=auto_connect(p)
   return self.send_json({'ok':ok,'hardware':backend.status(),'error':None if ok else '自動接続できませんでした。接続先を確認してください。'})
  if path=='/api/connect':
   with connection_lock:
    engine.enable(False)
    fn_hid.stop();ghub_state.stop()
    ok=backend.connect(obj.get('backend','openrgb'));return self.send_json({'ok':ok,'hardware':backend.status()})
  if path=='/api/select':
   with connection_lock:
    engine.enable(False)
    ok=backend.select(obj.get('index'))
    if ok:
     p=prefs.load();d=next((d for d in backend.list_devices() if d['id']==obj.get('index')),None)
     backend.set_layout((p['editor'] or {}).get('layout','jis'))
     if backend.kind=='logitech':
      backend.set_method(p['method']);backend.set_key_method('Backslash',p['bracket_method']);backend.set_key_method('Fn',p['fn_method']);backend.set_key_method('IntlYen',p['yen_method'])
     if backend.kind=='logitech' and p['bitmap_layout']==backend.layout:
      backend.configure_bitmap(p['bitmap_mapping'],False)
      if p['bitmap_enabled'] and not backend.configure_bitmap(p['bitmap_mapping'],True):prefs.update({'bitmap_enabled':False})
     if d:prefs.update({'backend':backend.kind,'device_name':d['name'],'device_leds':d['leds']})
    return self.send_json({'ok':ok,'hardware':backend.status()})
  if path=='/api/game_sync':
   enabled=obj.get('enabled')
   if type(enabled) is not bool:return self.send_json({'error':'invalid enabled'},400)
   with connection_lock:
    if enabled:
     hs=fn_hid.status()
     if hs['active'] and hs['phase']!='learned':return self.send_json({'error':'HID学習を停止してください'},400)
     if not keys.enabled:return self.send_json({'error':'入力検出を開始してください'},400)
     game_sync.arm(True)
     if not ghub_state.start():game_sync.disconnect();return self.send_json({'error':'G HUB監視を開始できません'},400)
    else:game_sync.arm(False);ghub_state.stop()
   return self.send_json({'ok':True,'status':sync_status(),'game_mode':keys.game.status()})
  if path=='/api/ghub_state':
   with connection_lock:
    if obj.get('action')=='start':
     hs=fn_hid.status()
     if hs['active'] and hs['phase']!='learned':return self.send_json({'ok':False,'error':'HID学習を完了または停止してから開始してください','status':ghub_state.status()})
     ok=keys.enabled and ghub_state.start()
    elif obj.get('action')=='stop':ghub_state.stop();ok=True
    else:return self.send_json({'error':'invalid action'},400)
    return self.send_json({'ok':ok,'status':ghub_state.status()})
  if path=='/api/fn_hid':
   action=obj.get('action')
   if action=='list':return self.send_json({'ok':True,'devices':fn_hid.list(),'status':fn_hid.status()})
   if action=='stop':fn_hid.stop();ok=True
   elif action=='start':
    ghub_state.stop()
    engine.enable(False)
    backend.clear_pending()
    # Wait for any already-dispatched SDK write before starting the HID baseline.
    if backend.kind=='logitech':
     with backend.impl.lock:pass
    ok=keys.enabled and fn_hid.start(obj.get('index'),obj.get('target','Fn'))
   elif action=='learn':
    ghub_state.stop()
    engine.enable(False)
    if backend.kind=='logitech':
     with backend.impl.lock:pass
    ok=keys.enabled and fn_hid.learn(obj.get('target'))
   elif action=='sample':ok=keys.enabled and fn_hid.arm()
   elif action=='enable':ok=keys.enabled and fn_hid.enable()
   else:return self.send_json({'error':'invalid action'},400)
   return self.send_json({'ok':ok,'status':fn_hid.status()})
  if path=='/api/special_probe':
   with connection_lock:
    engine.enable(False)
    ok=backend.kind=='logitech' and backend.probe_special(obj.get('code'),obj.get('method'),obj.get('color'))
    return self.send_json({'ok':ok,'hardware':backend.status()})
  if path=='/api/coverage_test':
   with connection_lock:
    engine.enable(False)
    ok=backend.kind=='logitech' and backend.test_coverage(obj.get('color'))
    return self.send_json({'ok':ok,'hardware':backend.status()})
  if path=='/api/bitmap_test':
   with connection_lock:
    engine.enable(False)
    ok=backend.kind=='logitech' and backend.test_bitmap(obj.get('pattern'),obj.get('index',0))
    return self.send_json({'ok':ok,'hardware':backend.status()})
  if path=='/api/bitmap_config':
   with connection_lock:
    engine.enable(False)
    mapping=obj.get('mapping');enabled=obj.get('enabled') is True
    if backend.kind!='logitech' or not isinstance(mapping,dict):return self.send_json({'ok':False,'error':'公式SDKに接続してください'},400)
    if enabled:
     # Full-frame SDK mode must cover all regular physical keys in the scene.
     scene=engine.scene
     required=set(scene[0])-{'Fn','BoardLogo','GameMode','LightButton'} if scene else set()
     if not required or not required.issubset(mapping):return self.send_json({'ok':False,'error':'通常キーの全対応付けが必要です。未割り当てのキーを消灯させないため、有効化を中止しました。'},400)
    ok=backend.configure_bitmap(mapping,enabled)
    if ok:prefs.update({'bitmap_layout':backend.layout,'bitmap_mapping':mapping,'bitmap_enabled':enabled})
    return self.send_json({'ok':ok,'hardware':backend.status()})
  if path=='/api/led_test':
   engine.enable(False)
   ok=backend.test_led(obj.get('index'),obj.get('color','#ffffff'));return self.send_json({'ok':ok,'hardware':backend.status()})
  if path=='/api/jis_test':
   engine.enable(False)
   ok=backend.kind=='logitech' and backend.test_jis();return self.send_json({'ok':ok,'hardware':backend.status()})
  if path=='/api/sdk_method':
   engine.enable(False)
   ok=backend.set_method(obj.get('method'))
   if ok:prefs.update({'method':obj['method']})
   return self.send_json({'ok':ok,'hardware':backend.status()})
  if path=='/api/key_method':
   engine.enable(False)
   ok=backend.set_key_method(obj.get('code'),obj.get('method'))
   if ok:prefs.update({({'Backslash':'bracket_method','Fn':'fn_method','IntlYen':'yen_method'}[obj['code']]):obj['method']})
   return self.send_json({'ok':ok,'hardware':backend.status()})
  if path=='/api/led_map':
   ok=backend.set_mapping(obj.get('index'),obj.get('code'));return self.send_json({'ok':ok,'hardware':backend.status()})
  if path=='/api/game_mode':
   try:
    enabled=obj.get('enabled') is True
    # Validate before installing the global hook. Never enable on startup.
    from game_mode import GameMode
    check=GameMode();check.configure(enabled,obj.get('blocked'),obj.get('led','off'),obj.get('color','#ff5555'),obj.get('dim',25))
    with connection_lock:
     if enabled and not keys.start():return self.send_json({'error':keys.error or '入力制御を開始できません'},400)
     with game_sync.lock:
      if enabled!=keys.game.status()['enabled']:game_sync.manual()
      keys.game.configure(enabled,obj['blocked'],obj.get('led','off'),obj.get('color','#ff5555'),obj.get('dim',25))
    try:prefs.update({'game_mode':{**keys.game.status(),'enabled':False}})
    except OSError:pass
    return self.send_json({'ok':True,'game_mode':keys.game.status()})
   except ValueError as e:return self.send_json({'error':str(e)},400)
  if path=='/api/scene':
   try:
    validate(obj)
    with engine.lock:
     backend.set_layout(obj.get('layout','jis'));engine.configure(obj)
    return self.send_json({'ok':True,'engine':engine.status()})
   except ValueError as e:return self.send_json({'ok':False,'error':str(e)},400)
  if path=='/api/live':
   try:engine.enable(obj.get('enabled') is True);return self.send_json({'ok':True,'engine':engine.status()})
   except ValueError as e:return self.send_json({'ok':False,'error':str(e)},400)
  if path=='/api/pulse':
   code=obj.get('code');return self.send_json({'ok':isinstance(code,str) and engine.pulse(code)})
  if path=='/api/frame':
   if engine.active:return self.send_json({'ok':False,'error':'サーバー描画が有効です'})
   if backend.device is None:return self.send_json({'ok':False,'error':'デバイス未選択'})
   colors=obj.get('colors')
   if not isinstance(colors,dict) or len(colors)>180 or any(not CODE.fullmatch(k) or not isinstance(v,str) or not HEX.fullmatch(v) for k,v in colors.items()):raise ValueError('invalid frame')
   backend.queue_frame(keys.game.mask(colors));return self.send_json({'ok':True})
  if path=='/api/audio_toggle':
   if type(obj.get('enabled')) is not bool:raise ValueError('invalid enabled')
   if obj['enabled']:ok=audio.start(obj.get('endpoint','default'))
   else:audio.stop();ok=True
   return self.send_json({'ok':ok,'audio':audio.status()})
  if path=='/api/audio_demo':
   audio.demo(obj.get('layer_id'));return self.send_json({'ok':True,'audio':audio.status()})
  if path=='/api/keyhook':
   if type(obj.get('enabled')) is not bool:raise ValueError('invalid enabled')
   if obj['enabled']:ok=keys.start()
   else:fn_hid.stop();ghub_state.stop();keys.stop();ok=True
   return self.send_json({'ok':ok,'enabled':keys.enabled,'error':keys.error})
  if path=='/api/save':
   if not isinstance(obj.get('preset'),dict):return self.send_json({'error':'invalid preset'},400)
   preset=obj['preset'];name=preset.get('name')
   if not isinstance(name,str) or not 1<=len(name)<=60:return self.send_json({'error':'名前は1～60文字'},400)
   preset={'name':name,'state':clean_editor(preset.get('state'),strict=True)}
   previous=obj.get('previous_name')
   if not isinstance(previous,str):previous=None
   with preset_lock:
    val=[p for p in load_presets() if p.get('name') not in (name,previous)]
    val.insert(0,preset);val=val[:40];save_presets(val)
   return self.send_json({'ok':True,'presets':val})
  if path=='/api/delete':
   name=obj.get('name')
   if not isinstance(name,str):raise ValueError('invalid name')
   with preset_lock:
    val=[p for p in load_presets() if p.get('name')!=name];save_presets(val)
   return self.send_json({'ok':True,'presets':val})
  if path=='/api/shutdown':
   shutdown_requested.set()
   try:self.send_json({'ok':True})
   finally:threading.Thread(target=self.server.shutdown,daemon=True).start()
   return
  return self.send_json({'error':'not found'},404)


def launch(url):
 if desktop.supported():
  from native_ui import spawn
  try:spawn(urlparse(url).port)
  except Exception as e:
   (DATA/'native-ui-error.txt').write_text(str(e)[:1000],encoding='utf-8')
  return
 # Source-only development mode retains the normal browser.
 webbrowser.open(url)


def main():
 parser=argparse.ArgumentParser()
 parser.add_argument('--no-browser',action='store_true')
 parser.add_argument('--port',type=int,default=0)
 parser.add_argument('--background',action='store_true')
 parser.add_argument('--worker',action='store_true',help=argparse.SUPPRESS)
 parser.add_argument('--self-test',action='store_true',help=argparse.SUPPRESS)
 args=parser.parse_args()
 if args.self_test:
  # CI checks imports and bundled static resources without contacting hardware.
  import numpy, soundcard, pyaudiowpatch, hid, websocket, openrgb, pystray, webview
  from PIL import Image
  for name in ('index.html','app.js','style.css','version.json','lume-app-icon.ico','keyboard_geometry.json'):
   if not (ROOT/name).is_file():raise RuntimeError('Missing '+name)
  return
 global resident_tray
 shutdown_requested.clear();native_page_ready.clear()
 instance=desktop.Instance(DATA) if desktop.supported() else None
 if instance and instance.duplicate:
  try:
   port=instance.existing_port()
   if port and not args.background and not args.no_browser:launch(f'http://127.0.0.1:{port}/')
  finally:instance.close()
  return
 try:server=LocalServer(('127.0.0.1',args.port),Handler)
 except BaseException:
  if instance:instance.close()
  raise
 port=server.server_address[1]
 url=f'http://127.0.0.1:{port}/'
 if instance:instance.announce(port)
 stop=threading.Event();monitor=None
 if desktop.supported():
  p=prefs.load()
  if p['tray']:
   resident_tray=desktop.Tray(ROOT,lambda:launch(url),lambda:threading.Thread(target=server.shutdown,daemon=True).start())
  # Normal launches still show the editor; background startup stays silent only if tray works.
  monitor=threading.Thread(target=desktop_monitor,args=(stop,),daemon=True);monitor.start()
  if args.background:
   def fallback():
    if not desktop_status()['resident']:launch(url)
   timer=threading.Timer(3,fallback);timer.daemon=True;timer.start()
 if sys.stdout is not None:print('Lume Pro:',url,flush=True)
 if not args.no_browser and not args.background:
  timer=threading.Timer(0.65,launch,args=[url]);timer.daemon=True;timer.start()
 normal=False
 try:
  server.serve_forever(poll_interval=0.1);normal=True
 except KeyboardInterrupt:normal=True
 finally:
  shutdown_requested.set();stop.set()
  if resident_tray:resident_tray.close()
  if monitor:monitor.join(timeout=3)
  engine.close();fn_hid.stop();ghub_state.stop();keys.stop();audio.stop();backend.close();server.server_close()
  if instance:instance.close()
  restart=updater.pending and normal
  if getattr(sys,'frozen',False):
   # The apply handler already launched the external helper. It waits for this process.
   if not updater.pending:updater.finish()
  else:
   updater.finish()
   if restart:
    kwargs={'cwd':str(ROOT.parent),'stdout':subprocess.DEVNULL,'stderr':subprocess.DEVNULL,'stdin':subprocess.DEVNULL}
    if sys.platform=='win32':kwargs['creationflags']=subprocess.DETACHED_PROCESS|subprocess.CREATE_NEW_PROCESS_GROUP
    # Keep the same local origin so the current UI can reconnect after restart.
    subprocess.Popen([sys.executable,'-u',str(ROOT/'server.py'),'--port',str(port),'--no-browser'],**kwargs)

if __name__=='__main__':main()
