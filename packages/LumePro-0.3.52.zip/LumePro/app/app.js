/* Lume Pro / Pure browser rendering engine. No telemetry and no external resources. */
'use strict';
// Suppress browser context menus without intercepting Lume's layer-specific handlers.
if(typeof document!=='undefined')document.addEventListener('contextmenu',e=>e.preventDefault());
if(typeof document!=='undefined')document.addEventListener('keydown',e=>{if(e.key==='F12'||e.key==='F5'||((e.ctrlKey||e.metaKey)&&['r','l','u','p'].includes(e.key.toLowerCase()))||((e.ctrlKey||e.metaKey)&&e.shiftKey&&['i','j','c'].includes(e.key.toLowerCase()))){e.preventDefault();e.stopPropagation()}},true);

const $=id=>document.getElementById(id);
// Locally bundled, fixed SVG markup; never interpolates imported/user strings.
const LUME_ICONS=Object.freeze({"lighting":"<svg class=\"lume-icon\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.65\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M12 2v3m0 14v3M2 12h3m14 0h3M4.9 4.9 7 7m10 10 2.1 2.1M4.9 19.1 7 17M17 7l2.1-2.1\"/><path d=\"M12 6.5 13.8 10l3.7 2-3.7 2L12 17.5 10.2 14l-3.7-2 3.7-2Z\"/></svg>","keyboard":"<svg class=\"lume-icon\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.65\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\" focusable=\"false\"><rect x=\"2\" y=\"5\" width=\"20\" height=\"14\" rx=\"2.5\"/><path d=\"M5.5 9h.8m3.1 0h.8m3.1 0h.8m3.1 0h.8M5.5 12h.8m3.1 0h.8m3.1 0h.8m3.1 0h.8M6 15.5h12\"/></svg>","profiles":"<svg class=\"lume-icon\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.65\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\" focusable=\"false\"><rect x=\"6\" y=\"3\" width=\"14\" height=\"17\" rx=\"2\"/><path d=\"M3 7v12a3 3 0 0 0 3 3h10M9 7h8m-8 4h8m-8 4h5\"/></svg>","settings":"<svg class=\"lume-icon\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.65\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\" focusable=\"false\"><path d=\"m10 2-.7 2.8-2 .9L4.8 4.2 2 7l1.5 2.5-.8 2L0 12v0l2.7.7.8 2L2 17.2 4.8 20l2.5-1.5 2 .9L10 22h4l.7-2.6 2-.9 2.5 1.5 2.8-2.8-1.5-2.5.8-2 2.7-.7v-0l-2.7-.7-.8-2L22 7l-2.8-2.8-2.5 1.5-2-.9L14 2Z\" transform=\"translate(1.2 1.2) scale(.9)\"/><circle cx=\"12\" cy=\"12\" r=\"3.1\"/></svg>","undo":"<svg class=\"lume-icon\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.65\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\" focusable=\"false\"><path d=\"m9 5-5 5 5 5M4 10h10a6 6 0 0 1 0 12\" transform=\"translate(0 -1)\"/></svg>","redo":"<svg class=\"lume-icon\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.65\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\" focusable=\"false\"><path d=\"m15 5 5 5-5 5m5-5H10a6 6 0 0 0 0 12\" transform=\"translate(0 -1)\"/></svg>","plus":"<svg class=\"lume-icon\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.65\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M12 5v14M5 12h14\"/></svg>","close":"<svg class=\"lume-icon\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.65\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\" focusable=\"false\"><path d=\"m6 6 12 12M18 6 6 18\"/></svg>","up":"<svg class=\"lume-icon\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.65\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\" focusable=\"false\"><path d=\"m6 11 6-6 6 6m-6-6v14\"/></svg>","down":"<svg class=\"lume-icon\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.65\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\" focusable=\"false\"><path d=\"m6 13 6 6 6-6m-6 6V5\"/></svg>","copy":"<svg class=\"lume-icon\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.65\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\" focusable=\"false\"><rect x=\"8\" y=\"8\" width=\"12\" height=\"13\" rx=\"2\"/><path d=\"M16 5V4a1 1 0 0 0-1-1H5a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h1\"/></svg>","trash":"<svg class=\"lume-icon\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.65\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13M10 10v6m4-6v6\"/></svg>","more":"<svg class=\"lume-icon\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.65\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\" focusable=\"false\"><circle cx=\"5\" cy=\"12\" r=\"1.6\" fill=\"currentColor\" stroke=\"none\"/><circle cx=\"12\" cy=\"12\" r=\"1.6\" fill=\"currentColor\" stroke=\"none\"/><circle cx=\"19\" cy=\"12\" r=\"1.6\" fill=\"currentColor\" stroke=\"none\"/></svg>","grip":"<svg class=\"lume-icon\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.65\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\" focusable=\"false\"><g fill=\"currentColor\" stroke=\"none\"><circle cx=\"9\" cy=\"5\" r=\"1.6\"/><circle cx=\"15\" cy=\"5\" r=\"1.6\"/><circle cx=\"9\" cy=\"12\" r=\"1.6\"/><circle cx=\"15\" cy=\"12\" r=\"1.6\"/><circle cx=\"9\" cy=\"19\" r=\"1.6\"/><circle cx=\"15\" cy=\"19\" r=\"1.6\"/></g></svg>","eye":"<svg class=\"lume-icon\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.65\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M2 12s3.6-6.5 10-6.5S22 12 22 12s-3.6 6.5-10 6.5S2 12 2 12Z\"/><circle cx=\"12\" cy=\"12\" r=\"2.7\"/></svg>","eyeOff":"<svg class=\"lume-icon\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.65\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\" focusable=\"false\"><path d=\"m3 3 18 18M10.5 5.6 12 5.5c6.4 0 10 6.5 10 6.5a16 16 0 0 1-3 3.5M6 7.2A17 17 0 0 0 2 12s3.6 6.5 10 6.5c1.3 0 2.5-.3 3.6-.8M9.5 10.4a2.8 2.8 0 0 0 4.1 4.1\"/></svg>","play":"<svg class=\"lume-icon\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.65\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\" focusable=\"false\"><path d=\"m8 5 12 7-12 7Z\" fill=\"currentColor\" stroke=\"none\"/></svg>","pause":"<svg class=\"lume-icon\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.65\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\" focusable=\"false\"><rect x=\"6\" y=\"5\" width=\"4\" height=\"14\" rx=\"1\" fill=\"currentColor\" stroke=\"none\"/><rect x=\"14\" y=\"5\" width=\"4\" height=\"14\" rx=\"1\" fill=\"currentColor\" stroke=\"none\"/></svg>","save":"<svg class=\"lume-icon\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.65\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M5 3h12l4 4v12a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2Z\"/><path d=\"M7 3v6h10V3M7 21v-8h10v8\"/></svg>","reset":"<svg class=\"lume-icon\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.65\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M3 10a9 9 0 1 1 1 7M3 4v6h6\"/></svg>","edit":"<svg class=\"lume-icon\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.65\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\" focusable=\"false\"><path d=\"m4 16 11-11 4 4L8 20H4Zm9-9 4 4M14 20h7\"/></svg>","swap":"<svg class=\"lume-icon\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.65\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M3 7h17l-4-4M21 17H4l4 4M20 7l-4 4M4 17l4-4\"/></svg>","solo":"<svg class=\"lume-icon\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.65\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\" focusable=\"false\"><circle cx=\"12\" cy=\"12\" r=\"8\"/><circle cx=\"12\" cy=\"12\" r=\"3\"/><path d=\"M12 2v3m0 14v3M2 12h3m14 0h3\"/></svg>","download":"<svg class=\"lume-icon\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.65\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M12 3v12m-5-5 5 5 5-5M4 16v4h16v-4\"/></svg>","upload":"<svg class=\"lume-icon\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.65\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M12 16V4m-5 5 5-5 5 5M4 16v4h16v-4\"/></svg>","layers":"<svg class=\"lume-icon\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.65\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\" focusable=\"false\"><path d=\"m12 3 10 5-10 5L2 8Zm-10 9 10 5 10-5M2 16l10 5 10-5\"/></svg>","fit":"<svg class=\"lume-icon\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.65\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M8 3H4v4m12-4h4v4M4 17v4h4m12-4v4h-4\"/><rect x=\"8\" y=\"8\" width=\"8\" height=\"8\" rx=\"1\"/></svg>","grid":"<svg class=\"lume-icon\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.65\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\" focusable=\"false\"><rect x=\"3\" y=\"3\" width=\"7\" height=\"7\" rx=\"1.3\"/><rect x=\"14\" y=\"3\" width=\"7\" height=\"7\" rx=\"1.3\"/><rect x=\"3\" y=\"14\" width=\"7\" height=\"7\" rx=\"1.3\"/><rect x=\"14\" y=\"14\" width=\"7\" height=\"7\" rx=\"1.3\"/></svg>","list":"<svg class=\"lume-icon\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.65\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M9 5h12M9 12h12M9 19h12\"/><circle cx=\"4\" cy=\"5\" r=\"1\"/><circle cx=\"4\" cy=\"12\" r=\"1\"/><circle cx=\"4\" cy=\"19\" r=\"1\"/></svg>","lasso":"<svg class=\"lume-icon\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.65\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M8 17c-4 0-6-2-6-5 0-5 6-8 11-8s9 2 9 6-5 7-10 7H9c-3 0-4 1-4 3s3 2 4 0l1-2\"/></svg>","target":"<svg class=\"lume-icon\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.65\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\" focusable=\"false\"><rect x=\"4\" y=\"4\" width=\"16\" height=\"16\" rx=\"2\" stroke-dasharray=\"3 2\"/><rect x=\"9\" y=\"9\" width=\"6\" height=\"6\" rx=\"1\"/></svg>","cursor":"<svg class=\"lume-icon\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.65\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\" focusable=\"false\"><path d=\"m5 3 15 10-7 1-3 7Z\"/></svg>","angle":"<svg class=\"lume-icon\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.65\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M5 20V5m0 15h15M5 20 19 6m-7 0h7v7\"/></svg>","sliders":"<svg class=\"lume-icon\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.65\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M3 6h6m4 0h8M3 12h12m4 0h2M3 18h3m4 0h11\"/><circle cx=\"11\" cy=\"6\" r=\"2\"/><circle cx=\"17\" cy=\"12\" r=\"2\"/><circle cx=\"8\" cy=\"18\" r=\"2\"/></svg>","palette":"<svg class=\"lume-icon\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.65\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M12 3a9 9 0 1 0 0 18h1a2 2 0 0 0 1.6-3.2 1.8 1.8 0 0 1 1.5-2.8H18a3 3 0 0 0 3-3 9 9 0 0 0-9-9Z\"/><path d=\"M7 11h.01M10 7h.01M15 7h.01M18 11h.01\" stroke-width=\"3\"/></svg>","static":"<svg class=\"lume-icon\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.65\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M12 3s6 6.2 6 11a6 6 0 0 1-12 0c0-4.8 6-11 6-11Z\"/><path d=\"M9 14a3 3 0 0 0 3 3\"/></svg>","prism":"<svg class=\"lume-icon\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.65\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\" focusable=\"false\"><path d=\"m12 3 8 15H4Zm-10 8h5m10 1 5-4m-5 7 5 0m-6 2 5 4\"/></svg>","wave":"<svg class=\"lume-icon\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.65\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M2 12c3 0 3-7 6-7s3 14 6 14 3-7 8-7\"/></svg>","wave2":"<svg class=\"lume-icon\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.65\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M2 8c4 0 5-4 8-4s5 4 12 4M2 13c4 0 5-4 8-4s5 4 12 4M2 18c4 0 5-4 8-4s5 4 12 4\"/></svg>","ripple":"<svg class=\"lume-icon\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.65\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\" focusable=\"false\"><circle cx=\"12\" cy=\"12\" r=\"3\"/><circle cx=\"12\" cy=\"12\" r=\"6.5\"/><circle cx=\"12\" cy=\"12\" r=\"10\" stroke-dasharray=\"8 3\"/></svg>","circle":"<svg class=\"lume-icon\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.65\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\" focusable=\"false\"><circle cx=\"12\" cy=\"12\" r=\"9\"/><circle cx=\"12\" cy=\"12\" r=\"5\"/><circle cx=\"12\" cy=\"12\" r=\"1\" fill=\"currentColor\"/></svg>","flower":"<svg class=\"lume-icon\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.65\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M12 12C1 11 4 2 10 5l2 7c1-11 10-8 7-2l-7 2c11 1 8 10 2 7l-2-7c-1 11-10 8-7 2Z\"/><circle cx=\"12\" cy=\"12\" r=\"1.5\"/></svg>","music":"<svg class=\"lume-icon\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.65\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M9 17V5l12-2v12M9 8l12-2\"/><ellipse cx=\"6\" cy=\"18\" rx=\"3\" ry=\"2.5\"/><ellipse cx=\"18\" cy=\"16\" rx=\"3\" ry=\"2.5\"/></svg>","visualizer":"<svg class=\"lume-icon\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.65\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M2 12h20M5 9v6M9 5v14M13 3v18M17 7v10M21 10v4\"/></svg>","spectrum":"<svg class=\"lume-icon\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.65\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M3 20h18M5 17v-6m4 6V5m4 12V9m4 8V3m4 14v-8\"/></svg>","orbit":"<svg class=\"lume-icon\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.65\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\" focusable=\"false\"><ellipse cx=\"12\" cy=\"12\" rx=\"10\" ry=\"5\" transform=\"rotate(-35 12 12)\"/><circle cx=\"12\" cy=\"12\" r=\"2\"/><circle cx=\"20\" cy=\"6\" r=\"2.3\" fill=\"currentColor\" stroke=\"none\"/></svg>","scan":"<svg class=\"lume-icon\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.65\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M4 3v18m16-18v18M12 3v18M7 8l3-3M7 16l3 3m7-11-3-3m3 11-3 3\"/></svg>","rain":"<svg class=\"lume-icon\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.65\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M5 3v5m0 4v7M12 6v7m0 4v4M19 2v7m0 4v5\"/></svg>","stereo":"<svg class=\"lume-icon\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.65\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M12 3v18M9 8l-5 4 5 4m6-8 5 4-5 4M4 12h5m6 0h5\"/></svg>","beat":"<svg class=\"lume-icon\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.65\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M2 12h5l3-7 4 14 3-7h5\"/></svg>","aurora":"<svg class=\"lume-icon\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.65\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M2 19C6 3 10 3 13 11s5 9 9-6M2 14C6 1 10 1 13 8s5 9 9-6\"/></svg>","silk":"<svg class=\"lume-icon\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.65\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M2 16c5-10 8-10 12-4s5 5 8-4M2 20c5-10 8-10 12-4s5 5 8-4\"/></svg>","moon":"<svg class=\"lume-icon\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.65\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M16 3a8 8 0 0 0 4 13A9 9 0 1 1 16 3Z\"/><path d=\"M3 21c3-2 5 2 8 0s5 2 8 0\"/></svg>","flame":"<svg class=\"lume-icon\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.65\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M12 2c1 5-4 7-2 11 2-1 3-3 4-5 5 4 6 7 4 11-3 5-12 3-13-3C4 11 9 7 12 2Z\"/></svg>","stars":"<svg class=\"lume-icon\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.65\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\" focusable=\"false\"><path d=\"m12 2 2.2 6.8L21 11l-6.8 2.2L12 20l-2.2-6.8L3 11l6.8-2.2Z M20 2v4m-2-2h4M4 18v4m-2-2h4\"/></svg>","comet":"<svg class=\"lume-icon\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.65\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\" focusable=\"false\"><circle cx=\"17\" cy=\"7\" r=\"4\"/><path d=\"m14 10-10 10M10 10l-7 7m14-3-7 7\"/></svg>","bloom":"<svg class=\"lume-icon\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.65\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M12 2v4m0 12v4M2 12h4m12 0h4M5 5l3 3m8 8 3 3M5 19l3-3m8-8 3-3\"/><circle cx=\"12\" cy=\"12\" r=\"4\"/></svg>","chevron":"<svg class=\"lume-icon\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.65\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\" focusable=\"false\"><path d=\"m6 9 6 6 6-6\"/></svg>","power":"<svg class=\"lume-icon\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.65\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M12 2v10M6 5a9 9 0 1 0 12 0\"/></svg>","search":"<svg class=\"lume-icon\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.65\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\" focusable=\"false\"><circle cx=\"10.5\" cy=\"10.5\" r=\"6.5\"/><path d=\"m16 16 5 5\"/></svg>","device":"<svg class=\"lume-icon\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.65\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\" focusable=\"false\"><rect x=\"3\" y=\"4\" width=\"18\" height=\"13\" rx=\"2\"/><path d=\"M12 17v4m-5 0h10\"/></svg>","pipette":"<svg class=\"lume-icon\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.65\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\" focusable=\"false\"><path d=\"m14 7 3-3a2.8 2.8 0 0 1 4 4l-3 3M12 5l7 7M13 8 4 17v3h3l9-9\"/></svg>"});
const EFFECT_ICONS=Object.freeze({"signature_flow":"wave2","signature_response":"stars","static":"static","prism":"prism","audio_wave":"wave","ripple":"ripple","spring":"wave2","flower":"flower","circle":"circle","music":"music","audio_visualizer":"visualizer","spectrum":"spectrum","orbit":"orbit","scanner":"scan","rain":"rain","waveform":"wave","stereo":"stereo","beat":"beat","aurora":"aurora","silk":"silk","tide":"moon","ember":"flame","stardust":"stars","comet":"comet","bloom":"bloom"});
const uiIcon=n=>LUME_ICONS[n]||LUME_ICONS.lighting;
const effectIcon=type=>uiIcon(EFFECT_ICONS[type]);
const EFFECTS={
 signature_flow:{name:'シグネチャー背景',en:'SIGNATURE FLOW',desc:'標準プリセットの空間発光。動きからテーマを変更できます。',short:'テーマ別の背景発光',category:'ambient'},
 signature_response:{name:'シグネチャー反応',en:'SIGNATURE RESPONSE',desc:'テーマごとに異なる波紋、拡散、残光。動きからテーマを変更できます。',short:'テーマ別の入力反応',category:'reactive'},
 static:{name:'単色',en:'STATIC',desc:'単色または最大4色のグラデーション',short:'固定色・グラデーション'},
 prism:{name:'プリズム',en:'PRISM',desc:'複数色のグラデーションが滑らかに往復する光',short:'流れる多色グラデーション',category:'ambient'},
 audio_wave:{name:'オーディオ波形',en:'AUDIO WAVE',desc:'映像編集ソフト風の直近の音声振幅を左右に流す',short:'実測の振幅波形',category:'audio'},
 ripple:{name:'リップル',en:'RIPPLE',desc:'キー入力に反応する光の波紋',short:'キー入力に反応'},
 spring:{name:'カラースプリング',en:'COLOR SPRING',desc:'柔らかなグラデーションが鍵盤を横切る、滑らかなカラーウェーブ。',short:'色が流れるように'},
 flower:{name:'フラワーウェーブ',en:'FLOWER WAVE',desc:'花びらのような放射状の光の模様が、ゆっくり回転します。',short:'放射状の光'},
 circle:{name:'サークルウェーブ',en:'CIRCLE WAVE',desc:'同心円状の光がキーボードの中心から広がるエフェクト。',short:'同心円のアニメ'},
 music:{name:'ミュージックフォロー',en:'MUSIC FOLLOW',desc:'低音・中音・高音の立ち上がりを検出し、音楽のアタックに合わせて発光。',short:'音のアタックに追従',category:'audio'},
 audio_visualizer:{name:'オーディオウェーブ',en:'AUDIO VISUALIZER',desc:'実測の時間波形と周波数スペクトルを合成。中央から上下に伸びるバーに、音のアタックを重ねます。',short:'波形 × スペクトル × リズム',category:'audio'},
 spectrum:{name:'スペクトラムバー',en:'SPECTRUM',desc:'48帯域の実測FFTを段状の縦バーで表示。',short:'周波数別のイコライザー',category:'audio'},
 orbit:{name:'オービット',en:'ORBIT',desc:'独立した光の先端が楕円軌道を周回し、後方へ残光を引く。',short:'回転する光輪',category:'ambient'},
 scanner:{name:'ライトスキャン',en:'LIGHT SCAN',desc:'一列の光の帯が端から端まで走査する。往復・片方向を選択。',short:'往復する光のライン',category:'ambient'},
 rain:{name:'レインフォール',en:'RAINFALL',desc:'独立した光の雫が、異なる速度とタイミングで落下する。',short:'縦に落ちる光の粒',category:'ambient'},
 waveform:{name:'オシロスコープ',en:'OSCILLOSCOPE',desc:'実際の音声波形をキーの高さに投影。',short:'実測波形',category:'audio'},
 stereo:{name:'ステレオフロー',en:'STEREO FLOW',desc:'左右の音のアタックに追従中心から光が伸びる。',short:'左右チャンネル',category:'audio'},
 beat:{name:'ビートパルス',en:'BEAT PULSE',desc:'音の立ち上がりに同期するリング、帯状の光、短い高音アクセント。',short:'リズムのアタック検出',category:'audio'},
 aurora:{name:'オーロラ',en:'AURORA',desc:'重なり合う光のカーテン',short:'重なり合う光のカーテン',category:'ambient'},
 silk:{name:'シルク',en:'SILK',desc:'細く滑らかな光沢の流れ',short:'細く滑らかな光沢の流れ',category:'ambient'},
 tide:{name:'ムーンタイド',en:'MOON TIDE',desc:'ゆらめく月光と波',short:'ゆらめく月光と波',category:'ambient'},
 ember:{name:'エンバー',en:'EMBER',desc:'燃え残る光の揺らぎ',short:'燃え残る光の揺らぎ',category:'ambient'},
 stardust:{name:'スターダスト',en:'STARDUST',desc:'明滅する微細な星',short:'明滅する微細な星',category:'ambient'},
 comet:{name:'コメット',en:'COMET',desc:'入力から方向へ走る光',short:'入力から方向へ走る光',category:'reactive'},
 bloom:{name:'ブルーム',en:'BLOOM',desc:'入力から柔らかく咲く光',short:'入力から柔らかく咲く光',category:'reactive'}
};
const SIGNATURE_PRESETS=[["GLACIER","氷河",["#102B50","#226EB8","#72D9FF","#E8FBFF"]],["VELVET","深紅",["#260509","#7D0D24","#D52B47","#FF8C9B"]],["NEBULA","星雲",["#25124C","#6741B7","#B54FDE","#4E9FE7"]],["MONOCHROME","白銀",["#171717","#484848","#A9A9A9","#FFFFFF"]],["DUSK","夕暮れ",["#533278","#B54B88","#ED846F","#FFC087"]],["ABYSS","深海",["#041C28","#07506C","#128F9B","#7EE6D3"]],["SOLARIS","太陽",["#471307","#AC390B","#F78E25","#FFE5A1"]],["SAKURA","桜",["#402338","#A05C88","#F2A5CB","#FFF0F5"]],["AURORA","極光",["#18375E","#206E90","#42C998","#8E6DDD"]],["GHOST","残光",["#08090C","#141820","#576777","#D1E4F7"]]];
const SIGNATURE_TYPES=new Set(['signature_flow','signature_response']);
const signatureIndex=l=>Math.max(0,SIGNATURE_PRESETS.findIndex(p=>p[0]===l.signatureStyle));
const AUDIO=new Set(['music','spectrum','waveform','stereo','beat','audio_wave','audio_visualizer']);
const dynamicEffect=type=>AUDIO.has(type)||REACTIVE.has(type);
const REACTIVE=new Set(['ripple','comet','bloom','signature_response']);
const MOTION_DEFAULTS={angle:0,phase:0,width:50,floor:0,contrast:50,duration:36,sensitivity:50,audioWidth:50};
const BAR_DEFAULTS={bars:18,barHeight:100,barWidth:100,barSmooth:30,barGate:5,freqLow:0,freqHigh:100,barOrigin:'bottom',barShape:'blocks',barColor:'height',barPeak:false,barReverse:false,barMain:false,barBlack:true,barRange:54,barTilt:0,barResponse:'balanced',barPeakColor:'#E1F6FF'};
const SHAPE_DEFAULTS={pulseShape:'circle',aspect:100,originX:50,originY:50,petals:6,motionCurve:'natural',motionTrail:45,orbitHeads:2,rainDensity:55,scanMode:'bounce'};
const COLORS=['#76F3E1','#75B8F8','#9C91FF','#FB91CD','#FF9D71','#F4D27D','#F3FCF9'];
const BASE=()=>({layout:'jis',layers:[{id:1,type:'ripple',enabled:true,color:'#76F3E1',brightness:95,speed:55,spread:60,fade:65,direction:'radial'},{id:2,type:'circle',enabled:false,color:'#76F3E1',brightness:69,speed:24,spread:38,fade:62,direction:'right'}],selectedLayer:1,selectedKeys:[],keyColors:{},fixedColorMode:'reactive',reactivePriority:false,running:true,volume:0});
function validEditor(v){
 if(!v||!['jis','ansi'].includes(v.layout)||!Array.isArray(v.layers)||v.layers.length<1||v.layers.length>8)return false;
 const ids=new Set();return v.layers.every(l=>{if(!l||!Object.hasOwn(EFFECTS,l.type)||!Number.isSafeInteger(l.id)||l.id<1||l.id>2147483647||ids.has(l.id)||typeof l.color!=='string'||!/^#[0-9a-f]{6}$/i.test(l.color))return false;ids.add(l.id);return ['brightness','speed','spread','fade'].every(k=>l[k]===undefined||typeof l[k]==='number'&&Number.isFinite(l[k])&&l[k]>=0&&l[k]<=100)&&['secondary','barPeakColor'].every(k=>l[k]===undefined||typeof l[k]==='string'&&/^#[0-9a-f]{6}$/i.test(l[k]))&&(l.gradient===undefined||Array.isArray(l.gradient)&&l.gradient.length<=4&&l.gradient.every(c=>typeof c==='string'&&/^#[0-9a-f]{6}$/i.test(c)))&&(l.targets===undefined||Array.isArray(l.targets)&&l.targets.length<=180&&l.targets.every(k=>typeof k==='string'&&/^[A-Za-z0-9]{1,25}$/.test(k)))&&(l.enabled===undefined||typeof l.enabled==='boolean')})&&(v.keyColors===undefined||v.keyColors&&typeof v.keyColors==='object'&&!Array.isArray(v.keyColors)&&Object.keys(v.keyColors).length<=180&&Object.entries(v.keyColors).every(([k,c])=>/^[A-Za-z0-9]{1,25}$/.test(k)&&typeof c==='string'&&/^#[0-9a-f]{6}$/i.test(c)));
}
let state=BASE();
try{const saved=JSON.parse(localStorage.getItem('lume-pro-state')||'null');if(validEditor(saved)){state={...BASE(),...saved,running:true,selectedKeys:[]};}}catch{}
let undoStack=[],redoStack=[],recordedSnapshot='',pickerOpen=false,pickerMode='add',soloLayerId=null,layerMenuId=null,inspectorTab='basic';
let catalogPreview=null, previewTransition=null, transitionRequest=null, transitionSerial=0, hoveredPreset=null, editingPreset=null;
let profileView='cards';try{if(localStorage.getItem('lume-profile-view')==='list')profileView='list'}catch{}
const MOTION_PROFILES={responsive:[.006,.018],balanced:[.014,.045],smooth:[.034,.085]};
let motionProfile='balanced';try{const m=localStorage.getItem('lume-light-motion');if(Object.hasOwn(MOTION_PROFILES,m))motionProfile=m}catch{}
let transitionMs=600;try{transitionMs=Number(localStorage.getItem('lume-transition-ms')??600);if(![0,250,600,1000,1600].includes(transitionMs))transitionMs=600}catch{}
let frameInFlight=false,keysInFlight=false;let isAudioOn=false,audioStatus={enabled:false,volume:0,error:'未開始'};
let secret='',hardware={connected:false,active:false,devices:[],error:'未接続'},isLive=false,isHook=false,seq=0,profiles=[],activeView='lighting',frameCount=0,lastTime=performance.now(),periodicPush=0,lastMusicSample=0;
let desktopResident=false;
let preferences={auto:true,backend:'logitech',live:false,hook:false,editor:null},prefTimer=null,prefChain=Promise.resolve(),initializing=true,connectionBusy=false;
const keyLookup=new Map();let keyboardKeys=[],pulseEvents=[];let selectedPalette=0;
const key=(label,code,w=1)=>({label,code,w});const space=(w=.28)=>({label:'',code:null,w});
function layoutRows(layout){
 const fn=[key('Esc','Escape',1.1),space(.48),...['F1','F2','F3','F4'].map(x=>key(x,x)),space(.32),...['F5','F6','F7','F8'].map(x=>key(x,x)),space(.32),...['F9','F10','F11','F12'].map(x=>key(x,x)),space(.37),key('Prt','PrintScreen'),key('Scr','ScrollLock'),key('Pau','Pause')];
 const digits='1234567890'.split('').map(c=>key(c,'Digit'+c));
 const r2=layout==='jis'?[key('半角','Backquote'),...digits,key('-','Minus'),key('^','Equal'),key('￥','IntlYen'),key('Back','Backspace'),space(.35),key('Ins','Insert'),key('Home','Home'),key('PgUp','PageUp')]:[key('~','Backquote',1.12),...digits,key('-','Minus'),key('=','Equal'),key('Back','Backspace',2),space(.35),key('Ins','Insert'),key('Home','Home'),key('PgUp','PageUp')];
 const letters=seq=>seq.split('').map(c=>key(c,'Key'+c));
 const r3=layout==='jis'?[key('Tab','Tab',1.5),...letters('QWERTYUIOP'),key('@','BracketLeft'),key('[','BracketRight'),space(.20),space(.35),key('Del','Delete'),key('End','End'),key('PgDn','PageDown')]:[key('Tab','Tab',1.5),...letters('QWERTYUIOP'),key('[','BracketLeft'),key(']','BracketRight'),key('\\','Backslash',1.36),space(.35),key('Del','Delete'),key('End','End'),key('PgDn','PageDown')];
 const r4=layout==='jis'?[key('Caps','CapsLock',1.75),...letters('ASDFGHJKL'),key(';','Semicolon'),key(':','Quote'),key(']','Backslash'),key('Enter','Enter',1.65),space(.35),space(3.25)]:[key('Caps','CapsLock',1.83),...letters('ASDFGHJKL'),key(';','Semicolon'),key("'",'Quote'),key('Enter','Enter',2.28),space(.35),space(3.25)];
 const r5=layout==='jis'?[key('Shift','ShiftLeft',2),...letters('ZXCVBNM'),key(',','Comma'),key('.','Period'),key('/','Slash'),key('\\','IntlRo'),key('Shift','ShiftRight',2),space(.35),space(1.13),key('↑','ArrowUp'),space(1.12)]:[key('Shift','ShiftLeft',2.38),...letters('ZXCVBNM'),key(',','Comma'),key('.','Period'),key('/','Slash'),key('Shift','ShiftRight',2.55),space(.35),space(1.13),key('↑','ArrowUp'),space(1.12)];
 const r6=layout==='jis'?[key('Ctrl','ControlLeft',1.5),key('Win','MetaLeft',1.25),key('Alt','AltLeft',1),key('無変換','NonConvert',1.25),key('','Space',3.75),key('変換','Convert',1),key('かな','KanaMode',1.25),key('Fn','Fn',1),key('Menu','ContextMenu',1),key('Ctrl','ControlRight',2),space(.35),key('←','ArrowLeft'),key('↓','ArrowDown'),key('→','ArrowRight')]:[key('Ctrl','ControlLeft',1.3),key('Win','MetaLeft',1.28),key('Alt','AltLeft',1.21),key('','Space',6.05),key('Alt','AltRight',1.26),key('Fn','Fn',1.08),key('Menu','ContextMenu',1.19),key('Ctrl','ControlRight',1.37),space(.35),key('←','ArrowLeft'),key('↓','ArrowDown'),key('→','ArrowRight')];
 return [fn,r2,r3,r4,r5,r6];
}
function createKeyboard(target){
 target.innerHTML='';const main=target===$('keyboard');const outer=main?$('keyboardFrame'):document.createElement('div');
 if(!main){outer.className='keyboard-frame';target.appendChild(outer)}
 const grille=main?target:document.createElement('div');if(!main){grille.className='keyboard-grille';outer.appendChild(grille)}
 const rows=layoutRows(state.layout);const arr=[];const isJis=state.layout==='jis';outer.dataset.layout=state.layout;outer.classList.add('photo-board');
 let header=main?outer.querySelector('.keyboard-status'):document.createElement('div');
 header.className='keyboard-status';header.replaceChildren();if(!main)outer.insertBefore(header,grille);
 const addAccessory=(parent,code,label,x,kind)=>{const el=document.createElement('button');el.type='button';el.className='board-accessory '+kind;el.dataset.code=code;el.title=label;el.setAttribute('aria-label',label);if(code==='BoardLogo')el.textContent='G';else el.innerHTML=code==='GameMode'?'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M7 8h10l3 9-3 2-4-4h-2l-4 4-3-2z"/><path d="M8 10v4m-2-2h4m5-1h.01m2 3h.01"/></svg>':'<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="4"/><path d="M12 2v3m0 14v3M2 12h3m14 0h3M5 5l2 2m10 10 2 2M19 5l-2 2M7 17l-2 2"/></svg>';el.addEventListener('click',e=>onKeyClick(code,e));parent.appendChild(el);arr.push({code,x,y:0,el})};
 addAccessory(header,'BoardLogo','G ロゴ',.6,'board-logo');const locks=document.createElement('div');locks.className='board-locks';locks.innerHTML='<span><i></i><small>CAPS</small></span><span><i></i><small>SCROLL</small></span>';header.appendChild(locks);const buttons=document.createElement('div');buttons.className='board-buttons';header.appendChild(buttons);addAccessory(buttons,'GameMode','ゲームモードボタン',16.9,'board-round');addAccessory(buttons,'LightButton','照明ボタン',17.8,'board-round');
 // physical unit coordinates: 15u main block, navigation cluster separated by .35u.
 const widths=[15,15,15,15,15,15];
 rows.forEach((row,y)=>{
  let x=0; const right= y===0?3:y===1||y===2||y===5?3:y===4?3:1;
  const mainItems=row.slice(0,-right-1);const nav=row.slice(-right);
  const mainTotal=mainItems.reduce((a,b)=>a+b.w,0)||15;
  const render=(item,px,py,w,height=1,enter=false)=>{
   if(!item.code)return;
   const e=document.createElement('button');e.type='button';e.className='key physical-key';e.dataset.code=item.code;e.setAttribute('aria-label',item.code);e.title=item.label||'Space';
   e.style.setProperty('--x',px);e.style.setProperty('--y',py);e.style.setProperty('--w',w);e.style.setProperty('--h',height);
   if(item.code==='Space')e.classList.add('space');if(enter)e.classList.add('jis-enter');
   e.dataset.skin=String(Math.max(3,Math.min(25,Math.round(w*4))));const obj={code:item.code,x:px+w/2,y:py+.8,el:e,geometry:{x:px,y:py,w,h:height}};arr.push(obj);e.innerHTML='<span></span>';e.firstChild.className='key-legend';e.firstChild.textContent=({Backspace:'←',Tab:'⇥',Enter:'↵',MetaLeft:'⊞',ContextMenu:'▤',PrintScreen:'Prt Sc',ScrollLock:'Scr Lk',Pause:'Pause',PageUp:'Pg Up',PageDown:'Pg Dn',Space:'',KanaMode:'かな',IntlYen:'¥',IntlRo:'\\'})[item.code]??item.label; if(e.firstChild.textContent.length>=4)e.classList.add('long-legend');if(isJis){const legends={Digit1:'ぬ',Digit2:'ふ',Digit3:'あ',Digit4:'う',Digit5:'え',Digit6:'お',Digit7:'や',Digit8:'ゆ',Digit9:'よ',Digit0:'わ',Minus:'ほ',Equal:'へ',IntlYen:'ー',KeyQ:'た',KeyW:'て',KeyE:'い',KeyR:'す',KeyT:'か',KeyY:'ん',KeyU:'な',KeyI:'に',KeyO:'ら',KeyP:'せ',BracketLeft:'゛',BracketRight:'゜',KeyA:'ち',KeyS:'と',KeyD:'し',KeyF:'は',KeyG:'き',KeyH:'く',KeyJ:'ま',KeyK:'の',KeyL:'り',Semicolon:'れ',Quote:'け',Backslash:'む',KeyZ:'つ',KeyX:'さ',KeyC:'そ',KeyV:'ひ',KeyB:'こ',KeyN:'み',KeyM:'も',Comma:'ね',Period:'る',Slash:'め',IntlRo:'ろ'};if(legends[item.code]){const sub=document.createElement('small');sub.className='key-kana';sub.textContent=legends[item.code];e.append(sub);e.classList.add('has-kana')}const shifted={Digit1:'!',Digit2:'"',Digit3:'#',Digit4:'$',Digit5:'%',Digit6:'&',Digit7:"'",Digit8:'(',Digit9:')',Minus:'=',Equal:'~',IntlYen:'|',BracketLeft:'`',BracketRight:'{',Semicolon:'+',Quote:'*',Backslash:'}',Comma:'<',Period:'>',Slash:'?',IntlRo:'_'};if(shifted[item.code]){const sub=document.createElement('small');sub.className='key-shifted';sub.textContent=shifted[item.code];e.append(sub);e.classList.add('has-shifted')}}
   e.addEventListener('click',ev=>onKeyClick(obj.code,ev));grille.appendChild(e);
  };
  if(isJis&&y===2){
   // The top row of the JIS Enter occupies the remaining space at the right.
   const items=row.slice(0,13);const total=items.reduce((a,b)=>a+b.w,0);
   for(const item of items){const w=item.w/total*13.5;render(item,x,2.38,w);x+=w}
   render({label:'↵',code:'Enter'},13.5,2.38,1.5,2,true);
  }else if(isJis&&y===3){
   const items=row.filter(i=>i.code&&i.code!=='Enter');const total=items.reduce((a,b)=>a+b.w,0);
   for(const item of items){const w=item.w/total*13.75;render(item,x,3.38,w);x+=w}
  }else{
   const items=y===0?row.slice(0,-4):y===4?row.filter(i=>i.code&&i.code!=='ArrowUp'):mainItems;
   const total=items.reduce((a,b)=>a+b.w,0)||15;
   for(const item of items){const w=item.w/total*15;render(item,x,y?y+.38:0,w);x+=w}
  }
  if(y===0||y===1||y===2||y===5){nav.forEach((item,i)=>render(item,15.45+i,y?y+.38:0,1))}
  if(y===4)render({label:'↑',code:'ArrowUp'},16.45,4.38,1);
 });
 const light=document.createElement('canvas');light.className='board-lightmap';light.setAttribute('aria-hidden','true');light.width=target.closest('.profile-visual')?480:1107;light.height=Math.round(light.width*6.23/18.45);grille.prepend(light);const surface={canvas:light,keys:arr.filter(k=>k.geometry),queued:false};for(const k of surface.keys)k.lightSurface=surface;
 return arr;
}
function renderKeyboards(){
 keyboardKeys=createKeyboard($('keyboard'));
 const mapping=createKeyboard($('mappingKeyboard'));for(const k of keyboardKeys)k.view='lighting';for(const k of mapping)k.view='keyboard';previewDirty=true;
 for(const k of [...keyboardKeys,...mapping]){
  if(!keyLookup.has(k.code))keyLookup.set(k.code,[]);
 }
 keyLookup.clear();
 for(const k of [...keyboardKeys,...mapping]){
  if(!keyLookup.has(k.code))keyLookup.set(k.code,[]);
  keyLookup.get(k.code).push(k);
 }
 updateSelection();
}
let keyMode='color',gameBusy=false;
let gameState={enabled:false,blocked:['MetaLeft','MetaRight','ContextMenu'],led:'off',color:'#ff5555',dim:25};
const gameProtected=new Set(['ControlLeft','ControlRight','AltLeft','AltRight','F12','Fn','BoardLogo','LightButton','GameMode','NumLock']);
function gameMask(code,rgb){if(!gameState.enabled||!gameState.blocked.includes(code))return rgb;switch(gameState.led){case 'off':return [0,0,0];case 'dim':return rgb.map(v=>v*gameState.dim/100);case 'color':return hexToRGB(gameState.color);default:return rgb}}
function renderGame(){
 if(!$('gameToggle'))return;
 $('gameTopState').textContent='ゲームモード '+(gameState.enabled?'ON':'OFF');$('gameTopState').classList.toggle('on',gameState.enabled);
 $('gameToggle').hidden=keyMode!=='game';$('gameToggle').textContent=gameState.enabled?'OFF にする':'ON にする';$('gameToggle').setAttribute('aria-pressed',String(gameState.enabled));$('gameToggle').disabled=gameBusy;
 $('gameStatus').textContent=gameState.enabled?(isLive?'入力遮断中 · LED連動中':'入力遮断中 · 実機反映OFF'):'停止中 · 無効化するキーを設定できます';
 $('gameCount').textContent=gameState.blocked.length+' キー';$('keyGameLegend').textContent=gameState.enabled?'ゲームモード有効 · 設定したキーの入力を遮断':'有効にすると設定したキーの入力を遮断';$('gameControls').classList.toggle('game-active',gameState.enabled);$('gameLed').value=gameState.led;$('gameDim').value=String(gameState.dim);$('gameDimValue').textContent=gameState.dim+'%';$('gameColor').value=gameState.color;
 $('gameDimWrap').hidden=gameState.led!=='dim';$('gameColorWrap').hidden=gameState.led!=='color';
 const list=$('gameKeyList');list.replaceChildren();for(const code of gameState.blocked){const b=document.createElement('button');b.type='button';b.textContent=(keyboardKeys.find(k=>k.code===code)?.el.title||code)+' ×';b.title='無効化リストから外す';b.disabled=gameBusy;b.onclick=()=>changeGame({blocked:gameState.blocked.filter(k=>k!==code)});list.append(b)}
 if(!gameState.blocked.length){const t=document.createElement('span');t.className='field-help';t.textContent='無効化するキーを選択してください';list.append(t)}
 for(const k of $('mappingKeyboard').querySelectorAll('[data-code]')){const blocked=keyMode==='game'&&gameState.blocked.includes(k.dataset.code);k.classList.toggle('game-blocked',blocked);let mark=k.querySelector('.game-key-mark');if(blocked&&!mark){mark=document.createElement('span');mark.className='game-key-mark';mark.textContent='×';k.append(mark)}else if(!blocked&&mark)mark.remove();k.classList.toggle('game-protected',keyMode==='game'&&gameProtected.has(k.dataset.code));if(keyMode==='game')k.setAttribute('aria-pressed',String(blocked));else k.removeAttribute('aria-pressed')}
 if(keyMode==='game')$('mappingCount').textContent=gameState.blocked.length+' キー無効化設定';
}
function setKeyMode(mode){keyMode=mode;$('mappingKeyboard').classList.toggle('game-edit',mode==='game');$('keyTabColor').setAttribute('aria-pressed',String(mode==='color'));$('keyTabGame').setAttribute('aria-pressed',String(mode==='game'));$('keyColorControls').hidden=mode!=='color';$('keySelectionTools').hidden=mode!=='color';$('keyGameHint').hidden=mode!=='game';$('gameControls').hidden=mode!=='game';$('keyBoardTitle').textContent=mode==='game'?'無効化するキーをクリック':'カラーを設定するキーを選択';$('keyBoardHelp').textContent=mode==='game'?'クリックで無効化リストへ追加／解除。×印は無効化の対象です。':'クリックで選択、Shift / Ctrl + クリックで複数選択。';updateSelection();renderGame()}
async function changeGame(patch){if(gameBusy)return;const next={...gameState,...patch};if(next.enabled&&!gameState.enabled&&!confirm('Windows上のすべてのキーボードで選択キーを無効化します。キーから手を離して有効にしてください。Ctrl + Alt + F12で緊急解除できます。続けますか？'))return;gameBusy=true;renderGame();try{const r=await post('/api/game_mode',next);if(!r.ok||!r.game_mode)throw Error(r.error||'設定を変更できませんでした');gameState=r.game_mode;await refreshStatus();if(activeView==='keyboard'||activeView==='lighting')paintFrame(performance.now()/1000);if('enabled' in patch)toast(gameState.enabled?'ゲームモードを有効にしました':'ゲームモードを解除しました')}catch(e){toast('ゲームモード: '+e.message)}finally{gameBusy=false;renderGame()}}
function onKeyClick(code,ev){
 if(keyMode==='game'&&ev.currentTarget?.closest('#mappingKeyboard')){if(gameProtected.has(code)){toast('このキーは無効化対象外です');return}const blocked=new Set(gameState.blocked);if(blocked.has(code))blocked.delete(code);else blocked.add(code);changeGame({blocked:[...blocked]});return}

 triggerPulse(code);document.querySelectorAll('[data-group]').forEach(el=>el.classList.remove('active'));
 if(ev.shiftKey || ev.ctrlKey){
  const sel=new Set(state.selectedKeys);if(sel.has(code))sel.delete(code);else sel.add(code);state.selectedKeys=[...sel];
 }else{state.selectedKeys=[code]}
 updateSelection();remember();
}
function updateSelection(){
 keyLookup.forEach((entries,code)=>entries.forEach(x=>x.el.classList.toggle('selected',state.selectedKeys.includes(code))));
 $('mappingCount').textContent=state.selectedKeys.length+' キー選択中';
 const count=state.selectedKeys.length;$('keyColorCount').textContent=count+' キー';
 const names=state.selectedKeys.slice(0,8).map(code=>keyboardKeys.find(k=>k.code===code)?.el.title||code);$('keySelectedNames').textContent=count?names.join('、')+(count>8?' ほか '+(count-8)+' キー':''):'キーボードからキーを選択';
 for(const id of ['applyKeyColor','clearKeyColor','pickKeyColor','clearSelection'])$(id).disabled=!count;
 $('selectedKeysText').textContent=state.selectedKeys.length?state.selectedKeys.length+' キー選択中':'キーが選択されていません';updateTargetOutlines();renderGame();
}
function inputCode(code){return state.layout==='jis'&&code==='AltRight'?'Fn':code}
function triggerPulse(code,source='local'){previewDirty=true;
 code=inputCode(code);
 if(isLive&&source!=='hook')post('/api/pulse',{code}).catch(()=>{});
 const obj=keyboardKeys.find(x=>x.code===code);
 if(!obj)return;
 for(const k of keyLookup.get(code)||[]){k.el.classList.add('pressed');clearTimeout(k.pressTimer);k.pressTimer=setTimeout(()=>k.el.classList.remove('pressed'),110)}
 const now=performance.now()/1000;
 pulseEvents.push({x:obj.x,y:obj.y,start:now});
 pulseEvents=pulseEvents.slice(-34);
}
function hexToRGB(s){if(!/^#[0-9a-fA-F]{6}$/.test(s||''))s='#76F3E1';return [parseInt(s.slice(1,3),16),parseInt(s.slice(3,5),16),parseInt(s.slice(5,7),16)]}
function rgbToHex(rgb){return '#'+rgb.map(c=>Math.min(255,Math.max(0,Math.round(c))).toString(16).padStart(2,'0')).join('')}
function mix(a,b,t){return a.map((x,i)=>x*(1-t)+b[i]*t)}
function clamp(v,a=0,b=1){return Math.min(b,Math.max(a,v))}
function smooth(v){v=clamp(v);return v*v*(3-2*v)}
function adjustedColor(base,t){
 const c=hexToRGB(base);const blue=[76,132,244],white=[225,251,248];
 return mix(mix(c,blue,clamp(Math.sin(t)*.25+.20)),white,clamp((Math.sin(t+1.2)+1)*.18));
}
function lerpSample(values,u){if(!values?.length)return 0;const pos=clamp(u)*(values.length-1),i=Math.floor(pos);return values[i]+(values[Math.min(i+1,values.length-1)]-values[i])*(pos-i)}
function gradientAt(layer,u,v,t=0){const colors=(layer.gradient?.length>1?layer.gradient:[layer.color,layer.secondary||'#B79BFF']).map(hexToRGB),a=(layer.gradientAngle||0)*Math.PI/180,c=Math.cos(a),d=Math.sin(a);let pos=layer.gradientMode==='radial'?clamp(Math.hypot(u-.5,v-.5)*Math.SQRT2):clamp(.5+((u-.5)*c+(v-.5)*d)/Math.max(.001,Math.abs(c)+Math.abs(d)));if(layer.type==='prism')pos=.5+.5*Math.sin(pos*2*Math.PI/(.5+layer.spread/100*1.8)-t*(.35+layer.speed/100*2.4)*(layer.direction==='left'?-1:1));const n=pos*(colors.length-1),i=Math.min(colors.length-2,Math.floor(n));return mix(colors[i],colors[i+1],n-i)}
function demoAudio(t){const a=.55+.35*Math.sin(t*3),rhythm={levels:[.5,.28,.18],events:[['kick',0,.5,1],['mid',.25,.5,.75],['high',.125,.25,.55]].map(([kind,offset,period,strength],id)=>({id,kind,age:((t-offset)%period+period)%period,strength}))};return {rhythm,visual_envelope:Array.from({length:24},(_,i)=>.03+.38*(.5+.5*Math.sin(i*.63-t*10))**3*a),volume:a,bass:a,beat:.5+.5*Math.sin(t*4),stereo:[a,1-a/2],bands:Array.from({length:18},(_,i)=>.2+.75*(.5+.5*Math.sin(i*.5-t*4))),spectrum:Array.from({length:48},(_,i)=>.06+.9*(.5+.5*Math.sin(i*.39-t*4))**3),spectrum_slow:Array.from({length:48},(_,i)=>.12+.8*(.5+.5*Math.sin(i*.39-t*3.6))**2),spectrum_peak:Array.from({length:48},(_,i)=>.16+.83*(.5+.5*Math.sin(i*.39-t*4+.4))**2),trace:Array.from({length:72},(_,i)=>.75*Math.sin(i*.18-t*6)+.13*Math.sin(i*.46+t*3)),envelope:Array.from({length:36},(_,i)=>.08+.77*(.5+.5*Math.sin(i*.43-t*7))**2)}}
let boundsCache=new WeakMap();
function bounds(){let v=boundsCache.get(keyboardKeys);if(!v){const xs=keyboardKeys.map(k=>k.x),ys=keyboardKeys.map(k=>k.y),main=keyboardKeys.filter(k=>!['BoardLogo','LightButton','GameMode'].includes(k.code));v=[Math.min(...xs),Math.max(...xs),Math.min(...ys),Math.max(...ys),Math.min(...main.map(k=>k.y))];boundsCache.set(keyboardKeys,v)}return v}
function rhythmPixel(kind,a,u,v,gain,width,speed,primary,secondary,elapsed=0){
 if(gain<=0)return {power:0,color:primary};
 const r=a.rhythm,vol=a.volume||0,bass=a.bass||0,dist=Math.hypot((u-.5)*1.8,v-.5);
 if(!r||(!r.events.length&&!r.levels.some(Boolean)&&vol>0)){
  if(kind==='music')return {power:clamp(vol*gain),color:mix(primary,secondary,clamp(bass*gain))};
  const beat=clamp((a.beat||0)*gain);return {power:beat*Math.exp(-Math.pow((dist-(1-beat))/width,2)*3)+clamp(bass*gain)*.12,color:mix(primary,secondary,beat)};
 }
 const [low,mid,high]=r.levels;let power=kind==='music'?(low*.32*(1-smooth(dist))+mid*.28*(1-v*.65)+high*.18*(.25+.75*v))*gain:0,accent=0;
 for(const e of r.events){const age=e.age+elapsed,strength=e.strength*gain;if(age>1)continue;
  if(e.kind==='kick'){const radius=age*(.8+speed*.55),ring=Math.exp(-Math.pow((dist-radius)/Math.max(.10,width),2))*Math.exp(-age/.23),core=Math.exp(-dist*dist/.16-age/.065);power+=strength*(ring*.9+core*.65);accent=Math.max(accent,core*strength);}
  else if(e.kind==='mid'){const hit=Math.exp(-age/.115)*Math.exp(-Math.pow((v-.52)/.30,2));power+=strength*hit*.85;accent=Math.max(accent,hit*strength);}
  else{const hit=Math.exp(-age/.065)*(.35+.65*Math.abs(u-.5)*2);power+=strength*hit*.48;accent=Math.max(accent,hit*strength*.65);}
 }return {power:clamp(power),color:mix(primary,secondary,clamp(accent+high*.25))};
}
function keyUV(k){const [x0,x1,y0,y1]=bounds();return [clamp((k.x-x0)/Math.max(.1,x1-x0)),clamp((k.y-y0)/Math.max(.1,y1-y0))]}
function paletteAt(colors,pos){const n=clamp(pos)*(colors.length-1),i=Math.min(colors.length-2,Math.floor(n));return colors.length>1?mix(colors[i],colors[i+1],n-i):colors[0]}
function visualizerPixel(l,a,u,v){
 const gain=(l.sensitivity??50)/50*(.25+(l.waveGain??50)/40)/1.5,primary=hexToRGB(l.color),secondary=hexToRGB(l.secondary||'#B79BFF');
 if(gain<=0)return {power:0,color:primary};
 let gate=smooth(((a.volume||0)-.002)/.06);gate*=1-smooth(((a.packet_age_ms||0)-90)/220);
 const raw=Math.max(0,lerpSample(a.visual_envelope||a.envelope,u)),wave=1-Math.exp(-raw*5*gain),fast=Math.max(0,lerpSample(a.spectrum||a.bands,u)),slow=Math.max(0,lerpSample(a.spectrum_slow,u));
 const blend=(l.waveMix??45)/100,trail=(l.waveTrail??18)/100,beat=(l.waveBeat??30)/100;
 const freq=clamp((fast*.85+Math.max(0,slow-fast)*trail*.65)*gain);
 let height=wave*(1-blend)+freq*blend,accent=0;
 for(const e of a.rhythm?.events||[]){const center=({kick:.12,mid:.5,high:.88})[e.kind]??.5;const age=e.age+(a.receivedAt==null?0:Math.max(0,performance.now()/1000-a.receivedAt));accent=Math.max(accent,e.strength*Math.exp(-age/.09)*Math.exp(-(((u-center)/.27)**2)))}
 height=clamp(height*(1+accent*beat*.75)+accent*beat*.22*Math.min(1,gain));
 const mirror=l.waveMirror!==false,edge=mirror?Math.abs(v-.5)*2:1-v,half=mirror?.20:.10,width=.045+(l.audioWidth??50)/100*.20;
 let power=smooth((height-edge+half+width*.28)/(half*1.6))*clamp(height*5)*gate;
 if(l.waveIdle===true)power=Math.max(power,.075*smooth((half*1.4-edge)/half));
 return {power:clamp(power),color:mix(primary,secondary,clamp(edge*.65+accent*beat*.35))};
}
function spectrumPixel(layer,a,k){
 const l={...BAR_DEFAULTS,...layer};if(['BoardLogo','LightButton','GameMode'].includes(k.code)||(l.barMain&&k.x>=15.45))return {power:0,color:hexToRGB(l.color)};
 const [x0,x1,y0,y1,top]=bounds();let u=clamp((k.x-x0)/Math.max(.1,(l.barMain?15:x1)-x0)),v=clamp((k.y-top)/Math.max(.1,y1-top));if(l.barReverse)u=1-u;
 const count=Math.round(l.bars),q=u*(count-1),col=Math.round(q),frac=col/Math.max(1,count-1),lo=Math.min(l.freqLow,l.freqHigh)/100,hi=Math.max(l.freqLow,l.freqHigh)/100,f=lo+(hi-lo)*frac;
 const dense=a.spectrum||a.bands||[0],slow=a.spectrum_slow||dense,scale=h=>clamp((h-l.barGate/100)/Math.max(.01,1-l.barGate/100)*(l.sensitivity??50)/50*l.barHeight/100);
 const raw=lerpSample(dense,f),slowValue=lerpSample(slow,f),response=l.barResponse==='fast'?0:l.barResponse==='smooth'?1:l.barSmooth/100;const shapeAmp=v=>v<=0?0:clamp(1+(v-1)*54/l.barRange+l.barTilt/100*(f-.5)*.8);const h=scale(shapeAmp(raw*(1-response)+slowValue*response)),edge=l.barOrigin==='top'?v:l.barOrigin==='center'?Math.abs(v-.5)*2:1-v,steps=l.barOrigin==='center'?3:6,z=edge*(steps-1)+.5,level=h*steps;
 let power=l.barShape==='soft'?clamp(level-z+.5):Number(level>=z);
 if(l.barShape==='outline')power=Number(h>.01&&(Math.abs(level-z)<.55||(level>=z&&(Math.abs(q-col)>.32||z<1))));if(l.barShape==='dot')power=Number(Math.abs(level-z)<.5&&h>.01);
 const mask=l.barWidth>=100?1:smooth((l.barWidth/200-Math.abs(q-col)+.12)/.12);power*=mask;
 const colors=(l.gradient?.length>1?l.gradient:[l.color,l.secondary||'#16E7F2']).map(hexToRGB);let color=paletteAt(colors,l.barColor==='frequency'?f:edge);
 const pk=scale(shapeAmp(lerpSample(a.spectrum_peak||dense,f)));if(l.barPeak&&pk>.04&&Math.abs(pk*steps-z)<.52&&mask>.15){power=Math.max(power,mask*.86);color=mix(color,hexToRGB(l.barPeakColor),.62)}return {power,color};
}
// Physical key coordinate motion; same equations as engine.motion_pixel.
function motionPixel(l,k,t,b){
 const [x0,x1,_,y1,y0]=b,dx=Math.max(.1,x1-x0),dy=Math.max(.1,y1-y0),x=k.x,y=k.y;
 const dir=l.direction==='left'?-1:1,z=t*(.35+l.speed/100*2.4),phase=l.phase/100,w=l.width/100,spread=l.spread/100,trail=l.motionTrail/100;
 const theta=l.angle*Math.PI/180,co=Math.cos(theta),si=Math.sin(theta),c=hexToRGB(l.color),accent=hexToRGB(l.secondary||'#B79BFF'),tau=Math.PI*2,mod=(v,n)=>((v%n)+n)%n;
 if(l.type==='orbit'){
  const cx=x0+dx*l.originX/100,cy=y0+dy*l.originY/100,radius=.38+.55*spread,rx=Math.max(.7,dx*.5*radius*l.aspect/100),ry=Math.max(.7,dy*.5*radius),px=(x-cx)/rx,py=(y-cy)/ry,u=px*co+py*si,v=-px*si+py*co;
  const angle=Math.atan2(v,u),r=Math.hypot(u,v),thickness=.12+.38*w,ring=Math.exp(-(((r-1)/thickness)**2)),headAngle=dir*(z*.85+phase*tau);let power=0,hot=0;
  for(let i=0;i<l.orbitHeads;i++){const d=mod(dir*(headAngle+i*tau/l.orbitHeads-angle)+Math.PI,tau)-Math.PI,head=Math.exp(-((d/(.18+.50*w))**2)),tail=d>0&&trail>0?Math.exp(-d/(.10+trail*1.4))*smooth((2.7-d)/.6):0;power=Math.max(power,head,tail*.68);hot=Math.max(hot,head)}
  return {power:ring*power,color:mix(c,accent,hot)};
 }
 if(l.type==='scanner'){
  const u=(x-(x0+x1)/2)*co+(y-(y0+y1)/2)*si,half=Math.max(.1,(Math.abs(co)*dx+Math.abs(si)*dy)/2),width=.38+1.55*w,distance=(half+width*1.8)*(.45+.55*spread),progress=z*.20+phase;
  const center=l.scanMode==='loop'?dir*distance*(2*mod(progress,1)-1):-dir*distance*Math.cos(tau*progress),travel=l.scanMode==='loop'?dir:dir*(Math.sin(tau*progress)>=0?1:-1),signed=(center-u)*travel,head=Math.exp(-(((u-center)/width)**2)),tail=signed>0&&trail>0?Math.exp(-signed/(.25+trail*4.5))*.58:0;
  const seam=l.scanMode==='loop'?smooth(Math.min(mod(progress,1),1-mod(progress,1))/.055):1,turn=l.scanMode==='loop'?1:smooth(Math.abs(Math.sin(tau*progress))/.22);
  return {power:Math.max(head,tail*turn)*seam,color:mix(c,accent,head*seam)};
 }
 const u=(x-x0)*co+(y-y0)*si,v0=-(x-x0)*si+(y-y0)*co,vv=[0,-dx*si,dy*co,-dx*si+dy*co],low=Math.min(...vv),high=Math.max(...vv),v=dir<0?high-v0:v0-low,spacing=.85+(1-spread)*.9,lane=Math.floor(u/spacing+.5),seed=(i,k)=>mod(i*137+k*191+97,997)/997;
 const rate=1.5+seed(lane,1)*2.1,length=Math.max(1,high-low),tailLen=.25+trail*3.1,age=z*rate+seed(lane,2)*(length+4)+phase*(length+4),period=length+2+tailLen,cycle=Math.floor(age/period),head=mod(age,period)-1;
 if(seed(lane+cycle*31,3)>.22+.78*l.rainDensity/100)return {power:0,color:c};
 const off=Math.abs(u-lane*spacing),horizontal=Math.exp(-((off/(.22+.65*w))**2)),dist=head-v,hot=Math.exp(-((dist/(.24+.58*w))**2)),wake=dist>0&&trail>0?Math.exp(-dist/Math.max(.1,tailLen))*.65:0;
 const cyclePos=mod(age,period),envelope=smooth(Math.min(cyclePos,period-cyclePos)/.55);
 return {power:horizontal*Math.max(hot,wake)*envelope,color:mix(c,accent,hot)};
}
// Shared signature reference equations; mirrored by Python for the actual LEDs.
function signatureFlow(l,k,t){
 const [u,v]=keyUV(k),i=signatureIndex(l),speed=(.35+l.speed/100*2.4)/1.67,scale=(.5+l.spread/100*1.8)/1.58;
 const x=u*.96+.02,y=.16+v*.72,z=t*speed*(l.direction==='left'?-1:1),w=.5+.5*Math.sin(x*6/scale-y*4+z*.6);
 const colors=[l.color,l.secondary||l.color,l.gradient?.[2]||l.secondary||l.color,l.gradient?.[3]||l.gradient?.[2]||l.secondary||l.color].map(hexToRGB);
 let c=mix(colors[0],colors[1],w);
 if(i===2)c=mix(colors[0],colors[2],(.5+.5*Math.sin(x*8/scale+y*7+z*.45))*.55);
 if(i===4)c=mix(colors[0],colors[2],x*.85);
 if(i===5)c=mix(colors[0],colors[2],w*.6);
 if(i===8)c=mix(mix(colors[0],colors[2],w),colors[3],(.5+.5*Math.sin(x*10/scale-y*4-z*.45))*.55);
 if(i===9)c=colors[0];
 return c;
}
function signatureResponse(l,k,t,events){
 const i=signatureIndex(l),speed=(.35+l.speed/100*2.4)/1.67,spread=(.5+l.spread/100*1.8)/1.58,fade=.55+(1-l.fade/100)*1.2857142857;
 let power=0;
 for(const p of events){const age=t-p.start;if(age<0||age>l.duration/10)continue;
  const d=Math.hypot((k.x-p.x)/(l.aspect/100),k.y-p.y)*40/spread,a=age*speed,dec=age*fade*speed;
  let v=0;
  if(i===0)v=Math.exp(-(((d-a*200)/43)**2))*Math.exp(-dec*1.6);
  else if(i===1)v=Math.exp(-(((d-a*245)/65)**2))*Math.exp(-dec*1.9);
  else if(i===2)v=Math.exp(-d/45-dec*1.8)*(.7+.3*Math.cos(a*22+d));
  else if(i===3)v=Math.exp(-d/32-dec*2);
  else if(i===4)v=Math.exp(-(((d-a*115)/85)**2))*Math.exp(-dec*1.5);
  else if(i===5)v=Math.exp(-d*d/(900+a*3800))*Math.exp(-dec*1.2);
  else if(i===6)v=Math.exp(-d*d/(600+a*6000))*Math.exp(-dec*1.7);
  else if(i===7)v=Math.exp(-(((d-a*140)/38)**2))*Math.exp(-dec*1.4);
  else if(i===8)v=Math.exp(-(((d-a*160)/55)**2))*Math.exp(-dec);
  else v=Math.exp(-d/26-dec*1.4);
  power+=v*smooth((l.duration/10-age)/.35);
 }
 return clamp(power);
}
function effectAt(layer,k,t){
 const sx=k.x,sy=k.y,b=layer.brightness/100,speed=(.35+layer.speed/100*2.4),spread=.5+layer.spread/100*1.8,dir=layer.direction==='left'?-1:1;
 let strength=0,col=hexToRGB(layer.color);
 if(Array.isArray(layer.targets)&&layer.targets.length&&!layer.targets.includes(k.code))return {color:col,strength:0};
 const m={...MOTION_DEFAULTS,...SHAPE_DEFAULTS,...layer},secondary=hexToRGB(layer.secondary||'#B79BFF');
 if(layer.type==='signature_flow'){strength=1;col=signatureFlow(m,k,t)}else if(layer.type==='signature_response'){strength=signatureResponse(m,k,t,layer===catalogPreview?[{x:9,y:3,start:t-(t%3.1)},{x:4,y:2,start:t-((t+1.4)%3.1)}]:pulseEvents)}else if(layer.type==='static'||layer.type==='prism'){strength=1;if(layer.type==='prism'||layer.gradient?.length>1){const [u,v]=keyUV(k);col=gradientAt(layer,u,v,t)}}else if(REACTIVE.has(layer.type)){
  let power=0;
  for(const p of (layer===catalogPreview?[{x:9,y:3,start:t-(t%3.1)},{x:4,y:2,start:t-((t+1.4)%3.1)}]:pulseEvents)){
   const age=t-p.start;
   if(age<0 || age>m.duration/10)continue;
   const dx0=(sx-p.x)/(m.aspect/100),dy0=sy-p.y,shape=layer.type==='ripple'?m.pulseShape:'circle',d=shape==='diamond'?Math.abs(dx0)+Math.abs(dy0):shape==='square'?Math.max(Math.abs(dx0),Math.abs(dy0)):shape==='horizontal'?Math.abs(dy0):shape==='vertical'?Math.abs(dx0):Math.hypot(dx0,dy0);
   const r=age*(1.8+speed*1.9)*spread;
   const thickness=(.9+layer.fade/100*1.5)*(.45+m.width/100*1.1);
   let ring=Math.exp(-Math.pow((d-r)/thickness,2)*1.4);
   const dec=Math.exp(-age*(.55+(100-layer.fade)/100*1.2))*smooth((m.duration/10-age)/.65);
   if(layer.type==='bloom')ring=Math.exp(-Math.pow(d/(.5+age*speed*spread),2))*smooth((m.duration/10-age)/(m.duration/10));
   if(layer.type==='comet'){const a=m.angle*Math.PI/180,dx=sx-p.x,dy=sy-p.y,u=(dx*Math.cos(a)+dy*Math.sin(a))*dir,v=-dx*Math.sin(a)+dy*Math.cos(a);ring=.9*Math.exp(-Math.pow((u-r)/thickness,2)-Math.pow(v/(.75+spread*.45),2))+.35*Math.exp(-Math.pow(d/.6,2)-age*6);}
   power=1-(1-power)*(1-clamp(ring*dec));
  }
  strength=clamp(power);
  col=hexToRGB(layer.color);
 }else if(layer.type==='spring'){
  const [x0,x1,y0,y1]=bounds(),theta=m.angle*Math.PI/180,cx=9+(m.originX/100-.5)*(x1-x0),cy=2.7+(m.originY/100-.5)*(y1-y0),axis=layer.direction==='radial'?Math.hypot((sx-cx)/(m.aspect/100),sy-cy):(sx*Math.cos(theta)+sy*Math.sin(theta))*dir;
  const v=Math.sin(axis*.57/spread-t*speed*2.1+m.phase/100*2*Math.PI);
  strength=.31+.66*smooth((v+1)/2);
  col=adjustedColor(layer.color,axis*.42-t*speed*.7);
 }else if(layer.type==='flower'){
  const [x0,x1,y0,y1]=bounds(),dx=(sx-9-(m.originX/100-.5)*(x1-x0))/(m.aspect/100),dy=(sy-2.45-(m.originY/100-.5)*(y1-y0))*2.9;
  const a=Math.atan2(dy,dx)+m.angle*Math.PI/180,r=Math.hypot(dx,dy);
  const petal=Math.sin(a*m.petals-t*speed*.86+r*.34/spread+m.phase/100*2*Math.PI);
  strength=(.16+.82*smooth((petal+1)/2))*(.65+.35*smooth((Math.cos(r*.48-t*speed)+1)/2));
  col=adjustedColor(layer.color,a*2+t);
 }else if(layer.type==='circle'){
  const [x0,x1,y0,y1]=bounds(),dx=(sx-9-(m.originX/100-.5)*(x1-x0))/(m.aspect/100),dy=(sy-2.5-(m.originY/100-.5)*(y1-y0))*2.8,r=Math.hypot(dx,dy);
  const v=Math.sin(r*(1.16/spread)-t*speed*1.8*dir+m.phase/100*2*Math.PI);
  strength=.09+.9*smooth((v+.72)/1.65);
  col=adjustedColor(layer.color,r*.5-t*speed*.8);
 }else if(['aurora','silk','tide','ember','stardust'].includes(layer.type)){
  const theta=m.angle*Math.PI/180,u=(sx-9)*Math.cos(theta)+(sy-3)*Math.sin(theta),v=-(sx-9)*Math.sin(theta)+(sy-3)*Math.cos(theta),z=t*speed*dir+m.phase/100*Math.PI*2,f=u/spread,w=.35+m.width/100*1.3;let a,b;
  if(layer.type==='aurora'){a=Math.sin(f*.53+Math.sin(v*.8+z*.48)*1.25-z*.7);b=Math.sin(f*.24+v*.65+z*.35);strength=.16+.84*smooth((a+b*.42+1.42)/2.84);col=mix(col,secondary,smooth((b+1)/2));}
  else if(layer.type==='silk'){a=Math.sin(f*.85+Math.sin(v*.68-z*.43)*1.45-z);strength=.12+.88*Math.exp(-Math.pow(a/(.35+w*.45),2));col=mix(col,secondary,smooth((Math.sin(f*.28+z*.33)+1)/2));}
  else if(layer.type==='tide'){a=Math.sin(f*.45-z*.7+Math.sin(v*.8+z*.35)*.85);b=Math.sin(f*.23+z*.44-v*.45);strength=.15+.85*smooth((a+b*.65+1.65)/3.3);col=mix(col,secondary,smooth((a+1)/2));}
  else if(layer.type==='ember'){a=Math.sin(f*.72+v*.91-z*.8);b=Math.sin(f*1.13-v*.5+z*.49);strength=.05+.95*Math.pow(smooth((a+b+2)/4),2);col=mix(col,secondary,strength);}
  else {let seed=Math.sin(sx*127.1+sy*311.7)*43758.5453;seed-=Math.floor(seed);a=(Math.sin(z*(.45+seed*.7)+seed*Math.PI*2)+1)/2;strength=.07+.93*Math.pow(a,3.5/w);col=mix(col,secondary,seed);}
 }else if(['orbit','scanner','rain'].includes(layer.type)){
  const motion=motionPixel(m,k,t,bounds());strength=motion.power;col=motion.color;
 }else if(AUDIO.has(layer.type)){
  const audio=layer===catalogPreview?demoAudio(t):(isAudioOn||audioStatus.demo)?audioStatus:{},gain=m.sensitivity/50,width=.045+m.audioWidth/100*.20;
  let [u,v]=keyUV(k);if(dir<0)u=1-u;
  const vol=audio.volume||0,idx=Math.min(17,Math.floor(u*18)),bass=audio.bass||0;strength=0;
  if(['music','beat'].includes(layer.type)){const r=rhythmPixel(layer.type,audio,u,v,gain,width,speed,col,secondary,audio.receivedAt==null?0:Math.max(0,performance.now()/1000-audio.receivedAt));strength=r.power;col=r.color;}
  else if(layer.type==='spectrum'){const pixel=spectrumPixel(layer,audio,k);strength=pixel.power;col=pixel.color;}
  else if(layer.type==='audio_visualizer'){if(!['BoardLogo','LightButton','GameMode'].includes(k.code)){const [, , , bottom,top]=bounds(),pixel=visualizerPixel(layer,audio,u,clamp((k.y-top)/Math.max(.1,bottom-top)));strength=pixel.power;col=pixel.color;}}
  else if(layer.type==='waveform'){const sample=Math.max(-1,Math.min(1,lerpSample(audio.trace||audio.wave,u)*gain*(.25+(layer.waveGain??50)/40)));strength=Math.exp(-Math.pow((v-(.5-.45*sample))/Math.max(.09,width),2))*clamp(vol*gain*5);col=mix(col,secondary,Math.abs(sample));}
  else if(layer.type==='audio_wave'){const amp=1-Math.exp(-Math.max(0,lerpSample(audio.envelope||audio.wave?.map(Math.abs),u))*gain*(.25+(layer.waveGain??50)/40)*2),edge=layer.waveMirror===false?1-v:Math.abs(v-.5)*2;strength=smooth((amp-edge+width)*5)*clamp(amp*8)*clamp(vol*gain*5);col=mix(col,secondary,clamp(edge));}
  else if(layer.type==='stereo'){const h=clamp((audio.stereo?.[u<.5?0:1]||0)*gain);strength=smooth((h-Math.abs(u-.5)*2+.08)*7)*Math.min(1,h*5);col=mix(col,secondary,u);}

 }
 if(!AUDIO.has(layer.type)&&layer.type!=='static'){strength=clamp(strength);strength=m.motionCurve==='soft'?smooth(strength):m.motionCurve==='sharp'?strength**2.2:m.motionCurve==='linear'?Math.sqrt(strength):strength}
 if(!['static','prism','spectrum','signature_flow'].includes(layer.type)&&layer.gradient?.length>1)col=paletteAt(layer.gradient.map(hexToRGB),clamp(strength));
 if(layer.type!=='static'){strength=Math.pow(clamp(strength),2**((m.contrast/100-.5)*2));if(!REACTIVE.has(layer.type))strength=m.floor/100+(1-m.floor/100)*strength;}
 return {color:col,strength:clamp(strength*b)};
}
// The keycap material is baked offline. Only the small diffuse LED map and
// transmissive legends change per frame. Geometry is shared with the DOM hit regions.
const lightSprites=new Map();
function lightSprite(color){const key=color.map(v=>Math.round(v/17)*17).join(',');if(lightSprites.has(key))return lightSprites.get(key);const c=document.createElement('canvas');c.width=c.height=64;const ctx=c.getContext('2d');const g=ctx.createRadialGradient(32,32,0,32,32,32);g.addColorStop(0,`rgba(${key},.94)`);g.addColorStop(.32,`rgba(${key},.48)`);g.addColorStop(.68,`rgba(${key},.09)`);g.addColorStop(1,`rgba(${key},0)`);ctx.fillStyle=g;ctx.fillRect(0,0,64,64);if(lightSprites.size>=128)lightSprites.delete(lightSprites.keys().next().value);lightSprites.set(key,c);return c;}
function ledOptics(rgb){const light=Math.max(...rgb),energy=Math.pow(light/255,.92),hue=light?rgb.map(v=>Math.round(v/light*255)):[0,0,0];return {light,energy,hue};}
function legendColor(rgb,base){const {energy,hue}=ledOptics(rgb);const lit=hue.map(v=>Math.min(255,v*.91+20));return rgbToHex(mix(base,lit,Math.pow(energy,.68)));}
function drawBoardLighting(surface){
 surface.queued=false;const c=surface.canvas;if(!c.isConnected||document.hidden||!c.getClientRects().length){surface.dirty=true;return;}surface.dirty=false;
 const ctx=c.getContext('2d');ctx.setTransform(1,0,0,1,0,0);ctx.clearRect(0,0,c.width,c.height);
 // CSS positions the keys against 6.38 units, not the canvas aspect ratio.
 ctx.setTransform(c.width/18.45,0,0,c.height/6.38,0,0);ctx.globalCompositeOperation='source-over';
 for(const k of surface.keys){const rgb=k.previewRGB;if(!rgb)continue;const {light,energy,hue}=ledOptics(rgb);if(light<2)continue;
  const g=k.geometry,sprite=lightSprite(hue),n=Math.max(1,Math.ceil(g.w/1.15));
  const pool=(cx,cy,rx,ry,power)=>{ctx.globalAlpha=energy*power;ctx.drawImage(sprite,cx-rx,cy-ry,rx*2,ry*2)};
  // Multiple small pools along wide caps instead of stretching one huge halo.
  for(let i=0;i<n;i++){const x=g.x+g.w*(i+.5)/n,r=Math.min(.72,g.w/n*.52+.07);pool(x,g.y+.20,r,.31,.40);pool(x,g.y+g.h-.15,r,.27,.23);}
 }
 ctx.globalAlpha=1;ctx.globalCompositeOperation='source-over';
}
function queueBoardLighting(surface){if(!surface||surface.queued)return;surface.queued=true;requestAnimationFrame(()=>drawBoardLighting(surface))}
function paintKeyVisual(obj,color){
 if(obj.lastColor===color){if(obj.lightSurface?.dirty)queueBoardLighting(obj.lightSurface);return;}obj.lastColor=color;
 const rgb=hexToRGB(color),{energy,hue}=ledOptics(rgb);obj.previewRGB=rgb;
 const base=obj.code==='BoardLogo'?[36,36,37]:obj.geometry?[99,100,102]:[57,58,59];const fg=legendColor(rgb,base);
 const glow=`rgb(${hue.join(' ')} / ${(.32*energy).toFixed(3)})`;
 const el=obj.el;el.style.setProperty('--rgb',color);el.style.setProperty('--key-foreground',fg);
 el.style.setProperty('--key-glow',glow);el.style.setProperty('--key-text-glow',glow);el.style.setProperty('--key-spill','transparent');
 el.style.setProperty('--surface-tint',`rgb(${hue.join(' ')} / ${(.085*energy).toFixed(3)})`);
 queueBoardLighting(obj.lightSurface);
}
// Same temporal envelope as engine; raw rendering remains deterministic.
const previewMemory=new Map();let previewSampleAt=null,previewSettling=false;
function filterRGB(target,prev,dt,profile){const [attack,release]=MOTION_PROFILES[profile]||MOTION_PROFILES.balanced;const a=-Math.expm1(-clamp(dt,0,.25)/(Math.max(...target)>=Math.max(...prev)?attack:release));return prev.map((v,i)=>{const n=v+(target[i]-v)*a;return Math.abs(n-target[i])<.65?target[i]:n})}
function paintFrame(t,updateDOM=true,temporal=false){
 const elapsed=previewSampleAt==null?1/60:t-previewSampleAt;const dt=elapsed>.25?1/60:elapsed;
 const blendTime=updateDOM&&temporal&&state.running&&!catalogPreview&&dt>=0&&dt<.25;
 if(updateDOM){previewSampleAt=t;previewSettling=false;}
 // Remove old pulses before evaluating (key-down events are never written to disk).
 pulseEvents=pulseEvents.filter(p=>t-p.start<8);
 const frame={};
 const demoLayer=audioStatus.demo?state.layers.find(l=>l.id===audioStatus.demo_layer&&AUDIO.has(l.type)&&l.enabled):null;
 const ordered=catalogPreview?[catalogPreview]:demoLayer?[demoLayer]:[...state.layers].reverse();if(state.reactivePriority===true)ordered.sort((a,b)=>Number(dynamicEffect(a.type))-Number(dynamicEffect(b.type)));
 const enabledLayers=ordered.filter(layer=>layer.enabled&&(catalogPreview||demoLayer||soloLayerId==null||soloLayerId===layer.id));
 for(const k of keyboardKeys){
  const fixed=catalogPreview||demoLayer?null:state.keyColors[k.code];
  let composite=fixed?hexToRGB(fixed):[0,0,0];
  for(const layer of enabledLayers){
   if(fixed&&(state.fixedColorMode==='fixed'||!dynamicEffect(layer.type)))continue;
   if(layer.targets?.length&&!layer.targets.includes(k.code))continue;
   if(layer.type==='spectrum'&&layer.barBlack&&!['BoardLogo','LightButton','GameMode'].includes(k.code)&&(!layer.barMain||k.x<15.45))composite=[0,0,0];
   const {color,strength}=effectAt(layer,k,t);
   const mode=fixed||dynamicEffect(layer.type)&&state.reactivePriority===true?'normal':(layer.blend||'normal');
   if(mode==='add')composite=composite.map((v,i)=>Math.min(255,v+color[i]*strength));
   else if(mode==='max')composite=composite.map((v,i)=>Math.max(v,color[i]*strength));
   else if(mode==='replace'&&strength>0)composite=mix([0,0,0],color,strength);
   else composite=mix(composite,color,strength);
  }
  if(updateDOM&&!catalogPreview&&previewTransition){const u=clamp((t-previewTransition.start)/Math.max(.001,previewTransition.ms/1000));composite=mix(hexToRGB(previewTransition.frame[k.code]||'#000000'),composite,smooth(u));}
  if(updateDOM){
   const target=hexToRGB(rgbToHex(composite));const prev=previewMemory.get(k.code)||target;
   const value=blendTime?filterRGB(target,prev,dt,state.layers.some(l=>l.enabled&&AUDIO.has(l.type)&&(soloLayerId==null||soloLayerId===l.id))?'responsive':motionProfile):target;
   previewMemory.set(k.code,value);if(value.some((v,i)=>v!==target[i]))previewSettling=true;
   composite=gameMask(k.code,value); // mask after smoothing
  }
  frame[k.code]=rgbToHex(composite);
  if(!updateDOM)continue;
  (keyLookup.get(k.code)||[]).forEach(obj=>{const el=obj.el;if(el.isConnected&&obj.view===activeView)paintKeyVisual(obj,frame[k.code]);});
 }
 return frame;
}
async function apiFetch(path,options={}){const send=()=>fetch(path,{...options,headers:{...options.headers,'X-Lume-Token':secret}});let r=await send();if(r.status===403){try{const next=await(await fetch('/api/token',{headers:{'X-Lume-Bootstrap':'1'}})).json();if(typeof next.token==='string'&&next.token!==secret){secret=next.token;r=await send()}}catch{}}return r}
async function post(path,body){
 const response=await fetch(path,{method:'POST',headers:{'Content-Type':'application/json','X-Lume-Token':secret},body:JSON.stringify(body)});
 const data=await response.json();if(!response.ok)throw Error(data.error||'request failed');return data;
}
let previewDirty=true,lastPreviewFrame=0;
function needsPreview(now){return previewDirty||previewSettling||!!catalogPreview||!!previewTransition||!!audioStatus.demo||state.running&&state.layers.some(l=>l.enabled&&(soloLayerId==null||soloLayerId===l.id)&&(REACTIVE.has(l.type)?pulseEvents.some(p=>now/1000-p.start<=(l.duration??36)/10+.1):AUDIO.has(l.type)?isAudioOn:l.type!=='static'));}
function animation(now){
 if(!document.hidden&&(activeView==='lighting'||activeView==='keyboard')&&needsPreview(now)&&now-lastPreviewFrame>=15&&(state.running||previewDirty||catalogPreview||previewTransition)){
  paintFrame(now/1000,true,true);previewDirty=false;lastPreviewFrame=now;
  frameCount++;

 }
 if(now-lastTime>1600){$('fpsInfo').textContent=frameCount?Math.round(frameCount*1000/(now-lastTime))+' FPS':'待機中';frameCount=0;lastTime=now}
 if(previewTransition&&now/1000-previewTransition.start>=previewTransition.ms/1000)previewTransition=null;
 if(activeView==='profiles'&&hoveredPreset&&hoveredPreset.visible&&!document.hidden&&now-hoveredPreset.last>=15){hoveredPreset.last=now;paintThumbnail(hoveredPreset,1.42+(now-hoveredPreset.start)/1000);}
 requestAnimationFrame(animation);
}
let sceneTimer=null,sceneChain=Promise.resolve(),liveBusy=false,engineStatus={};
function scenePayload(){return {layout:state.layout,keys:keyboardKeys.map(({code,x,y})=>({code,x,y})),layers:state.layers.map(l=>({...l,enabled:l.enabled&&(soloLayerId==null||soloLayerId===l.id)})),keyColors:{...state.keyColors},fixedColorMode:state.fixedColorMode||'reactive',reactivePriority:state.reactivePriority===true,running:state.running,motionProfile}}
function sendScene(){clearTimeout(sceneTimer);const payload=JSON.parse(JSON.stringify({...scenePayload(),...(transitionRequest?{transition:transitionRequest}:{})}));transitionRequest=null;sceneChain=sceneChain.catch(()=>{}).then(()=>post('/api/scene',payload));return sceneChain}
function scheduleScene(){if(!secret||!keyboardKeys.length||!hardware.active)return;clearTimeout(sceneTimer);sceneTimer=setTimeout(()=>sendScene().catch(e=>toast('設定送信: '+e.message)),70)}
async function setLive(on){if(liveBusy)return false;liveBusy=true;$('liveToggle').disabled=true;try{if(on){if(!hardware.active)throw Error('先にキーボードに接続してください');await sendScene()}const r=await post('/api/live',{enabled:on});isLive=!!r.engine.active;engineStatus=r.engine;$('liveToggle').checked=isLive;updateConnectionUI();return isLive===on}catch(e){toast(e.message);$('liveToggle').checked=isLive;return false}finally{liveBusy=false;$('liveToggle').disabled=false}}
function currentLayer(){return state.layers.find(x=>x.id===state.selectedLayer)||state.layers[0]}
function serializeState(){return JSON.stringify({...presetState(),profileName:$('currentProfileName').textContent,editingPreset})}
function historyKey(snap){try{const x=JSON.parse(snap);delete x.selectedLayer;return JSON.stringify(x)}catch{return snap}}
function updateHistoryButtons(){ $('undoBtn').disabled=!undoStack.length; $('redoBtn').disabled=!redoStack.length;const b=$('saveProfileBtn');b.title=editingPreset?'編集中のプリセットを更新（Ctrl+S）':'プリセットを保存（Ctrl+S）';$('editPresetLabel').hidden=!editingPreset;$('renamePresetBtn').hidden=!editingPreset; }
function savePreferences(patch){Object.assign(preferences,patch);if(!secret)return Promise.resolve();prefChain=prefChain.catch(()=>{}).then(()=>post('/api/preferences',patch));return prefChain}
function editorSnapshot(){return {...presetState(),editingPreset,profileName:$('currentProfileName').textContent}}
let draftWriteSerial=0;
function persistState(){previewDirty=true;scheduleScene();try{localStorage.setItem('lume-pro-state',JSON.stringify({...state,selectedKeys:[],running:true,volume:0}))}catch{}if(initializing)return;const serial=++draftWriteSerial;$('saveState').textContent='作業内容を保存中…';clearTimeout(prefTimer);prefTimer=setTimeout(()=>savePreferences({editor:editorSnapshot()}).then(()=>{if(serial===draftWriteSerial)$('saveState').textContent='作業内容を自動保存済み'}).catch(()=>{if(serial===draftWriteSerial)$('saveState').textContent='作業内容の保存に失敗'}),120)}
async function autoConnect(){if(connectionBusy||!preferences.auto||hardware.active)return;connectionBusy=true;$('detectBtn').disabled=true;try{const r=await post('/api/auto_connect',{});hardware=r.hardware;updateConnectionUI();updateDiag();if(r.ok){if(preferences.hook&&!isHook)await toggleHook(true);if(preferences.live)await setLive(true);toast('前回の接続方式で自動接続しました')}else{$('connectionMessage').textContent=r.error||hardware.error||'自動接続に失敗しました'}}catch(e){$('connectionMessage').textContent='自動接続: '+e.message}finally{connectionBusy=false;$('detectBtn').disabled=false}}

function remember(){
 updatePreviewTools();const snap=serializeState();
 if(historyKey(snap)!==historyKey(recordedSnapshot)){if(recordedSnapshot)undoStack.push(recordedSnapshot);undoStack=undoStack.slice(-70);redoStack=[];recordedSnapshot=snap;updateHistoryButtons()}
 recordedSnapshot=snap;persistState();
}
function restoreSnapshot(snap){
 try{const data=JSON.parse(snap);if(!validEditor(data))return;state={...BASE(),...data,selectedKeys:[],running:true,volume:0};if(!state.layers.some(x=>x.id===state.selectedLayer))state.selectedLayer=state.layers[0].id;editingPreset=data.editingPreset||null;$('currentProfileName').textContent=data.profileName||'新規プロファイル';soloLayerId=null;recordedSnapshot=snap;setLayout(state.layout,false);refreshAll();persistState();updateHistoryButtons()}
 catch(e){console.error('履歴の復元に失敗しました',e)}
}
function undo(){if(!undoStack.length)return;redoStack.push(recordedSnapshot);restoreSnapshot(undoStack.pop());toast('元に戻しました')}
function redo(){if(!redoStack.length)return;undoStack.push(recordedSnapshot);restoreSnapshot(redoStack.pop());toast('やり直しました')}
function setPickerOpen(v,mode='add'){clearCatalogPreview();if(v){setInspector(false);closeLayerMenu();$('effectSearch').value='';$('effectCategory').value='all';refreshCatalog();$('effectsCatalog').scrollTop=0}else if(pickerOpen)$('newLayerBtn').focus({preventScroll:true});$('effectPicker').inert=!v;pickerOpen=v;pickerMode=mode;$('effectPicker').classList.toggle('open',v);$('effectPicker').setAttribute('aria-hidden',String(!v));animatePickerInset(v);$('newLayerBtn').setAttribute('aria-expanded',String(v));if(v){document.querySelector('.picker-head strong').textContent=mode==='change'?'エフェクトを変更':'エフェクトを追加';$('effectSearch').focus({preventScroll:true})}}

const EFFECT_PALETTES={audio_visualizer:['#FFFFFF','#B8D8FF'],signature_flow:['#102B50','#226EB8'],signature_response:['#E8FBFF','#72D9FF'],spectrum:['#1157F5','#16E7F2'],orbit:['#655BDE','#B6C9FF'],scanner:['#25B9B5','#B3FFF2'],rain:['#2369B2','#A4EEFF'],prism:['#624CE8','#31B6EF','#62F7C8','#F0B5FF'],aurora:['#4363E8','#76EEC5'],silk:['#A58AE8','#D9E7FF'],tide:['#3280C9','#85D8E9'],ember:['#EB5730','#FFBF6A'],stardust:['#8681D8','#E0DCFF'],audio_wave:['#76F3E1','#75B8F8'],waveform:['#76F3E1','#75B8F8']};
function freshEffect(type){const p=EFFECT_PALETTES[type]||['#76F3E1','#B79BFF'];return {...MOTION_DEFAULTS,...SHAPE_DEFAULTS,...(type==='spectrum'?BAR_DEFAULTS:{}),type,...(SIGNATURE_TYPES.has(type)?{signatureStyle:'GLACIER'}:{}),color:p[0],secondary:p[1],brightness:(['orbit','scanner','rain'].includes(type)?100:85),speed:({orbit:35,scanner:40,rain:42}[type]??55),spread:({orbit:80,scanner:100,rain:80}[type]??60),width:({orbit:60,scanner:34,rain:58}[type]??50),motionTrail:({orbit:70,scanner:28,rain:70}[type]??45),rainDensity:type==='rain'?75:55,fade:65,direction:'right',blend:'normal',enabled:true,targets:[],gradient:['prism','spectrum'].includes(type)?[...p]:[],gradientMode:'linear',gradientAngle:0,waveGain:50,waveMirror:true,...(type==='audio_visualizer'?{waveMix:45,waveTrail:18,waveBeat:30,waveIdle:false}: {})};}
function clearCatalogPreview(){if(catalogPreview){catalogPreview=null;previewDirty=true;if(!state.running&&keyboardKeys.length)paintFrame(performance.now()/1000)}if($('catalogPreviewStatus'))$('catalogPreviewStatus').textContent='カーソルで試す · クリックで追加';document.querySelectorAll('.effect-card.previewing').forEach(b=>b.classList.remove('previewing'))}
function showCatalogPreview(btn){if(!pickerOpen)return;const id=btn.dataset.effect;catalogPreview=freshEffect(id);document.querySelectorAll('.effect-card').forEach(b=>b.classList.toggle('previewing',b===btn));$('catalogPreviewStatus').textContent=EFFECTS[id].name+' · '+(AUDIO.has(id)?'サンプル波形':'ライブプレビュー')+'（実機は変更しません）';}
function refreshCatalog(){
 clearCatalogPreview();const selected=currentLayer(),category=$('effectCategory').value;$('effectsCatalog').scrollTop=0;
 const group=(id,e)=>e.category||(id==='static'?'static':id==='ripple'?'reactive':'ambient');
 const entries=Object.entries(EFFECTS).filter(([id,e])=>(category==='all'||group(id,e)===category)&&[e.name,e.en,e.short,e.desc,id].join(' ').toLowerCase().includes(($('effectSearch').value||'').trim().toLowerCase()));
 const sections=[['static','固定色'],['reactive','キー反応'],['ambient','アンビエント'],['audio','音声連動']];
 $('effectsCatalog').innerHTML=sections.map(([g,label])=>{const items=entries.filter(([id,e])=>group(id,e)===g);if(!items.length)return '';return `<section class="catalog-section"><h3>${label}<span>${items.length}</span></h3><div class="catalog-grid">${items.map(([id,e])=>{const p=EFFECT_PALETTES[id]||['#76F3E1','#B79BFF'];return `<button class="effect-card ${selected?.type===id?'active':''}" data-effect="${id}" title="${e.desc}"><span class="effect-symbol" style="--tile-a:${p[0]};--tile-b:${p[1]}">${effectIcon(id)}</span><b>${e.name}</b><small>${e.en}</small></button>`}).join('')}</div></section>`}).join('')||'<p class="field-help">一致するエフェクトがありません</p>';
 $('effectCount').textContent=entries.length+' 件';
 document.querySelectorAll('[data-effect]').forEach(btn=>{btn.addEventListener('pointerenter',()=>showCatalogPreview(btn));btn.addEventListener('pointerleave',clearCatalogPreview);btn.addEventListener('focus',()=>showCatalogPreview(btn));btn.addEventListener('blur',clearCatalogPreview);btn.addEventListener('click',()=>{
  if(pickerOpen&&pickerMode==='add'){addLayer(btn.dataset.effect)}else{Object.assign(selected,freshEffect(btn.dataset.effect),{id:selected.id,targets:selected.targets,enabled:selected.enabled,brightness:selected.brightness});refreshAll();remember()}
  setPickerOpen(false);inspectorTab='basic';setInspector(true);
  if(AUDIO.has(currentLayer().type))toast('基本設定から音声取得を開始できます');
 });});
}
function closeLayerMenu(restore=false){const old=layerMenuId;layerMenuId=null;const menu=$('layerMenu');menu.classList.remove('open');menu.inert=true;document.querySelectorAll('.layer-more').forEach(b=>b.setAttribute('aria-expanded','false'));if(restore&&old!=null)document.querySelector(`.layer-item[data-id="${old}"] .layer-more`)?.focus({preventScroll:true})}
function layerAction(id,action){const i=state.layers.findIndex(l=>l.id===id);if(i<0)return;const layer=state.layers[i];closeLayerMenu();if(action==='edit'||action==='change'){state.selectedLayer=id;refreshAll();remember();if(action==='change')setPickerOpen(true,'change');else setInspector(true);return}if(action==='duplicate'){addLayer(layer.type,layer);setInspector(true);return}if(action==='solo'){soloLayerId=soloLayerId===id?null:id;refreshLayers();scheduleScene();return}if(action==='remove'){if(state.layers.length<=1){toast('最低1つのレイヤーが必要です');return}state.layers.splice(i,1);if(soloLayerId===id)soloLayerId=null;if(state.selectedLayer===id)state.selectedLayer=state.layers[Math.min(i,state.layers.length-1)].id}else if(action==='up'||action==='down'){const n=i+(action==='up'?-1:1);if(n<0||n>=state.layers.length)return;[state.layers[i],state.layers[n]]=[state.layers[n],state.layers[i]]}refreshAll();remember()}
function openLayerMenu(id,button){if(layerMenuId===id){closeLayerMenu();return}closeLayerMenu();layerMenuId=id;const menu=$('layerMenu'),panel=document.querySelector('.layer-panel'),r=button.getBoundingClientRect(),pr=panel.getBoundingClientRect();menu.style.top=Math.max(8,Math.min(r.bottom-pr.top+5,panel.clientHeight-248))+'px';menu.querySelector('[data-layer-action="solo"]').innerHTML=uiIcon("solo")+(soloLayerId===id?'単独表示を解除':'このレイヤーだけ表示');const i=state.layers.findIndex(l=>l.id===id);menu.querySelector('[data-layer-action="up"]').disabled=i===0;menu.querySelector('[data-layer-action="down"]').disabled=i===state.layers.length-1;menu.querySelector('[data-layer-action="remove"]').disabled=state.layers.length<=1;menu.querySelector('[data-layer-action="duplicate"]').disabled=state.layers.length>=8;menu.inert=false;menu.classList.add('open');button.setAttribute('aria-expanded','true')}
function refreshLayerCommands(){const i=state.layers.findIndex(l=>l.id===state.selectedLayer);$('layerUpQuick').disabled=i<=0;$('layerDownQuick').disabled=i<0||i>=state.layers.length-1;$('layerDuplicateQuick').disabled=i<0||state.layers.length>=8;$('layerRemoveQuick').disabled=i<0||state.layers.length<=1;}
function refreshLayers(){
 previewDirty=true;refreshLayerCommands();
 closeLayerMenu();if(soloLayerId!=null&&!state.layers.some(l=>l.id===soloLayerId))soloLayerId=null;
 $('layerCount').textContent=state.layers.length+'/8';$('newLayerBtn').disabled=state.layers.length>=8;$('soloReset').hidden=soloLayerId==null;$('layerSummary').hidden=soloLayerId!=null;
 $('layerList').innerHTML=state.layers.map((layer,i)=>{const e=EFFECTS[layer.type];return `<div class="layer-item ${layer.id===state.selectedLayer?'active':''} ${!layer.enabled?'disabled-layer':''} ${soloLayerId===layer.id?'solo-layer':''}" data-id="${escapeHtml(layer.id)}" draggable="true" style="--layer-color:${escapeHtml(layer.color)}"><span class="layer-handle" title="ドラッグして並べ替え">${uiIcon("grip")}</span><div class="layer-symbol">${effectIcon(layer.type)}</div><div class="layer-text"><strong>${e.name}</strong><small><i class="layer-swatch"></i><span class="layer-strength">${escapeHtml(layer.brightness)}%</span><span class="layer-target">${layer.targets?.length?layer.targets.length+'キー':'全キー'}</span></small></div><button class="layer-action visible" title="表示切替" aria-pressed="${layer.enabled===true}" aria-label="表示切替">${uiIcon(layer.enabled?"eye":"eyeOff")}</button><button class="layer-action layer-more" title="レイヤー操作" aria-label="レイヤー操作" aria-expanded="false">${uiIcon("more")}</button></div>`}).join('');
 document.querySelectorAll('.layer-item').forEach(row=>{const id=Number(row.dataset.id),layer=state.layers.find(x=>x.id===id);row.tabIndex=0;row.setAttribute('aria-label',EFFECTS[layer.type].name);row.setAttribute('aria-current',String(layer.id===state.selectedLayer));row.addEventListener('click',e=>{if(e.target.closest('button'))return;state.selectedLayer=id;document.querySelector('.panel-scroll').scrollTop=0;document.querySelectorAll('.layer-item').forEach(r=>{r.classList.toggle('active',r===row);r.setAttribute('aria-current',String(r===row))});renderInspector();refreshLayerCommands();remember();setInspector(true)});row.addEventListener('keydown',e=>{if(e.target===row&&['Enter',' '].includes(e.key)){e.preventDefault();row.click()}});row.addEventListener('contextmenu',e=>{e.preventDefault();openLayerMenu(id,row.querySelector('.layer-more'))});
 row.addEventListener('dragstart',e=>{closeLayerMenu();row.classList.add('dragging');e.dataTransfer.setData('text/plain',String(id));e.dataTransfer.effectAllowed='move'});row.addEventListener('dragend',()=>{row.classList.remove('dragging');document.querySelectorAll('.drop-target').forEach(r=>r.classList.remove('drop-target'))});row.addEventListener('dragover',e=>{e.preventDefault();row.classList.add('drop-target');e.dataTransfer.dropEffect='move'});row.addEventListener('dragleave',()=>row.classList.remove('drop-target'));row.addEventListener('drop',e=>{e.preventDefault();const from=Number(e.dataTransfer.getData('text/plain'));const a=state.layers.findIndex(l=>l.id===from),b=state.layers.findIndex(l=>l.id===id);if(a<0||b<0||a===b)return;const [v]=state.layers.splice(a,1);state.layers.splice(b,0,v);refreshLayers();remember()});
 row.querySelector('.visible').addEventListener('click',e=>{e.stopPropagation();layer.enabled=!layer.enabled;refreshLayers();remember()});row.querySelector('.layer-more').addEventListener('click',e=>{e.stopPropagation();openLayerMenu(id,e.currentTarget)});
 });
}
// Only animate intentional navigation, never the render loop or slider updates.
const inspectorAnimations=new Map();
function cancelInspectorAnimations(){for(const a of inspectorAnimations.values())a.cancel();inspectorAnimations.clear()}
function animateInspector(el,frames,options){if(!el||!motionAllowed()||document.hidden||activeView!=='lighting'||!document.querySelector('.inspector').classList.contains('revealed'))return;inspectorAnimations.get(el)?.cancel();const a=el.animate(frames,{duration:360,easing:'cubic-bezier(.45,0,.2,1)',...options});inspectorAnimations.set(el,a);const clear=()=>{if(inspectorAnimations.get(el)===a)inspectorAnimations.delete(el)};a.onfinish=clear;a.oncancel=clear}
function setAccordionOpen(p,open){p.classList.toggle('open',open);p.querySelector('.accordion-trigger').setAttribute('aria-expanded',String(open));p.querySelector('.accordion-clip').inert=!open}
function setInspectorTab(tab,{reset=false,animate=false}={}){
 const groups={basic:['color','intensity'],motion:['motion'],keys:['keys'],advanced:['inputs']};if(!groups[tab])return;
 const changed=inspectorTab!==tab,previous=inspectorTab;if(changed){cancelInspectorAnimations();document.querySelector('.panel-scroll').scrollTop=0}inspectorTab=tab;
 document.querySelectorAll('[data-inspector-tab]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.inspectorTab===tab)));
 for(const p of document.querySelectorAll('.accordion')){const visible=groups[tab].includes(p.dataset.accordion)&&!(currentLayer().type==='static'&&p.dataset.accordion==='motion'),wasVisible=!p.hidden;p.hidden=!visible;setAccordionOpen(p,visible&&(changed||reset||!wasVisible||p.classList.contains('open')))}
 $('noMotion').hidden=!(tab==='motion'&&currentLayer().type==='static');
 if(changed&&animate){const dir=Object.keys(groups).indexOf(tab)>Object.keys(groups).indexOf(previous)?1:-1;const visible=[...document.querySelectorAll('.panel-scroll .accordion:not([hidden]),.panel-scroll #noMotion:not([hidden])')];visible.forEach((p,i)=>animateInspector(p,[{opacity:.12,transform:`translate(${dir*16}px, 6px)`},{opacity:1,transform:'translate(0, 0)'}],{duration:330,easing:'cubic-bezier(.16,1,.3,1)',delay:Math.min(i*30,60),fill:'backwards'}))}
}
let lastInspectorEffect='';
function animateInspectorSelection(layer){const next=layer.id+':'+layer.type,changed=lastInspectorEffect!==next;lastInspectorEffect=next;if(!changed)return;cancelInspectorAnimations();animateInspector(document.querySelector('.active-layer'),[{opacity:.25,transform:'translateX(12px)'},{opacity:1,transform:'translateX(0)'}]);animateInspector(document.querySelector('.panel-scroll'),[{opacity:.25,transform:'translateY(10px)'},{opacity:1,transform:'translateY(0)'}],{duration:290,easing:'cubic-bezier(.22,.68,0,1.02)'})}

function setCanvasMenu(on){const menu=$('canvasMenu');if(on){setGroups(false);placeCanvasMenu(menu,$('canvasMore'))}menu.classList.toggle('open',on);menu.inert=!on;$('canvasMore').setAttribute('aria-expanded',String(on))}
function renderBarControls(layer){const el=$('spectrumControls');el.hidden=layer.type!=='spectrum';if(el.hidden)return;for(const [key,def] of Object.entries(BAR_DEFAULTS)){const input=$(key);if(!input)continue;const value=layer[key]??(key==='barBlack'?false:def);if(input.type==='checkbox')input.checked=value;else input.value=value;const out=$(key+'Value');if(out)out.textContent=key.startsWith('freq')?Math.round(40*400**(Number(value)/100))+' Hz':key==='bars'?String(value):key==='barRange'?value+' dB':value+'%'}}
function renderShapeControls(layer){const eligible=!AUDIO.has(layer.type)&&layer.type!=='static';$('shapeControls').hidden=!eligible;if(!eligible)return;const center=['spring','flower','circle','orbit'].includes(layer.type),spatial=['orbit','scanner','rain'].includes(layer.type);for(const [id,def] of Object.entries(SHAPE_DEFAULTS)){const input=$(id),field=input.closest('.shape-field'),v=layer[id]??def;field.hidden=id==='pulseShape'?layer.type!=='ripple':id==='aspect'?!(center||REACTIVE.has(layer.type)):id==='originX'||id==='originY'?!center:id==='petals'?layer.type!=='flower':id==='motionTrail'?!spatial:id==='orbitHeads'?layer.type!=='orbit':id==='rainDensity'?layer.type!=='rain':id==='scanMode'?layer.type!=='scanner':false;input.value=v;const out=$(id+'Value');if(out)out.textContent=['petals','orbitHeads'].includes(id)?v:v+'%'}}
function bindShapeControls(){for(const id of Object.keys(SHAPE_DEFAULTS)){const el=$(id),change=()=>{currentLayer()[id]=el.tagName==='SELECT'||el.type==='color'?el.value:Number(el.value);renderShapeControls(currentLayer());updatePreviewTools();persistState()};el.oninput=change;el.onchange=()=>{change();remember()}}}
function bindBarControls(){for(const [key,def] of Object.entries(BAR_DEFAULTS)){const el=$(key);if(!el)continue;const change=()=>{currentLayer()[key]=el.type==='checkbox'?el.checked:el.tagName==='SELECT'?el.value:Number(el.value);renderBarControls(currentLayer());persistState()};el.oninput=change;el.onchange=()=>{change();remember()}}}
// Display only; no extra per-frame work and no changes to engine values.
function syncRangeFill(input){const min=Number(input.min||0),max=Number(input.max||100),value=Number(input.value);const ratio=max>min?Math.max(0,Math.min(1,(value-min)/(max-min))):0;input.style.setProperty('--range-fill',(ratio*100).toFixed(2)+'%');}
function syncInspectorRanges(){document.querySelectorAll('.inspector input[type=range]').forEach(syncRangeFill);}

function renderInspector(){
 const layer=currentLayer(),e=EFFECTS[layer.type];
 $('signatureField').hidden=!SIGNATURE_TYPES.has(layer.type);$('signatureStyle').value=SIGNATURE_PRESETS[signatureIndex(layer)][0];
 $('effectIcon').innerHTML=effectIcon(layer.type);$('inspectorName').textContent=e.name;$('inspectorDesc').textContent=e.desc; $('colorMeta').textContent=layer.color.toUpperCase();$('brightnessValueTop').textContent=layer.brightness+'%';$('blendMode').value=layer.blend||'normal';
 for(const id of ['brightness','speed','spread','fade']){$(id).value=layer[id];$(id+'Value').textContent=layer[id]+'%'}
 for(const [id,value] of Object.entries(MOTION_DEFAULTS)){const v=layer[id]??value;$(id).value=v;$(id+'Value').textContent=id==='angle'?v+'°':id==='duration'?(v/10).toFixed(1)+' s':v+'%';const field=$(id).closest('.motion-field');if(field)field.hidden=!((id==='sensitivity'&&AUDIO.has(layer.type))||(id==='audioWidth'&&['waveform','beat','music','audio_wave','audio_visualizer'].includes(layer.type))||id==='contrast'||(id==='floor'&&!REACTIVE.has(layer.type))||(id==='duration'&&REACTIVE.has(layer.type))||(id==='angle'&&['aurora','silk','tide','ember','comet','orbit','scanner','rain','spring','flower'].includes(layer.type))||(id==='phase'&&['aurora','silk','tide','ember','stardust','orbit','scanner','rain','spring','flower','circle'].includes(layer.type))||(id==='width'&&['ripple','comet','silk','stardust','orbit','scanner','rain'].includes(layer.type)));}
 document.querySelectorAll('.direction').forEach(b=>{b.closest('.segmented').hidden=layer.type==='spectrum';const spatial=['orbit','scanner','rain'].includes(layer.type);b.hidden=spatial&&b.dataset.direction==='radial';const names=layer.type==='orbit'?['反時計回り','時計回り']:layer.type==='rain'?['逆方向','落下']:['逆方向','順方向'];b.textContent=spatial?(b.dataset.direction==='left'?names[0]:names[1]):({left:'←',radial:'◉',right:'→'}[b.dataset.direction]);b.setAttribute('aria-label',b.textContent)});$('directionLabel').hidden=layer.type==='spectrum';
 const animatedNew=['aurora','silk','tide','ember','stardust','comet','bloom','orbit','scanner','rain'].includes(layer.type);for(const id of ['speed','spread','fade']){const visible=AUDIO.has(layer.type)?id==='speed'&&['music','beat'].includes(layer.type):id==='speed'?true:id==='fade'?(!animatedNew||REACTIVE.has(layer.type)):layer.type!=='stardust';$(id).hidden=!visible;$(id).previousElementSibling.hidden=!visible;}
 const labels={orbit:['軌道の半径','光輪の太さ','開始角度'],scanner:['走査範囲','光帯の太さ','走査角度'],rain:['列の密度','雫の太さ','落下角度']}[layer.type]||['範囲','光の幅','角度'];for(const [i,id] of ['spread','width','angle'].entries()){const label=document.querySelector('label[for='+id+']');if(label)label.textContent=labels[i]}renderBarControls(layer);renderShapeControls(layer);if(SIGNATURE_TYPES.has(layer.type)){const response=layer.type==='signature_response';$('directionLabel').hidden=response;document.querySelectorAll('.direction').forEach(b=>b.closest('.segmented').hidden=response);$('fade').hidden=!response;$('fade').previousElementSibling.hidden=!response;}$('audioQuick').hidden=!AUDIO.has(layer.type);
 $('waveControls').hidden=!['waveform','audio_wave','audio_visualizer'].includes(layer.type);$('visualizerControls').hidden=layer.type!=='audio_visualizer';for(const [id,def] of Object.entries({waveMix:45,waveTrail:18,waveBeat:30})){const v=layer[id]??def;$(id).value=v;$(id+'Value').textContent=v+'%';}$('waveIdle').checked=layer.waveIdle===true;$('waveGain').value=layer.waveGain??50;$('waveGainValue').textContent=(layer.waveGain??50)+'%';$('waveMirrorField').hidden=!['audio_wave','audio_visualizer'].includes(layer.type);$('waveMirror').checked=layer.waveMirror!==false;
 $('secondaryColor').value=layer.secondary||'#B79BFF';$('secondaryField').hidden=!AUDIO.has(layer.type)&&!['aurora','silk','tide','ember','stardust','orbit','scanner','rain','spring','flower','circle','signature_flow'].includes(layer.type);
 $('targetLabel').textContent=layer.targets?.length?layer.targets.length+'キー':'すべて';
 $('hexInput').value=layer.color.toUpperCase();$('colorInput').value=layer.color;
 $('musicCaptureField').hidden=!AUDIO.has(layer.type);document.querySelector('[data-accordion=motion]').hidden=layer.type==='static';
 document.querySelectorAll('.direction').forEach(btn=>btn.classList.toggle('active',btn.dataset.direction===layer.direction||(['orbit','scanner','rain'].includes(layer.type)&&layer.direction==='radial'&&btn.dataset.direction==='right')));
 renderPalette();renderGradient();const layerChanged=lastInspectorEffect!==layer.id+':'+layer.type;setInspectorTab(inspectorTab,{reset:layerChanged});updateColorHint();updatePreviewTools();syncInspectorRanges();animateInspectorSelection(layer);
}
function renderGradient(){const l=currentLayer(),g=$('gradientControls'),eligible=l.type!=='signature_response';g.hidden=!eligible;if(!eligible)return;const colors=l.gradient?.length>1?(l.type==='signature_flow'?[l.color,l.secondary||l.color,...l.gradient.slice(2)]:l.gradient):[];$('gradientCount').options[0].disabled=l.type==='prism';$('gradientCount').value=String(colors.length||(l.type==='prism'?2:1));$('gradientOptions').hidden=!colors.length;$('gradientMode').value=l.gradientMode||'linear';$('gradientAngle').value=l.gradientAngle||0;$('gradientAngleValue').textContent=(l.gradientAngle||0)+'°';$('gradientAngleField').hidden=l.gradientMode==='radial'||!['static','prism'].includes(l.type);$('gradientMode').closest('.control-line').hidden=!['static','prism'].includes(l.type);$('gradientStrip').style.background=colors.length?`linear-gradient(90deg,${colors.join(',')})`:l.color;$('gradientStops').replaceChildren();colors.forEach((c,i)=>{const label=document.createElement('label');label.textContent=String(i+1);const input=document.createElement('input');input.type='color';input.value=c;input.setAttribute('aria-label','グラデーション色 '+(i+1));input.oninput=()=>{l.gradient[i]=input.value;if(l.type==='signature_flow'){if(i===0){l.color=input.value;$('colorInput').value=input.value;$('hexInput').value=input.value;$('colorMeta').textContent=input.value}if(i===1){l.secondary=input.value;$('secondaryColor').value=input.value}}$('gradientStrip').style.background=`linear-gradient(90deg,${l.gradient.join(',')})`;persistState()};input.onchange=remember;label.append(input);$('gradientStops').append(label)})}
function renderPalette(){
 const active=currentLayer().color.toUpperCase();
 $('palette').innerHTML=COLORS.map((col,i)=>`<button class="color-chip ${col.toUpperCase()===active?'active':''}" data-idx="${i}" style="--swatch:${col}" aria-label="${col}" title="${col}"></button>`).join('');
 document.querySelectorAll('.color-chip').forEach(el=>el.addEventListener('click',()=>{setLayerColor(COLORS[Number(el.dataset.idx)])}));
}
function setLayerColor(s,commit=true){if(!/^#[0-9a-fA-F]{6}$/.test(s))return;currentLayer().color=s.toUpperCase();if(currentLayer().type==='signature_flow'&&currentLayer().gradient?.length>1){currentLayer().gradient[0]=s.toUpperCase();renderGradient()}$('colorMeta').textContent=currentLayer().color;if(document.activeElement!==$('hexInput'))$('hexInput').value=currentLayer().color;if(document.activeElement!==$('colorInput'))$('colorInput').value=s;renderPalette();refreshLayers();if(commit)remember();else persistState();updateColorHint()}
function updateColorHint(){const l=currentLayer();$('colorHint').textContent=!l.enabled?'このレイヤーは無効です。':soloLayerId!=null&&soloLayerId!==l.id?'別のレイヤーを単独表示中です。':!state.running?'再生停止中です。':!isLive?'プレビューのみ（実機反映 OFF）':REACTIVE.has(l.type)?'キーを押すと選択色の波紋が広がります。':'実機へ反映中';$('testLayerColor').hidden=!REACTIVE.has(l.type);$('fixedColorMode').value=state.fixedColorMode||'reactive';$('reactivePriority').checked=state.reactivePriority===true;} 
async function testCurrentColor(){if(!REACTIVE.has(currentLayer().type))return;if(!currentLayer().enabled||soloLayerId!=null&&soloLayerId!==currentLayer().id){toast('選択したレイヤーを有効にしてください');return;}if(!state.running)togglePlayback();try{if(isLive)await sendScene();triggerPulse(currentLayer().targets?.[0]||'KeyG');}catch(e){toast(e.message)}}
function refreshAll(){refreshCatalog();refreshLayers();renderInspector();$('fixedColorMode').value=state.fixedColorMode||'reactive';updateSelection()}
function addLayer(type,source){
 if(state.layers.length>=8){toast('レイヤーは8個まで追加できます');return}
 const base=source||freshEffect(type||currentLayer().type);const layer={...base,id:Math.max(...state.layers.map(x=>x.id))+1,targets:[...(base.targets||[])],gradient:[...(base.gradient||[])]};
 state.layers.unshift(layer);state.selectedLayer=layer.id;refreshAll();remember();toast('新しいレイヤーを追加しました');
}
function navigate(view){if(view===activeView)return;cancelLasso();closePresetMenu(false);if(activeView==='lighting'){if(document.querySelector('.inspector').classList.contains('revealed'))setInspector(false,false);setGroups(false);setCanvasMenu(false);closeLayerMenu();if(pickerOpen)setPickerOpen(false);}
 stopPresetPreview();activeView=view;previewDirty=true;
 document.querySelectorAll('.nav-link').forEach(b=>b.classList.toggle('active',b.dataset.view===view));
 document.querySelectorAll('.view').forEach(el=>el.classList.toggle('active',el.id==='view-'+view));
 $('bread').textContent={lighting:'ライティング',keyboard:'キー設定',profiles:'プリセット',settings:'デバイスと設定'}[view];
 document.querySelector('.page-scroller')?.scrollTo(0,0);
 if(view==='lighting'&&matchMedia('(min-width:1120px)').matches)setInspector(true);
 if(view==='profiles'){if(!allProfiles.length||profileLayout!==state.layout)loadProfiles();else{refreshProfileStatus();scheduleThumbnails()}}
 if(view==='settings'||view==='keyboard')refreshStatus();if(view==='keyboard')renderGame();if(view==='lighting'||view==='keyboard')paintFrame(performance.now()/1000);
}
function toast(s){const t=$('toast');t.textContent=s;t.classList.add('show');clearTimeout(toast.timeout);toast.timeout=setTimeout(()=>t.classList.remove('show'),3500)}
function togglePlayback(){previewDirty=true;state.running=!state.running;$('pauseBtn').innerHTML=uiIcon(state.running?'pause':'play')+(state.running?'<span>停止</span>':'<span>再生</span>');persistState();toast(state.running?'プレビューを再開':'プレビューを停止')}
function presetState(){return {layout:state.layout,layers:state.layers.map(x=>({...x})),selectedLayer:state.selectedLayer,keyColors:{...state.keyColors},fixedColorMode:state.fixedColorMode||'reactive',reactivePriority:state.reactivePriority===true}}
let modalOrigin=null;function showModal(){modalOrigin=document.activeElement;$('modalBackdrop').hidden=false;$('presetName').value=$('currentProfileName').textContent==='新規プロファイル'?EFFECTS[currentLayer().type].name:$('currentProfileName').textContent;$('presetName').focus();$('presetName').select()}
function hideModal(){$('modalBackdrop').hidden=true;modalOrigin?.focus({preventScroll:true})}
async function saveProfile(){const name=$('presetName').value.trim();if(!name){toast('プリセット名を入力してください');return}
 try{if(allProfiles.some(p=>!p.builtin&&p.name===name)&&editingPreset!==name&&!confirm('同名のプリセットを上書きしますか？'))return;await post('/api/save',{preset:{name,state:presetState()},previous_name:editingPreset});editingPreset=name;hideModal();$('currentProfileName').textContent=name;recordedSnapshot=serializeState();updateHistoryButtons();persistState();toast('「'+name+'」を保存しました');loadProfiles()}
 catch(e){toast('保存失敗: '+e.message)}
}
let allProfiles=[],profileLoadId=0,profileLayout='',thumbObserver=null,thumbQueue=[],thumbScheduled=false,profileMenuAnchor=null,profileMenuPreset=null,profileSearchTimer=null,hoverIntent=null,thumbPauseUntil=0;
let uiMotion=true;try{uiMotion=localStorage.getItem('lume-ui-motion')!=='off'}catch{}
function motionAllowed(){return uiMotion&&!matchMedia('(prefers-reduced-motion: reduce)').matches}
function setUiMotion(on){uiMotion=!!on;document.documentElement.classList.toggle('no-ui-motion',!uiMotion);$('uiMotionToggle').checked=uiMotion;try{localStorage.setItem('lume-ui-motion',uiMotion?'on':'off')}catch{}if(!uiMotion){stopPresetPreview();cancelInspectorAnimations();stopWorkspaceMotion()}}
// Gallery rendering has its own bounded work queue. No DOM key elements per card.
function stopPresetPreview(){clearTimeout(hoverIntent);hoverIntent=null;if(!hoveredPreset)return;const item=hoveredPreset;hoveredPreset=null;item.host.closest('.profile-card')?.classList.remove('is-previewing');if(item.canvas&&item.host.isConnected&&!document.hidden)paintThumbnail(item,1.42);scheduleThumbnails()}
function trimThumbs(){const cached=[...$('profileGrid').querySelectorAll('.profile-visual')].map(h=>h._thumb).filter(i=>i?.canvas);for(const item of cached){if(cached.filter(i=>i.canvas).length<=16)break;if(item.visible||item===hoveredPreset)continue;item.canvas.width=1;item.canvas.height=1;item.host.replaceChildren();item.canvas=null;item.ctx=null;item.frame=null;item.host.classList.add('thumb-pending')}}
function hydrateThumb(item){if(item.canvas||!item.host.isConnected)return;item.board=thumbBoard(item.p.state.layout);item.keys=item.board.keys;item.canvas=document.createElement('canvas');item.canvas.className='preset-preview-canvas';item.canvas.width=THUMB_W;item.canvas.height=THUMB_H;item.ctx=item.canvas.getContext('2d',{alpha:false});item.host.replaceChildren(item.canvas);paintThumbnail(item,1.42);item.host.classList.remove('thumb-pending');trimThumbs()}
function scheduleThumbnails(){if(thumbScheduled||!thumbQueue.length||activeView!=='profiles'||document.hidden||hoveredPreset||hoverIntent||profileMenuAnchor||$('presetRenameDialog').open)return;thumbScheduled=true;const work=()=>{thumbScheduled=false;if(activeView!=='profiles'||document.hidden||hoveredPreset||hoverIntent||profileMenuAnchor||$('presetRenameDialog').open)return;if(performance.now()<thumbPauseUntil){setTimeout(scheduleThumbnails,Math.max(20,thumbPauseUntil-performance.now()));return}while(thumbQueue.length){const item=thumbQueue.shift();if(item.host.isConnected&&item.visible&&!item.canvas){hydrateThumb(item);break}}scheduleThumbnails()};if(window.requestIdleCallback)requestIdleCallback(work,{timeout:150});else setTimeout(work,16)}
function refreshProfileStatus(){const signature=JSON.stringify([state.layout,state.layers,state.keyColors||{}]);const name=$('currentProfileName').textContent;for(const card of $('profileGrid').querySelectorAll('.profile-card')){const p=card._preset;const active=p&&p.name===name&&card._stateSignature===signature;card.classList.toggle('preset-current',!!active);const b=card.querySelector('.apply-profile');if(b)b.textContent=active?'適用中':'適用'}}
function closePresetMenu(restore=true){if(!profileMenuAnchor)return;const anchor=profileMenuAnchor;profileMenuAnchor=null;profileMenuPreset=null;$('presetMenu').hidden=true;anchor.setAttribute('aria-expanded','false');if(restore&&anchor.isConnected)anchor.focus({preventScroll:true});scheduleThumbnails()}
function positionPresetMenu(){const anchor=profileMenuAnchor;if(!anchor)return;if(!anchor.isConnected||!thumbnailVisible(anchor)){closePresetMenu(false);return}const menu=$('presetMenu'),r=anchor.getBoundingClientRect(),w=menu.offsetWidth,h=menu.offsetHeight;menu.style.left=Math.max(8,Math.min(innerWidth-w-8,r.right-w))+'px';menu.style.top=(r.bottom+h+8<=innerHeight?r.bottom+4:Math.max(8,r.top-h-4))+'px'}
function openPresetMenu(anchor,p){stopPresetPreview();if(profileMenuAnchor===anchor){closePresetMenu();return}closePresetMenu(false);profileMenuAnchor=anchor;profileMenuPreset=p;const menu=$('presetMenu');menu.hidden=false;anchor.setAttribute('aria-expanded','true');for(const b of menu.querySelectorAll('button'))b.disabled=p.builtin&&['rename','delete'].includes(b.dataset.presetAction);positionPresetMenu();menu.querySelector('button:not(:disabled)').focus({preventScroll:true})}
async function presetAction(action,p){if(!p)return;try{if(action==='edit'){applyProfile(p,true);return}if(action==='share'){downloadPreset(p);return}if(action==='rename'){if(p.builtin)return;const input=await renamePresetDialog(p.name);if(input==null)return;const name=input.trim();if(name===p.name)return;if(!name||name.length>60||allProfiles.some(x=>x.name===name)){toast('1～60文字の重複しない名前を指定してください');return}await post('/api/save',{preset:{name,state:p.state},previous_name:p.name});if(editingPreset===p.name)editingPreset=name;if($('currentProfileName').textContent===p.name)$('currentProfileName').textContent=name;remember();toast('名前を変更しました')}else if(action==='duplicate'){let name=p.name.slice(0,47)+' コピー',n=2;while(allProfiles.some(x=>x.name===name))name=p.name.slice(0,44)+' コピー '+n++;await post('/api/save',{preset:{name,state:p.state}});toast('プリセットを複製しました')}else if(action==='delete'){if(p.builtin||!confirm('「'+p.name+'」を削除しますか？'))return;await post('/api/delete',{name:p.name});if(editingPreset===p.name){editingPreset=null;remember()}toast('プリセットを削除しました')}await loadProfiles()}catch(e){toast(e.message)}}
function renamePresetDialog(name){return new Promise(resolve=>{const d=$('presetRenameDialog'),input=$('presetRenameInput');input.value=name;let settled=false;const finish=value=>{if(settled)return;settled=true;d.close();scheduleThumbnails();resolve(value)};$('presetRenameCancel').onclick=()=>finish(null);$('presetRenameForm').onsubmit=e=>{e.preventDefault();const n=input.value.trim();if(!n||n.length>60||(n!==name&&allProfiles.some(p=>p.name===n))){$('presetRenameError').textContent='1～60文字の重複しない名前を入力してください。';return}finish(n)};d.oncancel=e=>{e.preventDefault();finish(null)};$('presetRenameError').textContent='';d.showModal();input.focus();input.select()})}
function bindPresetMenu(){matchMedia('(prefers-reduced-motion: reduce)').addEventListener('change',()=>{if(!motionAllowed()){stopPresetPreview();cancelInspectorAnimations();stopWorkspaceMotion()}});document.addEventListener('pointerdown',()=>{thumbPauseUntil=performance.now()+220;stopPresetPreview();setTimeout(scheduleThumbnails,240)},true);const menu=$('presetMenu');menu.addEventListener('click',e=>{const b=e.target.closest('[data-preset-action]');if(!b||b.disabled)return;const p=profileMenuPreset;closePresetMenu();presetAction(b.dataset.presetAction,p)});document.addEventListener('pointerdown',e=>{if(profileMenuAnchor&&!menu.contains(e.target)&&!profileMenuAnchor.contains(e.target))closePresetMenu(false)},true);document.addEventListener('keydown',e=>{if(!profileMenuAnchor)return;const items=[...menu.querySelectorAll('button:not(:disabled)')],i=items.indexOf(document.activeElement);if(e.key==='Escape'||e.key==='Tab'){e.preventDefault();e.stopImmediatePropagation();closePresetMenu();return}if(['ArrowDown','ArrowUp','Home','End'].includes(e.key)){e.preventDefault();e.stopImmediatePropagation();items[e.key==='Home'?0:e.key==='End'?items.length-1:(i+(e.key==='ArrowDown'?1:-1)+items.length)%items.length]?.focus()}},true);window.addEventListener('resize',()=>closePresetMenu(false));document.addEventListener('scroll',positionPresetMenu,true);document.addEventListener('visibilitychange',()=>{if(document.hidden)stopPresetPreview();else{previewDirty=true;scheduleThumbnails()}});}

function thumbnailVisible(host){const r=host.getBoundingClientRect();return r.width>0&&r.height>0&&r.bottom>0&&r.top<innerHeight&&r.right>0&&r.left<innerWidth;}
function setProfileView(mode){stopPresetPreview();profileView=mode==='list'?'list':'cards';const grid=$('profileGrid');grid.dataset.presentation=profileView;for(const b of document.querySelectorAll('[data-profile-view]'))b.setAttribute('aria-pressed',String(b.dataset.profileView===profileView));try{localStorage.setItem('lume-profile-view',profileView)}catch{}}

// Keep the original material atlas and exact physical layout. Rasterize the case
// and keycaps once per layout; only lighting and legends change per hover frame.
const THUMB_W=720,THUMB_H=305,THUMB_SCALE=38,THUMB_X=9,THUMB_Y=49;
const thumbBoards=new Map(),thumbMaterials=new Map();
let thumbMaterialPromise=null;
function prepareThumbMaterials(){if(thumbMaterialPromise)return thumbMaterialPromise;const jobs=[];for(const sheet of document.styleSheets){let rules;try{rules=sheet.cssRules}catch{continue}for(const rule of rules){if(!rule.style)continue;const sel=rule.selectorText||'';for(const [prop,id] of [['--case-image','case'],['--round-image','round'],['--cap-image',sel.includes('.jis-enter')?'enter':sel.match(/data-skin="(\d+)"/)?.[1]]]){if(!id||thumbMaterials.has(id))continue;const value=rule.style.getPropertyValue(prop),match=value.match(/url\(["']?(data:image\/[^"')]+)["']?\)/);if(!match)continue;const img=new Image();thumbMaterials.set(id,img);img.src=match[1];jobs.push(img.decode().catch(()=>{}))}}}thumbMaterialPromise=Promise.all(jobs).then(()=>{for(const board of thumbBoards.values())bakeThumbBoard(board);if(activeView==='profiles'&&!document.hidden)for(const host of $('profileGrid').querySelectorAll('.profile-visual')){const item=host._thumb;if(item?.canvas&&item.visible&&item!==hoveredPreset)paintThumbnail(item,1.42)}});return thumbMaterialPromise}
function thumbBoard(layout){layout=layout==='ansi'?'ansi':'jis';if(thumbBoards.has(layout))return thumbBoards.get(layout);const host=document.createElement('div'),old=state;let keys;try{state={...BASE(),layout};keys=createKeyboard(host).map(k=>({code:k.code,x:k.x,y:k.y,geometry:k.geometry,skin:k.el.dataset.skin,enter:k.el.classList.contains('jis-enter'),label:k.el.querySelector('.key-legend')?.textContent||'',kana:k.el.querySelector('.key-kana')?.textContent||'',shifted:k.el.querySelector('.key-shifted')?.textContent||''}))}finally{state=old}const base=document.createElement('canvas');base.width=THUMB_W;base.height=THUMB_H;const board={keys,base};thumbBoards.set(layout,board);bakeThumbBoard(board);return board}
function thumbRect(k){const g=k.geometry;return g?[THUMB_X+g.x*THUMB_SCALE+1,THUMB_Y+g.y*THUMB_SCALE+1,g.w*THUMB_SCALE-2,g.h*THUMB_SCALE-2]:[THUMB_X+k.x*THUMB_SCALE-12,15,25,25]}
function thumbImage(ctx,id,x,y,w,h,fallback){const img=thumbMaterials.get(id);if(img?.complete&&img.naturalWidth)ctx.drawImage(img,x,y,w,h);else{ctx.fillStyle=fallback;ctx.fillRect(x,y,w,h)}}
function bakeThumbBoard(board){const ctx=board.base.getContext('2d',{alpha:false});ctx.fillStyle='#151617';ctx.fillRect(0,0,THUMB_W,THUMB_H);thumbImage(ctx,'case',0,0,THUMB_W,THUMB_H,'#242526');for(const k of board.keys){const [x,y,w,h]=thumbRect(k);if(k.code==='BoardLogo')continue;if(k.enter){ctx.save();ctx.beginPath();ctx.moveTo(x,y);ctx.lineTo(x+w,y);ctx.lineTo(x+w,y+h);ctx.lineTo(x+w*.17,y+h);ctx.lineTo(x+w*.17,y+h*.5);ctx.lineTo(x,y+h*.5);ctx.closePath();ctx.clip()}thumbImage(ctx,k.geometry?(k.enter?'enter':k.skin):'round',x,y,w,h,'#202123');if(k.enter)ctx.restore()}}
function paintThumbnail(item,t){
 if(!item.ctx)return;const saved={state,keyboardKeys,pulseEvents,catalogPreview,soloLayerId,audioStatus,isAudioOn};let frame;
 try{state=item.scene;keyboardKeys=item.keys;catalogPreview=null;soloLayerId=null;audioStatus=item.hasAudio?demoAudio(t):{};isAudioOn=item.hasAudio;pulseEvents=[{x:7,y:3,start:t-(t+.99)%2.6},{x:12,y:4,start:t-(t+1.23)%2.6}];frame=paintFrame(t,false)}finally{({state,keyboardKeys,pulseEvents,catalogPreview,soloLayerId,audioStatus,isAudioOn}=saved)}
 item.frame=frame;const ctx=item.ctx;ctx.drawImage(item.board.base,0,0);ctx.globalCompositeOperation='screen';for(const k of item.keys){if(!k.geometry)continue;const rgb=hexToRGB(frame[k.code]),light=Math.max(...rgb);if(light<2)continue;const [x,y,w,h]=thumbRect(k),sprite=lightSprite(rgb.map(v=>Math.round(v/light*255)));ctx.globalAlpha=(light/255)**.92*.28;ctx.drawImage(sprite,x-1,y-3,w+2,10);ctx.globalAlpha=(light/255)**.92*.16;ctx.drawImage(sprite,x-1,y+h-7,w+2,10)}ctx.globalAlpha=1;ctx.globalCompositeOperation='source-over';ctx.textBaseline='top';ctx.textAlign='left';for(const k of item.keys){const rgb=hexToRGB(frame[k.code]),light=Math.max(...rgb),[x,y,w,h]=thumbRect(k);ctx.fillStyle=legendColor(rgb,k.geometry?[99,100,102]:[57,58,59]);if(!k.geometry){ctx.font=k.code==='BoardLogo'?'bold 24px sans-serif':'15px sans-serif';ctx.fillText(k.code==='BoardLogo'?'G':k.code==='GameMode'?'◇':'☼',x+3,y+3);continue}ctx.font=(k.label.length>=4?'8':'10')+'px sans-serif';if(k.label)ctx.fillText(k.label,x+w*(k.enter?.56:.18),y+h*(k.enter?.33:k.shifted?.47:.21),Math.max(4,w*.77));if(k.shifted){ctx.font='9px sans-serif';ctx.fillText(k.shifted,x+w*.18,y+h*.14)}if(k.kana){ctx.font='8px sans-serif';ctx.fillText(k.kana,x+w*.60,y+h*.56)}}
}
function profileThumbnail(p){const host=document.createElement('div');host.className='profile-visual thumb-pending';host.setAttribute('aria-hidden','true');host.inert=true;return {host,p,keys:null,canvas:null,visible:false,scene:{...BASE(),...p.state,selectedKeys:[],running:true},hasAudio:p.state.layers.some(l=>l.enabled&&AUDIO.has(l.type)),start:0,last:0};}
function beginTransition(){if(!transitionMs)return;const now=performance.now()/1000;previewTransition={frame:paintFrame(now,false),start:now,ms:transitionMs};transitionRequest={id:Date.now().toString(36)+'-'+(++transitionSerial),ms:transitionMs};}
function applyProfile(p,edit=false){const ns=JSON.parse(JSON.stringify(p.state));if(!validEditor(ns))return toast('未対応のプリセットです');if(p.state.layout===state.layout)beginTransition();else {previewTransition=null;transitionRequest=null}state={...BASE(),...ns,running:true,selectedKeys:[]};if(!state.layers.some(l=>l.id===state.selectedLayer))state.selectedLayer=state.layers[0].id;soloLayerId=null;editingPreset=edit&&!p.builtin?p.name:null;$('currentProfileName').textContent=edit&&p.builtin?p.name+' コピー':p.name;stopPresetPreview();setLayout(state.layout,false);refreshAll();remember();if(edit){navigate('lighting');setInspector(true);toast(p.builtin?'標準プリセットをコピーとして編集します':'編集モード：保存で更新できます')}else{if(activeView==='profiles'){refreshProfileStatus();scheduleThumbnails()}toast('「'+p.name+'」を適用しました')}}
function downloadPreset(p){const blob=new Blob([JSON.stringify({format:'lume-pro',version:2,name:p.name,state:p.state},null,2)],{type:'application/json'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=(p.name.replace(/[\\/:*?"<>|]/g,'_')||'LumePro')+'.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),6000)}
function renderProfiles(){
 const q=$('profileSearch').value.trim().toLowerCase(),filter=$('profileFilter').value,grid=$('profileGrid');closePresetMenu(false);stopPresetPreview();thumbObserver?.disconnect();thumbQueue=[];
 const shown=allProfiles.filter(p=>(filter==='all'||(filter==='builtin'?p.builtin:!p.builtin))&&[p.name,p.theme||'',...(p.state?.layers||[]).map(l=>EFFECTS[l.type]?.name||'')].join(' ').toLowerCase().includes(q));$('profileCount').textContent=shown.length+' 件';const frag=document.createDocumentFragment();const cached=new Map([...grid.querySelectorAll('.profile-card')].map(c=>[c._cacheKey,c]));
 thumbObserver=new IntersectionObserver(entries=>{for(const e of entries){const item=e.target._thumb;item.visible=e.isIntersecting;if(item.visible&&!item.canvas&&!thumbQueue.includes(item))thumbQueue.push(item);if(!item.visible&&hoveredPreset===item)stopPresetPreview()}scheduleThumbnails()},{root:null,threshold:.01});
 for(const p of shown){const cacheKey=JSON.stringify([!!p.builtin,p.name,p.state]);const prev=cached.get(cacheKey);if(prev){frag.append(prev);const host=prev.querySelector('.profile-visual');if(host?._thumb)thumbObserver.observe(host);continue}const card=document.createElement('article');card.className='profile-card';card._preset=p;card._cacheKey=cacheKey;card._stateSignature=JSON.stringify([p.state.layout,p.state.layers,p.state.keyColors||{}]);const thumb=profileThumbnail(p);thumb.host._thumb=thumb;card.append(thumb.host);const start=()=>{clearTimeout(hoverIntent);hoverIntent=setTimeout(()=>{hoverIntent=null;if(!card.matches(':hover')||performance.now()<thumbPauseUntil||!motionAllowed()||profileMenuAnchor||activeView!=='profiles'||!thumb.visible||p.state.layers.every(l=>!l.enabled||l.type==='static')){scheduleThumbnails();return}stopPresetPreview();hydrateThumb(thumb);hoveredPreset=thumb;thumb.start=performance.now();thumb.last=0;card.classList.add('is-previewing')},90)};const stop=()=>{clearTimeout(hoverIntent);hoverIntent=null;if(hoveredPreset?.host===thumb.host)stopPresetPreview();scheduleThumbnails()};card.addEventListener('pointerenter',start);card.addEventListener('pointerleave',stop);const info=document.createElement('div');info.className='profile-info';const title=document.createElement('strong');title.textContent=p.name;title.title=p.name;const caption=document.createElement('small');caption.className='profile-kind';caption.textContent=(p.builtin?'標準プリセット'+(p.theme?' · '+p.theme:''):'マイプリセット')+' · '+p.state.layers.length+' レイヤー';info.append(title,caption);const detail=document.createElement('span');detail.className='profile-effects';detail.textContent=p.state.layers.filter(l=>l.enabled).map(l=>EFFECTS[l.type]?.name).filter(Boolean).join(' / ')||'消灯';info.append(detail);card.append(info);
 const actions=document.createElement('div');actions.className='profile-actions';const apply=document.createElement('button');apply.className='button primary apply-profile';apply.textContent='適用';apply.onclick=()=>applyProfile(p);const more=document.createElement('button');more.type='button';more.className='button preset-more';more.innerHTML=uiIcon('more');more.title='その他の操作';more.setAttribute('aria-label',p.name+' のメニュー');more.setAttribute('aria-haspopup','menu');more.setAttribute('aria-expanded','false');more.onclick=()=>openPresetMenu(more,p);const edit=document.createElement('button');edit.type='button';edit.className='button preset-edit-direct';edit.textContent='編集';edit.title=p.builtin?'コピーとして編集':'プリセットを編集';edit.onclick=()=>applyProfile(p,true);actions.append(apply,edit,more);card.append(actions);frag.append(card);thumbObserver.observe(thumb.host)}
 if(!shown.length){const empty=document.createElement('p');empty.className='field-help';empty.textContent='該当するプリセットがありません。';frag.append(empty)}grid.replaceChildren(frag);refreshProfileStatus();scheduleThumbnails();
}
async function loadProfiles(){
 const request=++profileLoadId;try{profiles=(await(await apiFetch('/api/presets')).json()).presets||[]}catch{profiles=[]}if(request!==profileLoadId)return;
 const builtins=SIGNATURE_PRESETS.map(([name,theme,colors])=>({name,theme,builtin:true,state:{...BASE(),layout:state.layout,layers:[
  {...freshEffect('signature_response'),id:1,signatureStyle:name,color:colors[3],secondary:colors[2],brightness:85,speed:55,spread:60,fade:65,duration:26,direction:'radial'},
  {...freshEffect('signature_flow'),id:2,signatureStyle:name,color:colors[0],secondary:colors[1],gradient:[...colors],brightness:85,speed:55,spread:60,fade:65}
 ],selectedLayer:1}}));
 profileLayout=state.layout;allProfiles=[...profiles.filter(p=>typeof p?.name==='string'&&validEditor(p.state)),...builtins];renderProfiles();
}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
let statusInFlight=false;
async function refreshStatus(){
 if(connectionBusy||statusInFlight)return;statusInFlight=true;
 try{const status=await (await apiFetch('/api/status')).json();hardware=status.hardware;if(status.audio){const enabled=!!status.audio.enabled;if(enabled!==isAudioOn){isAudioOn=enabled;if(enabled)apiFetch('/api/audio').then(r=>r.json()).then(a=>{audioStatus=a;showAudioStatus()}).catch(()=>{});else{audioStatus={enabled:false,volume:0,signal:'off'};state.volume=0;showAudioStatus()}}}if(status.desktop){desktopResident=status.desktop.resident;for(const [id,key] of [['trayToggle','tray'],['startupToggle','startup'],['recoveryToggle','recovery']]){const el=$(id);if(el){el.disabled=!status.desktop.supported;el.checked=!!status.desktop[key]}}}if(status.ghub_state)updateGhubState(status.ghub_state);if(status.game_mode&&!gameBusy){const changed=JSON.stringify(gameState)!==JSON.stringify(status.game_mode);gameState=status.game_mode;if(changed){renderGame();previewDirty=true;if(!state.running&&(activeView==='lighting'||activeView==='keyboard'))paintFrame(performance.now()/1000);}}if(status.engine){engineStatus=status.engine;if(!liveBusy){isLive=!!engineStatus.active;$('liveToggle').checked=isLive;}}if(status.keyhook){const c=status.keyhook.special_counts||{}; $('specialInputStatus').textContent=`］ ${c.Backslash||0} 回 · Fn/右Alt ${(c.Fn||0)+(c.AltRight||0)} 回 · 照明 ${c.LightButton||0} 回 · ゲーム ${c.GameMode||0} 回`;isHook=status.keyhook.enabled;$('hookToggle').checked=isHook;$('inputQuick').setAttribute('aria-pressed',String(isHook));$('inputQuick').textContent=isHook?'入力反応 ON':'入力反応 OFF';}updateConnectionUI();if($('ledDiagnostics').open)$('diagSummary').textContent=`${hardware.backend==='logitech'?'SDK候補キー':'対応LED'} ${hardware.matched||0} / ${hardware.led_map?.length||0} ・送信 ${hardware.sent||0} 回${hardware.backend==='logitech'?` ・送信間隔 ${hardware.send_fps||0} FPS ・処理 ${hardware.send_ms||0} ms`:''}`; }catch(e){$('connectionMessage').textContent='ローカルサーバーとの接続が切れました。'}finally{statusInFlight=false}
}
function updateConnectionUI(){
 if($('gameStatus'))$('gameStatus').textContent=gameState.enabled?(isLive?'入力遮断中 · LED連動中':'入力遮断中 · 実機反映OFF'):'停止中 · 無効化するキーを設定できます';
 const h=hardware;const connected=h.active;
 if(!connected&&isLive){isLive=false;$('liveToggle').checked=false;}
 $('deviceChip').textContent=connected?'接続中':'プレビュー';$('deviceChip').classList.toggle('connected',connected);
 $('sideDot').classList.toggle('on',connected);$('sideStatus').textContent=connected?'キーボード接続中':'プレビューモード';
 $('connectTopBtn').title=connected?'設定 · キーボード接続済み':'設定 · キーボード未接続';
 $('liveHint').textContent=connected?(isLive?'独立エンジンで送信中':'実機反映 OFF'):'実機未接続';$('deviceChip').textContent=connected?(isLive?'実機反映中':'接続済み · 反映OFF'):'プレビュー';$('engineSummary').textContent=`${isLive?'実機反映中':'実機反映停止'} · 入力反応 ${isHook?'ON':'OFF'} · 波紋 ${engineStatus.pulses||0} 回 · 送信 ${hardware.sent||0} 回`;if(engineStatus.error)$('engineSummary').textContent+=' · '+engineStatus.error;
 $('connectionMessage').textContent=h.error || (connected?`接続中 / ${h.backend==='logitech'?'SDK候補キー':'対応LED'}: ${h.matched} / ${h.led_map?.length||0} 個 · 送信 ${h.sent||0} 回`:'キーボードを選択してください');
 const s=$('deviceSelect');const v=s.value,deviceSignature=JSON.stringify([h.backend,h.devices]);if(s.dataset.signature!==deviceSignature){s.dataset.signature=deviceSignature;s.innerHTML='<option value="">選択してください</option>'+(h.devices||[]).filter(d=>d.keyboard===true).map(d=>`<option value="${escapeHtml(d.id)}">${escapeHtml(d.name)} (${escapeHtml(d.leds)} ${h.backend==='logitech'?'候補キー':'LED'})</option>`).join('');}
 if(h.device!=null&&s.value!==String(h.device))s.value=String(h.device);else if(h.device==null&&s.value!==v)s.value=v;
 if(!s.value)s.selectedIndex=0;
 $('selectDeviceBtn').disabled=!(h.devices||[]).some(d=>d.keyboard===true);
 $('sdkMethodRow').hidden=h.backend!=='logitech'||!h.active;
 if(h.backend==='logitech'&&h.active)$('sdkMethod').value=h.method||'auto';
 $('assignLed').disabled=h.backend==='logitech';
 $('specialSdk').hidden=h.backend!=='logitech'||!h.active;
 if(h.backend==='logitech'&&h.active){$('bracketMethod').value=h.key_methods?.Backslash||'auto';$('fnMethod').value=h.key_methods?.Fn||'auto';}
 $('bitmapDiagnostics').hidden=h.backend!=='logitech'||!h.active; $('bitmapStatus').textContent=h.bitmap_available?'ビットマップAPIを検出 · '+(h.output_mode==='bitmap'?'ビットマップ制御中':'通常SDK制御中'):'このSDKではビットマップAPIが利用できません'; for(const id of ['bitmapAll','bitmapOff','bitmapBitTest','bitmapCellTest','bitmapAssign','bitmapRemove','bitmapEnable'])$(id).disabled=!h.bitmap_available; $('bitmapMapCount').textContent='保存済みの対応付け: '+Object.keys(h.bitmap_mapping||{}).length+' 個'+(h.bitmap_missing?.length?' · 通常キー未設定 '+h.bitmap_missing.length+' 個':'');
 const unavailable=h.unsupported_keys||[];$('extraWarning').textContent=unavailable.length?'個別制御未対応: '+unavailable.map(c=>({GameMode:'ゲームモード',LightButton:'照明ボタン',BoardLogo:'Gロゴ'}[c]||c)).join(' / '):'';
 $('jisTest').hidden=h.backend!=='logitech'||!h.active;updateColorHint();
}
async function detectDevices(){
 if(connectionBusy)return;
 if(isLive)await setLive(false);
 $('connectionMessage').textContent='接続方式を確認しています…';
 try{const r=await post('/api/connect',{backend:$('backendSelect').value});hardware=r.hardware;updateConnectionUI();toast(r.ok?(hardware.backend==='logitech'?'公式SDK DLLを検出しました':`${hardware.devices.filter(d=>d.keyboard===true).length} 台のキーボードを検出しました`):hardware.error)}
 catch(e){toast('接続エラー: '+e.message)}
}
async function chooseDevice(){
 if(isLive)await setLive(false);
 if(!$('deviceSelect').value){toast('キーボードを選択してください');return}
 if(hardware.backend==='logitech'&&!confirm('G HUBを起動し、OpenRGBの制御を終了してください。公式SDKは対応するキー単位RGB機器全体に送信します。接続しますか？'))return;
 try{const r=await post('/api/select',{index:Number($('deviceSelect').value)});hardware=r.hardware;updateConnectionUI();updateDiag();if(r.ok){preferences.backend=hardware.backend;await savePreferences({auto:$('autoConnect').checked});if(preferences.hook&&!isHook)await toggleHook(true);if(preferences.live)await setLive(true)}toast(r.ok?'キーボードとの接続を準備しました':hardware.error)}
 catch(e){toast(e.message)}
}
async function toggleHook(enabled){
 try{const r=await post('/api/keyhook',{enabled});if(!r.ok)throw Error(r.error||'失敗');isHook=r.enabled;$('hookToggle').checked=isHook;$('inputQuick').setAttribute('aria-pressed',String(isHook));$('inputQuick').textContent=isHook?'入力反応 ON':'入力反応 OFF';if(!isHook&&gameState.enabled){gameState={...gameState,enabled:false};renderGame();paintFrame(performance.now()/1000)}if(isHook){const d=await (await apiFetch('/api/keys?since=0')).json();seq=d.seq??0;}toast(isHook?'キー入力への反応を有効にしました':'キー入力検出を停止しました')}
 catch(e){isHook=false;$('hookToggle').checked=false;$('inputQuick').setAttribute('aria-pressed','false');$('inputQuick').textContent='入力反応 OFF';toast('キー入力検出: '+e.message)}
}
let audioPollBusy=false,lastAudioMeter=0;
function drawAudioTrace(a){const canvas=$('audioTrace'),ctx=canvas.getContext('2d'),w=canvas.width,h=canvas.height;ctx.clearRect(0,0,w,h);ctx.strokeStyle='#414957';ctx.beginPath();ctx.moveTo(0,h/2);ctx.lineTo(w,h/2);ctx.stroke();const trace=a.trace||a.wave||[];ctx.strokeStyle='#76F3E1';ctx.lineWidth=1.8;ctx.beginPath();trace.forEach((v,i)=>{const x=i*w/Math.max(1,trace.length-1),y=h/2-clamp(v*3,-1,1)*h*.44;i?ctx.lineTo(x,y):ctx.moveTo(x,y)});ctx.stroke();$('audioTraceLabel').textContent=a.demo?'合成波形（テスト）':a.signal==='signal'?'実際の音声波形':a.signal==='silent'?'無音：再生先を確認':'音声波形 · '+(a.signal||'停止中')}
function showAudioStatus(){
 const a=audioStatus;const label={signal:'音声受信中',silent:'無音：再生先を確認',waiting:'音声待機中',stalled:'取得停止：再生先を確認',test:'合成信号テスト',off:'停止中'}[a.signal]||'接続中';
 $('audioStatus').textContent=a.demo?'TEST':a.enabled?Math.round((a.volume||0)*100)+'%':'OFF';
 $('audioMeter').value=Math.min(1,(a.captured_rms||0)*5);drawAudioTrace(a);$('audioDevice').textContent=[label,a.device,a.backend,a.frames!=null?a.frames+' frames':'',a.rate?a.rate+' Hz':'',a.error].filter(Boolean).join(' · ');
 $('audioPathStatus').textContent=`${label} / ${isLive?'実機反映ON':'実機反映OFF'} / ${state.running?'再生中':'停止中'} / 音声レイヤー ${state.layers.filter(l=>AUDIO.has(l.type)&&l.enabled&&(soloLayerId==null||soloLayerId===l.id)).length} / 信号 ${a.signal_frames||0} フレーム`;
 $('audioCaptureBtn').textContent=a.enabled?'音声キャプチャ停止':'音声取得・実機反映を開始';$('audioQuickBtn').textContent=a.enabled?'音声取得を停止':'音声取得を開始';$('audioQuickState').textContent=label;$('audioEndpoint').disabled=!!a.enabled;$('audioScanBtn').disabled=!!a.enabled;
}
async function pollAudio(){
 if(document.hidden||!['lighting','keyboard'].includes(activeView)||(!isAudioOn&&!audioStatus.demo)||audioPollBusy)return;audioPollBusy=true;
 try{const was=isAudioOn;audioStatus=await (await apiFetch('/api/audio')).json();audioStatus.receivedAt=performance.now()/1000;state.volume=audioStatus.volume||0;isAudioOn=!!audioStatus.enabled;
  if(was&&!isAudioOn&&audioStatus.error)toast(audioStatus.error);previewDirty=true;if(activeView==='lighting'&&performance.now()-lastAudioMeter>=100){lastAudioMeter=performance.now();showAudioStatus();}
 }catch{}finally{audioPollBusy=false;}
}
async function scanAudio(){
 $('audioScanBtn').disabled=true;
 try{const r=await(await apiFetch('/api/audio_devices')).json(),select=$('audioEndpoint'),old=select.value;select.replaceChildren(new Option('Windowsの既定の出力','default'));for(const d of r.devices||[])select.add(new Option(d.name+' · '+d.backend,d.id));if([...select.options].some(o=>o.value===old))select.value=old;toast((r.devices||[]).length+' 件の再生先を検出');if(!r.devices?.length)$('audioDevice').textContent=(r.errors||[]).join(' / ')}catch(e){toast(e.message)}finally{$('audioScanBtn').disabled=false}
}
async function prepareAudioLayer(){
 const layer=currentLayer();if(!AUDIO.has(layer.type))throw Error('音声エフェクトを選択してください');
 layer.enabled=true;soloLayerId=null;
 if(!state.running)togglePlayback();refreshAll();remember();
 if(hardware.active){if(!isLive){if(!await setLive(true))throw Error('実機反映を開始できません');savePreferences({live:true}).catch(()=>{})}else await sendScene()}
}
async function toggleAudio(){
 $('audioCaptureBtn').disabled=true;
 try{if(!isAudioOn)await prepareAudioLayer();const r=await post('/api/audio_toggle',{enabled:!isAudioOn,endpoint:$('audioEndpoint').value});if(!r.ok)throw Error(r.audio?.error||'取得失敗');isAudioOn=!!r.audio.enabled;savePreferences({audio_enabled:isAudioOn,audio_endpoint:$('audioEndpoint').value}).catch(()=>{});state.volume=0;audioStatus=r.audio;showAudioStatus();toast(isAudioOn?'PCの再生音の解析を開始':'音声の取得を終了');
 }catch(e){toast('音楽連動: '+e.message)}finally{$('audioCaptureBtn').disabled=false}
}
async function testAudio(){try{await prepareAudioLayer();const r=await post('/api/audio_demo',{layer_id:currentLayer().id});audioStatus=r.audio;showAudioStatus();toast('選択した音声エフェクトだけを4秒間テストします（合成信号）')}catch(e){toast(e.message)}}
async function pollKeys(){
 if(!isHook||keysInFlight||document.hidden||!['lighting','keyboard'].includes(activeView))return;keysInFlight=true;
 try{const view=activeView;const d=await (await apiFetch('/api/keys?since='+seq)).json();seq=d.seq??seq;if(activeView!==view||document.hidden)return;
  for(const item of d.events||[])triggerPulse(item.code,'hook');
 }catch{}finally{keysInFlight=false}
}
// Keep the keyboard's internal geometry fixed while the workspace tracks interpolate.
// Only its composited scale/position changes during panel motion.
let workspaceMotionTimer=0,previewBaseWidth=0,pickerInsetProgress=0,pickerMotionFrame=0;
function animatePickerInset(open){
 cancelAnimationFrame(pickerMotionFrame);pickerMotionFrame=0;
 const from=pickerInsetProgress,to=Number(open),start=performance.now(),menu=$('effectPicker');
 const apply=v=>{pickerInsetProgress=v;menu.style.setProperty('--picker-progress',v);menu.classList.toggle('picker-fading',v>0&&!open);fitPreview()};
 apply(from);
 if(!motionAllowed()||initializing||activeView!=='lighting'||document.hidden||from===to){apply(to);return}
 const duration=(open?300:240)*Math.max(.5,Math.abs(to-from));
 const tick=now=>{if(!motionAllowed()||activeView!=='lighting'||document.hidden){apply(to);pickerMotionFrame=0;return}
  const t=Math.min(1,Math.max(0,(now-start)/duration)),e=open?1-(1-t)**3:t*t*(3-2*t);apply(from+(to-from)*e);pickerMotionFrame=t<1?requestAnimationFrame(tick):0;};
 pickerMotionFrame=requestAnimationFrame(tick);
}
const compactEditor=typeof matchMedia==='function'?matchMedia('(max-width:1119px)'):null;
function fitPreview(){
 const stage=document.querySelector('.keyboard-stage'),board=document.querySelector('.keyboard-outer'),grid=document.querySelector('.editor-grid');
 if(!stage||!board||!stage.clientWidth)return false;
 const padding=24,base=Math.min(940,Math.max(180,grid.clientWidth-(compactEditor.matches?182:205)-padding));
 const resized=previewBaseWidth!==base;
 if(resized){previewBaseWidth=base;board.style.width=base+'px';}
 const layerWidth=parseFloat(getComputedStyle(grid).getPropertyValue('--layers-width'))||document.querySelector('.layer-panel').offsetWidth;
 const left=pickerInsetProgress*Math.max(0,$('effectPicker').offsetWidth-layerWidth+16);
 const scale=Math.min(1,Math.max(.12,(stage.clientWidth-left-36)/base));
 board.style.setProperty('--preview-scale',scale);board.style.setProperty('--preview-shift',(left/2)+'px');
 return resized;
}
function syncWorkspaceInert(){const grid=document.querySelector('.editor-grid'),closed=compactEditor.matches&&grid.classList.contains('has-inspector');grid.querySelector('.layer-panel').inert=closed;}
function stopWorkspaceMotion(){clearTimeout(workspaceMotionTimer);document.querySelector('#view-lighting').classList.remove('workspace-motion');}
function setInspector(open,fit=true){
 const view=document.querySelector('#view-lighting'),grid=view.querySelector('.editor-grid'),pane=grid.querySelector('.inspector'),wasOpen=pane.classList.contains('revealed');
 const animate=fit&&!initializing&&activeView==='lighting'&&!document.hidden&&motionAllowed()&&wasOpen!==open;
 if(wasOpen!==open){setGroups(false);setCanvasMenu(false);cancelLasso();}if(animate){clearTimeout(workspaceMotionTimer);view.classList.add('workspace-motion');getComputedStyle(grid).gridTemplateColumns;}
 else if(wasOpen!==open)stopWorkspaceMotion();
 if(open)setInspectorTab(inspectorTab,{reset:!wasOpen});else cancelInspectorAnimations();
 pane.classList.toggle('revealed',open);pane.inert=!open;pane.setAttribute('aria-hidden',String(!open));
 grid.classList.toggle('has-inspector',open);$('showLayersBtn').disabled=!open;syncWorkspaceInert();
 $('inspectorToggle').setAttribute('aria-expanded',String(open));
 // Keep content intact while closing; don't collapse all settings before the slide finishes.
 if(fit){fitPreview();requestAnimationFrame(fitPreview)}
 if(animate)workspaceMotionTimer=setTimeout(()=>{stopWorkspaceMotion();fitPreview();updatePreviewTools()},650);
}
function placeCanvasMenu(menu,button){const panel=document.querySelector('.canvas-panel'),p=panel.getBoundingClientRect(),b=button.getBoundingClientRect();menu.style.right=Math.max(8,p.right-b.right)+'px';menu.style.top=Math.max(4,b.bottom-p.top+7)+'px';menu.style.maxHeight=Math.max(70,p.bottom-b.bottom-15)+'px';}
function setGroups(open){const menu=$('groupsMenu');if(open){setCanvasMenu(false);placeCanvasMenu(menu,$('groupsToggle'))}menu.classList.toggle('revealed',open);menu.inert=!open;$('groupsToggle').setAttribute('aria-expanded',String(open))}
function updateDiag(){const target=$('cellTarget'),tv=target.value;target.replaceChildren(...keyboardKeys.slice().sort((a,b)=>{const specials=['Backslash','Fn','LightButton','GameMode','BoardLogo'];const priority=k=>specials.includes(k.code)?specials.indexOf(k.code):10;return priority(a)-priority(b)}).map(k=>new Option(`${k.el.title} (${k.code})`,k.code)));if(keyboardKeys.some(k=>k.code===tv))target.value=tv;const bm=$('bitmapKey'),bv=bm.value;bm.innerHTML=keyboardKeys.map(k=>`<option value="${k.code}">${escapeHtml(k.el.title)} (${k.code})</option>`).join('');if(keyboardKeys.some(k=>k.code===bv))bm.value=bv;const map=hardware.led_map||[];const sel=$('ledIndex'),prev=sel.value;const codes=$('ledCode');const old=codes.value;sel.innerHTML=map.map(m=>`<option value="${m.index}">${m.index+1} · ${escapeHtml(m.name)} · ${m.code||'未対応'}</option>`).join('');if(map.some(m=>String(m.index)===prev))sel.value=prev;codes.innerHTML='<option value="">未割り当て</option>'+keyboardKeys.map(k=>`<option value="${k.code}">${escapeHtml(k.el.title)} (${k.code})</option>`).join('');codes.value=map.find(m=>String(m.index)===sel.value)?.code||old||'';$('diagSummary').textContent=`${hardware.backend==='logitech'?'SDK候補キー':'対応LED'} ${hardware.matched||0} / ${map.length} ・送信 ${hardware.sent||0} 回${hardware.backend==='logitech'?` ・送信間隔 ${hardware.send_fps||0} FPS ・処理 ${hardware.send_ms||0} ms`:''}`; const missing=hardware.missing_jis||[];$('jisWarning').textContent=state.layout==='jis'&&missing.length?'SDKのキー一覧に存在しない、または未割当のJISキー: '+missing.join(' / ')+'。実機での点灯を個別テストで確認してください。':'';}
async function bitmapProbe(pattern,index=0){
 await setLive(false);try{const r=await post('/api/bitmap_test',{pattern,index});hardware=r.hardware;updateConnectionUI();updateDiag();toast(r.ok?'SDKに送信しました。実際の点灯を確認してください':hardware.error||'ビットマップAPIが利用できません');return r.ok}catch(e){toast(e.message);return false}
}
async function bitmapSave(mapping,enabled){
 await setLive(false);try{if(enabled)await sendScene();const r=await post('/api/bitmap_config',{mapping,enabled});hardware=r.hardware;updateConnectionUI();updateDiag();toast(r.ok?'対応付け・送信方式を保存しました':hardware.error||'設定できませんでした')}catch(e){toast(e.message)}
}
async function ledTest(index,color){await setLive(false);try{const r=await post('/api/led_test',{index,color});hardware=r.hardware;updateConnectionUI();updateDiag();toast(r.ok?'点灯テストを送信しました':hardware.error||'キーボード未接続')}catch(e){toast(e.message)}}
const specialProbeMethods={Backslash:[['hid','HID 0x32'],['hid31','HID 0x31'],['hid64','HID 0x64'],['scan','Scan 0x2B'],['scan56','Scan 0x56'],['keyname','SDK 0x2B'],['iso56','SDK 0x56']],IntlYen:[['hid','HID 0x89'],['scan','Scan 0x7D'],['keyname','SDK 0x7D']],Fn:[['hid','HID 0xE6'],['scan','Scan 0x138'],['keyname','SDK 0x138']]};
let specialProbe=null,probeBusy=false;
async function sendSpecialProbe(){
 if(!specialProbe||probeBusy)return;probeBusy=true;const p=specialProbe,method=specialProbeMethods[p.code][p.index];$('probeYes').disabled=true;$('probeSwap').disabled=true;$('probeNo').disabled=true;
 try{await setLive(false);const r=await post('/api/special_probe',{code:p.code,method:method[0],color:p.phase?'#d000dc':'#00b0ff'});hardware=r.hardware;updateConnectionUI();p.accepted[p.phase]=!!r.ok;$('probeStep').textContent=`候補 ${p.index+1}/${specialProbeMethods[p.code].length} · ${method[1]} · ${p.phase?'紫':'水色'}`;$('probeResult').textContent=r.ok?'SDKに送信しました。実機で対象のキーを確認してください。':hardware.error||'SDKに拒否されました';}catch(e){$('probeResult').textContent=e.message}finally{probeBusy=false;$('probeSwap').disabled=false;$('probeNo').disabled=false;$('probeYes').disabled=!p.accepted.every(Boolean)}
}
function setupSpecialWizard(){
 $('probeStart').onclick=()=>{if(probeBusy)return;specialProbe={code:$('probeTarget').value,index:0,phase:0,accepted:[false,false]};$('probeBody').hidden=false;sendSpecialProbe()};
 $('probeSwap').onclick=()=>{if(!specialProbe||probeBusy)return;specialProbe.phase=1-specialProbe.phase;sendSpecialProbe()};
 $('probeNo').onclick=()=>{if(!specialProbe||probeBusy)return;const p=specialProbe;if(++p.index>=specialProbeMethods[p.code].length){specialProbe=null;$('probeStep').textContent='全候補の確認終了';$('probeResult').textContent='有効な候補を確認できませんでした。ビットマップの全領域点灯・消灯で切り分けてください。';for(const id of ['probeSwap','probeNo','probeYes'])$(id).disabled=true;return}p.phase=0;p.accepted=[false,false];sendSpecialProbe()};
 $('probeYes').onclick=async()=>{if(!specialProbe||probeBusy||!specialProbe.accepted.every(Boolean))return;const p=specialProbe;probeBusy=true;try{const r=await post('/api/key_method',{code:p.code,method:specialProbeMethods[p.code][p.index][0]});hardware=r.hardware;updateConnectionUI();if(r.ok){specialProbe=null;$('probeStep').textContent='確認した送信方式を保存しました';$('probeResult').textContent='実機反映を再開してリップル等を確認してください。';for(const id of ['probeSwap','probeNo','probeYes'])$(id).disabled=true}else $('probeResult').textContent='保存できませんでした'}catch(e){$('probeResult').textContent=e.message}finally{probeBusy=false}};
}
// Session-local vendor HID learning. No raw input data is exposed to the editor.
let fnPollTimer=null,fnBusy=false;
function updateFnHid(s){
 if(!s)return;const label=({Fn:'Fn',GameMode:'ゲームモード',LightButton:'照明'}[s.target]||'Fn');const labels={off:'停止中',baseline:'待機中：キーを押さないでください',ready:`${label}の学習 ${s.samples||0}/${s.required_samples||3}`,sample:`${label}だけを1回押して離してください（残り ${Math.ceil(s.remaining||0)} 秒）`,verify:`学習候補を検出。もう一度${label}を押して検出回数を確認してください（${s.matches||0} 回${s.alternate_states?'、確認済み '+(s.verified_states||0)+'/2状態':''}）`,learned:`専用HID入力 有効 · ${(s.learned||[]).join(" / ")} · ${s.matches||0} 回`,failed:'通知を確定できませんでした'};
 $('fnHidStatus').textContent=(labels[s.phase]||'停止中')+(s.error?' · '+s.error:'')+(s.collection_stats?.length?' · '+s.collection_stats.map(c=>`${c.usage}: ${c.opened?c.reports+'件（学習中 '+(c.phase_reports?.sample||0)+'件）':'開けません'}`).join(' / '):'');$('fnHidSample').disabled=fnBusy||s.phase!=='ready';$('fnHidEnable').disabled=fnBusy||s.phase!=='verify'||!(s.can_enable??(s.matches>0));$('fnHidStart').disabled=fnBusy;$('fnHidStart').textContent=s.active?'別のボタンを学習':'学習を開始';$('fnHidStart').dataset.active=String(!!s.active);
 if(!s.active&&fnPollTimer){clearInterval(fnPollTimer);fnPollTimer=null;}
}
async function fnRequest(action,extra={}){
 if(fnBusy)return;fnBusy=true;try{const r=await post('/api/fn_hid',{action,...extra});if(r.devices){$('fnHidDevice').replaceChildren(new Option('選択してください',''));for(const d of r.devices)$('fnHidDevice').add(new Option(`${d.name} · PID ${d.pid} · ${d.usage}`,String(d.index)));if(r.devices.length){$('fnHidDevice').add(new Option('すべての専用HIDを調べる','-1'),1);$('fnHidDevice').value='-1';}if(!r.devices.length)toast(r.status?.error||'PROキーボードの専用HIDが見つかりません');}fnBusy=false;if(r.status)updateFnHid(r.status);return r;}catch(e){toast(e.message)}finally{fnBusy=false;}
}
async function pollFnHid(){try{updateFnHid(await(await apiFetch('/api/fn_hid_status')).json())}catch{}}
let ghubTimer=null,ghubBusy=false;
function updateGhubState(s){
 if(!s)return;if('sync_enabled' in s){$('gameSyncToggle').checked=!!s.sync_enabled;$('gameSyncStatus').textContent=s.sync_enabled?(s.states?.GameMode==null?'状態通知待ち':`本体 ${s.states.GameMode?'ON':'OFF'} · 状態変化 ${s.changes?.GameMode||0}回`):s.error||'連動OFF（G HUBが必要）';}const label=s.active?(s.detected_c339?'C339を検出 · 監視中':s.connected?'機器を確認中':'G HUBに接続中'):'停止中';
 const states=['GameMode','LightButton'].map(code=>{const name=code==='GameMode'?'ゲームモード':'照明';const v=s.states?.[code];return `${name}: ${v===true?'ON':v===false?'OFF':'未取得'} / 変化 ${s.changes?.[code]||0}回 / 通知 ${s.messages?.[code]||0}件`});
 $('ghubStateStatus').textContent=[label,...states,s.error].filter(Boolean).join(' · ');
 $('ghubStateStart').disabled=ghubBusy||!!s.active;$('ghubStateStop').disabled=ghubBusy||!s.active;
 if(!s.active&&ghubTimer){clearInterval(ghubTimer);ghubTimer=null;}
}
let gameSyncPollBusy=false;
async function pollGameSync(){if(!$('gameSyncToggle').checked||gameSyncPollBusy||gameBusy)return;gameSyncPollBusy=true;try{const r=await(await apiFetch('/api/game_sync')).json();if(r.status)updateGhubState(r.status);if(r.game_mode&&!gameBusy&&JSON.stringify(r.game_mode)!==JSON.stringify(gameState)){gameState=r.game_mode;previewDirty=true;renderGame();if(activeView==='keyboard'||activeView==='lighting')paintFrame(performance.now()/1000)}}catch{}finally{gameSyncPollBusy=false}}
async function pollGhubState(){try{updateGhubState(await(await apiFetch('/api/ghub_state_status')).json())}catch{if(ghubTimer){clearInterval(ghubTimer);ghubTimer=null;}updateGhubState({active:false,error:'ローカルサーバーに接続できません'});}}
async function requestGhubState(action){
 if(ghubBusy)return;ghubBusy=true;try{if(action==='start'&&!isHook){await toggleHook(true);if(!isHook)return;}const r=await post('/api/ghub_state',{action});ghubBusy=false;if(r.status)updateGhubState(r.status);if(action==='start'&&r.ok&&r.status?.active){clearInterval(ghubTimer);ghubTimer=setInterval(pollGhubState,650);await pollFnHid();}else if(!r.ok)toast(r.error||'状態監視を開始できませんでした');}catch(e){toast(e.message)}finally{ghubBusy=false;await pollGhubState();}
}
let cellSession=null,cellBusy=false;
function cellControls(choices,verify){$('cellChoices').hidden=!choices;$('cellVerify').hidden=!verify;for(const id of ['cellCyan','cellPurple','cellUnknown','cellConfirmCyan','cellConfirmPurple','cellStart','cellCancel'])$(id).disabled=cellBusy;}
async function cellPattern(){const p=cellSession;if(!p)return;cellBusy=true;cellControls(false,false);try{if(!await bitmapProbe('bit',p.bits.length))throw Error('ビットマップ送信に失敗しました');$('cellProgress').textContent=`パターン ${p.bits.length+1}/7：実物の対象キーの色を選択してください。`;cellBusy=false;cellControls(true,false);}catch(e){$('cellProgress').textContent=e.message;cellSession=null;cellBusy=false;cellControls(false,false);}}
async function cellAnswer(bit){const p=cellSession;if(!p||cellBusy)return;p.bits.push(bit);if(p.bits.length<7)return cellPattern();const n=p.bits.reduce((a,b,i)=>a+(b<<i),0);if(n>125){$('cellProgress').textContent='有効なセル番号を特定できませんでした。';cellSession=null;cellControls(false,false);return;}p.cell=n;cellBusy=true;cellControls(false,false);const ok=await bitmapProbe('cell',n);cellBusy=false;if(!ok){$('cellProgress').textContent='セルの確認に失敗しました。';cellSession=null;cellControls(false,false);return;}p.phase='cyan';$('cellProgress').textContent=`セル ${n}：対象キーだけ水色になった場合に確認してください。`;cellControls(false,true);$('cellConfirmPurple').disabled=true;}
async function setupExtendedDiagnostics(){
 $('ghubStateStart').onclick=()=>requestGhubState('start');$('ghubStateStop').onclick=()=>requestGhubState('stop');
 $('fnHidList').onclick=()=>fnRequest('list');$('fnHidStart').onclick=async()=>{const target=$('fnHidTarget').value,active=$('fnHidStart').dataset.active==='true';if(!active&&!$('fnHidDevice').value)return toast('専用HIDを選択してください');if(!confirm('LED送信を一時停止して学習します。対象ボタンだけを押してください。完了後は実機反映を再度ONにできます。'))return;if(isLive&&!await setLive(false))return;if(!isHook)await toggleHook(true);if(!isHook)return;const r=await fnRequest(active?'learn':'start',{index:Number($('fnHidDevice').value),target});if(r?.ok){clearInterval(fnPollTimer);fnPollTimer=setInterval(pollFnHid,300);await pollFnHid();await pollGhubState();}};
 $('fnHidSample').onclick=async()=>{await fnRequest('sample');await pollFnHid();};$('fnHidEnable').onclick=async()=>{if(!confirm('対象ボタンを押した時だけ検出回数が増えることを確認しましたか？'))return;await fnRequest('enable');await pollFnHid();};$('fnHidStop').onclick=()=>fnRequest('stop');
 $('cellStart').onclick=async()=>{if(cellBusy||!hardware.bitmap_available)return;cellSession={target:$('cellTarget').value,bits:[],wasLive:isLive};await cellPattern();};$('cellCyan').onclick=()=>cellAnswer(1);$('cellPurple').onclick=()=>cellAnswer(0);$('cellUnknown').onclick=()=>{$('cellProgress').textContent='色が確認できないため特定を中止しました。個別制御に対応していない可能性があります。';cellSession=null;cellControls(false,false);};
 $('cellConfirmCyan').onclick=async()=>{const p=cellSession;if(!p||p.phase!=='cyan'||cellBusy)return;cellBusy=true;cellControls(false,true);const ok=await bitmapProbe('cell_magenta',p.cell);cellBusy=false;cellControls(false,ok);if(!ok){$('cellProgress').textContent='紫の送信に失敗しました。';cellSession=null;return;}p.phase='purple';$('cellConfirmCyan').disabled=true;$('cellProgress').textContent=`セル ${p.cell}：同じ対象キーだけ紫になったか確認してください。`;};
 $('cellConfirmPurple').onclick=async()=>{const p=cellSession;if(!p||p.phase!=='purple'||cellBusy)return;const mapping={...(hardware.bitmap_mapping||{})};if(Object.entries(mapping).some(([k,v])=>k!==p.target&&v===p.cell)){toast('このセルは別のキーに割り当て済みです。');return;}mapping[p.target]=p.cell;cellBusy=true;cellControls(false,true);try{const r=await post('/api/bitmap_config',{mapping,enabled:false});hardware=r.hardware;updateConnectionUI();updateDiag();if(!r.ok)throw Error('保存できませんでした');$('cellProgress').textContent=`${p.target} → セル ${p.cell} を保存しました。通常キーの全対応付けが完了するまでビットマップ制御は有効にしません。`;cellSession=null;}catch(e){$('cellProgress').textContent=e.message;}finally{cellBusy=false;cellControls(false,false);}};
 $('cellCancel').onclick=async()=>{if(cellBusy)return;const resume=cellSession?.wasLive;cellSession=null;cellControls(false,false);if(resume)await setLive(true);$('cellProgress').textContent=resume&&isLive?'診断を終了し、実機反映を再開しました。':'診断を終了しました。必要に応じて実機反映を再開してください。';};
}


let previewMode='normal',previewGesture=null,skipPreviewClick=false;
function updateTargetOutlines(){if(!keyboardKeys.length)return;const target=new Set(currentLayer()?.targets||[]);for(const k of keyboardKeys)k.el.classList.toggle('target-highlight',previewMode==='target'&&target.has(k.code));}
function updatePreviewTools(){const l=currentLayer();if(!l)return;const center=['spring','flower','circle','orbit'].includes(l.type),angle=['aurora','silk','tide','ember','comet','orbit','scanner','rain','spring','flower'].includes(l.type)||(['static','prism'].includes(l.type)&&l.gradient?.length>1&&l.gradientMode!=='radial');const allowed={normal:true,lasso:true,target:true,origin:center,angle};if(!allowed[previewMode])previewMode='normal';for(const b of document.querySelectorAll('[data-preview-mode]')){b.disabled=!allowed[b.dataset.previewMode];b.setAttribute('aria-pressed',String(previewMode===b.dataset.previewMode));b.title=b.disabled?'このエフェクトには対応する設定がありません':'';}const guide=$('motionGuide');guide.hidden=!['origin','angle'].includes(previewMode);$('keyboardFrame').classList.toggle('direct-edit',previewMode!=='normal');$('previewModeHint').textContent=({normal:'キーをクリックして試写',lasso:'ドラッグで囲む · Shiftで追加 / Altで除外',target:l.targets?.length?'ドラッグで対象キーを追加・解除':'全キー適用中：ドラッグで対象を指定',origin:'ドラッグして中心位置を設定',angle:'中心からドラッグして方向を設定'})[previewMode];if(!guide.hidden){const g=$('keyboard'),b=$('keyboardFrame');guide.style.left=g.offsetLeft+'px';guide.style.top=g.offsetTop+'px';guide.style.width=g.offsetWidth+'px';guide.style.height=g.offsetHeight+'px';const isOrigin=previewMode==='origin';const [x0,x1,y0,y1]=bounds();const x=isOrigin?x0+(x1-x0)*(l.originX??50)/100:(x0+x1)/2,y=isOrigin?y0+(y1-y0)*(l.originY??50)/100:(y0+y1)/2;guide.style.setProperty('--guide-x',`${x/18.45*100}%`);guide.style.setProperty('--guide-y',`${(y-.8)/6.38*100}%`);const a=['static','prism'].includes(l.type)?(l.gradientAngle??0):(l.angle??0)+(l.type==='rain'?90:0);guide.style.setProperty('--guide-angle',`${a}deg`);guide.classList.toggle('direction-guide',!isOrigin);}updateTargetOutlines();}
// Freehand selection is evaluated in normalized board coordinates, independent
// of the animated workspace scale. It never sends synthetic key presses.
let lassoGesture=null;
function pointInLasso(x,y,points){let inside=false;for(let i=0,j=points.length-1;i<points.length;j=i++){const a=points[i],b=points[j];if((a.y>y)!==(b.y>y)&&x<(b.x-a.x)*(y-a.y)/(b.y-a.y)+a.x)inside=!inside}return inside;}
function cancelLasso(){const g=lassoGesture;if(!g)return;lassoGesture=null;g.svg.remove();for(const k of g.keys)k.el.classList.remove('lasso-candidate');if(g.board.hasPointerCapture(g.pointer))g.board.releasePointerCapture(g.pointer);}
function setupLasso(){const board=$('keyboardFrame');const point=(e,r)=>({x:(e.clientX-r.left)/r.width*1000,y:(e.clientY-r.top)/r.height*1000});
 const candidates=g=>g.centers.filter(c=>pointInLasso(c.x,c.y,g.points)).map(c=>c.code);
 const draw=g=>{g.raf=0;if(lassoGesture!==g)return;g.path.setAttribute('d',g.points.map((p,i)=>(i?'L':'M')+p.x.toFixed(1)+' '+p.y.toFixed(1)).join(' ')+' Z');const hit=new Set(candidates(g));for(const k of g.keys)k.el.classList.toggle('lasso-candidate',hit.has(k.code));};
 board.addEventListener('pointerdown',e=>{if(previewMode!=='lasso'||e.button!==0||!e.isPrimary)return;e.preventDefault();e.stopImmediatePropagation();cancelLasso();const r=board.getBoundingClientRect();if(!r.width||!r.height)return;const ns='http://www.w3.org/2000/svg',svg=document.createElementNS(ns,'svg'),path=document.createElementNS(ns,'path');svg.classList.add('lasso-overlay');svg.setAttribute('viewBox','0 0 1000 1000');svg.setAttribute('preserveAspectRatio','none');svg.setAttribute('aria-hidden','true');path.setAttribute('vector-effect','non-scaling-stroke');svg.append(path);board.append(svg);const keys=keyboardKeys.slice(),centers=keys.map(k=>{const b=k.el.getBoundingClientRect();return {code:k.code,x:(b.left+b.width/2-r.left)/r.width*1000,y:(b.top+b.height/2-r.top)/r.height*1000}});lassoGesture={board,svg,path,keys,centers,pointer:e.pointerId,points:[point(e,r)],initial:[...state.selectedKeys],mode:e.altKey?'subtract':e.shiftKey||e.ctrlKey?'add':'replace',raf:0};board.setPointerCapture(e.pointerId);},true);
 board.addEventListener('pointermove',e=>{const g=lassoGesture;if(!g||g.pointer!==e.pointerId)return;const p=point(e,board.getBoundingClientRect()),last=g.points.at(-1);if(Math.hypot(p.x-last.x,p.y-last.y)<3)return;if(g.points.length>=512)g.points=g.points.filter((_,i)=>i%2===0);g.points.push(p);if(!g.raf)g.raf=requestAnimationFrame(()=>draw(g));});
 board.addEventListener('pointerup',e=>{const g=lassoGesture;if(!g||g.pointer!==e.pointerId)return;g.points.push(point(e,board.getBoundingClientRect()));const hit=candidates(g),set=new Set(g.mode==='replace'?[]:g.initial);for(const code of hit)g.mode==='subtract'?set.delete(code):set.add(code);cancelLasso();state.selectedKeys=[...set];document.querySelectorAll('[data-group]').forEach(b=>b.classList.remove('active'));updateSelection();});
 for(const event of ['pointercancel','lostpointercapture'])board.addEventListener(event,()=>cancelLasso());
 board.addEventListener('click',e=>{if(previewMode==='lasso'){e.preventDefault();e.stopImmediatePropagation()}},true);
 window.addEventListener('blur',cancelLasso);document.addEventListener('keydown',e=>{if(e.key==='Escape'&&lassoGesture){e.preventDefault();e.stopImmediatePropagation();cancelLasso()}},true);
}
function setupWorkspaceTools(){setupLasso();for(const [id,action] of Object.entries({layerUpQuick:'up',layerDownQuick:'down',layerDuplicateQuick:'duplicate',layerRemoveQuick:'remove'}))$(id).onclick=()=>layerAction(currentLayer().id,action);const board=$('keyboardFrame'),grille=$('keyboard');$('showLayersBtn').onclick=()=>setInspector(false);document.querySelectorAll('[data-preview-mode]').forEach(b=>b.onclick=()=>{cancelLasso();previewMode=b.dataset.previewMode;updatePreviewTools()});
 function change(e){const g=previewGesture;if(!g)return;const l=currentLayer();if(!l||l.id!==g.id)return;const r=grille.getBoundingClientRect(),[x0,x1,y0,y1]=bounds();if(previewMode==='target'){const el=document.elementFromPoint(e.clientX,e.clientY)?.closest('[data-code]');if(!el||!board.contains(el)||g.seen.has(el.dataset.code))return;const code=el.dataset.code;if(!keyboardKeys.some(k=>k.code===code))return;g.seen.add(code);const targets=new Set(l.targets||[]);if(g.erase){if(targets.size===1&&targets.has(code)){toast('最後の対象キーは解除できません。全体適用でリセットできます');return}targets.delete(code)}else targets.add(code);l.targets=[...targets];$('targetLabel').textContent=l.targets.length?l.targets.length+'キー':'すべて';}else if(previewMode==='origin'){const x=(e.clientX-r.left)/r.width*18.45,y=(e.clientY-r.top)/r.height*6.38+.8;l.originX=Math.round(Math.max(0,Math.min(100,(x-x0)/(x1-x0)*100)));l.originY=Math.round(Math.max(0,Math.min(100,(y-y0)/(y1-y0)*100)));renderShapeControls(l);}else if(previewMode==='angle'){const cx=r.left+(x0+x1)/2/18.45*r.width,cy=r.top+((y0+y1)/2-.8)/6.38*r.height;if(Math.hypot(e.clientX-cx,e.clientY-cy)<5)return;const raw=Math.atan2(e.clientY-cy,e.clientX-cx)*180/Math.PI-(l.type==='rain'?90:0);const angle=Math.round(((raw+540)%360)-180);const prop=['static','prism'].includes(l.type)?'gradientAngle':'angle';l[prop]=angle;$(prop).value=angle;$(prop+'Value').textContent=angle+'°';}updatePreviewTools();scheduleScene();if(!state.running)paintFrame(performance.now()/1000);}
 board.addEventListener('pointerdown',e=>{if(['normal','lasso'].includes(previewMode)||e.button!==0)return;const code=e.target.closest('[data-code]')?.dataset.code;if(previewMode==='target'&&!code)return;e.preventDefault();e.stopPropagation();const l=currentLayer();previewGesture={id:l.id,seen:new Set(),erase:!!l.targets?.includes(code),pointer:e.pointerId};skipPreviewClick=true;board.setPointerCapture(e.pointerId);change(e)},true);
 board.addEventListener('pointermove',e=>{if(previewGesture?.pointer===e.pointerId)change(e)});const finish=e=>{if(!previewGesture||e.pointerId!==previewGesture.pointer)return;previewGesture=null;refreshLayers();renderInspector();remember();setTimeout(()=>skipPreviewClick=false,0)};board.addEventListener('pointerup',finish);board.addEventListener('pointercancel',finish);board.addEventListener('lostpointercapture',finish);board.addEventListener('click',e=>{if(skipPreviewClick||!['normal','lasso'].includes(previewMode)){e.preventDefault();e.stopImmediatePropagation()}},true);
 // Numeric entry through the existing input handlers so history and hardware settings agree.
 document.querySelectorAll('.inspector input[type=range]').forEach(input=>{const out=$(input.id+'Value');if(!out)return;out.tabIndex=0;out.setAttribute('role','button');out.title='クリックして数値を入力';out.setAttribute('aria-label',(document.querySelector(`label[for="${input.id}"]`)?.textContent||input.id)+'の数値を入力');const edit=()=>{if(out.querySelector('input'))return;const old=input.value,field=document.createElement('input');field.type='number';field.className='inline-number';field.min=input.min;field.max=input.max;field.step=input.step;field.value=old;out.replaceChildren(field);field.focus();field.select();let done=false;const finish=(apply)=>{if(done)return;done=true;const n=field.valueAsNumber;if(apply&&Number.isFinite(n)){input.value=String(Math.max(Number(input.min),Math.min(Number(input.max),n)));input.dispatchEvent(new Event('input',{bubbles:true}));input.dispatchEvent(new Event('change',{bubbles:true}));}else renderInspector();if(out.contains(field))out.textContent=input.value;};field.onblur=()=>finish(true);field.onkeydown=e=>{if(e.key==='Enter'||e.key==='Escape'){e.preventDefault();e.stopPropagation();finish(e.key==='Enter');out.focus()}}};out.addEventListener('click',e=>{if(e.target===out)edit()});out.addEventListener('keydown',e=>{if(e.target===out&&['Enter',' '].includes(e.key)){e.preventDefault();edit()}});});
}

function setupEvents(){
 setupWorkspaceTools();
 document.addEventListener('keydown',e=>{if(e.defaultPrevented||e.target.closest('input,textarea,select,[contenteditable=true]')||activeView!=='lighting'||!$('modalBackdrop').hidden)return;if(e.ctrlKey&&e.key.toLowerCase()==='d'){e.preventDefault();layerAction(currentLayer().id,'duplicate')}else if(e.ctrlKey&&e.key.toLowerCase()==='n'){e.preventDefault();setPickerOpen(true)}else if(e.key==='Delete'&&e.target.closest('.layer-item')){e.preventDefault();layerAction(currentLayer().id,'remove')}});
 bindBarControls();bindShapeControls();bindPresetMenu();setUiMotion(uiMotion);$('uiMotionToggle').onchange=e=>setUiMotion(e.target.checked);$('lightMotionProfile').value=motionProfile;$('lightMotionProfile').onchange=e=>{motionProfile=e.target.value;try{localStorage.setItem('lume-light-motion',motionProfile)}catch{}savePreferences({motion_profile:motionProfile}).catch(e=>toast('設定保存: '+e.message));previewDirty=true;scheduleScene()};setProfileView(profileView);document.querySelectorAll('[data-profile-view]').forEach(b=>b.onclick=()=>setProfileView(b.dataset.profileView));$('profileSearch').oninput=()=>{clearTimeout(profileSearchTimer);profileSearchTimer=setTimeout(renderProfiles,120)};$('profileFilter').onchange=renderProfiles;$('audioQuickBtn').onclick=toggleAudio;$('audioQuickDemo').onclick=testAudio;$('audioQuickSettings').onclick=()=>setInspectorTab('advanced',{animate:true});$('applySelectionQuick').onclick=()=>{if(!state.selectedKeys.length)return toast('対象キーを選択してください');currentLayer().targets=[...state.selectedKeys];refreshLayers();renderInspector();remember();toast('対象キーを更新しました')};$('resetTargetQuick').onclick=()=>{currentLayer().targets=[];refreshLayers();renderInspector();remember()};
 setupSpecialWizard();setupExtendedDiagnostics();
 setInspector(matchMedia('(min-width:1120px)').matches);setGroups(false);setCanvasMenu(false);$('effectPicker').inert=true;new ResizeObserver(()=>{if(fitPreview())updatePreviewTools()}).observe(document.querySelector('.keyboard-stage'));compactEditor.addEventListener('change',()=>{stopWorkspaceMotion();syncWorkspaceInert();fitPreview();updatePreviewTools()});matchMedia('(prefers-reduced-motion: reduce)').addEventListener('change',e=>{if(e.matches){stopWorkspaceMotion();cancelInspectorAnimations();fitPreview()}});
 $('effectSearch').oninput=refreshCatalog;$('effectCategory').onchange=refreshCatalog;$('canvasMore').onclick=()=>setCanvasMenu(!$('canvasMenu').classList.contains('open'));$('canvasMenu').appendChild($('resetBtn'));$('canvasMenu').addEventListener('click',e=>{if(e.target.closest('button'))setCanvasMenu(false)});$('fnPreview').onclick=()=>triggerPulse('Fn');$('soloReset').onclick=()=>{soloLayerId=null;refreshLayers();scheduleScene()};$('layerMenu').addEventListener('click',e=>{const b=e.target.closest('[data-layer-action]');if(b&&!b.disabled)layerAction(layerMenuId,b.dataset.layerAction)});document.querySelectorAll('[data-inspector-tab]').forEach(b=>b.onclick=()=>setInspectorTab(b.dataset.inspectorTab,{animate:true}));$('enableInputDiag').onclick=async()=>{await toggleHook(true);savePreferences({hook:isHook}).catch(()=>{});await refreshStatus()};$('bracketTest').onclick=async()=>{const m=(hardware.led_map||[]).find(x=>x.code==='Backslash');if(!m){toast('］のSDK候補が見つかりません');return}await ledTest(m.index,'#00ffff');$('bracketTestResult').textContent='選択した方式で送信。］が光ったか、別のキーが光ったかを確認してください。'};
 $('inspectorToggle').onclick=()=>setInspector(!document.querySelector('.inspector').classList.contains('revealed'));$('closeInspector').onclick=()=>{setInspector(false);$('inspectorToggle').focus()};$('groupsToggle').onclick=()=>setGroups(!$('groupsMenu').classList.contains('revealed'));$('lassoMenuBtn').onclick=()=>{setGroups(false);previewMode='lasso';updatePreviewTools()};$('groupsMenu').addEventListener('click',e=>{if(e.target.closest('[data-group]'))setGroups(false)});
 document.addEventListener('pointerdown',e=>{if(layerMenuId!=null&&!e.target.closest('#layerMenu,.layer-more'))closeLayerMenu();if(!e.target.closest('#canvasMenu,#canvasMore'))setCanvasMenu(false);if(pickerOpen&&!e.target.closest('#effectPicker,#newLayerBtn'))setPickerOpen(false);if($('groupsMenu').classList.contains('revealed')&&!e.target.closest('#groupsMenu,#groupsToggle'))setGroups(false)});
 $('bitmapBit').innerHTML=Array.from({length:7},(_,i)=>`<option value="${i}">パターン ${i+1} / 7（重み ${2**i}）</option>`).join('');
 async function coverageTest(color){await setLive(false);try{const r=await post('/api/coverage_test',{color});hardware=r.hardware;updateConnectionUI();updateDiag();toast(r.ok?'全方式で送信しました。実物を確認してください':hardware.error||'送信に失敗しました')}catch(e){toast(e.message)}}
 $('coverageCyan').onclick=()=>coverageTest('#00ffff');$('coverageOff').onclick=()=>coverageTest('#000000');
 $('bitmapAll').onclick=()=>bitmapProbe('all');$('bitmapOff').onclick=()=>bitmapProbe('off');$('bitmapBitTest').onclick=()=>bitmapProbe('bit',Number($('bitmapBit').value));$('bitmapCellTest').onclick=()=>bitmapProbe('cell',Number($('bitmapCell').value));
 $('fnLedTest').onclick=()=>{const m=(hardware.led_map||[]).find(x=>x.code==='Fn');if(m)ledTest(m.index,'#00ffff');else toast('Fnの候補がありません')};
 $('bitmapAssign').onclick=()=>{const key=$('bitmapKey').value,cell=Number($('bitmapCell').value);if(!key||!Number.isInteger(cell)||cell<0||cell>125){toast('キーと0〜125のセルを指定してください');return}if(!confirm('実機の該当キーが個別に点灯したことを確認しましたか？'))return;const mapping={...(hardware.bitmap_mapping||{})};if(Object.entries(mapping).some(([k,v])=>k!==key&&v===cell)){toast('このセルは別のキーに割り当て済みです');return}mapping[key]=cell;bitmapSave(mapping,false)};
 $('bitmapRemove').onclick=()=>{const mapping={...(hardware.bitmap_mapping||{})};delete mapping[$('bitmapKey').value];bitmapSave(mapping,false)};
 $('bitmapEnable').onclick=()=>{if(confirm('確認済みの全キー対応付けでビットマップ方式に切り替えますか？'))bitmapSave(hardware.bitmap_mapping||{},true)};
 $('bitmapDisable').onclick=()=>bitmapSave(hardware.bitmap_mapping||{},false);
 $('solidTest').onclick=()=>ledTest(null,'#404040');$('offTest').onclick=()=>ledTest(null,'#000000');$('individualTest').onclick=()=>{if($('ledIndex').value!=='')ledTest(Number($('ledIndex').value),'#00aaff')};$('ledIndex').onchange=()=>{$('ledCode').value=(hardware.led_map||[]).find(m=>String(m.index)===$('ledIndex').value)?.code||''};$('assignLed').onclick=async()=>{try{const r=await post('/api/led_map',{index:Number($('ledIndex').value),code:$('ledCode').value||null});hardware=r.hardware;updateDiag();toast(r.ok?'割り当てを更新しました（現在の接続）':'更新できませんでした')}catch(e){toast(e.message)}};
 $('jisTest').onclick=async()=>{await setLive(false);try{const r=await post('/api/jis_test',{});hardware=r.hardware;updateConnectionUI();updateDiag();toast(r.ok?'JISテスト送信：ろ=赤、かな=緑、￥=青、変換=紫、無変換=黄。実機を確認してください。':hardware.error||'JISテスト失敗')}catch(e){toast(e.message)}};
 $('exportDiag').onclick=async()=>{let diag;try{const r=await apiFetch('/api/diagnostic');if(!r.ok)throw Error('診断情報を取得できません');const d=await r.json();if(!d.fn_hid||!d.hardware)throw Error('新版の診断APIが見つかりません。旧版を完全終了してください。');diag={layout:state.layout,hook:isHook,...d}}catch(e){toast(e.message);return}const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([JSON.stringify(diag,null,2)],{type:'application/json'}));a.download='LumePro-led-diagnostic.json';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),2000)};
 $('inputQuick').onclick=async()=>{await toggleHook(!isHook);savePreferences({hook:isHook}).catch(()=>{})};$('ledDiagnostics').addEventListener('toggle',()=>{if($('ledDiagnostics').open)updateDiag()});

 document.querySelectorAll('[data-view]').forEach(el=>el.addEventListener('click',()=>navigate(el.dataset.view)));
 $('connectTopBtn').addEventListener('click',()=>navigate('settings'));setupUpdate();$('deviceDetails').addEventListener('click',()=>navigate('settings'));
 $('pauseBtn').addEventListener('click',togglePlayback);
 $('resetBtn').addEventListener('click',()=>{if(confirm('編集中のライティングを初期状態に戻しますか？')){state=BASE();editingPreset=null;$('currentProfileName').textContent='新規プロファイル';renderKeyboards();refreshAll();remember();toast('初期状態に戻しました')}});
 $('transitionDuration').value=String(transitionMs);$('transitionDuration').onchange=()=>{transitionMs=Number($('transitionDuration').value);try{localStorage.setItem('lume-transition-ms',String(transitionMs))}catch{}}; $('saveProfileBtn').addEventListener('click',()=>{if(editingPreset){$('presetName').value=editingPreset;saveProfile()}else showModal()});$('renamePresetBtn').onclick=showModal;$('saveProfileBtn2').addEventListener('click',showModal);
 $('exportProfileBtn').addEventListener('click',()=>{
  const value={format:'lume-pro',version:2,name:$('currentProfileName').textContent,state:presetState()};
  const blob=new Blob([JSON.stringify(value,null,2)],{type:'application/json;charset=utf-8'}),url=URL.createObjectURL(blob);
  const a=document.createElement('a');a.href=url;a.download='LumePro-'+new Date().toISOString().slice(0,10)+'.json';document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),6000);toast('設定を書き出しました');
 });
 $('importProfileBtn').addEventListener('click',()=>$('importProfileInput').click());
 $('importProfileInput').addEventListener('change',async e=>{
  const file=e.target.files?.[0];e.target.value='';if(!file)return;
  if(file.size>128000){toast('ファイルが大きすぎます（上限128KB）');return}
  try{
   const obj=JSON.parse(await file.text()),v=obj.state;
   if(obj.format!=='lume-pro'||!v||!['jis','ansi'].includes(v.layout)||!Array.isArray(v.layers)||v.layers.length<1||v.layers.length>8||!v.layers.every(l=>l&&Object.hasOwn(EFFECTS,l.type)&&/^#[0-9a-f]{6}$/i.test(l.color)&&['brightness','speed','spread','fade'].every(k=>Number.isFinite(l[k])&&l[k]>=0&&l[k]<=100)))throw Error('LUME / PROの設定ファイルではありません');
   const imported={...v,layers:v.layers.map((l,i)=>({...l,id:i+1})),selectedLayer:1};if(!validEditor(imported))throw Error('設定値が不正です');state={...BASE(),...imported,selectedKeys:[],running:true,volume:0};
   editingPreset=null;$('currentProfileName').textContent=typeof obj.name==='string'?obj.name.slice(0,60):'読み込んだ設定';setLayout(state.layout);refreshAll();remember();navigate('lighting');toast('設定を読み込みました');
  }catch(error){toast('読み込み失敗: '+error.message)}
 });
 $('modalClose').addEventListener('click',hideModal);$('modalCancel').addEventListener('click',hideModal);
 $('modalBackdrop').addEventListener('click',e=>{if(e.target===$('modalBackdrop'))hideModal()});
 $('presetName').addEventListener('keydown',e=>{if(e.key==='Enter')saveProfile()});$('modalSave').addEventListener('click',saveProfile);
 $('newLayerBtn').addEventListener('click',()=>setPickerOpen(!pickerOpen)); $('closePickerBtn').addEventListener('click',()=>setPickerOpen(false));
 document.querySelector('.active-layer').addEventListener('click',()=>setPickerOpen(true,'change'));
 document.querySelectorAll('.accordion-trigger').forEach(btn=>btn.addEventListener('click',()=>{const p=btn.closest('.accordion');const open=!p.classList.contains('open');setAccordionOpen(p,open)}));
 $('undoBtn').addEventListener('click',undo);$('redoBtn').addEventListener('click',redo);
 $('blendMode').addEventListener('change',e=>{currentLayer().blend=e.target.value;remember()});
 $('selectAllBtn').addEventListener('click',()=>{state.selectedKeys=[...keyLookup.keys()];updateSelection()});
 $('clearSelectionCanvas').addEventListener('click',()=>{state.selectedKeys=[];updateSelection()});
 $('fitBtn').addEventListener('click',()=>{renderKeyboards();toast('キーボード表示を更新しました')});
 document.querySelectorAll('[data-group]').forEach(btn=>btn.addEventListener('click',()=>{const group=btn.dataset.group;const items=[...keyLookup.keys()];state.selectedKeys=items.filter(code=>group==='all'||(group==='wasd'&&['KeyW','KeyA','KeyS','KeyD'].includes(code))||(group==='arrows'&&code.startsWith('Arrow'))||(group==='f'&&/^F([1-9]|1[0-2])$/.test(code))||(group==='number'&&code.startsWith('Digit'))||(group==='letters'&&code.startsWith('Key')));document.querySelectorAll('[data-group]').forEach(b=>b.classList.toggle('active',b===btn));updateSelection();toast(state.selectedKeys.length+' キーを選択しました')}));
 $('restrictLayerBtn').addEventListener('click',()=>{if(!state.selectedKeys.length){toast('キーボードでキーを選択してから操作してください');return}currentLayer().targets=[...state.selectedKeys];renderInspector();refreshLayers();remember();toast('選択したキーにレイヤーを限定しました')});
 $('allKeysBtn').addEventListener('click',()=>{currentLayer().targets=[];renderInspector();refreshLayers();remember();toast('すべてのキーに適用します')});
 for(const id of ['brightness','speed','spread','fade']){$(id).addEventListener('input',e=>{currentLayer()[id]=Number(e.target.value);$(id+'Value').textContent=e.target.value+'%';$('brightnessValueTop').textContent=currentLayer().brightness+'%';scheduleScene();persistState()})}
 for(const id of ['brightness','speed','spread','fade'])$(id).addEventListener('change',()=>{remember();refreshLayers()});
 for(const id of Object.keys(MOTION_DEFAULTS)){ $(id).oninput=()=>{const v=Number($(id).value);currentLayer()[id]=v;$(id+'Value').textContent=id==='angle'?v+'°':id==='duration'?(v/10).toFixed(1)+' s':v+'%';updatePreviewTools();persistState()};$(id).onchange=()=>remember();}
 $('gradientCount').onchange=()=>{const l=currentLayer(),n=Number($('gradientCount').value);const old=l.gradient||[];l.gradient=n===1?[]:Array.from({length:n},(_,i)=>old[i]||[l.color,'#75B8F8','#B79BFF','#FB91CD'][i]);renderGradient();remember()};$('gradientMode').onchange=()=>{currentLayer().gradientMode=$('gradientMode').value;renderGradient();remember()};$('gradientAngle').oninput=()=>{currentLayer().gradientAngle=Number($('gradientAngle').value);$('gradientAngleValue').textContent=$('gradientAngle').value+'°';updatePreviewTools();persistState()};$('gradientAngle').onchange=remember;$('waveGain').oninput=()=>{currentLayer().waveGain=Number($('waveGain').value);$('waveGainValue').textContent=$('waveGain').value+'%';persistState()};$('waveGain').onchange=remember;$('waveMirror').onchange=()=>{currentLayer().waveMirror=$('waveMirror').checked;remember()};for(const id of ['waveMix','waveTrail','waveBeat']){$(id).oninput=()=>{currentLayer()[id]=Number($(id).value);$(id+'Value').textContent=$(id).value+'%';syncRangeFill($(id));persistState()};$(id).onchange=remember;}$('waveIdle').onchange=()=>{currentLayer().waveIdle=$('waveIdle').checked;remember()};
 $('signatureStyle').onchange=()=>{currentLayer().signatureStyle=$('signatureStyle').value;remember()};$('secondaryColor').oninput=()=>{currentLayer().secondary=$('secondaryColor').value;if(currentLayer().type==='signature_flow'&&currentLayer().gradient?.length>1){currentLayer().gradient[1]=$('secondaryColor').value;renderGradient()}persistState()};$('secondaryColor').onchange=()=>remember();
 $('colorInput').addEventListener('input',e=>setLayerColor(e.target.value,false));$('colorInput').addEventListener('change',e=>setLayerColor(e.target.value));$('hexInput').addEventListener('input',e=>{if(/^#[\da-f]{6}$/i.test(e.target.value))setLayerColor(e.target.value,false)});$('hexInput').addEventListener('change',e=>{if(/^#[\da-f]{6}$/i.test(e.target.value))setLayerColor(e.target.value);else{toast('HEXは #RRGGBB 形式で入力してください');e.target.value=currentLayer().color}});$('testLayerColor').onclick=testCurrentColor;$('reactivePriority').onchange=()=>{state.reactivePriority=$('reactivePriority').checked;remember();updateColorHint()};$('fixedColorMode').onchange=()=>{state.fixedColorMode=$('fixedColorMode').value;remember();updateColorHint()};
 $('randomPalette').addEventListener('click',()=>{selectedPalette=(selectedPalette+1)%3;const sets=[['#76F3E1','#75B8F8','#9C91FF','#FB91CD','#FF9D71','#F4D27D','#F3FCF9'],['#F58D94','#F8BC78','#F3E99C','#8CCC9C','#9AC7F7','#D3A6F5','#F8F8F5'],['#8BFFA3','#51EBC9','#6BC0FD','#A6A5FF','#D1C0FB','#FEAAF1','#FFFFFF']];COLORS.splice(0,COLORS.length,...sets[selectedPalette]);renderPalette()});
 document.querySelectorAll('.direction').forEach(b=>b.addEventListener('click',()=>{currentLayer().direction=b.dataset.direction;renderInspector();remember()}));
 $('layoutToggle').addEventListener('click',()=>setLayout(state.layout==='jis'?'ansi':'jis'));
 $('layoutSelect').addEventListener('change',e=>setLayout(e.target.value));
 $('demoTrigger').addEventListener('click',()=>{
 if(!state.running)togglePlayback();
 if(!state.layers.some(l=>REACTIVE.has(l.type)&&l.enabled)){toast('キー反応レイヤーを有効にしてください');return}
 if(!isLive)toast('プレビューのみ。実機反映をONにするとキーボードでもテストできます');
  const codes=['KeyG','KeyH','KeyJ','KeyK','KeyL'];let n=0;
  const timer=setInterval(()=>{triggerPulse(codes[n++]);if(n>=codes.length)clearInterval(timer)},130);
 });
 $('keyTabColor').onclick=()=>setKeyMode('color');$('keyTabGame').onclick=()=>setKeyMode('game');
 $('gameSyncToggle').onchange=async e=>{const on=e.target.checked;if(on&&!confirm('G HUBからC339のゲームモード状態の変化を受信した場合、Windows上の全キーボードに設定した入力遮断を適用します。初回状態では有効にしません。続けますか？')){e.target.checked=false;return}try{if(on&&!isHook){await toggleHook(true);if(!isHook)throw Error('入力検出を開始できません')}const r=await post('/api/game_sync',{enabled:on});if(!r.ok)throw Error(r.error||'監視を開始できません');updateGhubState(r.status);await refreshStatus()}catch(err){e.target.checked=false;toast(err.message)}};$('gameToggle').onclick=()=>changeGame({enabled:!gameState.enabled});$('gameDefault').onclick=()=>changeGame({blocked:['MetaLeft','MetaRight','ContextMenu']});$('gameClear').onclick=()=>changeGame({blocked:[]});
 $('gameLed').onchange=()=>changeGame({led:$('gameLed').value});$('gameDim').oninput=()=>{$('gameDimValue').textContent=$('gameDim').value+'%'};$('gameDim').onchange=()=>changeGame({dim:Number($('gameDim').value)});$('gameColor').onchange=()=>changeGame({color:$('gameColor').value});
 document.querySelectorAll('[data-key-select]').forEach(b=>b.onclick=()=>{const group=b.dataset.keySelect;state.selectedKeys=keyboardKeys.filter(k=>group==='all'||(group==='wasd'&&['KeyW','KeyA','KeyS','KeyD'].includes(k.code))||(group==='arrows'&&k.code.startsWith('Arrow'))||(group==='function'&&/^F[0-9]+$/.test(k.code))).map(k=>k.code);updateSelection()});
 const syncKeyHex=()=>{$('keyHexInput').value=$('keyColor').value.toUpperCase()};$('keyColor').addEventListener('input',syncKeyHex);$('keyColor').addEventListener('change',syncKeyHex);$('keyHexInput').addEventListener('input',()=>{const value=$('keyHexInput').value;if(/^#[0-9a-f]{6}$/i.test(value))$('keyColor').value=value});$('keyHexInput').addEventListener('change',syncKeyHex);$('pickKeyColor').onclick=()=>{const code=state.selectedKeys[0];if(!code)return toast('先にキーを選択してください');$('keyColor').value=state.keyColors[code]||paintFrame(performance.now()/1000,false)[code]||'#ffffff';syncKeyHex()};
 $('applyKeyColor').addEventListener('click',()=>{if(!state.selectedKeys.length){toast('先にキーを選択してください');return}state.selectedKeys.forEach(x=>state.keyColors[x]=$('keyColor').value);remember();toast(state.selectedKeys.length+' キーの色を設定しました')});
 $('clearKeyColor').addEventListener('click',()=>{state.selectedKeys.forEach(x=>delete state.keyColors[x]);remember();toast('個別設定を解除しました')});
 $('clearSelection').addEventListener('click',()=>{state.selectedKeys=[];updateSelection()});
 $('audioCaptureBtn').addEventListener('click',toggleAudio);$('audioScanBtn').onclick=scanAudio;$('audioDemoBtn').onclick=testAudio;
 $('sdkMethod').addEventListener('change',async()=>{await setLive(false);try{const r=await post('/api/sdk_method',{method:$('sdkMethod').value});hardware=r.hardware;updateConnectionUI();updateDiag();toast(r.ok?'送信方式を変更しました':'変更失敗')}catch(e){toast(e.message)}});$('detectBtn').addEventListener('click',detectDevices);$('selectDeviceBtn').addEventListener('click',chooseDevice);
 $('hookSettingsBtn').addEventListener('click',()=>{navigate('lighting');setInspector(true);setInspectorTab('advanced')});
 $('quitBtn').addEventListener('click',async()=>{const button=$('quitBtn');if(button.disabled||!confirm('LUME / PRO を終了しますか？'))return;button.disabled=true;try{clearTimeout(prefTimer);await savePreferences({editor:editorSnapshot(),live:isLive,hook:isHook});const result=await post('/api/shutdown',{});if(!result.ok)throw Error(result.error||'終了できませんでした');toast('終了処理中…');if(new URLSearchParams(location.search).get('desktop')==='1'&&typeof window.pywebview?.api?.close_after_shutdown==='function'){try{await window.pywebview.api.close_after_shutdown()}catch{/* authenticated native monitor closes the window independently */}}else{toast('終了しました。ブラウザーのタブを閉じてください。')}}catch(e){button.disabled=false;toast('終了できませんでした: '+e.message)}});
 $('liveToggle').addEventListener('change',async e=>{const on=e.target.checked;if(on&&!hardware.active){e.target.checked=false;toast('設定画面でキーボードに接続してください');navigate('settings');return}if(await setLive(on)){savePreferences({live:on}).catch(()=>{});toast(on?'実機への送信を開始しました':'実機への送信を停止しました')}});
 $('hookToggle').addEventListener('change',async e=>{await toggleHook(e.target.checked);savePreferences({hook:isHook}).catch(()=>{})});
 for(const [id,key] of [['trayToggle','tray'],['startupToggle','startup'],['recoveryToggle','recovery']]){const el=$(id);el.onchange=async()=>{try{const r=await post('/api/desktop',{[key]:el.checked});Object.assign(preferences,r.preferences);desktopResident=r.resident;el.checked=!!preferences[key];toast(key==='startup'?'自動起動設定を変更しました':'設定を保存しました（次回起動から適用）')}catch(e){el.checked=!!preferences[key];toast(e.message)}}}
 $('autoConnect').onchange=async()=>{await savePreferences({auto:$('autoConnect').checked});if(preferences.auto&&!hardware.active)await autoConnect()};
 for(const [id,code] of [['bracketMethod','Backslash'],['fnMethod','Fn']]){$(id).onchange=async()=>{const method=$(id).value;const resume=isLive;await setLive(false);try{const r=await post('/api/key_method',{code,method});hardware=r.hardware;updateConnectionUI();updateDiag();toast(r.ok?'特殊キーの送信方式を変更しました。個別点灯で確認できます。':'変更できませんでした');if(resume&&r.ok)await setLive(true)}catch(e){toast(e.message)}}}
 $('rippleStart').addEventListener('click',async()=>{if(!hardware.active){navigate('settings');toast('キーボードに接続してください');return}if(!isHook&&!confirm('他のアプリでもキー入力に反応するようにしますか？ 入力は保存しません。'))return;let ripple=currentLayer().type==='ripple'?currentLayer():state.layers.find(l=>l.type==='ripple'&&l.enabled)||state.layers.find(l=>l.type==='ripple');if(!ripple){if(state.layers.length>=8){toast('レイヤーが上限です。リップルを追加できません');return}ripple={...BASE().layers[0],id:Math.max(0,...state.layers.map(l=>l.id))+1,color:currentLayer().color,blend:'normal'};state.layers.unshift(ripple)}ripple.enabled=true;soloLayerId=null;state.selectedLayer=ripple.id;state.running=true;$('pauseBtn').innerHTML=uiIcon('pause')+'<span>停止</span>';refreshAll();remember();if(!isHook)await toggleHook(true);if(await setLive(true)){savePreferences({live:true,hook:isHook,editor:editorSnapshot()}).catch(()=>{});toast(isHook?'現在の色とレイヤーでリップルを開始しました':'リップル開始：入力反応は未接続です')}});
 window.addEventListener('pagehide',()=>{if(!secret)return;if(!initializing){clearTimeout(prefTimer);fetch('/api/preferences',{method:'POST',headers:{'Content-Type':'application/json','X-Lume-Token':secret},body:JSON.stringify({editor:editorSnapshot()}),keepalive:true}).catch(()=>{})}fetch('/api/editor_closed',{method:'POST',headers:{'Content-Type':'application/json','X-Lume-Token':secret},body:'{}',keepalive:true}).catch(()=>{})});
 document.addEventListener('keydown',e=>{
  if(e.key==='Escape'){if(!$('updateBackdrop').hidden){closeUpdate();return}if(layerMenuId!=null){closeLayerMenu(true);return}if($('canvasMenu').classList.contains('open')){setCanvasMenu(false);$('canvasMore').focus();return}if(!$('modalBackdrop').hidden){hideModal();return}if(pickerOpen){setPickerOpen(false);return}if($('groupsMenu').classList.contains('revealed')){setGroups(false);$('groupsToggle').focus();return}if(document.querySelector('.inspector').classList.contains('revealed')){setInspector(false);$('inspectorToggle').focus();return}if(state.selectedKeys.length){state.selectedKeys=[];updateSelection();return}}
  if(e.target.matches('input:not([type=range]):not([type=checkbox]),textarea,select')||e.target.isContentEditable)return;
  if((e.ctrlKey||e.metaKey)&&!e.repeat){if(e.key.toLowerCase()==='z'){e.preventDefault();if(e.shiftKey)redo();else undo();return}if(e.key.toLowerCase()==='y'){e.preventDefault();redo();return}if(e.key.toLowerCase()==='s'){e.preventDefault();$('saveProfileBtn').click();return}if(e.key.toLowerCase()==='a'){e.preventDefault();state.selectedKeys=[...keyLookup.keys()];updateSelection();return}}
  if(!e.repeat&&(!isHook||e.code==='Fn')&&keyLookup.has(inputCode(e.code)))triggerPulse(e.code);
  if(e.key==='Escape'&&!$('modalBackdrop').hidden)hideModal();
 });
}
function setLayout(v,record=true){state.layout=v;$('layoutToggle').innerHTML=v.toUpperCase()+'<span>'+uiIcon('chevron')+'</span>';$('layoutSelect').value=v;if(!keyboardKeys.length||$('keyboardFrame').dataset.layout!==v)renderKeyboards();else{previewDirty=true;updateSelection()}if(record)remember()}
// Startup and periodic checks are throttled by the server; downloads require explicit consent.
let updateStatus=null,updatePoll=null,updateOrigin=null,updateBusy=false,updateApplyWhenReady=false;
function showUpdate(){if(!$('updateBackdrop').hidden)return;updateOrigin=document.activeElement;$('updateBackdrop').hidden=false;$('updateBackdrop').querySelector('.update-dialog').focus({preventScroll:true})}
function closeUpdate(){if(updateStatus?.phase==='applying'||updateBusy)return;updateApplyWhenReady=false;$('updateBackdrop').hidden=true;updateOrigin?.focus({preventScroll:true})}
function renderReleaseNotes(notes){const root=$('updateNotes');if(root.dataset.source===notes)return;root.dataset.source=notes;root.replaceChildren();for(const raw of notes.split(/\r?\n/)){const line=raw.trim();if(!line)continue;const heading=/^#{1,6}\s+/.test(line);const item=document.createElement(heading?'h4':'div');item.className=heading?'update-note-heading':'update-note-item';const label=line.replace(/^#{1,6}\s+|^(?:[-*・•]\s*|\d+[.)]\s+)/,'').replace(/\*\*/g,'');const text=document.createElement('span');text.textContent=label;item.append(text);root.append(item)}if(!root.childNodes.length)root.textContent='更新内容は登録されていません。'}
function renderUpdate(s){if(!s||typeof s.current!=='string')return;updateStatus=s;const r=s.release;const phase=s.phase;const available=s.available;const busy=['checking','downloading','applying'].includes(phase);$('installedVersion').textContent='v'+s.current;$('autoUpdateCheck').checked=s.auto;$('updateDot').hidden=!available;$('updateCurrent').textContent='v'+s.current;$('updateNextWrap').hidden=!available;$('updateNext').textContent=r?'v'+r.version:'';$('updateNotesArea').hidden=!available;renderReleaseNotes(r?.notes||'');$('updateReleaseDate').textContent=r?.published&&Number.isFinite(Date.parse(r.published))?new Date(r.published).toLocaleDateString('ja-JP'):'';$('updateProgressWrap').hidden=!['downloading','ready','applying'].includes(phase);$('updateProgressLabel').textContent=phase==='ready'?'検証完了':phase==='applying'?'更新を適用中':'ダウンロード中';$('updateProgressWrap').querySelector('[role=progressbar]').setAttribute('aria-valuenow',String(s.progress||0));$('updateProgressBar').style.width=(s.progress||0)+'%';$('updateProgressText').textContent=(s.progress||0)+'%';$('checkUpdateBtn').disabled=phase==='checking'||phase==='applying';$('updateClose').disabled=phase==='applying';$('updateLater').disabled=phase==='applying';$('updateLater').textContent=available?'後で':'閉じる';let title='最新版です',msg='現在のバージョンが最新です。',action='';if(phase==='checking'){title='更新を確認しています';msg='GitHubに接続しています。'}else if(phase==='downloading'){title='更新ファイルを取得中';msg=s.frozen?'ダウンロード後にSHA-256と実行ファイルを検証します。':'ダウンロード後にSHA-256とZIPの内容を検証します。'}else if(phase==='ready'){title='更新の準備ができました';msg='設定を保存し、LUME / PROを再起動します。';action='再起動して更新'}else if(phase==='applying'){title='更新を適用しています';msg='設定を保持して再起動しています。この画面は自動で再接続します。'}else if(phase==='error'){title='更新を確認できませんでした';msg=s.error||'通信に失敗しました。';action=available&&r?.installable?'更新して再起動':'再確認'}else if(available){title='新しいバージョンがあります';msg=r.installable?'ボタンを押すとダウンロード・検証・再起動まで自動で進みます。':'配布ファイルまたはSHA-256が登録されていません。';action=r.installable?'更新して再起動':''}else if(!s.last_check){title='更新を確認';msg='まだオンラインで確認していません。';action='再確認'}if(s.last_install_error&&!busy)msg+=' 前回の更新エラー: '+s.last_install_error;$('updateTitle').textContent=title;$('updateMessage').textContent=msg;$('updateAction').hidden=!action;$('updateAction').textContent=action;$('updateSummary').textContent=available?'更新可能 · v'+r.version:phase==='checking'?'確認中…':phase==='error'?s.error:s.last_check?'最終確認 '+new Date(s.last_check*1000).toLocaleString('ja-JP'):(s.private?'非公開開発版 · GitHub認証が必要':'公開配布版 · GitHubログイン不要');const dialog=$('updateBackdrop').querySelector('.update-dialog');dialog.dataset.phase=phase;dialog.dataset.available=String(!!available);dialog.dataset.checked=String(!!s.last_check);dialog.classList.toggle('has-release',!!available);$('updateBackdrop').classList.toggle('update-working',busy)}
function scheduleUpdatePoll(mode='none',started=Date.now()){clearTimeout(updatePoll);if(!['checking','downloading'].includes(updateStatus?.phase))return;if(Date.now()-started>240000){$('updateMessage').textContent='更新処理が長引いています。設定から状態を再確認してください。';return;}updatePoll=setTimeout(async()=>{try{let s=await(await apiFetch('/api/update/status')).json();renderUpdate(s);if(s.phase==='ready'&&updateApplyWhenReady&&!$('updateBackdrop').hidden){await applyReadyUpdate();return}if(s.phase==='error')updateApplyWhenReady=false;if(mode==='auto')await maybeNotifyUpdate(s);else if(mode==='manual'&&!$('updateBackdrop').hidden&&s.available&&s.notify&&s.phase!=='checking')await acknowledgeUpdate(s);scheduleUpdatePoll(mode,started)}catch{if(!$('updateBackdrop').hidden)$('updateMessage').textContent='更新処理の状態を取得できません。再接続を試みています。';scheduleUpdatePoll(mode,started)}},650)}
async function reconnectAfterUpdate(expected,previous){
 const deadline=Date.now()+(updateStatus?.frozen?240000:60000);
 // A successful apply restarts the backend on the same port with a new token.
 while(Date.now()<deadline){
  await new Promise(r=>setTimeout(r,900));
  try{
   // Minimal public status is intentionally available across token changes.
   const res=await fetch('/api/update/status',{cache:'no-store',signal:AbortSignal.timeout(2500)});
   if(!res.ok)continue;const s=await res.json();
   if(s.current===expected){try{sessionStorage.setItem('lume-update-result','success')}catch{}location.reload();return}
   if(s.current===previous&&s.phase!=='applying'&&s.last_install_error){try{sessionStorage.setItem('lume-update-result','rollback')}catch{}location.reload();return}
  }catch{}
 }
 $('updateTitle').textContent='再起動を確認できませんでした';$('updateMessage').textContent='更新結果は未確認です。LUME / PROを開き直して設定のバージョンを確認してください。';
 renderUpdate({...updateStatus,phase:'error',error:'再起動の確認がタイムアウトしました。LUME / PROを開き直し、設定からバージョンを確認してください。'});$('updateTitle').textContent='再起動を確認できませんでした';$('updateAction').hidden=true;
}
async function acknowledgeUpdate(s){try{await post('/api/update/ack',{version:s.release.version})}catch{}}
async function maybeNotifyUpdate(s){if(!s.available||!s.notify||s.phase==='checking')return;if(!$('modalBackdrop').hidden){toast('新しいバージョンがあります。設定から確認できます。')}else{showUpdate()}await acknowledgeUpdate(s)}
async function checkUpdate(manual){if(updateBusy)return;if(!manual&&['checking','downloading','ready','applying'].includes(updateStatus?.phase))return;updateBusy=true;try{if(manual)showUpdate();let s=await post('/api/update/check',{manual});renderUpdate(s);if(!manual&&s.auto)await maybeNotifyUpdate(s);else if(manual&&s.available&&s.notify&&s.phase!=='checking')await acknowledgeUpdate(s);scheduleUpdatePoll(manual?'manual':s.auto?'auto':'none')}catch(e){if(manual){$('updateTitle').textContent='更新確認に失敗しました';$('updateMessage').textContent=e.message}}finally{updateBusy=false}}
async function applyReadyUpdate(){if(updateBusy||updateStatus?.phase!=='ready')return;updateBusy=true;updateApplyWhenReady=false;$('updateAction').disabled=true;$('updateClose').disabled=true;$('updateLater').disabled=true;try{clearTimeout(prefTimer);await savePreferences({editor:editorSnapshot(),live:isLive,hook:isHook});const expected=updateStatus.release.version,previous=updateStatus.current;const r=await post('/api/update/apply',{});if(!r.ok)throw Error(r.error||'更新を開始できませんでした');renderUpdate({...updateStatus,phase:'applying'});reconnectAfterUpdate(expected,previous)}catch(e){renderUpdate(updateStatus);toast(e.message)}finally{updateBusy=false;$('updateAction').disabled=false}}
function setupUpdate(){document.addEventListener('keydown',e=>{if($('updateBackdrop').hidden)return;if(e.key==='Escape'){e.preventDefault();closeUpdate()}else if(e.key==='Tab'){const els=[...$('updateBackdrop').querySelectorAll('button:not([disabled]),[tabindex="0"]')].filter(el=>!el.hidden&&el.offsetWidth>0);if(els.length){const i=els.indexOf(document.activeElement);if(i<0||(!e.shiftKey&&i===els.length-1)||(e.shiftKey&&i===0)){e.preventDefault();els[e.shiftKey?els.length-1:0].focus()}}}e.stopPropagation()},true);$('checkUpdateBtn').onclick=()=>checkUpdate(true);$('updateClose').onclick=closeUpdate;$('updateLater').onclick=closeUpdate;$('updateBackdrop').addEventListener('click',e=>{if(e.target===$('updateBackdrop'))closeUpdate()});$('autoUpdateCheck').onchange=async e=>{try{renderUpdate(await post('/api/update/configure',{auto:e.target.checked}))}catch(err){toast(err.message)}};$('updateAction').onclick=async()=>{if(updateBusy)return;if(!updateStatus?.available||(!updateStatus.release?.installable&&updateStatus.phase!=='ready')){checkUpdate(true);return}if(updateStatus.phase==='ready'){await applyReadyUpdate();return}updateBusy=true;updateApplyWhenReady=true;$('updateAction').disabled=true;try{renderUpdate(await post('/api/update/download',{}));scheduleUpdatePoll()}catch(e){updateApplyWhenReady=false;toast(e.message)}finally{updateBusy=false;$('updateAction').disabled=false}};apiFetch('/api/update/status').then(r=>r.json()).then(s=>{renderUpdate(s);let result='';try{result=sessionStorage.getItem('lume-update-result');sessionStorage.removeItem('lume-update-result')}catch{}if(result==='success'){toast('v'+s.current+' への更新が完了しました。')}else if(result==='rollback'){showUpdate();renderUpdate({...s,phase:'error',error:'更新に失敗したため旧バージョンに戻しました。'})}}).catch(()=>{})}
async function init(){
 document.addEventListener('input',event=>{const input=event.target;if(input.matches?.('.inspector input[type=range]'))syncRangeFill(input);});
 try{secret=(await (await fetch('/api/token',{headers:{'X-Lume-Bootstrap':'1'}})).json()).token}catch{toast('サーバーへの接続に失敗しました')}
 try{const p=(await(await apiFetch('/api/preferences')).json()).preferences;if(p){preferences={...preferences,...p};if(Object.hasOwn(MOTION_PROFILES,p.motion_profile))motionProfile=p.motion_profile;if(validEditor(p.editor)){state={...BASE(),...p.editor,running:true,selectedKeys:[],volume:0};if(!state.layers.some(l=>l.id===state.selectedLayer))state.selectedLayer=state.layers[0].id;if(p.editor.profileName)$('currentProfileName').textContent=p.editor.profileName;editingPreset=typeof p.editor.editingPreset==='string'?p.editor.editingPreset:null}}}catch{}
 $('autoConnect').checked=preferences.auto;$('backendSelect').value=preferences.backend;
 recordedSnapshot=serializeState();updateHistoryButtons();setupEvents();setLayout(state.layout);refreshAll();await refreshStatus();loadProfiles();prepareThumbMaterials();initializing=false;if(new URLSearchParams(location.search).get('desktop')==='1')post('/api/native_ready',{}).catch(()=>{});setTimeout(()=>checkUpdate(false),2200);setInterval(()=>checkUpdate(false),15*60*1000);requestAnimationFrame(animation);await autoConnect();if(preferences.auto&&hardware.active){if(preferences.hook&&!isHook)await toggleHook(true);if(preferences.live&&!isLive)await setLive(true)}setInterval(pollKeys,35);setInterval(pollAudio,25);setInterval(()=>{if(!document.hidden)refreshStatus()},4500);setInterval(()=>{if(!document.hidden)pollGameSync()},450);
}
init();
